import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_32_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_32_000.smt2":52:1-52:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_32_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_32_000.smt2":17:1-28:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_32_000.smt2":29:1-39:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_32_000.smt2":40:1-50:2 (clause 4, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (B = (0 : Int)) →
  (C = (1 : Int)) →
  (D = (0 : Int) ∨ D = (1 : Int)) →
  (A = D) →
  r1 A B C D) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := G = if A = B % (2 : Int) then D + C else (-1 : Int) + D;
  r1 B C D A → F = (-3 : Int) + C + B → a!1 → H = (1 : Int) + (-1 : Int) * A → E = (1 : Int) + B → r1 E F G H) ∧
  ((∀ (A B C D : Int),
  (r1 C A D B) →
  (¬C ≤ (10 : Int)) →
  (¬D ≥ (0 : Int)) →
  r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_32_000»
