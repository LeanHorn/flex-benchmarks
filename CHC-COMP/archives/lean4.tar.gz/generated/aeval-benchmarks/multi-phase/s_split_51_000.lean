import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_51_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_51_000.smt2":53:1-53:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_51_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_51_000.smt2":17:1-29:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_51_000.smt2":30:1-40:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_51_000.smt2":41:1-51:2 (clause 4, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Prop),
  (∀ (A B C : Int),
  (B = (3333 : Int)) →
  (C = (6666 : Int)) →
  (A = (0 : Int)) →
  r0 A B C) ∧
  ((∀ (A B C D E F : Int),
  (r0 A B C) →
  (E = if (3333 : Int) ≤ A then (1 : Int) + B else B) →
  (F = if B ≥ (6666 : Int) then (1 : Int) + C else C) →
  (D = (1 : Int) + A) →
  r0 D E F) ∧
  ((∀ (A B C : Int),
  (r0 C A B) →
  (C = (9999 : Int)) →
  (¬B = C) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_51_000»
