import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_15_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_15_000.smt2":51:1-51:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_15_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_15_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_15_000.smt2":28:1-38:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_15_000.smt2":39:1-49:2 (clause 4, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Prop),
  (∀ (A B C : Int),
  (B = (0 : Int)) →
  (C = (0 : Int)) →
  (A = (0 : Int)) →
  r0 A B C) ∧
  ((∀ (A B C D E F : Int),
  (r0 B A C) →
  (E = (1 : Int) + A) →
  (F = if (500 : Int) ≤ B then C else (2 : Int) + C) →
  (D = ((1 : Int) + B) % (1000 : Int)) →
  r0 D E F) ∧
  ((∀ (A B C : Int),
  (r0 A B C) →
  (¬B = C) →
  (A = (0 : Int)) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_15_000»
