import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_30_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_30_000.smt2":55:1-55:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_30_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_30_000.smt2":17:1-31:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_30_000.smt2":32:1-42:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_30_000.smt2":43:1-53:2 (clause 4, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (B = (97 : Int)) →
  (C = (-76 : Int)) →
  (D = (0 : Int)) →
  (A = (52 : Int)) →
  r1 A B C D) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := H = if G ≤ (0 : Int) then D else D + (-1 : Int) * C;
  r1 C A B D →
    F = (54 : Int) + (-2 : Int) * A →
      G = (-8754 : Int) + (-5 : Int) * C + (3 : Int) * A + (4 : Int) * B →
        a!1 → E = (13 : Int) + (-7 : Int) * C → r1 E F G H) ∧
  ((∀ (A B C D : Int),
  (r1 A C B D) →
  (D ≤ (0 : Int)) →
  (C ≥ (80914 : Int)) →
  r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_30_000»
