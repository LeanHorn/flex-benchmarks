import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_03_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_03_000.smt2":51:1-51:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_03_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_03_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_03_000.smt2":28:1-38:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_03_000.smt2":39:1-49:2 (clause 4, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (D = (0 : Int)) →
  (¬B ≤ C) →
  (A = (0 : Int)) →
  r1 A B C D) ∧
  ((∀ (A B C D E F : Int),
  (r1 A D E B) →
  (F = if E ≤ A then (-2 : Int) + B else (1 : Int) + B) →
  (C = (1 : Int) + A) →
  r1 C D E F) ∧
  ((∀ (A B C D : Int),
  (r1 A B C D) →
  (¬D ≤ (0 : Int)) →
  (¬A ≤ B + C) →
  r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_03_000»
