import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_48_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_48_000.smt2":55:1-55:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_48_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_48_000.smt2":17:1-31:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_48_000.smt2":32:1-42:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_48_000.smt2":43:1-53:2 (clause 4, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Prop),
  (∀ (A B : Int),
  (B = (0 : Int)) →
  (A = (0 : Int)) →
  r1 A B) ∧
  ((∀ (A B C D : Int),
  let a!1 :=
    D =
      if (5000 : Int) ≤ A then if A ≥ (6000 : Int) then (-1 : Int) + B else (-4 : Int) + B
      else if A ≥ (4000 : Int) then (4 : Int) + B else (1 : Int) + B;
  r1 A B → a!1 → C = (1 : Int) + A → r1 C D) ∧
  ((∀ (A B : Int),
  (r1 A B) →
  (¬B = (0 : Int)) →
  (A = (10000 : Int)) →
  r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_48_000»
