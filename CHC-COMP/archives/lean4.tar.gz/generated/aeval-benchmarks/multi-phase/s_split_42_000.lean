import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_42_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_42_000.smt2":53:1-53:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_42_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_42_000.smt2":17:1-29:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_42_000.smt2":30:1-40:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_42_000.smt2":41:1-51:2 (clause 4, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Prop),
  (∀ (A B C : Int),
  (B = C) →
  (C = (0 : Int)) →
  (A = (0 : Int)) →
  r0 A B C) ∧
  ((∀ (A B C D E F : Int),
  (r0 A B C) →
  (E = if A ≥ (1765 : Int) then (2 : Int) + B else (1 : Int) + B) →
  (F = if B ≥ (5765 : Int) then (3 : Int) + C else (2 : Int) + C) →
  (D = (1 : Int) + A) →
  r0 D E F) ∧
  ((∀ (A B C : Int),
  (r0 B A C) →
  (C ≤ (27650 : Int)) →
  (¬B ≤ (17650 : Int)) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_42_000»
