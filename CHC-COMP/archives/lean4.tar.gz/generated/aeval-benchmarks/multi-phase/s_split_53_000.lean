import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_53_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_53_000.smt2":54:1-54:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_53_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_53_000.smt2":17:1-30:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_53_000.smt2":31:1-41:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_53_000.smt2":42:1-52:2 (clause 4, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (B = (0 : Int)) →
  (C = (0 : Int)) →
  (D = (500 : Int)) →
  (A = (0 : Int)) →
  r1 A B C D) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 C A B D) →
  (F = (1 : Int) + A) →
  (G = if (500 : Int) ≤ C then (-1 : Int) + B else (1 : Int) + B) →
  (H = if C ≥ (500 : Int) then (1 : Int) + D else (-1 : Int) + D) →
  (E = ((1 : Int) + C) % (1000 : Int)) →
  r1 E F G H) ∧
  ((∀ (A B C D : Int),
  (r1 A B C D) →
  (¬C = D) →
  (B = (2250 : Int)) →
  r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_53_000»
