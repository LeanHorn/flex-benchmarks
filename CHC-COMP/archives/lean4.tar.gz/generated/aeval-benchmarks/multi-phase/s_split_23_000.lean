import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_23_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_23_000.smt2":53:1-53:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_23_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_23_000.smt2":17:1-29:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_23_000.smt2":30:1-40:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-benchmarks/multi-phase/s_split_23_000.smt2":41:1-51:2 (clause 4, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Prop),
  (∀ (A B : Int),
  (B = (100 : Int)) →
  (A = (1000 : Int)) →
  r1 A B) ∧
  ((∀ (A B C D : Int),
  let a!1 := D = if B ≤ A / (10 : Int) then (1 : Int) + B else (-1 : Int) + B;
  let a!2 := C = if B ≤ A / (10 : Int) then (-1 : Int) + A else (1 : Int) + A;
  r1 A B → a!1 → a!2 → r1 C D) ∧
  ((∀ (A B : Int),
  (r1 B A) →
  (B ≤ A) →
  r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«aeval-benchmarks».«multi-phase».«s_split_23_000»
