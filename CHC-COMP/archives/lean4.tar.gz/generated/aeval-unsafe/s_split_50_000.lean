import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«aeval-unsafe».«s_split_50_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-unsafe/s_split_50_000.smt2":42:1-42:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-unsafe/s_split_50_000.smt2":6:1-15:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-unsafe/s_split_50_000.smt2":16:1-29:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/aeval-unsafe/s_split_50_000.smt2":30:1-40:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (C = (0 : Int)) →
  (B = (0 : Int)) →
  (A = (0 : Int)) →
  (D = (0 : Int)) →
  r0 D C B A) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 F H G E) →
  (C = (1 : Int) + H) →
  (B = if (1000 : Int) ≤ F then G else (1 : Int) + G) →
  (A = if F ≥ (1000 : Int) then (1 : Int) + E else E) →
  (D = ((1 : Int) + F) % (2000 : Int)) →
  r0 D C B A) ∧
  (∀ (A B C D : Int),
  (r0 D C B A) →
  (C = (999000 : Int)) →
  ((1000 : Int) = B + (-1 : Int) * A) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«aeval-unsafe».«s_split_50_000»
