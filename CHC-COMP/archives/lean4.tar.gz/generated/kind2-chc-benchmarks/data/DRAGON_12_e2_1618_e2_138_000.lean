import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«kind2-chc-benchmarks».«data».«DRAGON_12_e2_1618_e2_138_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":602:1-602:12 (check-sat, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":17:1-26:2 (clause 1, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":27:1-155:2 (clause 2, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":156:1-165:2 (clause 3, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":166:1-175:2 (clause 4, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":176:1-185:2 (clause 5, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":186:1-200:2 (clause 6, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":201:1-366:2 (clause 7, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":367:1-379:2 (clause 8, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":380:1-473:2 (clause 9, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":474:1-483:2 (clause 10, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":484:1-531:2 (clause 11, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":532:1-578:2 (clause 12, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":579:1-589:2 (clause 13, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_12_e2_1618_e2_138_000.smt2":590:1-600:2 (clause 14, command 27)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop →
    Prop →
      Prop →
        Prop →
          Prop →
            Prop →
              Prop →
                Prop →
                  Prop →
                    Prop →
                      Prop →
                        Prop →
                          Int →
                            Prop →
                              Int →
                                Prop →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Prop →
                                                Prop →
                                                  Prop →
                                                    Int →
                                                      Prop → Int → Int → Int → Int → Int → Int → Prop → Prop → Prop → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Prop → Int → Int → Int → Int → Int → Int → Prop → Prop),
  ∃ (r3 : Int → Prop → Int → Int → Int → Int → Int → Int → Prop → Prop → Prop → Prop → Prop),
  ∃ (r4 : Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop),
  ∃ (r5 : Prop),
  ∃ (r6 : Prop →
    Prop →
      Prop →
        Prop →
          Prop →
            Prop →
              Prop →
                Prop →
                  Prop →
                    Prop →
                      Prop →
                        Prop →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Prop →
                                        Int →
                                          Int →
                                            Int → Int → Int → Int → Prop → Int → Int → Int → Int → Int → Int → Prop → Prop),
  ∃ (r7 : Prop → Prop → Prop → Prop → Prop → Prop → Prop),
  ∃ (r8 : Int → Int → Int → Prop → Int → Prop → Prop),
  ∃ (r9 : Int →
    Prop →
      Int →
        Int →
          Int →
            Int →
              Int → Int → Prop → Prop → Prop → Int → Prop → Int → Int → Int → Int → Int → Int → Prop → Prop → Prop → Prop),
  ∃ (r10 : Prop → Prop → Prop → Prop → Prop),
  ∃ (r11 : Int → Prop → Int → Prop → Prop),
  (∀ (A B C D E F : Int),
  ∀ (G : Prop),
  ∀ (H I J K L M : Int),
  ∀ (N : Prop),
  (I = B) →
  (J = C) →
  (K = D) →
  (L = E) →
  (M = F) →
  (N = True) →
  (H = A) →
  r2 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Prop),
  ∀ (O : Int),
  ∀ (P Q R S T U V W X Y Z A1 : Prop),
  ∀ (B1 C1 D1 E1 F1 G1 : Int),
  ∀ (H1 : Prop),
  ∀ (I1 J1 K1 L1 M1 N1 : Int),
  ∀ (O1 : Prop),
  ∀ (P1 Q1 R1 S1 T1 U1 : Int),
  ∀ (V1 : Prop),
  let a!1 := I1 ≥ (1 : Int) ∧ M1 = (0 : Int) ∧ L1 = (0 : Int) ∧ K1 = (0 : Int) ∧ J1 = (0 : Int);
  let a!2 := H = (I1 ≥ (1 : Int) ∧ J1 + M1 + L1 + K1 ≥ (3 : Int));
  let a!3 := M = (I1 ≥ (1 : Int) ∧ J1 + M1 + L1 + K1 ≥ (1 : Int));
  let a!4 := (C ∨ D1 = M1) ∧ (¬C ∨ D1 = (-1 : Int) + M1);
  let a!6 := (M ∨ D1 = M1) ∧ (¬M ∨ D1 = M1 + L1 + K1 + J1);
  let a!8 := (D1 = M1 ∨ B) ∧ (¬B ∨ D1 = (-1 : Int) + M1 + K1);
  let a!10 := ¬T ∨ (K ∨ D1 = M1) ∧ (¬K ∨ D1 = (0 : Int));
  let a!11 := (H ∨ D1 = M1) ∧ (¬H ∨ D1 = (1 : Int) + M1 + L1);
  let a!13 := (F ∨ G1 = I1) ∧ (¬F ∨ G1 = (1 : Int) + I1);
  let a!15 := (G1 = I1 ∨ D) ∧ (¬D ∨ G1 = (1 : Int) + I1);
  let a!17 := (G1 = I1 ∨ C) ∧ (¬C ∨ G1 = (1 : Int) + I1);
  let a!19 := (N ∨ G1 = I1) ∧ (¬N ∨ G1 = (1 : Int) + I1);
  let a!21 := (M ∨ G1 = I1) ∧ (¬M ∨ G1 = (-1 : Int) + I1);
  let a!23 := (L ∨ G1 = I1) ∧ (¬L ∨ G1 = (-1 : Int) + I1);
  let a!25 := (H ∨ G1 = I1) ∧ (¬H ∨ G1 = (-1 : Int) + I1);
  let a!27 := (E ∨ G1 = I1) ∧ (¬E ∨ G1 = (-1 : Int) + I1);
  let a!29 := (C1 = L1 ∨ F) ∧ (¬F ∨ C1 = (-1 : Int) + L1);
  let a!31 := ¬W ∨ (M ∨ C1 = L1) ∧ (¬M ∨ C1 = (0 : Int));
  let a!32 := (I ∨ C1 = L1) ∧ (¬I ∨ C1 = (-1 : Int) + L1);
  let a!34 := ¬Q ∨ (H ∨ C1 = L1) ∧ (¬H ∨ C1 = (0 : Int));
  let a!35 := (C1 = L1 ∨ E) ∧ (¬E ∨ C1 = (1 : Int) + L1);
  let a!37 := (D ∨ E1 = K1) ∧ (¬D ∨ E1 = (-1 : Int) + K1);
  let a!39 := ¬W ∨ (M ∨ E1 = K1) ∧ (¬M ∨ E1 = (1 : Int));
  let a!40 := ¬U ∨ (B ∨ E1 = K1) ∧ (¬B ∨ E1 = (1 : Int));
  let a!42 := ¬S ∨ (J ∨ E1 = K1) ∧ (¬J ∨ E1 = (0 : Int));
  let a!43 := (H ∨ E1 = K1) ∧ (¬H ∨ E1 = K1 + J1);
  let a!45 := (F1 = J1 ∨ N) ∧ (¬N ∨ F1 = (-1 : Int) + J1);
  let a!47 := ¬W ∨ (F1 = J1 ∨ M) ∧ (¬M ∨ F1 = (0 : Int));
  let a!48 := (F1 = J1 ∨ L) ∧ (¬L ∨ F1 = (1 : Int) + J1);
  let a!50 := (F1 = J1 ∨ K) ∧ (¬K ∨ F1 = (1 : Int) + J1);
  let a!52 := (F1 = J1 ∨ J) ∧ (¬J ∨ F1 = (1 : Int) + J1);
  let a!54 := (F1 = J1 ∨ I) ∧ (¬I ∨ F1 = (1 : Int) + J1);
  let a!56 := ¬Q ∨ (F1 = J1 ∨ H) ∧ (¬H ∨ F1 = (0 : Int));
  let a!5 := W ∨ (¬Y ∨ a!4) ∧ (Y ∨ D1 = M1);
  let a!14 := Z ∨ (¬A1 ∨ a!13) ∧ (A1 ∨ G1 = I1);
  let a!30 := W ∨ (¬A1 ∨ a!29) ∧ (A1 ∨ C1 = L1);
  let a!38 := W ∨ (¬Z ∨ a!37) ∧ (Z ∨ E1 = K1);
  let a!46 := W ∨ (¬X ∨ a!45) ∧ (X ∨ F1 = J1);
  let a!7 := U ∨ a!5 ∧ (¬W ∨ a!6);
  let a!16 := Y ∨ a!14 ∧ (¬Z ∨ a!15);
  let a!33 := Q ∨ (R ∨ a!30 ∧ a!31) ∧ (¬R ∨ a!32);
  let a!41 := S ∨ (U ∨ a!38 ∧ a!39) ∧ a!40;
  let a!49 := T ∨ (V ∨ a!46 ∧ a!47) ∧ (¬V ∨ a!48);
  let a!9 := T ∨ a!7 ∧ (¬U ∨ a!8);
  let a!18 := X ∨ a!16 ∧ (¬Y ∨ a!17);
  let a!36 := G ∨ (P ∨ a!33 ∧ a!34) ∧ (¬P ∨ a!35);
  let a!44 := G ∨ (Q ∨ a!41 ∧ a!42) ∧ (¬Q ∨ a!43);
  let a!51 := S ∨ a!49 ∧ (¬T ∨ a!50);
  let a!12 := G ∨ (Q ∨ a!9 ∧ a!10) ∧ (¬Q ∨ a!11) ∧ O = N1;
  let a!20 := W ∨ a!18 ∧ (¬X ∨ a!19);
  let a!53 := R ∨ a!51 ∧ (¬S ∨ a!52);
  let a!22 := V ∨ a!20 ∧ (¬W ∨ a!21);
  let a!55 := Q ∨ a!53 ∧ (¬R ∨ a!54);
  let a!24 := Q ∨ a!22 ∧ (¬V ∨ a!23);
  let a!26 := P ∨ a!24 ∧ (¬Q ∨ a!25);
  let a!28 := G ∨ a!26 ∧ (¬P ∨ a!27);
  B = (K1 + M1 ≥ (2 : Int)) →
    C = (M1 ≥ (1 : Int)) →
      D = (K1 ≥ (1 : Int)) →
        E = a!1 →
          F = (L1 ≥ (1 : Int)) →
            G = A →
              a!2 →
                I = (L1 ≥ (1 : Int)) →
                  J = (M1 = (0 : Int) ∧ K1 = (1 : Int)) →
                    K = (M1 = (1 : Int) ∧ K1 = (0 : Int)) →
                      L = a!1 →
                        a!3 →
                          N = (J1 ≥ (1 : Int)) →
                            H1 = (C1 ≥ (2 : Int)) →
                              P1 = G1 →
                                Q1 = F1 →
                                  R1 = E1 →
                                    S1 = C1 →
                                      T1 = D1 →
                                        U1 = O →
                                          ¬G ∨ C1 = (0 : Int) →
                                            ¬G ∨ E1 = (0 : Int) →
                                              ¬G ∨ F1 = (0 : Int) →
                                                ¬G ∨ G1 = O →
                                                  G ∨ (Q ∨ a!9 ∧ a!10) ∧ (¬Q ∨ a!11) ∧ O = N1 →
                                                    ¬G ∨ D1 = (0 : Int) ∧ O = B1 →
                                                      G ∨ a!26 ∧ (¬P ∨ a!27) →
                                                        G ∨ (P ∨ a!33 ∧ a!34) ∧ (¬P ∨ a!35) →
                                                          G ∨ (Q ∨ a!41 ∧ a!42) ∧ (¬Q ∨ a!43) →
                                                            G ∨ a!55 ∧ a!56 →
                                                              ¬V1 →
                                                                A = O1 →
                                                                  r6 P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1
                                                                    K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 U1 V1) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D : Prop),
  (D = True) →
  (C = A) →
  r11 A B C D) ∧
  ((∀ (A B : Prop),
  ∀ (C D E : Int),
  ∀ (F : Prop),
  ∀ (G : Int),
  ∀ (H : Prop),
  (A = F) →
  (G = D) →
  (¬B ∨ D = C) →
  (D = E ∨ B) →
  (¬H) →
  (B = A) →
  r8 C D E F G H) ∧
  ((∀ (A B C D : Prop),
  (D = True) →
  (C = A) →
  r10 A B C D) ∧
  ((∀ (A B C D E F G H : Prop),
  (G = D) →
  (A = F) →
  (B ∨ D = (E ∧ C)) →
  (¬B ∨ D = C) →
  (¬H) →
  (B = A) →
  r7 C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M : Prop),
  (let shared := ¬D ∧ ¬C ∧ ¬B ∧ ¬A;
  let shared_1 := ¬E ∧ shared;
  let shared_2 := ¬H ∧ shared_1;
  let shared_3 := ¬I ∧ shared_2;
  let shared_4 := ¬G ∧ shared_3;
  let shared_5 := ¬J ∧ shared_4;
  let shared_6 := ¬L ∧ shared_5;
  let shared_7 := ¬K ∧ shared_6;
  M =
    (¬F ∧ shared_7 ∨
      ¬F ∧ ¬K ∧ ¬L ∧ ¬J ∧ ¬G ∧ ¬I ∧ ¬H ∧ ¬E ∧ ¬D ∧ ¬C ∧ ¬B ∧ A ∨
        ¬F ∧ ¬K ∧ ¬L ∧ ¬J ∧ ¬G ∧ ¬I ∧ ¬H ∧ ¬E ∧ ¬D ∧ ¬C ∧ B ∧ ¬A ∨
          ¬F ∧ ¬K ∧ ¬L ∧ ¬J ∧ ¬G ∧ ¬I ∧ ¬H ∧ ¬E ∧ ¬D ∧ C ∧ ¬B ∧ ¬A ∨
            ¬F ∧ ¬K ∧ ¬L ∧ ¬J ∧ ¬G ∧ ¬I ∧ ¬H ∧ ¬E ∧ D ∧ ¬C ∧ ¬B ∧ ¬A ∨
              ¬F ∧ ¬K ∧ ¬L ∧ ¬J ∧ ¬G ∧ ¬I ∧ ¬H ∧ E ∧ shared ∨
                ¬F ∧ ¬K ∧ ¬L ∧ ¬J ∧ ¬G ∧ ¬I ∧ H ∧ shared_1 ∨
                  ¬F ∧ ¬K ∧ ¬L ∧ ¬J ∧ ¬G ∧ I ∧ shared_2 ∨
                    ¬F ∧ ¬K ∧ ¬L ∧ ¬J ∧ G ∧ shared_3 ∨
                      ¬F ∧ ¬K ∧ ¬L ∧ J ∧ shared_4 ∨ ¬F ∧ ¬K ∧ L ∧ shared_5 ∨ ¬F ∧ K ∧ shared_6 ∨ F ∧ shared_7)) →
  r4 A B C D E F G H I J K L M) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C D E F G H : Int),
  ∀ (I J K : Prop),
  ∀ (L : Int),
  ∀ (M : Prop),
  ∀ (N O P Q R S : Int),
  ∀ (T U V : Prop),
  (r11 A B L M) →
  (r10 J K U V) →
  (r2 C D E F G H I N O P Q R S T) →
  (True) →
  r9 A B C D E F G H I J K L M N O P Q R S T U V) ∧
  ((∀ (A B C D : Prop),
  ∀ (E F G H : Int),
  ∀ (I : Prop),
  ∀ (J K L M N O : Int),
  ∀ (P : Prop),
  ∀ (Q : Int),
  ∀ (R S : Prop),
  ∀ (T U : Int),
  ∀ (V W X Y Z A1 B1 C1 D1 E1 F1 G1 : Prop),
  ∀ (H1 : Int),
  ∀ (I1 : Prop),
  ∀ (J1 : Int),
  ∀ (K1 : Prop),
  ∀ (L1 M1 N1 O1 P1 Q1 : Int),
  ∀ (R1 S1 T1 : Prop),
  ∀ (U1 : Int),
  ∀ (V1 : Prop),
  ∀ (W1 X1 Y1 Z1 A2 B2 : Int),
  ∀ (C2 D2 E2 : Prop),
  let a!1 := A = (B ∧ ¬H1 ≤ (0 : Int));
  r4 V W X Y Z A1 B1 C1 D1 E1 F1 G1 B →
    r7 A S C D D2 E2 →
      r6 V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 E F T G H I J K L M N O P W1 X1 Y1 Z1 A2 B2 C2 →
        r8 H1 U Q R U1 V1 →
          R = K1 →
            I1 = (¬S ∨ T ≤ U) →
              C = S1 →
                D = T1 →
                  a!1 →
                    J = L1 →
                      K = M1 →
                        L = N1 →
                          M = O1 →
                            N = P1 →
                              O = Q1 →
                                Q = J1 →
                                  P = R1 →
                                    r1 V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 U1 V1 W1 X1
                                      Y1 Z1 A2 B2 C2 D2 E2) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r5) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C D E F G H : Int),
  ∀ (I J K L M N O P Q R S T U V W : Prop),
  ∀ (X Y : Int),
  ∀ (Z : Prop),
  ∀ (A1 B1 C1 D1 E1 F1 : Int),
  ∀ (G1 H1 I1 : Prop),
  ∀ (J1 : Int),
  ∀ (K1 : Prop),
  ∀ (L1 M1 N1 O1 P1 Q1 : Int),
  ∀ (R1 S1 T1 U1 : Prop),
  (r1 L M N O P Q R S T U V W X U1 Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1) →
  (r5) →
  (r9 A B C D E F G H I J K Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1) →
  (True) →
  r3 J1 K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 U1) ∧
  ((∀ (A B C D E F G H I J K L M : Prop),
  ∀ (N O : Int),
  ∀ (P : Prop),
  ∀ (Q R S T U V : Int),
  ∀ (W X Y : Prop),
  ∀ (Z : Int),
  ∀ (A1 : Prop),
  ∀ (B1 C1 D1 E1 F1 G1 : Int),
  ∀ (H1 I1 J1 K1 : Prop),
  (r1 B C D E F G H I J K L M N K1 O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1) →
  (r3 O P Q R S T U V W X Y A) →
  (True) →
  r3 Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C D E F G H : Int),
  ∀ (I J K L : Prop),
  (r3 A B C D E F G H I J K L) →
  (¬L) →
  r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False)))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«kind2-chc-benchmarks».«data».«DRAGON_12_e2_1618_e2_138_000»
