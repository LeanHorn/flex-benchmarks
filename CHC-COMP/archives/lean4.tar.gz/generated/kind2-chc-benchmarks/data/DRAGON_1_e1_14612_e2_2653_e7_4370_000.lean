import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«kind2-chc-benchmarks».«data».«DRAGON_1_e1_14612_e2_2653_e7_4370_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_1_e1_14612_e2_2653_e7_4370_000.smt2":558:1-558:12 (check-sat, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_1_e1_14612_e2_2653_e7_4370_000.smt2":15:1-24:2 (clause 1, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_1_e1_14612_e2_2653_e7_4370_000.smt2":25:1-152:2 (clause 2, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_1_e1_14612_e2_2653_e7_4370_000.smt2":153:1-162:2 (clause 3, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_1_e1_14612_e2_2653_e7_4370_000.smt2":163:1-172:2 (clause 4, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_1_e1_14612_e2_2653_e7_4370_000.smt2":173:1-338:2 (clause 5, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_1_e1_14612_e2_2653_e7_4370_000.smt2":339:1-350:2 (clause 6, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_1_e1_14612_e2_2653_e7_4370_000.smt2":351:1-437:2 (clause 7, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_1_e1_14612_e2_2653_e7_4370_000.smt2":438:1-447:2 (clause 8, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_1_e1_14612_e2_2653_e7_4370_000.smt2":448:1-491:2 (clause 9, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_1_e1_14612_e2_2653_e7_4370_000.smt2":492:1-534:2 (clause 10, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_1_e1_14612_e2_2653_e7_4370_000.smt2":535:1-545:2 (clause 11, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/kind2-chc-benchmarks/data/DRAGON_1_e1_14612_e2_2653_e7_4370_000.smt2":546:1-556:2 (clause 12, command 23)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop → Prop → Int → Int → Int → Int → Int → Int → Prop → Prop → Prop → Int → Int → Int → Int → Int → Int → Prop → Prop),
  ∃ (r2 : Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop → Prop),
  ∃ (r3 : Prop),
  ∃ (r4 : Prop →
    Prop →
      Prop →
        Prop →
          Prop →
            Prop →
              Prop →
                Prop →
                  Prop →
                    Prop →
                      Prop →
                        Prop →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Prop →
                                        Int →
                                          Int →
                                            Int → Int → Int → Int → Prop → Int → Int → Int → Int → Int → Int → Prop → Prop),
  ∃ (r5 : Prop → Prop → Int → Int → Int → Int → Int → Int → Prop → Prop → Prop),
  ∃ (r6 : Prop → Prop → Prop → Prop → Prop → Prop → Prop),
  ∃ (r7 : Prop →
    Prop →
      Prop →
        Prop →
          Prop →
            Prop →
              Prop →
                Prop →
                  Prop →
                    Prop →
                      Prop →
                        Prop →
                          Int →
                            Prop →
                              Prop →
                                Prop →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int → Int → Prop → Prop → Prop → Int → Int → Int → Int → Int → Int → Prop → Prop),
  ∃ (r8 : Prop → Prop → Prop → Prop → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Prop → Int → Int → Int → Int → Int → Int → Prop → Prop),
  (∀ (A B C D E F : Int),
  ∀ (G : Prop),
  ∀ (H I J K L M : Int),
  ∀ (N : Prop),
  (I = B) →
  (J = C) →
  (K = D) →
  (L = E) →
  (M = F) →
  (N = True) →
  (H = A) →
  r9 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Prop),
  ∀ (O : Int),
  ∀ (P Q R S T U V W X Y Z A1 : Prop),
  ∀ (B1 C1 D1 E1 F1 G1 : Int),
  ∀ (H1 : Prop),
  ∀ (I1 J1 K1 L1 M1 N1 : Int),
  ∀ (O1 : Prop),
  ∀ (P1 Q1 R1 S1 T1 U1 : Int),
  ∀ (V1 : Prop),
  let a!1 := I1 ≥ (1 : Int) ∧ M1 = (0 : Int) ∧ L1 = (0 : Int) ∧ K1 = (0 : Int) ∧ J1 = (0 : Int);
  let a!2 := I1 ≥ (1 : Int) ∧ J1 + M1 + L1 + K1 ≥ (1 : Int);
  let a!3 := (C ∨ D1 = M1) ∧ (¬C ∨ D1 = (-1 : Int) + M1);
  let a!5 := (M ∨ D1 = M1) ∧ (¬M ∨ D1 = M1 + L1 + K1 + J1);
  let a!7 := (D1 = M1 ∨ B) ∧ (¬B ∨ D1 = (-1 : Int) + M1 + K1);
  let a!9 := ¬T ∨ (K ∨ D1 = M1) ∧ (¬K ∨ D1 = (0 : Int));
  let a!10 := (H ∨ D1 = M1) ∧ (¬H ∨ D1 = (1 : Int) + M1 + L1);
  let a!12 := (F ∨ G1 = I1) ∧ (¬F ∨ G1 = (1 : Int) + I1);
  let a!14 := (G1 = I1 ∨ D) ∧ (¬D ∨ G1 = (1 : Int) + I1);
  let a!16 := (G1 = I1 ∨ C) ∧ (¬C ∨ G1 = (1 : Int) + I1);
  let a!18 := (N ∨ G1 = I1) ∧ (¬N ∨ G1 = (1 : Int) + I1);
  let a!20 := (M ∨ G1 = I1) ∧ (¬M ∨ G1 = (-1 : Int) + I1);
  let a!22 := (L ∨ G1 = I1) ∧ (¬L ∨ G1 = (-1 : Int) + I1);
  let a!24 := (H ∨ G1 = I1) ∧ (¬H ∨ G1 = (-1 : Int) + I1);
  let a!26 := (E ∨ G1 = I1) ∧ (¬E ∨ G1 = (-1 : Int) + I1);
  let a!28 := (C1 = L1 ∨ F) ∧ (¬F ∨ C1 = (-1 : Int) + L1);
  let a!30 := ¬W ∨ (M ∨ C1 = L1) ∧ (¬M ∨ C1 = (0 : Int));
  let a!31 := (I ∨ C1 = L1) ∧ (¬I ∨ C1 = (-1 : Int) + L1);
  let a!33 := ¬Q ∨ (H ∨ C1 = L1) ∧ (¬H ∨ C1 = (0 : Int));
  let a!34 := (C1 = L1 ∨ E) ∧ (¬E ∨ C1 = (1 : Int) + L1);
  let a!36 := (D ∨ E1 = K1) ∧ (¬D ∨ E1 = (-1 : Int) + K1);
  let a!38 := ¬W ∨ (M ∨ E1 = K1) ∧ (¬M ∨ E1 = (1 : Int));
  let a!39 := ¬U ∨ (B ∨ E1 = K1) ∧ (¬B ∨ E1 = (1 : Int));
  let a!41 := ¬S ∨ (J ∨ E1 = K1) ∧ (¬J ∨ E1 = (0 : Int));
  let a!42 := (H ∨ E1 = K1) ∧ (¬H ∨ E1 = K1 + J1);
  let a!44 := (F1 = J1 ∨ N) ∧ (¬N ∨ F1 = (-1 : Int) + J1);
  let a!46 := ¬W ∨ (F1 = J1 ∨ M) ∧ (¬M ∨ F1 = (0 : Int));
  let a!47 := (F1 = J1 ∨ L) ∧ (¬L ∨ F1 = (1 : Int) + J1);
  let a!49 := (F1 = J1 ∨ K) ∧ (¬K ∨ F1 = (1 : Int) + J1);
  let a!51 := (F1 = J1 ∨ J) ∧ (¬J ∨ F1 = (1 : Int) + J1);
  let a!53 := (F1 = J1 ∨ I) ∧ (¬I ∨ F1 = (1 : Int) + J1);
  let a!55 := ¬Q ∨ (F1 = J1 ∨ H) ∧ (¬H ∨ F1 = (0 : Int));
  let a!4 := W ∨ (¬Y ∨ a!3) ∧ (Y ∨ D1 = M1);
  let a!13 := Z ∨ (¬A1 ∨ a!12) ∧ (A1 ∨ G1 = I1);
  let a!29 := W ∨ (¬A1 ∨ a!28) ∧ (A1 ∨ C1 = L1);
  let a!37 := W ∨ (¬Z ∨ a!36) ∧ (Z ∨ E1 = K1);
  let a!45 := W ∨ (¬X ∨ a!44) ∧ (X ∨ F1 = J1);
  let a!6 := U ∨ a!4 ∧ (¬W ∨ a!5);
  let a!15 := Y ∨ a!13 ∧ (¬Z ∨ a!14);
  let a!32 := Q ∨ (R ∨ a!29 ∧ a!30) ∧ (¬R ∨ a!31);
  let a!40 := S ∨ (U ∨ a!37 ∧ a!38) ∧ a!39;
  let a!48 := T ∨ (V ∨ a!45 ∧ a!46) ∧ (¬V ∨ a!47);
  let a!8 := T ∨ a!6 ∧ (¬U ∨ a!7);
  let a!17 := X ∨ a!15 ∧ (¬Y ∨ a!16);
  let a!35 := G ∨ (P ∨ a!32 ∧ a!33) ∧ (¬P ∨ a!34);
  let a!43 := G ∨ (Q ∨ a!40 ∧ a!41) ∧ (¬Q ∨ a!42);
  let a!50 := S ∨ a!48 ∧ (¬T ∨ a!49);
  let a!11 := G ∨ (Q ∨ a!8 ∧ a!9) ∧ (¬Q ∨ a!10) ∧ O = N1;
  let a!19 := W ∨ a!17 ∧ (¬X ∨ a!18);
  let a!52 := R ∨ a!50 ∧ (¬S ∨ a!51);
  let a!21 := V ∨ a!19 ∧ (¬W ∨ a!20);
  let a!54 := Q ∨ a!52 ∧ (¬R ∨ a!53);
  let a!23 := Q ∨ a!21 ∧ (¬V ∨ a!22);
  let a!25 := P ∨ a!23 ∧ (¬Q ∨ a!24);
  let a!27 := G ∨ a!25 ∧ (¬P ∨ a!26);
  B = (K1 + M1 ≥ (2 : Int)) →
    C = (M1 ≥ (1 : Int)) →
      D = (K1 ≥ (1 : Int)) →
        E = a!1 →
          F = (L1 ≥ (1 : Int)) →
            G = A →
              H = a!2 →
                I = (L1 ≥ (1 : Int)) →
                  J = (M1 = (0 : Int) ∧ K1 = (1 : Int)) →
                    K = (M1 = (1 : Int) ∧ K1 = (0 : Int)) →
                      L = a!1 →
                        M = a!2 →
                          N = (J1 ≥ (1 : Int)) →
                            H1 = (C1 ≥ (2 : Int)) →
                              P1 = G1 →
                                Q1 = F1 →
                                  R1 = E1 →
                                    S1 = C1 →
                                      T1 = D1 →
                                        U1 = O →
                                          ¬G ∨ C1 = (0 : Int) →
                                            ¬G ∨ E1 = (0 : Int) →
                                              ¬G ∨ F1 = (0 : Int) →
                                                ¬G ∨ G1 = O →
                                                  G ∨ (Q ∨ a!8 ∧ a!9) ∧ (¬Q ∨ a!10) ∧ O = N1 →
                                                    ¬G ∨ D1 = (0 : Int) ∧ O = B1 →
                                                      G ∨ a!25 ∧ (¬P ∨ a!26) →
                                                        G ∨ (P ∨ a!32 ∧ a!33) ∧ (¬P ∨ a!34) →
                                                          G ∨ (Q ∨ a!40 ∧ a!41) ∧ (¬Q ∨ a!42) →
                                                            G ∨ a!54 ∧ a!55 →
                                                              ¬V1 →
                                                                A = O1 →
                                                                  r4 P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1
                                                                    K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 U1 V1) ∧
  ((∀ (A B C D : Prop),
  (D = True) →
  (C = A) →
  r8 A B C D) ∧
  ((∀ (A B C D E F G H : Prop),
  (G = D) →
  (A = F) →
  (B ∨ D = (E ∨ C)) →
  (¬B ∨ D = C) →
  (¬H) →
  (B = A) →
  r6 C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M : Prop),
  (let shared := ¬D ∧ ¬C ∧ ¬B ∧ ¬A;
  let shared_1 := ¬E ∧ shared;
  let shared_2 := ¬G ∧ shared_1;
  let shared_3 := ¬H ∧ shared_2;
  let shared_4 := ¬I ∧ shared_3;
  let shared_5 := ¬J ∧ shared_4;
  let shared_6 := ¬K ∧ shared_5;
  let shared_7 := ¬L ∧ shared_6;
  M =
    (¬F ∧ shared_7 ∨
      ¬F ∧ ¬L ∧ ¬K ∧ ¬J ∧ ¬I ∧ ¬H ∧ ¬G ∧ ¬E ∧ ¬D ∧ ¬C ∧ ¬B ∧ A ∨
        ¬F ∧ ¬L ∧ ¬K ∧ ¬J ∧ ¬I ∧ ¬H ∧ ¬G ∧ ¬E ∧ ¬D ∧ ¬C ∧ B ∧ ¬A ∨
          ¬F ∧ ¬L ∧ ¬K ∧ ¬J ∧ ¬I ∧ ¬H ∧ ¬G ∧ ¬E ∧ ¬D ∧ C ∧ ¬B ∧ ¬A ∨
            ¬F ∧ ¬L ∧ ¬K ∧ ¬J ∧ ¬I ∧ ¬H ∧ ¬G ∧ ¬E ∧ D ∧ ¬C ∧ ¬B ∧ ¬A ∨
              ¬F ∧ ¬L ∧ ¬K ∧ ¬J ∧ ¬I ∧ ¬H ∧ ¬G ∧ E ∧ shared ∨
                ¬F ∧ ¬L ∧ ¬K ∧ ¬J ∧ ¬I ∧ ¬H ∧ G ∧ shared_1 ∨
                  ¬F ∧ ¬L ∧ ¬K ∧ ¬J ∧ ¬I ∧ H ∧ shared_2 ∨
                    ¬F ∧ ¬L ∧ ¬K ∧ ¬J ∧ I ∧ shared_3 ∨
                      ¬F ∧ ¬L ∧ ¬K ∧ J ∧ shared_4 ∨ ¬F ∧ ¬L ∧ K ∧ shared_5 ∨ ¬F ∧ L ∧ shared_6 ∨ F ∧ shared_7)) →
  r2 A B C D E F G H I J K L M) ∧
  ((∀ (A B : Prop),
  ∀ (C D E F G H : Int),
  ∀ (I J K : Prop),
  ∀ (L M N O P Q : Int),
  ∀ (R : Prop),
  (r8 A B J K) →
  (r9 C D E F G H I L M N O P Q R) →
  (True) →
  r1 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A : Prop),
  ∀ (B C D E F G H I J K L : Int),
  ∀ (M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Prop),
  ∀ (E1 : Int),
  ∀ (F1 G1 H1 : Prop),
  ∀ (I1 J1 K1 L1 M1 N1 : Int),
  ∀ (O1 P1 Q1 : Prop),
  ∀ (R1 S1 T1 U1 V1 W1 : Int),
  ∀ (X1 : Prop),
  let a!1 := A = (N ∧ ¬E1 ≤ (0 : Int));
  r4 S T U V W X Y Z A1 B1 C1 D1 E1 B C D E F R G H I J K L M R1 S1 T1 U1 V1 W1 X1 →
    r2 S T U V W X Y Z A1 B1 C1 D1 N →
      r6 A Q O P P1 Q1 →
        O = G1 →
          P = H1 →
            F1 = (¬R ∨ ¬Q) →
              a!1 →
                G = I1 →
                  H = J1 →
                    I = K1 →
                      J = L1 →
                        K = M1 →
                          L = N1 →
                            M = O1 →
                              r7 S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 U1 V1 W1 X1) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r3) ∧
  ((∀ (A B : Prop),
  ∀ (C D E F G H : Int),
  ∀ (I J K L M N O P Q R S T U : Prop),
  ∀ (V : Int),
  ∀ (W X : Prop),
  ∀ (Y Z A1 B1 C1 D1 : Int),
  ∀ (E1 F1 G1 : Prop),
  ∀ (H1 I1 J1 K1 L1 M1 : Int),
  ∀ (N1 O1 : Prop),
  (r7 J K L M N O P Q R S T U V O1 W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1) →
  (r3) →
  (r1 A B C D E F G H I W X Y Z A1 B1 C1 D1 E1) →
  (True) →
  r5 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1) ∧
  ((∀ (A B C D E F G H I J K L M : Prop),
  ∀ (N : Int),
  ∀ (O P : Prop),
  ∀ (Q R S T U V : Int),
  ∀ (W X Y : Prop),
  ∀ (Z A1 B1 C1 D1 E1 : Int),
  ∀ (F1 G1 : Prop),
  (r7 B C D E F G H I J K L M N G1 O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1) →
  (r5 O P Q R S T U V W A) →
  (True) →
  r5 X Y Z A1 B1 C1 D1 E1 F1 G1) ∧
  ((∀ (A B : Prop),
  ∀ (C D E F G H : Int),
  ∀ (I J : Prop),
  (r5 A B C D E F G H I J) →
  (¬J) →
  r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False)))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«kind2-chc-benchmarks».«data».«DRAGON_1_e1_14612_e2_2653_e7_4370_000»
