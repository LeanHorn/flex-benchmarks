import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_id_b5_o10_true-unreach-call_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_b5_o10_true-unreach-call_000.smt2":134:1-134:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_b5_o10_true-unreach-call_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_b5_o10_true-unreach-call_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_b5_o10_true-unreach-call_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_b5_o10_true-unreach-call_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_b5_o10_true-unreach-call_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_b5_o10_true-unreach-call_000.smt2":61:1-90:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_b5_o10_true-unreach-call_000.smt2":91:1-100:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_b5_o10_true-unreach-call_000.smt2":101:1-121:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_b5_o10_true-unreach-call_000.smt2":122:1-132:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Prop),
    ∃ (r1 : Int → Prop),
    ∃ (r2 : Prop → Prop → Prop → Int → Int → Prop),
    ∃ (r3 : Int → Prop),
    ∃ (r4 : Int → Int → Prop),
    (∀ (A B : Int),
    ∀ (v_2 v_3 v_4 : Prop),
    (True) →
    (v_2 = True) →
    (v_3 = True) →
    (v_4 = True) →
    r2 v_2 v_3 v_4 A B) ∧
    ((∀ (A B : Int),
    ∀ (v_2 v_3 v_4 : Prop),
    (True) →
    (v_2 = False) →
    (v_3 = True) →
    (v_4 = True) →
    r2 v_2 v_3 v_4 A B) ∧
    ((∀ (A B : Int),
    ∀ (v_2 v_3 v_4 : Prop),
    (True) →
    (v_2 = False) →
    (v_3 = False) →
    (v_4 = False) →
    r2 v_2 v_3 v_4 A B) ∧
    ((∀ (A B : Int),
    ∀ (v_2 v_3 v_4 : Prop),
    (r4 B A) →
    (v_2 = True) →
    (v_3 = False) →
    (v_4 = False) →
    r2 v_2 v_3 v_4 A B) ∧
    ((∀ (A : Int),
    (True) →
    r1 A) ∧
    ((∀ (A B : Int),
    ∀ (C : Prop),
    ∀ (D E : Int),
    ∀ (F G : Prop),
    ∀ (H : Int),
    ∀ (I J : Prop),
    ∀ (K : Int),
    ∀ (L M : Prop),
    ∀ (N O : Int),
    ∀ (v_15 v_16 : Prop),
    let a!1 := ¬G ∨ ¬(B ≤ (4 : Int)) = C;
    r1 O →
      r2 G v_15 v_16 A B →
        v_15 = False →
          v_16 = False →
            ¬I ∨ ¬G ∨ ¬F →
              ¬J ∨ ¬I ∨ K = (0 : Int) →
                ¬J ∨ ¬I ∨ N = K →
                  ¬J ∨ ¬I ∨ F →
                    ¬L ∨ L ∧ G ∨ J ∧ I →
                      ¬L ∨ ¬G ∨ H = E →
                        ¬L ∨ ¬G ∨ N = H →
                          ¬G ∨ ¬(B ≤ (4 : Int)) = C →
                            ¬G ∨ A = (-1 : Int) + O →
                              ¬G ∨ D = (1 : Int) + B →
                                (¬G ∨ E = if C then (5 : Int) else D) →
                                  ¬G ∨ I ∧ G → ¬J ∨ I → ¬M ∨ M ∧ L → M = True → F = (O = (0 : Int)) → r4 N O) ∧
    ((∀ (A : Int),
    (True) →
    r3 A) ∧
    ((∀ (A B C D : Int),
    ∀ (E F G H I v_9 v_10 v_11 : Prop),
    (r3 B) →
    (r2 v_9 v_10 v_11 C D) →
    (v_9 = True) →
    (v_10 = False) →
    (v_11 = False) →
    (A = B) →
    (¬G ∨ G ∧ F) →
    (¬H ∨ H ∧ G) →
    (¬I ∨ I ∧ H) →
    (E = True) →
    (I = True) →
    (E = (D = (10 : Int))) →
    r0) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r0) →
    (True) →
    False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_id_b5_o10_true-unreach-call_000»
