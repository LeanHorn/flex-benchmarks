import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":140:1-140:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":61:1-90:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":91:1-100:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":101:1-127:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":128:1-138:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Prop),
  ∃ (r3 : Prop → Prop → Prop → Int → Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  (∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = True) →
  (v_3 = True) →
  (v_4 = True) →
  r3 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = True) →
  (v_4 = True) →
  r3 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = False) →
  (v_4 = False) →
  r3 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (r4 B A) →
  (v_2 = True) →
  (v_3 = False) →
  (v_4 = False) →
  r3 v_2 v_3 v_4 A B) ∧
  ((∀ (A : Int),
  (True) →
  r2 A) ∧
  ((∀ (A B : Int),
  ∀ (C D : Prop),
  ∀ (E F : Int),
  ∀ (G : Prop),
  ∀ (H : Int),
  ∀ (I : Prop),
  ∀ (J : Int),
  ∀ (K L : Prop),
  ∀ (M N : Int),
  ∀ (v_14 v_15 v_16 v_17 : Prop),
  (r2 N) →
  (r3 G v_14 v_15 A B) →
  (r3 G v_16 v_17 B E) →
  (v_14 = False) →
  (v_15 = False) →
  (v_16 = False) →
  (v_17 = False) →
  (¬G ∨ ¬D ∨ ¬C) →
  (¬I ∨ D ∨ ¬C) →
  (¬K ∨ K ∧ I ∨ K ∧ G) →
  (¬K ∨ ¬G ∨ H = E) →
  (¬K ∨ ¬G ∨ M = H) →
  (¬K ∨ ¬I ∨ J = F) →
  (¬K ∨ ¬I ∨ M = J) →
  (¬G ∨ A = (11 : Int) + N) →
  (¬G ∨ G ∧ C) →
  (¬I ∨ F = (-10 : Int) + N) →
  (¬I ∨ I ∧ C) →
  (¬L ∨ L ∧ K) →
  (L = True) →
  (¬(N ≤ (100 : Int)) = D) →
  r4 M N) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r1) ∧
  ((∀ (A B : Prop),
  ∀ (C D E : Int),
  ∀ (F G H I J K L v_12 v_13 v_14 : Prop),
  let a!1 := ¬I ∨ ¬(C ≤ (101 : Int)) = F;
  r1 →
    r3 v_12 v_13 v_14 C D →
      v_12 = True →
        v_13 = False →
          v_14 = False →
            ¬K ∨ J ∧ K →
              ¬L ∨ L ∧ K →
                ¬I ∨ E = (-10 : Int) + C →
                  ¬I ∨ ¬(C ≤ (101 : Int)) = F →
                    ¬I ∨ H = (G ∧ F) →
                      ¬I ∨ G = (D = E) → ¬I ∨ I ∧ B → ¬I ∨ ¬H → ¬J ∨ J ∧ I → L = True → ¬A → A = (D = (91 : Int)) → r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000»
