import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_terminator_02_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_terminator_02_true-unreach-call_true-termination_000.smt2":120:1-120:12 (check-sat, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_terminator_02_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_terminator_02_true-unreach-call_true-termination_000.smt2":18:1-44:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_terminator_02_true-unreach-call_true-termination_000.smt2":45:1-77:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_terminator_02_true-unreach-call_true-termination_000.smt2":78:1-107:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_terminator_02_true-unreach-call_true-termination_000.smt2":108:1-118:2 (clause 5, command 9)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Prop),
    ∃ (r1 : Int → Int → Int → Prop),
    ∃ (r2 : Int → Int → Prop),
    (∀ (A B : Int),
    (True) →
    r2 A B) ∧
    ((∀ (A B C D E F : Int),
    ∀ (G H I : Prop),
    ∀ (J K L : Int),
    ∀ (M N : Prop),
    ∀ (O P Q R : Int),
    let a!1 := H = (¬(199 : Int) ≤ E ∧ E ≥ (0 : Int));
    let a!2 := G = (¬(199 : Int) ≤ F ∧ F ≥ (0 : Int));
    r2 R D →
      a!1 →
        I = (H ∧ G) →
          A = D →
            B = D →
              C = D →
                E = (99 : Int) + K →
                  F = (99 : Int) + J →
                    ¬N ∨ ¬M ∨ L = J →
                      ¬N ∨ ¬M ∨ O = K →
                        ¬N ∨ ¬M ∨ P = O → ¬N ∨ ¬M ∨ Q = L → ¬M ∨ N ∧ M → I = True → M = True → a!2 → r1 P Q R) ∧
    ((∀ (A B C D : Prop),
    ∀ (E : Int),
    ∀ (F G : Prop),
    ∀ (H I J K L M : Int),
    ∀ (N : Prop),
    ∀ (O P : Int),
    ∀ (Q R : Prop),
    ∀ (S T U V : Int),
    (r1 H K V) →
    (¬(K ≤ (100 : Int)) = B) →
    (D = (B ∧ A)) →
    (¬F ∨ D ∨ ¬C) →
    (¬N ∨ ¬G ∨ ¬F) →
    (¬Q ∨ R ∧ Q ∨ Q ∧ N) →
    (¬Q ∨ ¬N ∨ M = I) →
    (¬Q ∨ ¬N ∨ O = J) →
    (¬Q ∨ ¬N ∨ T = O) →
    (¬Q ∨ ¬N ∨ U = M) →
    (¬R ∨ ¬F ∨ G) →
    (¬R ∨ ¬Q ∨ P = K) →
    (¬R ∨ ¬Q ∨ S = L) →
    (¬R ∨ ¬Q ∨ T = S) →
    (¬R ∨ ¬Q ∨ U = P) →
    (¬F ∨ E = V) →
    (¬F ∨ F ∧ C) →
    (¬N ∨ I = (-1 : Int) + K) →
    (¬N ∨ J = (-1 : Int) + H) →
    (¬N ∨ N ∧ F) →
    (¬R ∨ L = (1 : Int) + H) →
    (¬R ∨ R ∧ F) →
    (Q = True) →
    (¬((100 : Int) ≤ H) = A) →
    r1 T U V) ∧
    ((∀ (A : Int),
    ∀ (B C D E : Prop),
    ∀ (F G : Int),
    ∀ (H I J K L M : Prop),
    ∀ (N : Int),
    ∀ (O P Q R S : Prop),
    let a!1 := ¬L ∨ ¬((101 : Int) ≤ G) = I;
    let a!2 := ¬L ∨ ¬(F ≤ (99 : Int)) = H;
    r1 F G A →
      ¬(G ≤ (100 : Int)) = C →
        E = (C ∧ B) →
          ¬D ∨ ¬E ∨ ¬L →
            ¬L ∨ ¬((101 : Int) ≤ G) = I →
              ¬L ∨ ¬(F ≤ (99 : Int)) = H →
                ¬L ∨ J = (I ∨ H) →
                  (¬L ∨ N = if J then (1 : Int) else (0 : Int)) →
                    ¬L ∨ D ∧ L →
                      ¬M ∨ M ∧ L →
                        ¬K ∨ ¬L →
                          ¬P ∨ O = (N = (0 : Int)) →
                            ¬P ∨ P ∧ M →
                              ¬Q ∨ Q ∧ P → ¬R ∨ R ∧ Q → ¬S ∨ S ∧ R → O ∨ ¬P → S = True → ¬((100 : Int) ≤ F) = B → r0) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r0) →
    (True) →
    False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_terminator_02_true-unreach-call_true-termination_000»
