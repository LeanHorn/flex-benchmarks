import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":136:1-136:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":61:1-88:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":89:1-98:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":99:1-123:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":124:1-134:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop → Prop → Prop → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Prop),
  ∃ (r3 : Prop),
  ∃ (r4 : Int → Prop),
  (∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = True) →
  (v_3 = True) →
  (v_4 = True) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = True) →
  (v_4 = True) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = False) →
  (v_4 = False) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (r2 B A) →
  (v_2 = True) →
  (v_3 = False) →
  (v_4 = False) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A : Int),
  (True) →
  r4 A) ∧
  ((∀ (A B C D : Int),
  ∀ (E F : Prop),
  ∀ (G : Int),
  ∀ (H I : Prop),
  ∀ (J : Int),
  ∀ (K L : Prop),
  ∀ (M N : Int),
  ∀ (v_14 v_15 : Prop),
  (r4 N) →
  (r0 F v_14 v_15 A B) →
  (v_14 = False) →
  (v_15 = False) →
  (¬H ∨ ¬F ∨ ¬E) →
  (¬I ∨ ¬H ∨ J = (1 : Int)) →
  (¬I ∨ ¬H ∨ M = J) →
  (¬I ∨ ¬H ∨ E) →
  (¬K ∨ K ∧ F ∨ I ∧ H) →
  (¬K ∨ ¬F ∨ G = D) →
  (¬K ∨ ¬F ∨ M = G) →
  (¬F ∨ A = (-1 : Int) + N) →
  (¬F ∨ C = (2 : Int) * B) →
  (¬F ∨ D = (1 : Int) + C) →
  (¬F ∨ H ∧ F) →
  (¬I ∨ H) →
  (¬L ∨ L ∧ K) →
  (L = True) →
  (E = (N = (1 : Int))) →
  r2 M N) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r3) ∧
  ((∀ (A : Int),
  ∀ (B C : Prop),
  ∀ (D E : Int),
  ∀ (F G H I J v_10 v_11 : Prop),
  let a!1 := ¬G ∨ ¬(E ≤ D) = F;
  let a!2 := B = (¬A ≤ (30 : Int) ∨ ¬A ≥ (0 : Int));
  r3 →
    r0 G v_10 v_11 E D →
      v_10 = False →
        v_11 = False →
          A = (-1 : Int) + E →
            ¬G ∨ ¬(E ≤ D) = F → ¬G ∨ G ∧ C → ¬G ∨ F → ¬H ∨ H ∧ G → ¬I ∨ I ∧ H → ¬J ∨ J ∧ I → ¬B → J = True → a!2 → r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000»
