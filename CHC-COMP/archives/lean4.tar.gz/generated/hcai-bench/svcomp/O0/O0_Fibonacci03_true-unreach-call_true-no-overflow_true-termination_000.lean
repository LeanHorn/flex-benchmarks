import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_Fibonacci03_true-unreach-call_true-no-overflow_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Fibonacci03_true-unreach-call_true-no-overflow_true-termination_000.smt2":147:1-147:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Fibonacci03_true-unreach-call_true-no-overflow_true-termination_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Fibonacci03_true-unreach-call_true-no-overflow_true-termination_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Fibonacci03_true-unreach-call_true-no-overflow_true-termination_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Fibonacci03_true-unreach-call_true-no-overflow_true-termination_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Fibonacci03_true-unreach-call_true-no-overflow_true-termination_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Fibonacci03_true-unreach-call_true-no-overflow_true-termination_000.smt2":61:1-98:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Fibonacci03_true-unreach-call_true-no-overflow_true-termination_000.smt2":99:1-108:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Fibonacci03_true-unreach-call_true-no-overflow_true-termination_000.smt2":109:1-134:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Fibonacci03_true-unreach-call_true-no-overflow_true-termination_000.smt2":135:1-145:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Prop),
  ∃ (r4 : Prop → Prop → Prop → Int → Int → Prop),
  (∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = True) →
  (v_3 = True) →
  (v_4 = True) →
  r4 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = True) →
  (v_4 = True) →
  r4 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = False) →
  (v_4 = False) →
  r4 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (r1 B A) →
  (v_2 = True) →
  (v_3 = False) →
  (v_4 = False) →
  r4 v_2 v_3 v_4 A B) ∧
  ((∀ (A : Int),
  (True) →
  r3 A) ∧
  ((∀ (A B C D E : Int),
  ∀ (F G H : Prop),
  ∀ (I : Int),
  ∀ (J K : Prop),
  ∀ (L : Int),
  ∀ (M N : Prop),
  ∀ (O : Int),
  ∀ (P Q : Prop),
  ∀ (R S : Int),
  ∀ (v_19 v_20 v_21 v_22 : Prop),
  (r3 S) →
  (r4 H v_19 v_20 A C) →
  (r4 H v_21 v_22 B D) →
  (v_19 = False) →
  (v_20 = False) →
  (v_21 = False) →
  (v_22 = False) →
  (¬P ∨ P ∧ H ∨ N ∧ M ∨ K ∧ J) →
  (¬J ∨ ¬H ∨ ¬F) →
  (¬K ∨ ¬J ∨ L = (1 : Int)) →
  (¬K ∨ ¬J ∨ R = L) →
  (¬K ∨ ¬J ∨ F) →
  (¬M ∨ ¬J ∨ ¬G) →
  (¬N ∨ ¬M ∨ O = (0 : Int)) →
  (¬N ∨ ¬M ∨ R = O) →
  (¬N ∨ ¬M ∨ G) →
  (¬P ∨ ¬H ∨ I = E) →
  (¬P ∨ ¬H ∨ R = I) →
  (¬H ∨ A = (-1 : Int) + S) →
  (¬H ∨ B = (-2 : Int) + S) →
  (¬H ∨ E = C + D) →
  (¬H ∨ J ∧ H) →
  (¬J ∨ F = (S = (1 : Int))) →
  (¬J ∨ M ∧ J) →
  (¬K ∨ J) →
  (¬N ∨ M) →
  (¬Q ∨ Q ∧ P) →
  (Q = True) →
  (¬((1 : Int) ≤ S) = G) →
  r1 R S) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r2) ∧
  ((∀ (A B : Prop),
  ∀ (C D : Int),
  ∀ (E F G H I J K v_11 v_12 : Prop),
  let a!1 := ¬H ∨ ¬((9 : Int) ≤ C) = E;
  let a!2 := ¬H ∨ ¬(D ≤ (33 : Int)) = F;
  r2 →
    r4 H v_11 v_12 C D →
      v_11 = False →
        v_12 = False →
          ¬H ∨ ¬((9 : Int) ≤ C) = E →
            ¬H ∨ ¬(D ≤ (33 : Int)) = F →
              ¬H ∨ G = (F ∨ E) →
                ¬H ∨ H ∧ B → ¬I ∨ I ∧ H → ¬H ∨ ¬G → ¬J ∨ J ∧ I → ¬K ∨ K ∧ J → ¬A → K = True → ¬(C ≤ (46 : Int)) = A → r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_Fibonacci03_true-unreach-call_true-no-overflow_true-termination_000»
