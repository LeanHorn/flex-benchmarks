import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_sum01_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum01_true-unreach-call_true-termination_000.smt2":99:1-99:12 (check-sat, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum01_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum01_true-unreach-call_true-termination_000.smt2":18:1-38:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum01_true-unreach-call_true-termination_000.smt2":39:1-59:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum01_true-unreach-call_true-termination_000.smt2":60:1-86:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum01_true-unreach-call_true-termination_000.smt2":87:1-97:2 (clause 5, command 9)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Int → Prop),
    ∃ (r1 : Prop),
    ∃ (r2 : Int → Int → Int → Prop),
    (∀ (A : Int),
    (True) →
    r0 A) ∧
    ((∀ (A B C : Int),
    ∀ (D : Prop),
    ∀ (E : Int),
    ∀ (F G : Prop),
    ∀ (H I J K : Int),
    let a!1 := D = (¬(2000 : Int) ≤ C ∧ C ≥ (0 : Int));
    r0 B →
      A = B →
        C = (1000 : Int) + I →
          ¬G ∨ ¬F ∨ E = (0 : Int) →
            ¬G ∨ ¬F ∨ H = (1 : Int) → ¬G ∨ ¬F ∨ J = E → ¬G ∨ ¬F ∨ K = H → ¬F ∨ G ∧ F → D = True → F = True → a!1 → r2 I J K) ∧
    ((∀ (A B : Prop),
    ∀ (C D E F G : Int),
    ∀ (H I : Prop),
    ∀ (J K L M : Int),
    (r2 K C D) →
    (¬I ∨ ¬B ∨ ¬A) →
    (¬I ∨ ¬H ∨ G = E) →
    (¬I ∨ ¬H ∨ J = F) →
    (¬I ∨ ¬H ∨ L = G) →
    (¬I ∨ ¬H ∨ M = J) →
    (¬H ∨ I ∧ H) →
    (¬I ∨ F = (1 : Int) + D) →
    (¬I ∨ E = (2 : Int) + C) →
    (¬I ∨ I ∧ A) →
    (H = True) →
    (¬(D ≤ K) = B) →
    r2 K L M) ∧
    ((∀ (A : Int),
    ∀ (B C : Prop),
    ∀ (D E F : Int),
    ∀ (G H I J K L : Prop),
    ∀ (M : Int),
    ∀ (N O P Q R : Prop),
    (r2 D F A) →
    (¬K ∨ C ∨ ¬B) →
    (¬L ∨ K ∧ L) →
    (¬O ∨ N = (M = (0 : Int))) →
    (¬O ∨ O ∧ L) →
    (¬P ∨ P ∧ O) →
    (¬Q ∨ Q ∧ P) →
    (¬R ∨ R ∧ Q) →
    (¬K ∨ H = (F = (0 : Int))) →
    (¬K ∨ I = (G ∨ H)) →
    (¬K ∨ G = (F = E)) →
    (¬K ∨ E = (2 : Int) * D) →
    (¬K ∨ M = if I then (1 : Int) else (0 : Int)) →
    (¬K ∨ K ∧ B) →
    (¬K ∨ ¬J) →
    (N ∨ ¬O) →
    (R = True) →
    (¬(A ≤ D) = C) →
    r1) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r1) →
    (True) →
    False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_sum01_true-unreach-call_true-termination_000»
