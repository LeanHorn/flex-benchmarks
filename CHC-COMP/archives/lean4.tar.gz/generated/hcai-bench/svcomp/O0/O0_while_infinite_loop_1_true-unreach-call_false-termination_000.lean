import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_while_infinite_loop_1_true-unreach-call_false-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_while_infinite_loop_1_true-unreach-call_false-termination_000.smt2":143:1-143:12 (check-sat, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_while_infinite_loop_1_true-unreach-call_false-termination_000.smt2":11:1-20:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_while_infinite_loop_1_true-unreach-call_false-termination_000.smt2":21:1-30:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_while_infinite_loop_1_true-unreach-call_false-termination_000.smt2":31:1-40:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_while_infinite_loop_1_true-unreach-call_false-termination_000.smt2":41:1-51:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_while_infinite_loop_1_true-unreach-call_false-termination_000.smt2":52:1-61:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_while_infinite_loop_1_true-unreach-call_false-termination_000.smt2":62:1-72:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_while_infinite_loop_1_true-unreach-call_false-termination_000.smt2":73:1-82:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_while_infinite_loop_1_true-unreach-call_false-termination_000.smt2":83:1-93:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_while_infinite_loop_1_true-unreach-call_false-termination_000.smt2":94:1-111:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_while_infinite_loop_1_true-unreach-call_false-termination_000.smt2":112:1-130:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_while_infinite_loop_1_true-unreach-call_false-termination_000.smt2":131:1-141:2 (clause 11, command 18)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Prop),
  ∃ (r4 : Int → Prop),
  ∃ (r5 : Prop → Prop → Prop → Int → Prop),
  (∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (True) →
  (v_1 = True) →
  (v_2 = True) →
  (v_3 = True) →
  r5 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (True) →
  (v_1 = False) →
  (v_2 = True) →
  (v_3 = True) →
  r5 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (True) →
  (v_1 = False) →
  (v_2 = False) →
  (v_3 = False) →
  r5 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (r0 A) →
  (v_1 = True) →
  (v_2 = False) →
  (v_3 = False) →
  r5 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  (True) →
  r4 A) ∧
  ((∀ (A B C : Prop),
  ∀ (D : Int),
  (r4 D) →
  (¬C ∨ C ∧ B) →
  (¬A) →
  (C = True) →
  (A = (D = (0 : Int))) →
  r0 D) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r3) ∧
  ((∀ (A B : Prop),
  (r3) →
  (B = True) →
  (¬B ∨ A ∧ B) →
  r1) ∧
  ((∀ (A B C D v_4 v_5 : Prop),
  ∀ (v_6 : Int),
  (r1) →
  (r5 C v_4 v_5 v_6) →
  (v_4 = False) →
  (v_5 = False) →
  ((1 : Int) = v_6) →
  (¬D ∨ C ∧ D) →
  (¬C ∨ C ∧ A) →
  (D = True) →
  (¬C ∨ B ∨ ¬A) →
  r1) ∧
  ((∀ (A B C D E F G H : Prop),
  (r1) →
  (¬C ∨ C ∧ A) →
  (¬H ∨ G ∧ H) →
  (¬E ∨ E ∧ C) →
  (¬E ∨ D) →
  (¬E ∨ ¬D) →
  (¬F ∨ F ∧ E) →
  (¬G ∨ G ∧ F) →
  (H = True) →
  (¬C ∨ ¬B ∨ ¬A) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  (True) →
  False))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_while_infinite_loop_1_true-unreach-call_false-termination_000»
