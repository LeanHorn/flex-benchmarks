import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_sum_non_eq_true-unreach-call_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_non_eq_true-unreach-call_000.smt2":131:1-131:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_non_eq_true-unreach-call_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_non_eq_true-unreach-call_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_non_eq_true-unreach-call_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_non_eq_true-unreach-call_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_non_eq_true-unreach-call_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_non_eq_true-unreach-call_000.smt2":61:1-87:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_non_eq_true-unreach-call_000.smt2":88:1-97:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_non_eq_true-unreach-call_000.smt2":98:1-118:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_non_eq_true-unreach-call_000.smt2":119:1-129:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  ∃ (r3 : Prop → Prop → Prop → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  (∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = True) →
  (v_4 = True) →
  (v_5 = True) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = True) →
  (v_5 = True) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = False) →
  (v_5 = False) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (r2 C A B) →
  (v_3 = True) →
  (v_4 = False) →
  (v_5 = False) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B : Int),
  (True) →
  r4 A B) ∧
  ((∀ (A B C : Int),
  ∀ (D E : Prop),
  ∀ (F : Int),
  ∀ (G H : Prop),
  ∀ (I : Int),
  ∀ (J K : Prop),
  ∀ (L M N : Int),
  ∀ (v_14 v_15 : Prop),
  (r4 M N) →
  (r3 E v_14 v_15 A B C) →
  (v_14 = False) →
  (v_15 = False) →
  (¬G ∨ ¬E ∨ ¬D) →
  (¬H ∨ ¬G ∨ I = N) →
  (¬H ∨ ¬G ∨ L = I) →
  (¬H ∨ ¬G ∨ D) →
  (¬J ∨ J ∧ E ∨ H ∧ G) →
  (¬J ∨ ¬E ∨ F = C) →
  (¬J ∨ ¬E ∨ L = F) →
  (¬E ∨ A = (-1 : Int) + M) →
  (¬E ∨ B = (1 : Int) + N) →
  (¬E ∨ G ∧ E) →
  (¬H ∨ G) →
  (¬K ∨ K ∧ J) →
  (K = True) →
  (D = (M = (0 : Int))) →
  r2 L M N) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r1) ∧
  ((∀ (A B C D : Int),
  ∀ (E F G H I v_9 v_10 v_11 : Prop),
  (r1) →
  (r3 v_9 v_10 v_11 A B C) →
  (v_9 = True) →
  (v_10 = False) →
  (v_11 = False) →
  (D = A + B) →
  (¬G ∨ G ∧ F) →
  (¬H ∨ H ∧ G) →
  (¬I ∨ I ∧ H) →
  (¬E) →
  (I = True) →
  (E = (C = D)) →
  r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_sum_non_eq_true-unreach-call_000»
