import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_Addition01_true-unreach-call_true-no-overflow_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":159:1-159:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":61:1-108:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":109:1-118:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":119:1-146:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":147:1-157:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Prop → Prop → Prop → Int → Int → Int → Prop),
  ∃ (r3 : Prop),
  ∃ (r4 : Int → Int → Prop),
  (∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = True) →
  (v_4 = True) →
  (v_5 = True) →
  r2 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = True) →
  (v_5 = True) →
  r2 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = False) →
  (v_5 = False) →
  r2 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (r0 C A B) →
  (v_3 = True) →
  (v_4 = False) →
  (v_5 = False) →
  r2 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B : Int),
  (True) →
  r4 A B) ∧
  ((∀ (A B : Int),
  ∀ (C D : Prop),
  ∀ (E F G : Int),
  ∀ (H : Prop),
  ∀ (I J : Int),
  ∀ (K L : Prop),
  ∀ (M : Int),
  ∀ (N O : Prop),
  ∀ (P : Int),
  ∀ (Q : Prop),
  ∀ (R : Int),
  ∀ (S T : Prop),
  ∀ (U : Int),
  ∀ (V W : Prop),
  ∀ (X Y Z : Int),
  ∀ (v_26 v_27 v_28 v_29 : Prop),
  let a!1 := ¬C ∨ ¬(Z ≤ (0 : Int)) = D;
  let a!2 := ¬N ∨ ¬((0 : Int) ≤ Z) = H;
  r4 Y Z →
    r2 L v_26 v_27 A B G →
      r2 Q v_28 v_29 E F J →
        v_26 = False →
          v_27 = False →
            v_28 = False →
              v_29 = False →
                ¬V ∨ V ∧ Q ∨ V ∧ L ∨ T ∧ S ∨ O ∧ N →
                  ¬N ∨ ¬D ∨ ¬C →
                    ¬N ∨ ¬L ∨ H →
                      ¬O ∨ ¬N ∨ P = I →
                        ¬O ∨ ¬N ∨ X = P →
                          ¬O ∨ ¬N ∨ ¬H →
                            ¬Q ∨ ¬C ∨ D →
                              ¬S ∨ ¬K ∨ ¬C →
                                ¬T ∨ ¬S ∨ U = Y →
                                  ¬T ∨ ¬S ∨ X = U →
                                    ¬T ∨ ¬S ∨ K →
                                      ¬V ∨ ¬L ∨ M = G →
                                        ¬V ∨ ¬L ∨ X = M →
                                          ¬V ∨ ¬Q ∨ R = J →
                                            ¬V ∨ ¬Q ∨ X = R →
                                              ¬C ∨ ¬(Z ≤ (0 : Int)) = D →
                                                ¬C ∨ S ∧ C →
                                                  ¬L ∨ A = (-1 : Int) + Y →
                                                    ¬L ∨ B = (1 : Int) + Z →
                                                      ¬L ∨ N ∧ L →
                                                        ¬N ∨ ¬((0 : Int) ≤ Z) = H →
                                                          ¬N ∨ N ∧ C →
                                                            ¬O ∨ N →
                                                              ¬Q ∨ E = (1 : Int) + Y →
                                                                ¬Q ∨ F = (-1 : Int) + Z →
                                                                  ¬Q ∨ Q ∧ C →
                                                                    ¬T ∨ S →
                                                                      ¬W ∨ W ∧ V →
                                                                        W = True → K = (Z = (0 : Int)) → r0 X Y Z) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r3) ∧
  ((∀ (A B C D : Prop),
  ∀ (E F G H : Int),
  ∀ (I J K L M v_13 v_14 : Prop),
  let a!1 := C = (¬F ≤ (1073741823 : Int) ∨ ¬F ≥ (0 : Int));
  let a!2 := A = (¬E ≤ (1073741823 : Int) ∨ ¬E ≥ (0 : Int));
  r3 →
    r2 J v_13 v_14 E F G →
      v_13 = False →
        v_14 = False →
          ¬D ∨ a!1 →
            ¬D ∨ D ∧ B →
              ¬J ∨ I = (G = H) →
                ¬J ∨ H = E + F →
                  ¬J ∨ J ∧ D → ¬J ∨ ¬I → ¬D ∨ ¬C → ¬K ∨ K ∧ J → ¬L ∨ L ∧ K → ¬M ∨ M ∧ L → ¬A → M = True → a!2 → r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_Addition01_true-unreach-call_true-no-overflow_true-termination_000»
