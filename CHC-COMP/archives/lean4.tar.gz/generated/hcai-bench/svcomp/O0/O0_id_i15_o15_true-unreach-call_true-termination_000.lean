import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_id_i15_o15_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_i15_o15_true-unreach-call_true-termination_000.smt2":131:1-131:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_i15_o15_true-unreach-call_true-termination_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_i15_o15_true-unreach-call_true-termination_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_i15_o15_true-unreach-call_true-termination_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_i15_o15_true-unreach-call_true-termination_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_i15_o15_true-unreach-call_true-termination_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_i15_o15_true-unreach-call_true-termination_000.smt2":61:1-87:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_i15_o15_true-unreach-call_true-termination_000.smt2":88:1-97:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_i15_o15_true-unreach-call_true-termination_000.smt2":98:1-118:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_id_i15_o15_true-unreach-call_true-termination_000.smt2":119:1-129:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Prop),
  ∃ (r3 : Prop → Prop → Prop → Int → Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  (∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = True) →
  (v_3 = True) →
  (v_4 = True) →
  r3 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = True) →
  (v_4 = True) →
  r3 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = False) →
  (v_4 = False) →
  r3 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (r4 B A) →
  (v_2 = True) →
  (v_3 = False) →
  (v_4 = False) →
  r3 v_2 v_3 v_4 A B) ∧
  ((∀ (A : Int),
  (True) →
  r2 A) ∧
  ((∀ (A B C : Int),
  ∀ (D E : Prop),
  ∀ (F : Int),
  ∀ (G H : Prop),
  ∀ (I : Int),
  ∀ (J K : Prop),
  ∀ (L M : Int),
  ∀ (v_13 v_14 : Prop),
  (r2 M) →
  (r3 E v_13 v_14 A B) →
  (v_13 = False) →
  (v_14 = False) →
  (¬G ∨ ¬E ∨ ¬D) →
  (¬H ∨ ¬G ∨ I = (0 : Int)) →
  (¬H ∨ ¬G ∨ L = I) →
  (¬H ∨ ¬G ∨ D) →
  (¬J ∨ J ∧ E ∨ H ∧ G) →
  (¬J ∨ ¬E ∨ F = C) →
  (¬J ∨ ¬E ∨ L = F) →
  (¬E ∨ A = (-1 : Int) + M) →
  (¬E ∨ C = (1 : Int) + B) →
  (¬E ∨ G ∧ E) →
  (¬H ∨ G) →
  (¬K ∨ K ∧ J) →
  (K = True) →
  (D = (M = (0 : Int))) →
  r4 L M) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r1) ∧
  ((∀ (A : Int),
  ∀ (B C D E F v_6 v_7 v_8 : Prop),
  ∀ (v_9 : Int),
  (r1) →
  (r3 v_6 v_7 v_8 v_9 A) →
  (v_6 = True) →
  (v_7 = False) →
  (v_8 = False) →
  ((15 : Int) = v_9) →
  (¬D ∨ D ∧ C) →
  (¬E ∨ E ∧ D) →
  (¬F ∨ F ∧ E) →
  (¬B) →
  (F = True) →
  (B = (A = (15 : Int))) →
  r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_id_i15_o15_true-unreach-call_true-termination_000»
