import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_trex04_true-unreach-call_false-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex04_true-unreach-call_false-termination_000.smt2":183:1-183:12 (check-sat, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex04_true-unreach-call_false-termination_000.smt2":11:1-20:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex04_true-unreach-call_false-termination_000.smt2":21:1-30:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex04_true-unreach-call_false-termination_000.smt2":31:1-40:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex04_true-unreach-call_false-termination_000.smt2":41:1-51:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex04_true-unreach-call_false-termination_000.smt2":52:1-61:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex04_true-unreach-call_false-termination_000.smt2":62:1-72:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex04_true-unreach-call_false-termination_000.smt2":73:1-82:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex04_true-unreach-call_false-termination_000.smt2":83:1-126:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex04_true-unreach-call_false-termination_000.smt2":127:1-145:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex04_true-unreach-call_false-termination_000.smt2":146:1-170:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex04_true-unreach-call_false-termination_000.smt2":171:1-181:2 (clause 11, command 18)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Int → Int → Prop),
    ∃ (r1 : Prop),
    ∃ (r2 : Int → Prop),
    ∃ (r3 : Int → Int → Prop),
    ∃ (r4 : Prop → Prop → Prop → Prop),
    ∃ (r5 : Int → Prop),
    (∀ (v_0 v_1 v_2 : Prop),
    (True) →
    (v_0 = True) →
    (v_1 = True) →
    (v_2 = True) →
    r4 v_0 v_1 v_2) ∧
    ((∀ (v_0 v_1 v_2 : Prop),
    (True) →
    (v_0 = False) →
    (v_1 = True) →
    (v_2 = True) →
    r4 v_0 v_1 v_2) ∧
    ((∀ (v_0 v_1 v_2 : Prop),
    (True) →
    (v_0 = False) →
    (v_1 = False) →
    (v_2 = False) →
    r4 v_0 v_1 v_2) ∧
    ((∀ (A : Int),
    ∀ (v_1 v_2 v_3 : Prop),
    (r2 A) →
    (v_1 = True) →
    (v_2 = False) →
    (v_3 = False) →
    r4 v_1 v_2 v_3) ∧
    ((∀ (A : Int),
    (True) →
    r5 A) ∧
    ((∀ (A B : Int),
    ∀ (C D : Prop),
    ∀ (E : Int),
    (r5 E) →
    (B = E) →
    (¬D ∨ D ∧ C) →
    (D = True) →
    (A = E) →
    r2 E) ∧
    ((∀ (A B : Int),
    (True) →
    r3 A B) ∧
    ((∀ (A B C : Int),
    ∀ (D E : Prop),
    ∀ (F G : Int),
    ∀ (H I J K L : Prop),
    ∀ (M N O : Int),
    ∀ (P Q R S T U : Prop),
    ∀ (V W X : Int),
    ∀ (Y Z : Prop),
    ∀ (A1 B1 C1 : Int),
    ∀ (v_29 v_30 v_31 v_32 : Prop),
    let a!1 := D = (¬(2000001 : Int) ≤ C ∧ C ≥ (0 : Int));
    r3 O B →
      r4 I v_29 v_30 →
        r4 P v_31 v_32 →
          v_29 = False →
            v_30 = False →
              v_31 = False →
                v_32 = False →
                  A = B →
                    C = (1000000 : Int) + X →
                      ¬J ∨ ¬I ∨ L →
                        ¬L ∨ ¬K ∨ ¬J →
                          ¬Q ∨ Q ∧ I ∨ K ∧ J →
                            ¬P ∨ ¬Q ∨ S →
                              ¬S ∨ ¬R ∨ ¬Q →
                                ¬Z ∨ Z ∧ P ∨ R ∧ Q →
                                  ¬Z ∨ ¬Y ∨ A1 = X →
                                    ¬Z ∨ ¬Y ∨ B1 = A1 →
                                      ¬I ∨ J ∧ I →
                                        ¬J ∨ ¬T = H →
                                          ¬J ∨ F = O →
                                            ¬J ∨ G = O →
                                              (¬J ∨ W = if H then (1 : Int) else (0 : Int)) →
                                                ¬J ∨ J ∧ E →
                                                  ¬K ∨ J →
                                                    ¬P ∨ Q ∧ P →
                                                      ¬Q ∨ M = O →
                                                        ¬Q ∨ N = O →
                                                          ¬R ∨ Q →
                                                            ¬Y ∨ Z ∧ Y →
                                                              (¬Z ∨ V = if T then (-1 : Int) else (0 : Int)) →
                                                                (¬Z ∨ C1 = if U then V else W) →
                                                                  D = True → Y = True → a!1 → r0 B1 C1) ∧
    ((∀ (A B : Prop),
    ∀ (C D : Int),
    ∀ (E F : Prop),
    ∀ (G H I : Int),
    let a!1 := ¬F ∨ D = C + (-1 : Int) * I;
    r0 C I →
      ¬F ∨ ¬E ∨ G = D →
        ¬F ∨ ¬E ∨ H = G →
          ¬F ∨ B ∨ ¬A → ¬E ∨ F ∧ E → ¬F ∨ D = C + (-1 : Int) * I → ¬F ∨ F ∧ A → E = True → ¬(C ≤ (0 : Int)) = B → r0 H I) ∧
    ((∀ (A : Int),
    ∀ (B C : Prop),
    ∀ (D : Int),
    ∀ (E F G H : Prop),
    ∀ (I : Int),
    ∀ (J K L M N : Prop),
    let a!1 := ¬G ∨ ¬((1 : Int) ≤ D) = E;
    r0 D A →
      ¬G ∨ ¬C ∨ ¬B →
        ¬K ∨ J = (I = (0 : Int)) →
          ¬K ∨ H ∧ K →
            ¬K ∨ J →
              ¬H ∨ G ∧ H →
                ¬N ∨ M ∧ N →
                  ¬G ∨ ¬((1 : Int) ≤ D) = E →
                    (¬G ∨ I = if E then (1 : Int) else (0 : Int)) →
                      ¬G ∨ G ∧ B → ¬G ∨ ¬F → ¬L ∨ L ∧ K → ¬M ∨ M ∧ L → N = True → ¬(D ≤ (0 : Int)) = C → r1) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r1) →
    (True) →
    False))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_trex04_true-unreach-call_false-termination_000»
