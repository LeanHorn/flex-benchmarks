import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_afterrec_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_true-unreach-call_true-termination_000.smt2":153:1-153:12 (check-sat, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_true-unreach-call_true-termination_000.smt2":11:1-20:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_true-unreach-call_true-termination_000.smt2":21:1-30:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_true-unreach-call_true-termination_000.smt2":31:1-40:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_true-unreach-call_true-termination_000.smt2":41:1-51:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_true-unreach-call_true-termination_000.smt2":52:1-61:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_true-unreach-call_true-termination_000.smt2":62:1-72:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_true-unreach-call_true-termination_000.smt2":73:1-82:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_true-unreach-call_true-termination_000.smt2":83:1-98:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_true-unreach-call_true-termination_000.smt2":99:1-118:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_true-unreach-call_true-termination_000.smt2":119:1-140:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_true-unreach-call_true-termination_000.smt2":141:1-151:2 (clause 11, command 18)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Prop),
  ∃ (r2 : Prop → Prop → Prop → Int → Prop),
  ∃ (r3 : Prop),
  ∃ (r4 : Int → Prop),
  ∃ (r5 : Int → Prop),
  (∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (True) →
  (v_1 = True) →
  (v_2 = True) →
  (v_3 = True) →
  r2 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (True) →
  (v_1 = False) →
  (v_2 = True) →
  (v_3 = True) →
  r2 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (True) →
  (v_1 = False) →
  (v_2 = False) →
  (v_3 = False) →
  r2 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (r5 A) →
  (v_1 = True) →
  (v_2 = False) →
  (v_3 = False) →
  r2 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  (True) →
  r4 A) ∧
  ((∀ (A B C : Prop),
  ∀ (D : Int),
  (r4 D) →
  (¬C ∨ C ∧ B) →
  (A = True) →
  (C = True) →
  (¬((3 : Int) ≤ D) = A) →
  r5 D) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r3) ∧
  ((∀ (A B C D : Prop),
  ∀ (E F : Int),
  (r3) →
  (¬D ∨ ¬C ∨ F = E) →
  (¬C ∨ D ∧ C) →
  (¬D ∨ D ∧ B) →
  (¬A) →
  (C = True) →
  (¬D ∨ ¬C ∨ E = (2 : Int)) →
  r1 F) ∧
  ((∀ (A B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F : Int),
  ∀ (G H : Prop),
  ∀ (I J : Int),
  (r1 C) →
  (¬H ∨ ¬E ∨ ¬D) →
  (¬H ∨ ¬G ∨ I = F) →
  (¬H ∨ ¬G ∨ J = I) →
  (¬D ∨ F = (-1 : Int) + C) →
  (¬D ∨ D ∧ B) →
  (¬G ∨ H ∧ G) →
  (¬H ∨ H ∧ D) →
  (¬A) →
  (G = True) →
  (¬((3 : Int) ≤ C) = A) →
  r1 J) ∧
  ((∀ (A B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F : Int),
  ∀ (G H I v_9 v_10 : Prop),
  (r1 C) →
  (r2 G v_9 v_10 F) →
  (v_9 = False) →
  (v_10 = False) →
  (¬G ∨ E ∨ ¬D) →
  (¬I ∨ H ∧ I) →
  (¬D ∨ F = (-1 : Int) + C) →
  (¬D ∨ D ∧ B) →
  (¬G ∨ G ∧ D) →
  (¬H ∨ H ∧ G) →
  (¬A) →
  (I = True) →
  (¬((3 : Int) ≤ C) = A) →
  r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_afterrec_true-unreach-call_true-termination_000»
