import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_n.c11_true-unreach-call_false-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_n.c11_true-unreach-call_false-termination_000.smt2":89:1-89:12 (check-sat, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_n.c11_true-unreach-call_false-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_n.c11_true-unreach-call_false-termination_000.smt2":18:1-31:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_n.c11_true-unreach-call_false-termination_000.smt2":32:1-51:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_n.c11_true-unreach-call_false-termination_000.smt2":52:1-76:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_n.c11_true-unreach-call_false-termination_000.smt2":77:1-87:2 (clause 5, command 9)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Int → Int → Prop),
    ∃ (r1 : Int → Prop),
    ∃ (r2 : Prop),
    (∀ (A : Int),
    (True) →
    r1 A) ∧
    ((∀ (A B : Prop),
    ∀ (C D E : Int),
    (r1 E) →
    (¬B ∨ ¬A ∨ D = C) →
    (¬A ∨ B ∧ A) →
    (A = True) →
    (¬B ∨ ¬A ∨ C = (0 : Int)) →
    r0 D E) ∧
    ((∀ (A : Int),
    ∀ (B C : Prop),
    ∀ (D : Int),
    ∀ (E : Prop),
    ∀ (F G : Int),
    ∀ (H I : Prop),
    ∀ (J K L : Int),
    (r0 D L) →
    (¬I ∨ ¬B ∨ C) →
    (¬I ∨ ¬H ∨ J = G) →
    (¬I ∨ ¬H ∨ K = J) →
    (¬H ∨ I ∧ H) →
    (¬I ∨ E = (D = (4 : Int))) →
    (¬I ∨ F = (1 : Int) + D) →
    (¬I ∨ G = if E then (1 : Int) else F) →
    (¬I ∨ I ∧ B) →
    (H = True) →
    (A = L) →
    r0 K L) ∧
    ((∀ (A B : Int),
    ∀ (C D : Prop),
    ∀ (E : Int),
    ∀ (F G H I : Prop),
    ∀ (J : Int),
    ∀ (K L M N O : Prop),
    let a!1 := F = (¬(5 : Int) ≤ E ∧ E ≥ (0 : Int));
    r0 E B →
      ¬H ∨ ¬D ∨ ¬C →
        ¬I ∨ H ∧ I →
          ¬M ∨ L ∧ M →
            ¬N ∨ N ∧ M →
              ¬O ∨ O ∧ N →
                ¬H ∨ a!1 →
                  (¬H ∨ J = if F then (1 : Int) else (0 : Int)) →
                    ¬H ∨ H ∧ C → ¬H ∨ ¬G → ¬L ∨ K = (J = (0 : Int)) → ¬L ∨ L ∧ I → ¬L ∨ K → O = True → A = B → r2) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r2) →
    (True) →
    False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_n.c11_true-unreach-call_false-termination_000»
