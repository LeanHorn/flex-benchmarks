import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_trex01_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex01_true-unreach-call_true-termination_000.smt2":100:1-100:12 (check-sat, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex01_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex01_true-unreach-call_true-termination_000.smt2":18:1-44:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex01_true-unreach-call_true-termination_000.smt2":45:1-62:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex01_true-unreach-call_true-termination_000.smt2":63:1-87:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex01_true-unreach-call_true-termination_000.smt2":88:1-98:2 (clause 5, command 9)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Int → Int → Prop),
    ∃ (r1 : Prop),
    ∃ (r2 : Int → Int → Prop),
    (∀ (A B : Int),
    (True) →
    r2 A B) ∧
    ((∀ (A B : Int),
    ∀ (C D E F G H I J : Prop),
    ∀ (K L M N : Int),
    ∀ (O P : Prop),
    ∀ (Q R S : Int),
    (r2 N B) →
    (¬F ∨ ¬E ∨ ¬D) →
    (¬E ∨ F ∨ ¬H) →
    (¬P ∨ P ∧ J ∨ P ∧ I) →
    (¬P ∨ ¬O ∨ Q = (1 : Int)) →
    (¬P ∨ ¬O ∨ R = Q) →
    (¬D ∨ E ∧ D) →
    (¬D ∨ ¬C) →
    (¬H ∨ H ∧ E) →
    (¬H ∨ ¬G) →
    (¬I ∨ I ∧ D) →
    (¬J ∨ J ∧ H) →
    (¬O ∨ P ∧ O) →
    (¬P ∨ K = N) →
    (¬P ∨ L = N) →
    (¬P ∨ M = N) →
    (O = True) →
    (A = B) →
    r0 R S) ∧
    ((∀ (A B : Prop),
    ∀ (C D : Int),
    ∀ (E F : Prop),
    ∀ (G H I : Int),
    (r0 C I) →
    (¬F ∨ ¬E ∨ G = D) →
    (¬F ∨ ¬E ∨ H = G) →
    (¬F ∨ B ∨ ¬A) →
    (¬E ∨ F ∧ E) →
    (¬F ∨ D = (2 : Int) * C) →
    (¬F ∨ A ∧ F) →
    (E = True) →
    (¬(I ≤ C) = B) →
    r0 H I) ∧
    ((∀ (A : Int),
    ∀ (B C : Prop),
    ∀ (D : Int),
    ∀ (E F G H : Prop),
    ∀ (I : Int),
    ∀ (J K L M N : Prop),
    let a!1 := ¬G ∨ ¬(D ≤ (0 : Int)) = E;
    r0 D A →
      ¬G ∨ ¬C ∨ ¬B →
        ¬H ∨ G ∧ H →
          ¬L ∨ K ∧ L →
            ¬M ∨ M ∧ L →
              ¬N ∨ N ∧ M →
                ¬K ∨ J = (I = (0 : Int)) →
                  ¬K ∨ K ∧ H →
                    ¬K ∨ J →
                      ¬G ∨ ¬(D ≤ (0 : Int)) = E →
                        (¬G ∨ I = if E then (1 : Int) else (0 : Int)) → ¬G ∨ G ∧ B → ¬G ∨ ¬F → N = True → ¬(A ≤ D) = C → r1) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r1) →
    (True) →
    False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_trex01_true-unreach-call_true-termination_000»
