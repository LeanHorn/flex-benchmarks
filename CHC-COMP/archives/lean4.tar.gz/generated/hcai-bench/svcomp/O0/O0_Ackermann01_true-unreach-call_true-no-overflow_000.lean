import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_Ackermann01_true-unreach-call_true-no-overflow_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":159:1-159:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":61:1-102:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":103:1-112:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":113:1-146:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":147:1-157:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Prop → Prop → Prop → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  (∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = True) →
  (v_4 = True) →
  (v_5 = True) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = True) →
  (v_5 = True) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = False) →
  (v_5 = False) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (r1 C B A) →
  (v_3 = True) →
  (v_4 = False) →
  (v_5 = False) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B : Int),
  (True) →
  r4 A B) ∧
  ((∀ (A B : Int),
  ∀ (C D : Prop),
  ∀ (E : Int),
  ∀ (F G : Prop),
  ∀ (H I J : Int),
  ∀ (K : Prop),
  ∀ (L : Int),
  ∀ (M : Prop),
  ∀ (N : Int),
  ∀ (O : Prop),
  ∀ (P : Int),
  ∀ (Q R : Prop),
  ∀ (S T U : Int),
  ∀ (v_21 v_22 v_23 v_24 v_25 v_26 : Prop),
  ∀ (v_27 : Int),
  (r4 T U) →
  (r3 K v_21 v_22 U A B) →
  (r3 K v_23 v_24 E B H) →
  (r3 M v_25 v_26 E v_27 I) →
  (v_21 = False) →
  (v_22 = False) →
  (v_23 = False) →
  (v_24 = False) →
  (v_25 = False) →
  (v_26 = False) →
  ((1 : Int) = v_27) →
  (¬Q ∨ Q ∧ O ∨ Q ∧ M ∨ Q ∧ K) →
  (¬G ∨ ¬F ∨ ¬C) →
  (¬K ∨ ¬D ∨ ¬C) →
  (¬M ∨ ¬C ∨ D) →
  (¬O ∨ G ∨ ¬F) →
  (¬Q ∨ ¬K ∨ L = H) →
  (¬Q ∨ ¬K ∨ S = L) →
  (¬Q ∨ ¬M ∨ N = I) →
  (¬Q ∨ ¬M ∨ S = N) →
  (¬Q ∨ ¬O ∨ P = J) →
  (¬Q ∨ ¬O ∨ S = P) →
  (¬C ∨ D = (T = (0 : Int))) →
  (¬C ∨ E = (-1 : Int) + U) →
  (¬C ∨ F ∧ C) →
  (¬K ∨ A = (-1 : Int) + T) →
  (¬K ∨ K ∧ C) →
  (¬M ∨ M ∧ C) →
  (¬O ∨ J = (1 : Int) + T) →
  (¬O ∨ O ∧ F) →
  (¬R ∨ R ∧ Q) →
  (R = True) →
  (G = (U = (0 : Int))) →
  r1 S T U) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r2) ∧
  ((∀ (A B C D : Prop),
  ∀ (E F : Int),
  ∀ (G H : Prop),
  ∀ (I : Int),
  ∀ (J K L M N O P v_16 v_17 : Prop),
  let a!1 := C = (¬F ≤ (23 : Int) ∨ ¬F ≥ (0 : Int));
  let a!2 := ¬M ∨ ¬((0 : Int) ≤ F) = H;
  let a!3 := ¬M ∨ ¬((0 : Int) ≤ E) = G;
  let a!4 := ¬M ∨ ¬(I ≤ (-1 : Int)) = K;
  let a!5 := A = (¬E ≤ (3 : Int) ∨ ¬E ≥ (0 : Int));
  r2 →
    r3 M v_16 v_17 E F I →
      v_16 = False →
        v_17 = False →
          ¬D ∨ a!1 →
            ¬D ∨ B ∧ D →
              ¬D ∨ ¬C →
                ¬N ∨ M ∧ N →
                  ¬M ∨ ¬((0 : Int) ≤ F) = H →
                    ¬M ∨ ¬((0 : Int) ≤ E) = G →
                      ¬M ∨ ¬(I ≤ (-1 : Int)) = K →
                        ¬M ∨ J = (H ∨ G) →
                          ¬M ∨ L = (J ∨ K) → ¬M ∨ M ∧ D → ¬M ∨ ¬L → ¬O ∨ O ∧ N → ¬P ∨ P ∧ O → ¬A → P = True → a!5 → r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_Ackermann01_true-unreach-call_true-no-overflow_000»
