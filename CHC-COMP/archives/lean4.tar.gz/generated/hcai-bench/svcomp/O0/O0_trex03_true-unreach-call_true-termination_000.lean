import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_trex03_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex03_true-unreach-call_true-termination_000.smt2":147:1-147:12 (check-sat, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex03_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex03_true-unreach-call_true-termination_000.smt2":18:1-45:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex03_true-unreach-call_true-termination_000.smt2":46:1-102:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex03_true-unreach-call_true-termination_000.smt2":103:1-134:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_trex03_true-unreach-call_true-termination_000.smt2":135:1-145:2 (clause 5, command 9)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Prop),
    ∃ (r1 : Int → Int → Prop),
    ∃ (r2 : Int → Prop → Int → Int → Int → Int → Prop),
    (∀ (A B : Int),
    (True) →
    r1 A B) ∧
    ((∀ (A B C D E : Int),
    ∀ (F : Prop),
    ∀ (G : Int),
    ∀ (H : Prop),
    ∀ (I J K L : Int),
    ∀ (M : Prop),
    ∀ (N O P : Int),
    ∀ (Q R : Prop),
    ∀ (S T : Int),
    ∀ (U : Prop),
    ∀ (V W X Y : Int),
    (r1 T D) →
    (B = D) →
    (C = D) →
    (E = T) →
    (G = T) →
    (I = if F then (1 : Int) else (0 : Int)) →
    (¬R ∨ ¬Q ∨ M = H) →
    (¬R ∨ ¬Q ∨ U = M) →
    (¬R ∨ ¬Q ∨ N = I) →
    (¬R ∨ ¬Q ∨ O = J) →
    (¬R ∨ ¬Q ∨ P = K) →
    (¬R ∨ ¬Q ∨ S = L) →
    (¬R ∨ ¬Q ∨ V = N) →
    (¬R ∨ ¬Q ∨ W = O) →
    (¬R ∨ ¬Q ∨ X = P) →
    (¬R ∨ ¬Q ∨ Y = S) →
    (¬Q ∨ R ∧ Q) →
    (Q = True) →
    (A = D) →
    r2 T U V W X Y) ∧
    ((∀ (A B C D E F : Prop),
    ∀ (G : Int),
    ∀ (H I J : Prop),
    ∀ (K : Int),
    ∀ (L M : Prop),
    ∀ (N O P Q R S T U V : Int),
    ∀ (W : Prop),
    ∀ (X Y Z : Int),
    ∀ (A1 : Prop),
    ∀ (B1 C1 : Int),
    ∀ (D1 : Prop),
    ∀ (E1 : Int),
    ∀ (F1 : Prop),
    ∀ (G1 H1 I1 J1 : Int),
    ∀ (K1 : Prop),
    ∀ (L1 M1 N1 : Int),
    ∀ (O1 P1 : Prop),
    ∀ (Q1 R1 : Int),
    ∀ (S1 : Prop),
    ∀ (T1 U1 V1 W1 : Int),
    (r2 R1 J G R S Q) →
    (¬(R = (0 : Int)) = D) →
    (¬(S = (0 : Int)) = A) →
    (C = (B ∧ A)) →
    (F = (D ∧ C)) →
    (¬H ∨ ¬E ∨ F) →
    (¬W ∨ ¬H ∨ I) →
    (¬A1 ∨ ¬I ∨ ¬H) →
    (¬P1 ∨ P1 ∧ A1 ∨ P1 ∧ W) →
    (¬P1 ∨ ¬W ∨ U = O) →
    (¬P1 ∨ ¬W ∨ V = P) →
    (¬P1 ∨ ¬W ∨ X = Q) →
    (¬P1 ∨ ¬W ∨ H1 = U) →
    (¬P1 ∨ ¬W ∨ I1 = V) →
    (¬P1 ∨ ¬W ∨ J1 = X) →
    (¬P1 ∨ ¬A1 ∨ Y = R) →
    (¬P1 ∨ ¬A1 ∨ Z = S) →
    (¬P1 ∨ ¬A1 ∨ B1 = T) →
    (¬P1 ∨ ¬A1 ∨ H1 = Y) →
    (¬P1 ∨ ¬A1 ∨ I1 = Z) →
    (¬P1 ∨ ¬A1 ∨ J1 = B1) →
    (¬P1 ∨ ¬O1 ∨ K1 = F1) →
    (¬P1 ∨ ¬O1 ∨ S1 = K1) →
    (¬P1 ∨ ¬O1 ∨ L1 = G1) →
    (¬P1 ∨ ¬O1 ∨ M1 = H1) →
    (¬P1 ∨ ¬O1 ∨ N1 = I1) →
    (¬P1 ∨ ¬O1 ∨ Q1 = J1) →
    (¬P1 ∨ ¬O1 ∨ T1 = L1) →
    (¬P1 ∨ ¬O1 ∨ U1 = M1) →
    (¬P1 ∨ ¬O1 ∨ V1 = N1) →
    (¬P1 ∨ ¬O1 ∨ W1 = Q1) →
    (¬H ∨ I = (G = (0 : Int))) →
    (¬H ∨ H ∧ E) →
    (¬W ∨ ¬J = L) →
    (¬W ∨ ¬L = M) →
    (¬W ∨ K = if L then (-1 : Int) else (0 : Int)) →
    (¬W ∨ N = if M then (-1 : Int) else (0 : Int)) →
    (¬W ∨ O = R + K) →
    (¬W ∨ P = S + N) →
    (¬W ∨ W ∧ H) →
    (¬A1 ∨ T = (-1 : Int) + Q) →
    (¬A1 ∨ A1 ∧ H) →
    (¬O1 ∨ P1 ∧ O1) →
    (¬P1 ∨ C1 = R1) →
    (¬P1 ∨ E1 = R1) →
    (¬P1 ∨ G1 = if D1 then (1 : Int) else (0 : Int)) →
    (O1 = True) →
    (¬(Q = (0 : Int)) = B) →
    r2 R1 S1 T1 U1 V1 W1) ∧
    ((∀ (A : Int),
    ∀ (B : Prop),
    ∀ (C : Int),
    ∀ (D E F G H I : Prop),
    ∀ (J K : Int),
    ∀ (L M : Prop),
    ∀ (N : Int),
    ∀ (O P Q R S T : Prop),
    ∀ (U : Int),
    ∀ (V W X Y Z : Prop),
    (r2 A B C N K J) →
    (¬(J = (0 : Int)) = E) →
    (¬(K = (0 : Int)) = D) →
    (F = (E ∧ D)) →
    (I = (G ∧ F)) →
    (¬S ∨ ¬I ∨ ¬H) →
    (¬T ∨ S ∧ T) →
    (¬W ∨ V = (U = (0 : Int))) →
    (¬W ∨ W ∧ T) →
    (¬X ∨ X ∧ W) →
    (¬Y ∨ Y ∧ X) →
    (¬Z ∨ Z ∧ Y) →
    (¬S ∨ L = (J = (0 : Int))) →
    (¬S ∨ M = (K = (0 : Int))) →
    (¬S ∨ O = (M ∨ L)) →
    (¬S ∨ P = (N = (0 : Int))) →
    (¬S ∨ Q = (P ∨ O)) →
    (¬S ∨ U = if Q then (1 : Int) else (0 : Int)) →
    (¬S ∨ S ∧ H) →
    (¬S ∨ ¬R) →
    (V ∨ ¬W) →
    (Z = True) →
    (¬(N = (0 : Int)) = G) →
    r0) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r0) →
    (True) →
    False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_trex03_true-unreach-call_true-termination_000»
