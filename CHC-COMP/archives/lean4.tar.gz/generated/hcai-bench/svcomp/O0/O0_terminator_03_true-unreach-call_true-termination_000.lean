import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_terminator_03_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_terminator_03_true-unreach-call_true-termination_000.smt2":158:1-158:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_terminator_03_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_terminator_03_true-unreach-call_true-termination_000.smt2":18:1-39:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_terminator_03_true-unreach-call_true-termination_000.smt2":40:1-57:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_terminator_03_true-unreach-call_true-termination_000.smt2":58:1-104:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_terminator_03_true-unreach-call_true-termination_000.smt2":105:1-145:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_terminator_03_true-unreach-call_true-termination_000.smt2":146:1-156:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Int → Prop),
    ∃ (r1 : Prop),
    ∃ (r2 : Int → Int → Prop),
    (∀ (A : Int),
    (True) →
    r0 A) ∧
    ((∀ (A B C : Int),
    ∀ (D E F : Prop),
    ∀ (G : Int),
    ∀ (H I : Prop),
    ∀ (J K L : Int),
    let a!1 := ¬I ∨ ¬(L ≤ (0 : Int)) = F;
    r0 C →
      A = C →
        B = C →
          ¬I ∨ ¬H ∨ J = G →
            ¬I ∨ ¬H ∨ K = J →
              ¬I ∨ ¬H ∨ F →
                ¬H ∨ I ∧ H →
                  ¬I ∨ ¬(L ≤ (0 : Int)) = F → ¬I ∨ I ∧ E → D = True → H = True → ¬((1000001 : Int) ≤ L) = D → r2 K L) ∧
    ((∀ (A B : Prop),
    ∀ (C D : Int),
    ∀ (E F : Prop),
    ∀ (G H I : Int),
    (r2 C I) →
    (¬F ∨ B ∨ ¬A) →
    (¬F ∨ ¬E ∨ G = D) →
    (¬F ∨ ¬E ∨ H = G) →
    (¬E ∨ F ∧ E) →
    (¬F ∨ D = C + I) →
    (¬F ∨ F ∧ A) →
    (E = True) →
    (¬((100 : Int) ≤ C) = B) →
    r2 H I) ∧
    ((∀ (A B C : Int),
    ∀ (D E F : Prop),
    ∀ (G : Int),
    ∀ (H : Prop),
    ∀ (I J K : Int),
    ∀ (L M N O P Q R S T U V W X : Prop),
    ∀ (Y : Int),
    ∀ (Z A1 B1 C1 D1 : Prop),
    let a!1 := ¬H ∨ ¬(J ≤ (0 : Int)) = F;
    let a!2 := ¬P ∨ ¬(J ≤ (0 : Int)) = L;
    let a!3 := ¬P ∨ ¬(K ≤ (99 : Int)) = M;
    let a!4 := ¬R ∨ ¬((1 : Int) ≤ J) = O;
    r0 C →
      A = C →
        B = C →
          ¬R ∨ ¬H ∨ I = G →
            ¬R ∨ ¬H ∨ K = I →
              ¬R ∨ ¬H ∨ ¬F →
                ¬R ∨ ¬P ∨ ¬O →
                  ¬S ∨ ¬R ∨ U = T →
                    ¬S ∨ ¬R ∨ O →
                      ¬S ∨ ¬R ∨ T →
                        ¬W ∨ W ∧ P ∨ S ∧ R →
                          ¬W ∨ ¬P ∨ Q = N →
                            ¬W ∨ ¬P ∨ U = Q →
                              ¬H ∨ ¬(J ≤ (0 : Int)) = F →
                                ¬H ∨ H ∧ E →
                                  ¬P ∨ ¬(J ≤ (0 : Int)) = L →
                                    ¬P ∨ ¬(K ≤ (99 : Int)) = M →
                                      ¬P ∨ N = (M ∧ L) →
                                        ¬P ∨ R ∧ P →
                                          ¬R ∨ ¬((1 : Int) ≤ J) = O →
                                            ¬R ∨ R ∧ H →
                                              ¬S ∨ R →
                                                ¬B1 ∨ A1 ∧ B1 →
                                                  ¬C1 ∨ C1 ∧ B1 →
                                                    ¬D1 ∨ D1 ∧ C1 →
                                                      (¬W ∨ Y = if U then (1 : Int) else (0 : Int)) →
                                                        ¬W ∨ ¬V →
                                                          ¬X ∨ X ∧ W →
                                                            ¬A1 ∨ Z = (Y = (0 : Int)) →
                                                              ¬A1 ∨ A1 ∧ X →
                                                                ¬A1 ∨ Z →
                                                                  D = True → D1 = True → ¬((1000001 : Int) ≤ J) = D → r1) ∧
    ((∀ (A : Prop),
    ∀ (B : Int),
    ∀ (C : Prop),
    ∀ (D E F : Int),
    ∀ (G H I J K L M N O P Q R S : Prop),
    ∀ (T : Int),
    ∀ (U V W X Y : Prop),
    let a!1 := ¬K ∨ ¬(E ≤ (0 : Int)) = G;
    let a!2 := ¬K ∨ ¬(F ≤ (99 : Int)) = H;
    let a!3 := ¬M ∨ ¬((1 : Int) ≤ E) = J;
    r2 B E →
      ¬M ∨ ¬C ∨ D = B →
        ¬M ∨ ¬C ∨ F = D →
          ¬M ∨ ¬C ∨ ¬A →
            ¬M ∨ ¬K ∨ ¬J →
              ¬N ∨ ¬M ∨ P = O →
                ¬N ∨ ¬M ∨ J →
                  ¬N ∨ ¬M ∨ O →
                    ¬R ∨ R ∧ K ∨ N ∧ M →
                      ¬R ∨ ¬K ∨ L = I →
                        ¬R ∨ ¬K ∨ P = L →
                          ¬K ∨ ¬(E ≤ (0 : Int)) = G →
                            ¬K ∨ ¬(F ≤ (99 : Int)) = H →
                              ¬K ∨ I = (H ∧ G) →
                                ¬K ∨ M ∧ K →
                                  ¬M ∨ ¬((1 : Int) ≤ E) = J →
                                    ¬M ∨ M ∧ C →
                                      ¬N ∨ M →
                                        ¬W ∨ V ∧ W →
                                          ¬X ∨ X ∧ W →
                                            ¬Y ∨ Y ∧ X →
                                              (¬R ∨ T = if P then (1 : Int) else (0 : Int)) →
                                                ¬R ∨ ¬Q →
                                                  ¬S ∨ S ∧ R →
                                                    ¬V ∨ U = (T = (0 : Int)) →
                                                      ¬V ∨ V ∧ S → ¬V ∨ U → Y = True → ¬((100 : Int) ≤ B) = A → r1) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r1) →
    (True) →
    False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_terminator_03_true-unreach-call_true-termination_000»
