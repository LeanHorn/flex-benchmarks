import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_afterrec_2calls_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":239:1-239:12 (check-sat, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":14:1-23:2 (clause 1, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":24:1-33:2 (clause 2, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":34:1-43:2 (clause 3, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":44:1-54:2 (clause 4, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":55:1-64:2 (clause 5, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":65:1-75:2 (clause 6, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":76:1-85:2 (clause 7, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":86:1-95:2 (clause 8, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":96:1-105:2 (clause 9, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":106:1-116:2 (clause 10, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":117:1-126:2 (clause 11, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":127:1-137:2 (clause 12, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":138:1-147:2 (clause 13, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":148:1-163:2 (clause 14, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":164:1-191:2 (clause 15, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":192:1-226:2 (clause 16, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_afterrec_2calls_true-unreach-call_true-termination_000.smt2":227:1-237:2 (clause 17, command 27)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop → Prop → Prop → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Prop),
  ∃ (r3 : Prop → Prop → Prop → Int → Prop),
  ∃ (r4 : Prop),
  ∃ (r5 : Int → Prop),
  ∃ (r6 : Int → Prop),
  ∃ (r7 : Int → Prop),
  ∃ (r8 : Int → Prop),
  (∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (True) →
  (v_1 = True) →
  (v_2 = True) →
  (v_3 = True) →
  r0 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (True) →
  (v_1 = False) →
  (v_2 = True) →
  (v_3 = True) →
  r0 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (True) →
  (v_1 = False) →
  (v_2 = False) →
  (v_3 = False) →
  r0 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (r5 A) →
  (v_1 = True) →
  (v_2 = False) →
  (v_3 = False) →
  r0 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  (True) →
  r6 A) ∧
  ((∀ (A B C : Prop),
  ∀ (D : Int),
  (r6 D) →
  (¬C ∨ C ∧ B) →
  (A = True) →
  (C = True) →
  (¬((3 : Int) ≤ D) = A) →
  r5 D) ∧
  ((∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (True) →
  (v_1 = True) →
  (v_2 = True) →
  (v_3 = True) →
  r3 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (True) →
  (v_1 = False) →
  (v_2 = True) →
  (v_3 = True) →
  r3 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (True) →
  (v_1 = False) →
  (v_2 = False) →
  (v_3 = False) →
  r3 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  ∀ (v_1 v_2 v_3 : Prop),
  (r8 A) →
  (v_1 = True) →
  (v_2 = False) →
  (v_3 = False) →
  r3 v_1 v_2 v_3 A) ∧
  ((∀ (A : Int),
  (True) →
  r7 A) ∧
  ((∀ (A B C : Prop),
  ∀ (D : Int),
  (r7 D) →
  (¬C ∨ C ∧ B) →
  (A = True) →
  (C = True) →
  (¬((3 : Int) ≤ D) = A) →
  r8 D) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r4) ∧
  ((∀ (A B C D : Prop),
  ∀ (E F : Int),
  (r4) →
  (¬D ∨ ¬C ∨ F = E) →
  (¬C ∨ D ∧ C) →
  (¬D ∨ D ∧ B) →
  (¬A) →
  (C = True) →
  (¬D ∨ ¬C ∨ E = (2 : Int)) →
  r2 F) ∧
  ((∀ (A B : Prop),
  ∀ (C : Int),
  ∀ (D E F G H : Prop),
  ∀ (I : Int),
  ∀ (J K : Prop),
  ∀ (L : Int),
  ∀ (M N : Prop),
  ∀ (O P : Int),
  let a!1 := ¬H ∨ ¬((3 : Int) ≤ I) = G;
  r2 C →
    ¬F ∨ ¬E ∨ ¬D →
      ¬N ∨ ¬K ∨ ¬J →
        ¬N ∨ ¬M ∨ O = L →
          ¬N ∨ ¬M ∨ P = O →
            ¬D ∨ I = (-1 : Int) + C →
              ¬D ∨ D ∧ B →
                ¬F ∨ F ∧ D →
                  ¬H ∨ ¬((3 : Int) ≤ I) = G →
                    ¬H ∨ H ∧ F →
                      ¬H ∨ ¬G →
                        ¬J ∨ L = (-1 : Int) + I →
                          ¬J ∨ J ∧ H → ¬M ∨ N ∧ M → ¬N ∨ N ∧ J → ¬A → M = True → ¬((3 : Int) ≤ C) = A → r2 P) ∧
  ((∀ (A B : Prop),
  ∀ (C : Int),
  ∀ (D E F G H : Prop),
  ∀ (I : Int),
  ∀ (J K : Prop),
  ∀ (L : Int),
  ∀ (M N O P v_16 v_17 v_18 v_19 : Prop),
  let a!1 := ¬F ∨ ¬((3 : Int) ≤ L) = E;
  r2 C →
    r3 M v_16 v_17 I →
      r0 N v_18 v_19 L →
        v_16 = False →
          v_17 = False →
            v_18 = False →
              v_19 = False →
                ¬K ∨ ¬J ∨ ¬D →
                  ¬M ∨ H ∨ ¬G →
                    ¬N ∨ ¬J ∨ K →
                      ¬O ∨ O ∧ N ∨ O ∧ M →
                        ¬P ∨ O ∧ P →
                          ¬D ∨ J ∧ D →
                            ¬F ∨ ¬((3 : Int) ≤ L) = E →
                              ¬F ∨ F ∧ D →
                                ¬F ∨ ¬E →
                                  ¬G ∨ I = (-1 : Int) + L →
                                    ¬G ∨ G ∧ F →
                                      ¬J ∨ L = (-1 : Int) + C →
                                        ¬J ∨ J ∧ B → ¬M ∨ M ∧ G → ¬N ∨ N ∧ J → P = True → ¬A → ¬((3 : Int) ≤ C) = A → r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_afterrec_2calls_true-unreach-call_true-termination_000»
