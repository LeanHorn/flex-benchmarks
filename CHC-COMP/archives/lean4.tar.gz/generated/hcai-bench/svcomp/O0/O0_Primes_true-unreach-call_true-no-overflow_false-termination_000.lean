import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_Primes_true-unreach-call_true-no-overflow_false-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":481:1-481:12 (check-sat, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":19:1-28:2 (clause 1, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":29:1-38:2 (clause 2, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":39:1-48:2 (clause 3, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":49:1-59:2 (clause 4, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":60:1-69:2 (clause 5, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":70:1-126:2 (clause 6, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":127:1-136:2 (clause 7, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":137:1-146:2 (clause 8, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":147:1-156:2 (clause 9, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":157:1-167:2 (clause 10, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":168:1-177:2 (clause 11, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":178:1-242:2 (clause 12, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":243:1-252:2 (clause 13, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":253:1-262:2 (clause 14, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":263:1-272:2 (clause 15, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":273:1-283:2 (clause 16, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":284:1-293:2 (clause 17, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":294:1-310:2 (clause 18, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":311:1-320:2 (clause 19, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":321:1-330:2 (clause 20, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":331:1-340:2 (clause 21, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":341:1-351:2 (clause 22, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":352:1-361:2 (clause 23, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":362:1-413:2 (clause 24, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":414:1-423:2 (clause 25, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":424:1-468:2 (clause 26, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":469:1-479:2 (clause 27, command 42)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  ∃ (r3 : Prop → Prop → Prop → Int → Int → Int → Prop),
  ∃ (r4 : Prop),
  ∃ (r5 : Prop → Prop → Prop → Int → Int → Prop),
  ∃ (r6 : Prop → Prop → Prop → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Prop),
  ∃ (r10 : Int → Int → Prop),
  ∃ (r11 : Int → Prop),
  ∃ (r12 : Int → Int → Prop),
  ∃ (r13 : Prop → Prop → Prop → Int → Int → Int → Prop),
  (∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = True) →
  (v_4 = True) →
  (v_5 = True) →
  r6 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = True) →
  (v_5 = True) →
  r6 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = False) →
  (v_5 = False) →
  r6 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (r8 C B A) →
  (v_3 = True) →
  (v_4 = False) →
  (v_5 = False) →
  r6 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B : Int),
  (True) →
  r12 A B) ∧
  ((∀ (A : Int),
  ∀ (B C : Prop),
  ∀ (D : Int),
  ∀ (E F : Prop),
  ∀ (G H : Int),
  ∀ (I J : Prop),
  ∀ (K L : Int),
  ∀ (M : Prop),
  ∀ (N : Int),
  ∀ (O P : Prop),
  ∀ (Q : Int),
  ∀ (R S : Prop),
  ∀ (T : Int),
  ∀ (U : Prop),
  ∀ (V : Int),
  ∀ (W : Prop),
  ∀ (X : Int),
  ∀ (Y Z : Prop),
  ∀ (A1 B1 C1 : Int),
  ∀ (v_29 v_30 v_31 v_32 v_33 v_34 : Prop),
  let a!1 := ¬B ∨ ¬((0 : Int) ≤ C1) = C;
  let a!2 := ¬M ∨ A = C1 + (-1 : Int) * B1;
  r12 B1 C1 →
    r6 M v_29 v_30 A B1 H →
      r6 U v_31 v_32 D B1 K →
        r6 W v_33 v_34 C1 G L →
          v_29 = False →
            v_30 = False →
              v_31 = False →
                v_32 = False →
                  v_33 = False →
                    v_34 = False →
                      ¬Y ∨ Y ∧ W ∨ Y ∧ U ∨ Y ∧ M ∨ S ∧ R ∨ P ∧ O →
                        ¬F ∨ ¬E ∨ ¬B →
                          ¬O ∨ ¬M ∨ ¬I →
                            ¬P ∨ ¬O ∨ Q = (1 : Int) →
                              ¬P ∨ ¬O ∨ A1 = Q →
                                ¬P ∨ ¬O ∨ I →
                                  ¬R ∨ ¬C ∨ ¬B →
                                    ¬R ∨ ¬O ∨ ¬J →
                                      ¬S ∨ ¬R ∨ T = (0 : Int) →
                                        ¬S ∨ ¬R ∨ A1 = T →
                                          ¬S ∨ ¬R ∨ J →
                                            ¬U ∨ C ∨ ¬B →
                                              ¬E ∨ ¬W ∨ F →
                                                ¬Y ∨ ¬M ∨ N = H →
                                                  ¬Y ∨ ¬M ∨ A1 = N →
                                                    ¬Y ∨ ¬U ∨ V = K →
                                                      ¬Y ∨ ¬U ∨ A1 = V →
                                                        ¬Y ∨ ¬W ∨ X = L →
                                                          ¬Y ∨ ¬W ∨ A1 = X →
                                                            ¬B ∨ ¬((0 : Int) ≤ C1) = C →
                                                              ¬B ∨ E ∧ B →
                                                                ¬M ∨ A = C1 + (-1 : Int) * B1 →
                                                                  ¬M ∨ O ∧ M →
                                                                    ¬O ∨ I = (C1 = (0 : Int)) →
                                                                      ¬O ∨ R ∧ O →
                                                                        ¬P ∨ O →
                                                                          ¬R ∨ J = (B1 = (0 : Int)) →
                                                                            ¬R ∨ R ∧ B →
                                                                              ¬S ∨ R →
                                                                                ¬U ∨ D = (-1 : Int) * C1 →
                                                                                  ¬U ∨ U ∧ B →
                                                                                    ¬W ∨ G = (-1 : Int) * B1 →
                                                                                      ¬W ∨ W ∧ E →
                                                                                        ¬Z ∨ Z ∧ Y →
                                                                                          Z = True →
                                                                                            ¬((0 : Int) ≤ B1) = F →
                                                                                              r8 A1 B1 C1) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = True) →
  (v_4 = True) →
  (v_5 = True) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = True) →
  (v_5 = True) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = False) →
  (v_5 = False) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (r7 C B A) →
  (v_3 = True) →
  (v_4 = False) →
  (v_5 = False) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B : Int),
  (True) →
  r2 A B) ∧
  ((∀ (A B C : Int),
  ∀ (D E F : Prop),
  ∀ (G : Int),
  ∀ (H I J : Prop),
  ∀ (K : Int),
  ∀ (L M : Prop),
  ∀ (N : Int),
  ∀ (O P : Prop),
  ∀ (Q : Int),
  ∀ (R S : Prop),
  ∀ (T : Int),
  ∀ (U V : Prop),
  ∀ (W : Int),
  ∀ (X Y : Prop),
  ∀ (Z : Int),
  ∀ (A1 B1 : Prop),
  ∀ (C1 D1 E1 : Int),
  ∀ (v_31 v_32 v_33 v_34 : Prop),
  let a!1 := ¬O ∨ ¬((2 : Int) ≤ D1) = E;
  let a!2 := ¬R ∨ ¬(E1 ≤ (2 : Int)) = F;
  r2 D1 E1 →
    r6 L v_31 v_32 E1 D1 A →
      r3 J v_33 v_34 E1 B C →
        v_31 = False →
          v_32 = False →
            v_33 = False →
              v_34 = False →
                ¬A1 ∨ A1 ∧ J ∨ Y ∧ X ∨ U ∧ V ∨ R ∧ S ∨ O ∧ P ∨ L ∧ M →
                  ¬L ∨ N = (0 : Int) ∨ ¬M →
                    ¬L ∨ C1 = N ∨ ¬M →
                      ¬L ∨ ¬D ∨ ¬J →
                        D ∨ ¬L ∨ ¬M →
                          Q = (1 : Int) ∨ ¬P ∨ ¬O →
                            C1 = Q ∨ ¬P ∨ ¬O →
                              E ∨ ¬P ∨ ¬O →
                                ¬O ∨ ¬L ∨ ¬E →
                                  ¬R ∨ T = G ∨ ¬S →
                                    ¬R ∨ C1 = T ∨ ¬S →
                                      ¬R ∨ ¬F ∨ ¬S →
                                        ¬R ∨ ¬O ∨ F →
                                          ¬U ∨ ¬V ∨ W = (1 : Int) →
                                            ¬U ∨ ¬V ∨ C1 = W →
                                              ¬U ∨ ¬I ∨ ¬X →
                                                ¬U ∨ H ∨ ¬V →
                                                  ¬U ∨ ¬R ∨ ¬H →
                                                    ¬Y ∨ ¬X ∨ Z = (0 : Int) →
                                                      ¬Y ∨ ¬X ∨ C1 = Z →
                                                        ¬Y ∨ ¬X ∨ I →
                                                          ¬A1 ∨ ¬J ∨ K = C →
                                                            ¬A1 ∨ ¬J ∨ C1 = K →
                                                              ¬J ∨ B = (-1 : Int) + D1 →
                                                                ¬J ∨ L ∧ J →
                                                                  ¬L ∨ D = (A = (0 : Int)) →
                                                                    ¬L ∨ O ∧ L →
                                                                      L ∨ ¬M →
                                                                        ¬O ∨ ¬((2 : Int) ≤ D1) = E →
                                                                          ¬O ∨ R ∧ O →
                                                                            O ∨ ¬P →
                                                                              ¬R ∨ ¬(E1 ≤ (2 : Int)) = F →
                                                                                ¬R ∨ U ∧ R →
                                                                                  R ∨ ¬S →
                                                                                    ¬U ∨ H = (E1 = (2 : Int)) →
                                                                                      ¬U ∨ U ∧ X →
                                                                                        U ∨ ¬V →
                                                                                          ¬Y ∨ X →
                                                                                            ¬B1 ∨ B1 ∧ A1 →
                                                                                              B1 = True →
                                                                                                ¬((2 : Int) ≤ E1) = I →
                                                                                                  r7 C1 D1 E1) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = True) →
  (v_3 = True) →
  (v_4 = True) →
  r5 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = True) →
  (v_4 = True) →
  r5 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = False) →
  (v_4 = False) →
  r5 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (r9 B A) →
  (v_2 = True) →
  (v_3 = False) →
  (v_4 = False) →
  r5 v_2 v_3 v_4 A B) ∧
  ((∀ (A : Int),
  (True) →
  r11 A) ∧
  ((∀ (A : Int),
  ∀ (B C : Prop),
  ∀ (D E : Int),
  ∀ (v_5 v_6 v_7 : Prop),
  (r11 E) →
  (r3 v_5 v_6 v_7 E A D) →
  (v_5 = True) →
  (v_6 = False) →
  (v_7 = False) →
  (¬C ∨ C ∧ B) →
  (C = True) →
  (A = (-1 : Int) + E) →
  r9 D E) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = True) →
  (v_4 = True) →
  (v_5 = True) →
  r13 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = True) →
  (v_5 = True) →
  r13 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = False) →
  (v_5 = False) →
  r13 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (r1 C B A) →
  (v_3 = True) →
  (v_4 = False) →
  (v_5 = False) →
  r13 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B : Int),
  (True) →
  r10 A B) ∧
  ((∀ (A B C D : Prop),
  ∀ (E F : Int),
  ∀ (G H : Prop),
  ∀ (I J : Int),
  ∀ (K L : Prop),
  ∀ (M : Int),
  ∀ (N : Prop),
  ∀ (O : Int),
  ∀ (P Q : Prop),
  ∀ (R : Int),
  ∀ (S T : Prop),
  ∀ (U : Int),
  ∀ (V : Prop),
  ∀ (W : Int),
  ∀ (X Y : Prop),
  ∀ (Z A1 B1 : Int),
  ∀ (v_28 v_29 v_30 v_31 : Prop),
  let a!1 := ¬A ∨ ¬((1 : Int) ≤ A1) = B;
  r10 A1 B1 →
    r13 N v_28 v_29 B1 E F →
      r13 V v_30 v_31 B1 I M →
        v_28 = False →
          v_29 = False →
            v_30 = False →
              v_31 = False →
                ¬X ∨ X ∧ V ∨ X ∧ N ∨ T ∧ S ∨ Q ∧ P →
                  ¬C ∨ ¬P ∨ ¬K →
                    B ∨ ¬A ∨ ¬P →
                      ¬B ∨ ¬S ∨ ¬A →
                        ¬H ∨ ¬A ∨ ¬G →
                          ¬D ∨ ¬S ∨ ¬L →
                            ¬N ∨ P ∧ C ∨ D ∧ S →
                              ¬Q ∨ ¬P ∨ R = (0 : Int) →
                                ¬Q ∨ ¬P ∨ Z = R →
                                  ¬Q ∨ ¬P ∨ K →
                                    ¬T ∨ ¬S ∨ U = (1 : Int) →
                                      ¬T ∨ ¬S ∨ Z = U →
                                        ¬T ∨ L ∨ ¬S →
                                          ¬V ∨ H ∨ ¬G →
                                            ¬X ∨ ¬N ∨ O = J →
                                              ¬X ∨ ¬N ∨ Z = O →
                                                ¬X ∨ ¬V ∨ W = M →
                                                  ¬X ∨ ¬V ∨ Z = W →
                                                    ¬P ∨ K = (A1 = (0 : Int)) →
                                                      ¬P ∨ A ∧ P →
                                                        P ∨ ¬C →
                                                          ¬S ∨ L = (A1 = (1 : Int)) →
                                                            ¬S ∨ A ∧ S →
                                                              ¬A ∨ ¬((1 : Int) ≤ A1) = B →
                                                                ¬A ∨ A ∧ G →
                                                                  ¬D ∨ S →
                                                                    ¬N ∨ E = (-1 : Int) + A1 →
                                                                      ¬N ∨ J = F + B1 →
                                                                        ¬Q ∨ P →
                                                                          ¬T ∨ S →
                                                                            ¬V ∨ I = (-1 : Int) * A1 →
                                                                              ¬V ∨ V ∧ G →
                                                                                ¬Y ∨ Y ∧ X →
                                                                                  Y = True →
                                                                                    ¬((0 : Int) ≤ A1) = H → r1 Z A1 B1) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r4) ∧
  ((∀ (A : Int),
  ∀ (B C : Prop),
  ∀ (D : Int),
  ∀ (E F : Prop),
  ∀ (G H : Int),
  ∀ (I J K L : Prop),
  ∀ (M N O : Int),
  ∀ (P Q : Prop),
  ∀ (R : Int),
  ∀ (S T U V W X Y v_25 v_26 v_27 v_28 : Prop),
  let a!1 := B = (¬A ≤ (46339 : Int) ∨ ¬A ≥ (0 : Int));
  let a!2 := E = (¬D ≤ (46339 : Int) ∨ ¬D ≥ (0 : Int));
  let a!3 := I = (¬(46340 : Int) ≤ G ∧ G ≥ (0 : Int));
  let a!4 := ¬V ∨ ¬(O ≤ (1 : Int)) = Q;
  let a!5 := ¬V ∨ ¬(R ≤ (1 : Int)) = T;
  r4 →
    r5 F v_25 v_26 N H →
      r13 V v_27 v_28 O R M →
        v_25 = False →
          v_26 = False →
            v_27 = False →
              v_28 = False →
                a!1 →
                  ¬X ∨ W ∧ X →
                    ¬Y ∨ Y ∧ X →
                      ¬F ∨ D = (-1 : Int) + O →
                        ¬F ∨ a!2 →
                          ¬F ∨ F ∧ C →
                            ¬F ∨ ¬E →
                              ¬L ∨ G = (-1 : Int) + R →
                                ¬L ∨ J = (H = (1 : Int)) →
                                  ¬L ∨ a!3 →
                                    ¬L ∨ K = (I ∧ J) →
                                      ¬L ∨ L ∧ F →
                                        ¬L ∨ K →
                                          ¬V ∨ ¬(O ≤ (1 : Int)) = Q →
                                            ¬V ∨ ¬(R ≤ (1 : Int)) = T →
                                              ¬V ∨ P = (M = N) →
                                                ¬V ∨ S = (Q ∧ P) →
                                                  ¬V ∨ U = (S ∧ T) →
                                                    ¬V ∨ V ∧ L →
                                                      ¬V ∨ U → ¬W ∨ W ∧ V → Y = True → ¬B → A = (-1 : Int) + N → r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_Primes_true-unreach-call_true-no-overflow_false-termination_000»
