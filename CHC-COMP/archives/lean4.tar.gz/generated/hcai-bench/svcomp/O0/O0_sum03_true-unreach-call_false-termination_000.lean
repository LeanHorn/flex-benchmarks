import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_sum03_true-unreach-call_false-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum03_true-unreach-call_false-termination_000.smt2":167:1-167:12 (check-sat, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum03_true-unreach-call_false-termination_000.smt2":11:1-20:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum03_true-unreach-call_false-termination_000.smt2":21:1-30:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum03_true-unreach-call_false-termination_000.smt2":31:1-40:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum03_true-unreach-call_false-termination_000.smt2":41:1-51:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum03_true-unreach-call_false-termination_000.smt2":52:1-61:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum03_true-unreach-call_false-termination_000.smt2":62:1-72:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum03_true-unreach-call_false-termination_000.smt2":73:1-82:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum03_true-unreach-call_false-termination_000.smt2":83:1-100:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum03_true-unreach-call_false-termination_000.smt2":101:1-128:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum03_true-unreach-call_false-termination_000.smt2":129:1-154:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum03_true-unreach-call_false-termination_000.smt2":155:1-165:2 (clause 11, command 18)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Int → Prop),
    ∃ (r1 : Prop),
    ∃ (r2 : Int → Prop),
    ∃ (r3 : Prop → Prop → Prop → Int → Prop),
    ∃ (r4 : Int → Int → Prop),
    ∃ (r5 : Int → Prop),
    (∀ (A : Int),
    ∀ (v_1 v_2 v_3 : Prop),
    (True) →
    (v_1 = True) →
    (v_2 = True) →
    (v_3 = True) →
    r3 v_1 v_2 v_3 A) ∧
    ((∀ (A : Int),
    ∀ (v_1 v_2 v_3 : Prop),
    (True) →
    (v_1 = False) →
    (v_2 = True) →
    (v_3 = True) →
    r3 v_1 v_2 v_3 A) ∧
    ((∀ (A : Int),
    ∀ (v_1 v_2 v_3 : Prop),
    (True) →
    (v_1 = False) →
    (v_2 = False) →
    (v_3 = False) →
    r3 v_1 v_2 v_3 A) ∧
    ((∀ (A : Int),
    ∀ (v_1 v_2 v_3 : Prop),
    (r0 A) →
    (v_1 = True) →
    (v_2 = False) →
    (v_3 = False) →
    r3 v_1 v_2 v_3 A) ∧
    ((∀ (A : Int),
    (True) →
    r2 A) ∧
    ((∀ (A B C : Prop),
    ∀ (D : Int),
    (r2 D) →
    (¬C ∨ C ∧ B) →
    (¬A) →
    (C = True) →
    (A = (D = (0 : Int))) →
    r0 D) ∧
    ((∀ (A : Int),
    (True) →
    r5 A) ∧
    ((∀ (A B C D : Int),
    ∀ (E F : Prop),
    ∀ (G H I : Int),
    (r5 C) →
    (B = C) →
    (¬F ∨ ¬E ∨ D = (0 : Int)) →
    (¬F ∨ ¬E ∨ G = (0 : Int)) →
    (¬F ∨ ¬E ∨ H = D) →
    (¬F ∨ ¬E ∨ I = G) →
    (¬E ∨ F ∧ E) →
    (E = True) →
    (A = C) →
    r4 H I) ∧
    ((∀ (A B C : Int),
    ∀ (D E F G H : Prop),
    ∀ (I J K L : Int),
    ∀ (M N : Prop),
    ∀ (O P Q : Int),
    ∀ (v_17 v_18 : Prop),
    (r4 A B) →
    (r3 N v_17 v_18 I) →
    (v_17 = False) →
    (v_18 = False) →
    (E = (J = (0 : Int))) →
    (F = (E ∨ D)) →
    (C = (2 : Int) * K) →
    (I = if F then (1 : Int) else (0 : Int)) →
    (J = (2 : Int) + A) →
    (K = (1 : Int) + B) →
    (¬N ∨ ¬G ∨ H) →
    (¬N ∨ ¬M ∨ L = J) →
    (¬N ∨ ¬M ∨ O = K) →
    (¬N ∨ ¬M ∨ P = L) →
    (¬N ∨ ¬M ∨ Q = O) →
    (¬M ∨ N ∧ M) →
    (¬N ∨ N ∧ G) →
    (M = True) →
    (D = (J = C)) →
    r4 P Q) ∧
    ((∀ (A B C D E : Int),
    ∀ (F G H I J K : Prop),
    ∀ (L : Int),
    ∀ (M N O P Q : Prop),
    (r4 A B) →
    (G = (E = (0 : Int))) →
    (H = (G ∨ F)) →
    (D = (2 : Int) * C) →
    (E = (2 : Int) + A) →
    (C = (1 : Int) + B) →
    (L = if H then (1 : Int) else (0 : Int)) →
    (¬K ∨ ¬J ∨ ¬I) →
    (¬K ∨ K ∧ I) →
    (¬Q ∨ P ∧ Q) →
    (¬N ∨ M = (L = (0 : Int))) →
    (¬N ∨ N ∧ K) →
    (¬N ∨ M) →
    (¬O ∨ O ∧ N) →
    (¬P ∨ P ∧ O) →
    (Q = True) →
    (F = (E = D)) →
    r1) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r1) →
    (True) →
    False))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_sum03_true-unreach-call_false-termination_000»
