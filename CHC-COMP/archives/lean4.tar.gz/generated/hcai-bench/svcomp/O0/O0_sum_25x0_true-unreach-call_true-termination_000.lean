import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_sum_25x0_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_25x0_true-unreach-call_true-termination_000.smt2":133:1-133:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_25x0_true-unreach-call_true-termination_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_25x0_true-unreach-call_true-termination_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_25x0_true-unreach-call_true-termination_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_25x0_true-unreach-call_true-termination_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_25x0_true-unreach-call_true-termination_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_25x0_true-unreach-call_true-termination_000.smt2":61:1-88:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_25x0_true-unreach-call_true-termination_000.smt2":89:1-98:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_25x0_true-unreach-call_true-termination_000.smt2":99:1-120:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_sum_25x0_true-unreach-call_true-termination_000.smt2":121:1-131:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  ∃ (r3 : Prop → Prop → Prop → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  (∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = True) →
  (v_4 = True) →
  (v_5 = True) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = True) →
  (v_5 = True) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = False) →
  (v_5 = False) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (r2 C B A) →
  (v_3 = True) →
  (v_4 = False) →
  (v_5 = False) →
  r3 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B : Int),
  (True) →
  r4 A B) ∧
  ((∀ (A B : Int),
  ∀ (C D : Prop),
  ∀ (E F : Int),
  ∀ (G : Prop),
  ∀ (H : Int),
  ∀ (I : Prop),
  ∀ (J : Int),
  ∀ (K L : Prop),
  ∀ (M N O : Int),
  ∀ (v_15 v_16 : Prop),
  (r4 N O) →
  (r3 G v_15 v_16 A B E) →
  (v_15 = False) →
  (v_16 = False) →
  (¬G ∨ ¬D ∨ ¬C) →
  (¬I ∨ D ∨ ¬C) →
  (¬K ∨ K ∧ I ∨ K ∧ G) →
  (¬K ∨ ¬G ∨ H = E) →
  (¬K ∨ ¬G ∨ M = H) →
  (¬K ∨ ¬I ∨ J = F) →
  (¬K ∨ ¬I ∨ M = J) →
  (¬G ∨ A = (-1 : Int) + O) →
  (¬G ∨ B = (1 : Int) + N) →
  (¬G ∨ G ∧ C) →
  (¬I ∨ F = N + O) →
  (¬I ∨ I ∧ C) →
  (¬L ∨ L ∧ K) →
  (L = True) →
  (¬((1 : Int) ≤ O) = D) →
  r2 M N O) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r1) ∧
  ((∀ (A : Int),
  ∀ (B C D E F v_6 v_7 v_8 : Prop),
  ∀ (v_9 v_10 : Int),
  (r1) →
  (r3 v_6 v_7 v_8 v_9 v_10 A) →
  (v_6 = True) →
  (v_7 = False) →
  (v_8 = False) →
  ((25 : Int) = v_9) →
  ((0 : Int) = v_10) →
  (¬D ∨ D ∧ C) →
  (¬E ∨ E ∧ D) →
  (¬F ∨ F ∧ E) →
  (¬B) →
  (F = True) →
  (B = (A = (25 : Int))) →
  r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_sum_25x0_true-unreach-call_true-termination_000»
