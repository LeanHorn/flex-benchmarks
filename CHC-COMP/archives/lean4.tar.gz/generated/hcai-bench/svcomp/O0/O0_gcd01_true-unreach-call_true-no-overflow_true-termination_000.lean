import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_gcd01_true-unreach-call_true-no-overflow_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":165:1-165:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":61:1-109:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":110:1-119:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":120:1-152:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":153:1-163:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Prop → Prop → Prop → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  (∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = True) →
  (v_4 = True) →
  (v_5 = True) →
  r2 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = True) →
  (v_5 = True) →
  r2 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = False) →
  (v_5 = False) →
  r2 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (r3 C A B) →
  (v_3 = True) →
  (v_4 = False) →
  (v_5 = False) →
  r2 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B : Int),
  (True) →
  r4 A B) ∧
  ((∀ (A B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F G H : Int),
  ∀ (I J K : Prop),
  ∀ (L : Int),
  ∀ (M : Prop),
  ∀ (N : Int),
  ∀ (O P : Prop),
  ∀ (Q : Int),
  ∀ (R S : Prop),
  ∀ (T : Int),
  ∀ (U V : Prop),
  ∀ (W X Y : Int),
  ∀ (v_25 v_26 v_27 v_28 : Prop),
  let a!1 := ¬D ∨ ¬(X ≤ Y) = E;
  let a!2 := ¬K ∨ C = Y + (-1 : Int) * X;
  let a!3 := ¬M ∨ F = X + (-1 : Int) * Y;
  r4 X Y →
    r2 K v_25 v_26 X C G →
      r2 M v_27 v_28 F Y H →
        v_25 = False →
          v_26 = False →
            v_27 = False →
              v_28 = False →
                ¬((1 : Int) ≤ Y) = B →
                  J = (B ∨ A) →
                    ¬U ∨ U ∧ M ∨ U ∧ K ∨ S ∧ R ∨ P ∧ O →
                      ¬K ∨ ¬E ∨ ¬D →
                        ¬M ∨ ¬D ∨ E →
                          ¬O ∨ ¬I ∨ ¬D →
                            ¬P ∨ ¬O ∨ Q = X →
                              ¬P ∨ ¬O ∨ W = Q →
                                ¬P ∨ ¬O ∨ I →
                                  ¬R ∨ ¬O ∨ ¬J →
                                    ¬S ∨ ¬R ∨ T = (0 : Int) →
                                      ¬S ∨ ¬R ∨ W = T →
                                        ¬S ∨ ¬R ∨ J →
                                          ¬U ∨ ¬K ∨ L = G →
                                            ¬U ∨ ¬K ∨ W = L →
                                              ¬U ∨ ¬M ∨ N = H →
                                                ¬U ∨ ¬M ∨ W = N →
                                                  ¬D ∨ ¬(X ≤ Y) = E →
                                                    ¬D ∨ O ∧ D →
                                                      ¬K ∨ C = Y + (-1 : Int) * X →
                                                        ¬K ∨ K ∧ D →
                                                          ¬M ∨ F = X + (-1 : Int) * Y →
                                                            ¬M ∨ M ∧ D →
                                                              ¬O ∨ I = (X = Y) →
                                                                ¬O ∨ R ∧ O →
                                                                  ¬P ∨ O →
                                                                    ¬S ∨ R →
                                                                      ¬V ∨ V ∧ U →
                                                                        V = True → ¬((1 : Int) ≤ X) = A → r3 W X Y) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r1) ∧
  ((∀ (A B C D : Prop),
  ∀ (E F : Int),
  ∀ (G H : Prop),
  ∀ (I : Int),
  ∀ (J K L M N O P v_16 v_17 : Prop),
  let a!1 := ¬D ∨ ¬((1 : Int) ≤ I) = C;
  let a!2 := ¬M ∨ ¬((1 : Int) ≤ E) = G;
  let a!3 := ¬M ∨ ¬(F ≤ (0 : Int)) = H;
  let a!4 := ¬M ∨ ¬(I ≤ (0 : Int)) = K;
  r1 →
    r2 M v_16 v_17 F I E →
      v_16 = False →
        v_17 = False →
          ¬D ∨ ¬((1 : Int) ≤ I) = C →
            ¬D ∨ D ∧ B →
              ¬D ∨ ¬C →
                ¬M ∨ ¬((1 : Int) ≤ E) = G →
                  ¬M ∨ ¬(F ≤ (0 : Int)) = H →
                    ¬M ∨ ¬(I ≤ (0 : Int)) = K →
                      ¬M ∨ J = (H ∧ G) →
                        ¬M ∨ L = (K ∧ J) →
                          ¬M ∨ M ∧ D →
                            ¬M ∨ L → ¬N ∨ N ∧ M → ¬O ∨ O ∧ N → ¬P ∨ P ∧ O → ¬A → P = True → ¬((1 : Int) ≤ F) = A → r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_gcd01_true-unreach-call_true-no-overflow_true-termination_000»
