import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_count_up_down_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_count_up_down_true-unreach-call_true-termination_000.smt2":92:1-92:12 (check-sat, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_count_up_down_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_count_up_down_true-unreach-call_true-termination_000.smt2":18:1-34:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_count_up_down_true-unreach-call_true-termination_000.smt2":35:1-55:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_count_up_down_true-unreach-call_true-termination_000.smt2":56:1-79:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O0/O0_count_up_down_true-unreach-call_true-termination_000.smt2":80:1-90:2 (clause 5, command 9)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Int → Prop),
    ∃ (r1 : Prop),
    ∃ (r2 : Int → Int → Int → Prop),
    (∀ (A : Int),
    (True) →
    r0 A) ∧
    ((∀ (A B C : Int),
    ∀ (D E : Prop),
    ∀ (F G H I : Int),
    (r0 B) →
    (¬E ∨ ¬D ∨ C = H) →
    (¬E ∨ ¬D ∨ F = (0 : Int)) →
    (¬E ∨ ¬D ∨ G = F) →
    (¬E ∨ ¬D ∨ I = C) →
    (¬D ∨ E ∧ D) →
    (D = True) →
    (A = B) →
    r2 G H I) ∧
    ((∀ (A B : Prop),
    ∀ (C D E F G : Int),
    ∀ (H I : Prop),
    ∀ (J K L M : Int),
    (r2 D L C) →
    (¬I ∨ ¬B ∨ ¬A) →
    (¬I ∨ ¬H ∨ G = E) →
    (¬I ∨ ¬H ∨ J = F) →
    (¬I ∨ ¬H ∨ K = J) →
    (¬I ∨ ¬H ∨ M = G) →
    (¬H ∨ I ∧ H) →
    (¬I ∨ E = (-1 : Int) + C) →
    (¬I ∨ F = (1 : Int) + D) →
    (¬I ∨ I ∧ A) →
    (H = True) →
    (B = (C = (0 : Int))) →
    r2 K L M) ∧
    ((∀ (A : Int),
    ∀ (B C : Prop),
    ∀ (D E : Int),
    ∀ (F G H I : Prop),
    ∀ (J : Int),
    ∀ (K L M N O : Prop),
    (r2 D E A) →
    (C ∨ ¬H ∨ ¬B) →
    (¬H ∨ F = (D = E)) →
    (¬H ∨ J = if F then (1 : Int) else (0 : Int)) →
    (¬H ∨ H ∧ B) →
    (¬H ∨ ¬G) →
    (¬I ∨ I ∧ H) →
    (¬L ∨ K = (J = (0 : Int))) →
    (¬L ∨ L ∧ I) →
    (¬M ∨ M ∧ L) →
    (¬N ∨ N ∧ M) →
    (¬O ∨ O ∧ N) →
    (K ∨ ¬L) →
    (O = True) →
    (C = (A = (0 : Int))) →
    r1) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r1) →
    (True) →
    False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O0».«O0_count_up_down_true-unreach-call_true-termination_000»
