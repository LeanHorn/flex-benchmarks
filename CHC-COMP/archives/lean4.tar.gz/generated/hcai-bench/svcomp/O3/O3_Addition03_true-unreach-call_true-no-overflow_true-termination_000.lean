import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_Addition03_true-unreach-call_true-no-overflow_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_true-unreach-call_true-no-overflow_true-termination_000.smt2":161:1-161:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_true-unreach-call_true-no-overflow_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_true-unreach-call_true-no-overflow_true-termination_000.smt2":18:1-38:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_true-unreach-call_true-no-overflow_true-termination_000.smt2":39:1-74:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_true-unreach-call_true-no-overflow_true-termination_000.smt2":75:1-101:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_true-unreach-call_true-no-overflow_true-termination_000.smt2":102:1-148:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_true-unreach-call_true-no-overflow_true-termination_000.smt2":149:1-159:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  (∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r0) ∧
  ((∀ (A B : Prop),
  ∀ (C D E : Int),
  ∀ (F G : Prop),
  ∀ (H I J K L : Int),
  (r0) →
  (D = I) →
  (¬G ∨ ¬B ∨ ¬A) →
  (¬G ∨ ¬F ∨ E = C) →
  (¬G ∨ ¬F ∨ H = D) →
  (¬G ∨ ¬F ∨ K = E) →
  (¬G ∨ ¬F ∨ L = H) →
  (¬F ∨ G ∧ F) →
  (¬G ∨ C = J) →
  (¬G ∨ G ∧ A) →
  (F = True) →
  (B = (J = (0 : Int))) →
  r2 I J K L) ∧
  ((∀ (A B : Prop),
  ∀ (C D E F G H I : Int),
  ∀ (J : Prop),
  ∀ (K L : Int),
  ∀ (M : Prop),
  ∀ (N : Int),
  ∀ (O : Prop),
  ∀ (P Q R : Int),
  ∀ (S T : Prop),
  ∀ (U V W X Y : Int),
  (r2 V W D C) →
  (¬J ∨ ¬B ∨ ¬A) →
  (¬M ∨ ¬A ∨ B) →
  (¬T ∨ T ∧ M ∨ T ∧ J) →
  (¬T ∨ ¬J ∨ I = E) →
  (¬T ∨ ¬J ∨ K = F) →
  (¬T ∨ ¬J ∨ P = K) →
  (¬T ∨ ¬J ∨ Q = I) →
  (¬T ∨ ¬M ∨ L = G) →
  (¬T ∨ ¬M ∨ N = H) →
  (¬T ∨ ¬M ∨ P = N) →
  (¬T ∨ ¬M ∨ Q = L) →
  (¬T ∨ ¬S ∨ R = P) →
  (¬T ∨ ¬S ∨ U = Q) →
  (¬T ∨ ¬S ∨ X = R) →
  (¬T ∨ ¬S ∨ Y = U) →
  (¬T ∨ ¬S ∨ ¬O) →
  (¬J ∨ E = (-1 : Int) + C) →
  (¬J ∨ F = (1 : Int) + D) →
  (¬J ∨ J ∧ A) →
  (¬M ∨ G = (1 : Int) + C) →
  (¬M ∨ H = (-1 : Int) + D) →
  (¬M ∨ M ∧ A) →
  (¬S ∨ T ∧ S) →
  (¬T ∨ O = (P = (0 : Int))) →
  (S = True) →
  (¬(D ≤ (0 : Int)) = B) →
  r2 V W X Y) ∧
  ((∀ (A : Prop),
  ∀ (B : Int),
  ∀ (C : Prop),
  ∀ (D E F : Int),
  ∀ (G H : Prop),
  ∀ (I : Int),
  ∀ (J K L M N : Prop),
  let a!1 := ¬M ∨ ¬((100 : Int) ≤ E) = G;
  let a!2 := ¬M ∨ ¬((100 : Int) ≤ F) = H;
  let a!3 := ¬M ∨ ¬(I ≤ (199 : Int)) = K;
  r0 →
    B = E →
      ¬C ∨ D = B ∨ ¬M →
        ¬C ∨ I = D ∨ ¬M →
          ¬C ∨ A ∨ ¬M →
            ¬M ∨ ¬((100 : Int) ≤ E) = G →
              ¬M ∨ ¬((100 : Int) ≤ F) = H →
                ¬M ∨ ¬(I ≤ (199 : Int)) = K →
                  ¬M ∨ J = (H ∨ G) →
                    ¬M ∨ L = (K ∨ J) → ¬M ∨ C ∧ M → ¬M ∨ ¬L → ¬N ∨ N ∧ M → N = True → A = (F = (0 : Int)) → r1) ∧
  ((∀ (A B : Prop),
  ∀ (C D E F G H I : Int),
  ∀ (J : Prop),
  ∀ (K L : Int),
  ∀ (M : Prop),
  ∀ (N O : Int),
  ∀ (P : Prop),
  ∀ (Q : Int),
  ∀ (R : Prop),
  ∀ (S T : Int),
  ∀ (U : Prop),
  ∀ (V W X : Int),
  ∀ (Y Z : Prop),
  ∀ (A1 : Int),
  ∀ (B1 C1 D1 E1 F1 : Prop),
  let a!1 := ¬E1 ∨ ¬((100 : Int) ≤ W) = Y;
  let a!2 := ¬E1 ∨ ¬((100 : Int) ≤ X) = Z;
  let a!3 := ¬E1 ∨ ¬(A1 ≤ (199 : Int)) = C1;
  r2 W X D C →
    ¬J ∨ ¬B ∨ ¬A →
      B ∨ ¬M ∨ ¬A →
        ¬R ∨ R ∧ M ∨ R ∧ J →
          ¬R ∨ ¬J ∨ I = E →
            ¬R ∨ ¬J ∨ Q = I →
              ¬R ∨ ¬J ∨ K = F →
                ¬R ∨ ¬J ∨ O = K →
                  ¬R ∨ ¬M ∨ Q = L →
                    ¬R ∨ ¬M ∨ L = G →
                      ¬R ∨ ¬M ∨ N = H →
                        ¬R ∨ ¬M ∨ O = N →
                          ¬U ∨ ¬R ∨ S = Q →
                            ¬U ∨ ¬R ∨ T = S →
                              ¬U ∨ ¬R ∨ P →
                                ¬U ∨ V = T ∨ ¬E1 →
                                  ¬U ∨ A1 = V ∨ ¬E1 →
                                    ¬J ∨ E = (-1 : Int) + C →
                                      ¬J ∨ F = (1 : Int) + D →
                                        ¬J ∨ J ∧ A →
                                          ¬M ∨ G = (1 : Int) + C →
                                            ¬M ∨ H = (-1 : Int) + D →
                                              ¬M ∨ M ∧ A →
                                                ¬R ∨ P = (O = (0 : Int)) →
                                                  ¬E1 ∨ ¬((100 : Int) ≤ W) = Y →
                                                    ¬E1 ∨ ¬((100 : Int) ≤ X) = Z →
                                                      ¬E1 ∨ ¬(A1 ≤ (199 : Int)) = C1 →
                                                        ¬E1 ∨ B1 = (Z ∨ Y) →
                                                          ¬E1 ∨ D1 = (C1 ∨ B1) →
                                                            ¬E1 ∨ U ∧ E1 →
                                                              ¬E1 ∨ ¬D1 →
                                                                ¬F1 ∨ F1 ∧ E1 →
                                                                  ¬U ∨ U ∧ R → F1 = True → ¬(D ≤ (0 : Int)) = B → r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_Addition03_true-unreach-call_true-no-overflow_true-termination_000»
