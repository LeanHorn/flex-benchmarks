import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_count_up_down_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_count_up_down_true-unreach-call_true-termination_000.smt2":118:1-118:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_count_up_down_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_count_up_down_true-unreach-call_true-termination_000.smt2":18:1-37:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_count_up_down_true-unreach-call_true-termination_000.smt2":38:1-57:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_count_up_down_true-unreach-call_true-termination_000.smt2":58:1-79:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_count_up_down_true-unreach-call_true-termination_000.smt2":80:1-105:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_count_up_down_true-unreach-call_true-termination_000.smt2":106:1-116:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  (∀ (A : Int),
  (True) →
  r0 A) ∧
  ((∀ (A B : Int),
  ∀ (C D : Prop),
  ∀ (E : Int),
  ∀ (F G : Prop),
  ∀ (H I J K : Int),
  (r0 B) →
  (A = B) →
  (¬G ∨ ¬D ∨ ¬C) →
  (¬G ∨ ¬F ∨ E = (0 : Int)) →
  (¬G ∨ ¬F ∨ H = I) →
  (¬G ∨ ¬F ∨ J = H) →
  (¬G ∨ ¬F ∨ K = E) →
  (¬F ∨ G ∧ F) →
  (¬G ∨ G ∧ C) →
  (F = True) →
  (D = (I = (0 : Int))) →
  r2 I J K) ∧
  ((∀ (A B : Int),
  ∀ (C : Prop),
  ∀ (D E F : Int),
  ∀ (G H : Prop),
  ∀ (I J K L : Int),
  (r2 J A B) →
  (D = (1 : Int) + B) →
  (E = (-1 : Int) + A) →
  (¬H ∨ ¬G ∨ F = D) →
  (¬H ∨ ¬G ∨ I = E) →
  (¬H ∨ ¬G ∨ K = I) →
  (¬H ∨ ¬G ∨ L = F) →
  (¬H ∨ ¬G ∨ ¬C) →
  (¬G ∨ H ∧ G) →
  (G = True) →
  (C = (E = (0 : Int))) →
  r2 J K L) ∧
  ((∀ (A B : Int),
  ∀ (C D : Prop),
  ∀ (E F G : Int),
  ∀ (H I J K L : Prop),
  (r0 B) →
  (A = B) →
  (¬D ∨ ¬K ∨ E = (0 : Int)) →
  (¬D ∨ ¬K ∨ F = E) →
  (¬D ∨ ¬K ∨ C) →
  (¬K ∨ I = (F = G)) →
  (¬K ∨ ¬I = J) →
  (¬K ∨ D ∧ K) →
  (¬K ∨ J) →
  (¬L ∨ L ∧ K) →
  (¬K ∨ ¬H) →
  (L = True) →
  (C = (G = (0 : Int))) →
  r1) ∧
  ((∀ (A B C : Int),
  ∀ (D : Prop),
  ∀ (E : Int),
  ∀ (F : Prop),
  ∀ (G H : Int),
  ∀ (I : Prop),
  ∀ (J K L : Int),
  ∀ (M N O P Q : Prop),
  (r2 L A B) →
  (C = (-1 : Int) + A) →
  (E = (1 : Int) + B) →
  (¬I ∨ ¬F ∨ G = E) →
  (¬I ∨ ¬F ∨ H = G) →
  (¬I ∨ ¬F ∨ D) →
  (¬I ∨ ¬P ∨ J = H) →
  (¬I ∨ ¬P ∨ K = J) →
  (¬P ∨ N = (K = L)) →
  (¬P ∨ ¬N = O) →
  (¬P ∨ I ∧ P) →
  (¬P ∨ O) →
  (¬Q ∨ Q ∧ P) →
  (¬I ∨ I ∧ F) →
  (¬P ∨ ¬M) →
  (Q = True) →
  (D = (C = (0 : Int))) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_count_up_down_true-unreach-call_true-termination_000»
