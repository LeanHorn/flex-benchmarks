import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_terminator_03_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_03_true-unreach-call_true-termination_000.smt2":108:1-108:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_03_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_03_true-unreach-call_true-termination_000.smt2":18:1-38:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_03_true-unreach-call_true-termination_000.smt2":39:1-55:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_03_true-unreach-call_true-termination_000.smt2":56:1-76:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_03_true-unreach-call_true-termination_000.smt2":77:1-95:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_03_true-unreach-call_true-termination_000.smt2":96:1-106:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  ∃ (r2 : Prop),
  (∀ (A : Int),
  (True) →
  r1 A) ∧
  ((∀ (A B C : Int),
  ∀ (D E F : Prop),
  ∀ (G : Int),
  ∀ (H I : Prop),
  ∀ (J K L : Int),
  (r1 C) →
  (¬(L ≤ (0 : Int)) = F) →
  (A = C) →
  (B = C) →
  (¬E ∨ F ∨ ¬I) →
  (¬I ∨ ¬H ∨ J = G) →
  (¬I ∨ ¬H ∨ K = J) →
  (¬H ∨ I ∧ H) →
  (¬I ∨ I ∧ E) →
  (D = True) →
  (H = True) →
  (¬((1000001 : Int) ≤ L) = D) →
  r0 K L) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F G H : Int),
  (r0 A H) →
  (C = A + H) →
  (¬E ∨ ¬D ∨ F = C) →
  (¬E ∨ ¬D ∨ G = F) →
  (¬E ∨ ¬D ∨ B) →
  (¬D ∨ E ∧ D) →
  (D = True) →
  (¬((100 : Int) ≤ A) = B) →
  r0 G H) ∧
  ((∀ (A B C : Int),
  ∀ (D : Prop),
  ∀ (E : Int),
  ∀ (F G H I J : Prop),
  (r1 C) →
  (¬(E ≤ (0 : Int)) = G) →
  (B = C) →
  (A = C) →
  (¬G ∨ ¬F ∨ ¬I) →
  (¬I ∨ F ∧ I) →
  (¬I ∨ ¬H) →
  (¬J ∨ J ∧ I) →
  (¬I) →
  (J = True) →
  (D = True) →
  (¬((1000001 : Int) ≤ E) = D) →
  r2) ∧
  ((∀ (A B C : Int),
  ∀ (D E F G H I : Prop),
  (r0 B C) →
  (A = B + C) →
  (¬F ∨ ¬E ∨ ¬D) →
  (¬H ∨ F ∧ H) →
  (¬H ∨ ¬G) →
  (¬I ∨ I ∧ H) →
  (¬F ∨ F ∧ D) →
  (¬H) →
  (I = True) →
  (¬((100 : Int) ≤ B) = E) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  (True) →
  False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_terminator_03_true-unreach-call_true-termination_000»
