import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_afterrec_2calls_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_afterrec_2calls_true-unreach-call_true-termination_000.smt2":99:1-99:12 (check-sat, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_afterrec_2calls_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_afterrec_2calls_true-unreach-call_true-termination_000.smt2":18:1-32:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_afterrec_2calls_true-unreach-call_true-termination_000.smt2":33:1-54:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_afterrec_2calls_true-unreach-call_true-termination_000.smt2":55:1-86:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_afterrec_2calls_true-unreach-call_true-termination_000.smt2":87:1-97:2 (clause 5, command 9)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Prop),
  (∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r0) ∧
  ((∀ (A B C : Prop),
  ∀ (D E : Int),
  (r0) →
  (¬C ∨ ¬B ∨ E = D) →
  (¬B ∨ C ∧ B) →
  (¬A) →
  (B = True) →
  (¬C ∨ ¬B ∨ D = (2 : Int)) →
  r2 E) ∧
  ((∀ (A B C D : Prop),
  ∀ (E : Int),
  ∀ (F : Prop),
  ∀ (G : Int),
  ∀ (H I : Prop),
  ∀ (J K : Int),
  (r2 E) →
  (¬((3 : Int) ≤ E) = A) →
  (¬I ∨ ¬C ∨ ¬B) →
  (¬I ∨ ¬H ∨ J = G) →
  (¬I ∨ ¬H ∨ K = J) →
  (¬I ∨ ¬H ∨ ¬F) →
  (¬H ∨ I ∧ H) →
  (¬I ∨ G = (-2 : Int) + E) →
  (¬I ∨ I ∧ B) →
  (¬I ∨ ¬D) →
  (¬A) →
  (H = True) →
  (¬((4 : Int) ≤ E) = D) →
  r2 K) ∧
  ((∀ (A : Prop),
  ∀ (B : Int),
  ∀ (C : Prop),
  ∀ (D : Int),
  ∀ (E : Prop),
  ∀ (F G : Int),
  ∀ (H I J K L M N O P Q : Prop),
  let a!1 := ¬N ∨ ¬((3 : Int) ≤ G) = H;
  r2 B →
    ¬((3 : Int) ≤ B) = A →
      ¬P ∨ O ∧ P ∨ N ∧ P →
        ¬I ∨ ¬E ∨ ¬K →
          ¬N ∨ ¬E ∨ F = D →
            ¬N ∨ ¬E ∨ G = F →
              ¬N ∨ ¬E ∨ C →
                ¬O ∨ ¬K ∨ L = J →
                  ¬O ∨ ¬K ∨ M = L →
                    ¬O ∨ I ∨ ¬K →
                      ¬E ∨ D = (-2 : Int) + B →
                        ¬E ∨ K ∧ E →
                          ¬Q ∨ Q ∧ P →
                            ¬J ∨ ¬E →
                              ¬N ∨ ¬((3 : Int) ≤ G) = H →
                                ¬N ∨ N ∧ E → ¬N ∨ H → ¬O ∨ O ∧ K → ¬O ∨ M → ¬A → Q = True → ¬((4 : Int) ≤ B) = J → r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_afterrec_2calls_true-unreach-call_true-termination_000»
