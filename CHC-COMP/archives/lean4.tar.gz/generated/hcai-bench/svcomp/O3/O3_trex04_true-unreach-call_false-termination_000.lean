import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_trex04_true-unreach-call_false-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex04_true-unreach-call_false-termination_000.smt2":106:1-106:12 (check-sat, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex04_true-unreach-call_false-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex04_true-unreach-call_false-termination_000.smt2":18:1-58:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex04_true-unreach-call_false-termination_000.smt2":59:1-75:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex04_true-unreach-call_false-termination_000.smt2":76:1-93:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex04_true-unreach-call_false-termination_000.smt2":94:1-104:2 (clause 5, command 9)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Int → Int → Prop),
    ∃ (r1 : Prop),
    ∃ (r2 : Int → Int → Prop),
    (∀ (A B : Int),
    (True) →
    r2 A B) ∧
    ((∀ (A B C : Int),
    ∀ (D : Prop),
    ∀ (E F : Int),
    ∀ (G : Prop),
    ∀ (H I : Int),
    ∀ (J K L M : Prop),
    ∀ (N O P Q R : Int),
    ∀ (S T U V W X : Prop),
    ∀ (Y Z A1 : Int),
    ∀ (B1 C1 : Prop),
    ∀ (D1 E1 F1 : Int),
    let a!1 := D = (¬(2000001 : Int) ≤ C ∧ C ≥ (0 : Int));
    r2 R B →
      ¬W = G →
        A = B →
          C = (1000000 : Int) + A1 →
            E = R →
              F = R →
                (Z = if G then (1 : Int) else (0 : Int)) →
                  ¬J ∨ ¬K ∨ M →
                    ¬M ∨ ¬L ∨ ¬K →
                      ¬T ∨ T ∧ J ∨ L ∧ K →
                        ¬S ∨ ¬T ∨ V →
                          ¬V ∨ ¬U ∨ ¬T →
                            ¬C1 ∨ C1 ∧ S ∨ U ∧ T →
                              ¬C1 ∨ ¬B1 ∨ D1 = A1 →
                                ¬C1 ∨ ¬B1 ∨ E1 = D1 →
                                  ¬J ∨ H = R →
                                    ¬J ∨ I = R →
                                      ¬J ∨ K ∧ J →
                                        ¬L ∨ K →
                                          ¬S ∨ P = R →
                                            ¬S ∨ Q = R →
                                              ¬S ∨ T ∧ S →
                                                ¬T ∨ N = R →
                                                  ¬T ∨ O = R →
                                                    ¬U ∨ T →
                                                      ¬B1 ∨ C1 ∧ B1 →
                                                        (¬C1 ∨ Y = if W then (-1 : Int) else (0 : Int)) →
                                                          (¬C1 ∨ F1 = if X then Y else Z) →
                                                            D = True → B1 = True → a!1 → r0 E1 F1) ∧
    ((∀ (A : Int),
    ∀ (B : Prop),
    ∀ (C : Int),
    ∀ (D E : Prop),
    ∀ (F G H : Int),
    (r0 A H) →
    (C = A + (-1 : Int) * H) →
    (¬E ∨ ¬D ∨ F = C) →
    (¬E ∨ ¬D ∨ G = F) →
    (¬D ∨ B ∨ ¬E) →
    (¬D ∨ E ∧ D) →
    (D = True) →
    (¬(A ≤ (0 : Int)) = B) →
    r0 G H) ∧
    ((∀ (A B C : Int),
    ∀ (D E F G H : Prop),
    (r0 B C) →
    (A = B + (-1 : Int) * C) →
    (¬G ∨ ¬E ∨ ¬D) →
    (¬G ∨ G ∧ D) →
    (¬G ∨ ¬F) →
    (¬H ∨ H ∧ G) →
    (¬G) →
    (H = True) →
    (¬(B ≤ (0 : Int)) = E) →
    r1) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r1) →
    (True) →
    False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_trex04_true-unreach-call_false-termination_000»
