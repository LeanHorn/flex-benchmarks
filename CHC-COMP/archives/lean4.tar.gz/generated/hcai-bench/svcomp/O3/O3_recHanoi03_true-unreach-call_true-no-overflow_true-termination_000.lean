import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":133:1-133:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":61:1-88:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":89:1-98:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":99:1-120:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000.smt2":121:1-131:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop → Prop → Prop → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  (∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = True) →
  (v_3 = True) →
  (v_4 = True) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = True) →
  (v_4 = True) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = False) →
  (v_4 = False) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (r4 B A) →
  (v_2 = True) →
  (v_3 = False) →
  (v_4 = False) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A : Int),
  (True) →
  r3 A) ∧
  ((∀ (A B C : Int),
  ∀ (D E : Prop),
  ∀ (F : Int),
  ∀ (G : Prop),
  ∀ (H : Int),
  ∀ (I : Prop),
  ∀ (J : Int),
  ∀ (K L : Prop),
  ∀ (M N : Int),
  ∀ (v_14 v_15 : Prop),
  (r3 N) →
  (r0 I v_14 v_15 A B) →
  (v_14 = False) →
  (v_15 = False) →
  (¬G ∨ E ∨ ¬D) →
  (¬I ∨ ¬E ∨ ¬D) →
  (¬K ∨ K ∧ I ∨ K ∧ G) →
  (¬K ∨ ¬G ∨ H = (1 : Int)) →
  (¬K ∨ ¬G ∨ M = H) →
  (¬K ∨ ¬I ∨ J = F) →
  (¬K ∨ ¬I ∨ M = J) →
  (¬G ∨ G ∧ D) →
  (¬I ∨ A = (-1 : Int) + N) →
  (¬I ∨ C = (2 : Int) * B) →
  (¬I ∨ F = (1 : Int) + C) →
  (¬I ∨ I ∧ D) →
  (¬L ∨ L ∧ K) →
  (L = True) →
  (E = (N = (1 : Int))) →
  r4 M N) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r2) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C D : Int),
  ∀ (E F G v_7 v_8 v_9 : Prop),
  let a!1 := B = (¬A ≤ (30 : Int) ∨ ¬A ≥ (0 : Int));
  r2 →
    r0 v_7 v_8 v_9 D C →
      v_7 = True →
        v_8 = False → v_9 = False → a!1 → A = (-1 : Int) + D → ¬G ∨ G ∧ F → ¬B → E = True → G = True → ¬(D ≤ C) = E → r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_recHanoi03_true-unreach-call_true-no-overflow_true-termination_000»
