import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_trex03_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex03_true-unreach-call_true-termination_000.smt2":233:1-233:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex03_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex03_true-unreach-call_true-termination_000.smt2":18:1-52:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex03_true-unreach-call_true-termination_000.smt2":53:1-111:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex03_true-unreach-call_true-termination_000.smt2":112:1-149:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex03_true-unreach-call_true-termination_000.smt2":150:1-220:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex03_true-unreach-call_true-termination_000.smt2":221:1-231:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Int → Int → Int → Int → Int → Prop → Prop),
    ∃ (r1 : Prop),
    ∃ (r2 : Int → Int → Prop),
    (∀ (A B : Int),
    (True) →
    r2 A B) ∧
    ((∀ (A B C D E F : Int),
    ∀ (G H I J K L M : Prop),
    ∀ (N O P Q : Int),
    ∀ (R : Prop),
    ∀ (S T U V : Int),
    ∀ (W X Y : Prop),
    ∀ (Z A1 B1 C1 D1 : Int),
    ∀ (E1 : Prop),
    (r2 Z D) →
    (¬(O = (0 : Int)) = G) →
    (¬(P = (0 : Int)) = I) →
    (J = (H ∧ G)) →
    (L = (J ∧ I)) →
    (A = D) →
    (B = D) →
    (C = D) →
    (E = Z) →
    (F = Z) →
    (¬K ∨ ¬X ∨ L) →
    (¬X ∨ ¬W ∨ Y = R) →
    (¬X ∨ ¬W ∨ E1 = Y) →
    (¬X ∨ ¬W ∨ S = N) →
    (¬X ∨ ¬W ∨ T = O) →
    (¬X ∨ ¬W ∨ U = P) →
    (¬X ∨ ¬W ∨ V = Q) →
    (¬X ∨ ¬W ∨ A1 = S) →
    (¬X ∨ ¬W ∨ B1 = T) →
    (¬X ∨ ¬W ∨ C1 = U) →
    (¬X ∨ ¬W ∨ D1 = V) →
    (¬W ∨ X ∧ W) →
    (¬X ∨ Q = if M then (1 : Int) else (0 : Int)) →
    (¬X ∨ X ∧ K) →
    (W = True) →
    (¬(N = (0 : Int)) = H) →
    r0 Z A1 B1 C1 D1 E1) ∧
    ((∀ (A : Int),
    ∀ (B C D : Prop),
    ∀ (E : Int),
    ∀ (F G : Prop),
    ∀ (H I J K L M N O P : Int),
    ∀ (Q : Prop),
    ∀ (R S T : Int),
    ∀ (U : Prop),
    ∀ (V W : Int),
    ∀ (X : Prop),
    ∀ (Y : Int),
    ∀ (Z A1 B1 C1 D1 : Prop),
    ∀ (E1 F1 G1 H1 : Int),
    ∀ (I1 : Prop),
    ∀ (J1 K1 L1 M1 : Int),
    ∀ (N1 O1 P1 : Prop),
    ∀ (Q1 R1 S1 T1 U1 : Int),
    ∀ (V1 : Prop),
    let a!1 := ¬O1 ∨ ¬(E1 = (0 : Int)) = A1;
    let a!2 := ¬O1 ∨ ¬(F1 = (0 : Int)) = Z;
    let a!3 := ¬O1 ∨ ¬(G1 = (0 : Int)) = B1;
    r0 Q1 K M L A D →
      ¬Q ∨ ¬B ∨ C →
        ¬U ∨ ¬C ∨ ¬B →
          ¬O1 ∨ O1 ∧ U ∨ O1 ∧ Q →
            ¬O1 ∨ ¬Q ∨ O = I →
              ¬O1 ∨ ¬Q ∨ P = J →
                ¬O1 ∨ ¬Q ∨ R = K →
                  ¬O1 ∨ ¬Q ∨ E1 = R →
                    ¬O1 ∨ ¬Q ∨ F1 = P →
                      ¬O1 ∨ ¬Q ∨ G1 = O →
                        ¬O1 ∨ ¬U ∨ S = L →
                          ¬O1 ∨ ¬U ∨ T = M →
                            ¬O1 ∨ ¬U ∨ V = N →
                              ¬O1 ∨ ¬U ∨ E1 = V →
                                ¬O1 ∨ ¬U ∨ F1 = T →
                                  ¬O1 ∨ ¬U ∨ G1 = S →
                                    ¬O1 ∨ ¬N1 ∨ P1 = I1 →
                                      ¬O1 ∨ ¬N1 ∨ V1 = P1 →
                                        ¬O1 ∨ ¬N1 ∨ J1 = E1 →
                                          ¬O1 ∨ ¬N1 ∨ K1 = F1 →
                                            ¬O1 ∨ ¬N1 ∨ L1 = G1 →
                                              ¬O1 ∨ ¬N1 ∨ M1 = H1 →
                                                ¬O1 ∨ ¬N1 ∨ R1 = J1 →
                                                  ¬O1 ∨ ¬N1 ∨ S1 = K1 →
                                                    ¬O1 ∨ ¬N1 ∨ T1 = L1 →
                                                      ¬O1 ∨ ¬N1 ∨ U1 = M1 →
                                                        ¬O1 ∨ ¬N1 ∨ D1 →
                                                          ¬Q ∨ ¬D = F →
                                                            ¬Q ∨ ¬F = G →
                                                              (¬Q ∨ E = if F then (-1 : Int) else (0 : Int)) →
                                                                (¬Q ∨ H = if G then (-1 : Int) else (0 : Int)) →
                                                                  ¬Q ∨ I = L + E →
                                                                    ¬Q ∨ J = M + H →
                                                                      ¬Q ∨ Q ∧ B →
                                                                        ¬U ∨ N = (-1 : Int) + K →
                                                                          ¬U ∨ U ∧ B →
                                                                            ¬N1 ∨ O1 ∧ N1 →
                                                                              ¬O1 ∨ ¬(E1 = (0 : Int)) = A1 →
                                                                                ¬O1 ∨ ¬(F1 = (0 : Int)) = Z →
                                                                                  ¬O1 ∨ ¬(G1 = (0 : Int)) = B1 →
                                                                                    ¬O1 ∨ C1 = (A1 ∧ Z) →
                                                                                      ¬O1 ∨ D1 = (C1 ∧ B1) →
                                                                                        ¬O1 ∨ Y = Q1 →
                                                                                          ¬O1 ∨ W = Q1 →
                                                                                            (¬O1 ∨
                                                                                                H1 =
                                                                                                  if X then (1 : Int)
                                                                                                  else (0 : Int)) →
                                                                                              N1 = True →
                                                                                                C = (A = (0 : Int)) →
                                                                                                  r0 Q1 R1 S1 T1 U1 V1) ∧
    ((∀ (A B C D E F G : Int),
    ∀ (H I J K L : Prop),
    ∀ (M N O P Q : Int),
    ∀ (R : Prop),
    ∀ (S T U : Int),
    ∀ (V W : Prop),
    ∀ (X : Int),
    ∀ (Y Z A1 B1 C1 D1 E1 : Prop),
    (r2 G D) →
    (¬(N = (0 : Int)) = H) →
    (¬(O = (0 : Int)) = J) →
    (K = (I ∧ H)) →
    (L = (K ∧ J)) →
    (A = D) →
    (B = D) →
    (C = D) →
    (E = G) →
    (F = G) →
    (¬D1 ∨ X = S ∨ ¬R) →
    (¬D1 ∨ P = M ∨ ¬R) →
    (¬D1 ∨ Q = N ∨ ¬R) →
    (¬D1 ∨ S = O ∨ ¬R) →
    (¬D1 ∨ T = P ∨ ¬R) →
    (¬D1 ∨ U = Q ∨ ¬R) →
    (¬D1 ∨ ¬L ∨ ¬R) →
    (¬D1 ∨ V = (U = (0 : Int))) →
    (¬D1 ∨ Z = (W ∨ V)) →
    (¬D1 ∨ B1 = (Y ∨ Z)) →
    (¬D1 ∨ ¬B1 = C1) →
    (¬D1 ∨ W = (T = (0 : Int))) →
    (¬D1 ∨ Y = (X = (0 : Int))) →
    (¬D1 ∨ R ∧ D1) →
    (¬D1 ∨ ¬A1) →
    (¬D1 ∨ C1) →
    (¬E1 ∨ E1 ∧ D1) →
    (E1 = True) →
    (¬(M = (0 : Int)) = I) →
    r1) ∧
    ((∀ (A : Int),
    ∀ (B C D : Prop),
    ∀ (E : Int),
    ∀ (F G : Prop),
    ∀ (H I J K L M N O P : Int),
    ∀ (Q : Prop),
    ∀ (R S T : Int),
    ∀ (U : Prop),
    ∀ (V W X : Int),
    ∀ (Y : Prop),
    ∀ (Z A1 : Int),
    ∀ (B1 C1 D1 E1 F1 : Prop),
    ∀ (G1 H1 I1 J1 K1 : Int),
    ∀ (L1 : Prop),
    ∀ (M1 N1 O1 P1 Q1 R1 : Int),
    ∀ (S1 : Prop),
    ∀ (T1 U1 V1 : Int),
    ∀ (W1 X1 : Prop),
    ∀ (Y1 : Int),
    ∀ (Z1 A2 B2 C2 D2 E2 F2 : Prop),
    let a!1 := ¬L1 ∨ ¬(I1 = (0 : Int)) = D1;
    let a!2 := ¬L1 ∨ ¬(H1 = (0 : Int)) = B1;
    let a!3 := ¬L1 ∨ ¬(G1 = (0 : Int)) = C1;
    r0 A1 K M L A D →
      ¬U ∨ ¬C ∨ ¬B →
        C ∨ ¬Q ∨ ¬B →
          ¬L1 ∨ L1 ∧ U ∨ L1 ∧ Q →
            ¬L1 ∨ ¬U ∨ S = L →
              ¬L1 ∨ ¬U ∨ T = M →
                ¬L1 ∨ ¬U ∨ V = N →
                  ¬L1 ∨ ¬U ∨ I1 = S →
                    ¬L1 ∨ ¬U ∨ H1 = T →
                      ¬L1 ∨ ¬U ∨ G1 = V →
                        ¬L1 ∨ ¬Q ∨ P = J →
                          ¬L1 ∨ ¬Q ∨ O = I →
                            ¬L1 ∨ ¬Q ∨ R = K →
                              ¬L1 ∨ ¬Q ∨ I1 = O →
                                ¬L1 ∨ ¬Q ∨ H1 = P →
                                  ¬L1 ∨ ¬Q ∨ G1 = R →
                                    ¬E2 ∨ Y1 = T1 ∨ ¬S1 →
                                      ¬E2 ∨ Q1 = N1 ∨ ¬S1 →
                                        ¬E2 ∨ R1 = O1 ∨ ¬S1 →
                                          ¬E2 ∨ T1 = P1 ∨ ¬S1 →
                                            ¬E2 ∨ U1 = Q1 ∨ ¬S1 →
                                              ¬E2 ∨ V1 = R1 ∨ ¬S1 →
                                                ¬S1 ∨ ¬L1 ∨ J1 = G1 →
                                                  ¬S1 ∨ ¬L1 ∨ K1 = H1 →
                                                    ¬S1 ∨ ¬L1 ∨ M1 = I1 →
                                                      ¬S1 ∨ ¬L1 ∨ N1 = J1 →
                                                        ¬S1 ∨ ¬L1 ∨ O1 = K1 →
                                                          ¬S1 ∨ ¬L1 ∨ P1 = M1 →
                                                            ¬S1 ∨ ¬L1 ∨ ¬F1 →
                                                              ¬U ∨ N = (-1 : Int) + K →
                                                                ¬U ∨ U ∧ B →
                                                                  ¬Q ∨ ¬D = F →
                                                                    ¬Q ∨ ¬F = G →
                                                                      (¬Q ∨ E = if F then (-1 : Int) else (0 : Int)) →
                                                                        (¬Q ∨ H = if G then (-1 : Int) else (0 : Int)) →
                                                                          ¬Q ∨ I = L + E →
                                                                            ¬Q ∨ J = M + H →
                                                                              ¬Q ∨ Q ∧ B →
                                                                                ¬E2 ∨ W1 = (V1 = (0 : Int)) →
                                                                                  ¬E2 ∨ A2 = (X1 ∨ W1) →
                                                                                    ¬E2 ∨ C2 = (Z1 ∨ A2) →
                                                                                      ¬E2 ∨ ¬C2 = D2 →
                                                                                        ¬E2 ∨ X1 = (U1 = (0 : Int)) →
                                                                                          ¬E2 ∨ Z1 = (Y1 = (0 : Int)) →
                                                                                            ¬E2 ∨ S1 ∧ E2 →
                                                                                              ¬E2 ∨ ¬B2 →
                                                                                                ¬E2 ∨ D2 →
                                                                                                  ¬L1 ∨
                                                                                                      ¬(I1 = (0 : Int)) =
                                                                                                          D1 →
                                                                                                    ¬L1 ∨
                                                                                                        ¬(H1 = (0 : Int)) =
                                                                                                            B1 →
                                                                                                      ¬L1 ∨
                                                                                                          ¬(G1 =
                                                                                                                (0 : Int)) =
                                                                                                              C1 →
                                                                                                        ¬L1 ∨
                                                                                                            F1 = (E1 ∧ D1) →
                                                                                                          ¬L1 ∨
                                                                                                              E1 =
                                                                                                                (C1 ∧ B1) →
                                                                                                            ¬L1 ∨ W = A1 →
                                                                                                              (¬L1 ∨
                                                                                                                  X =
                                                                                                                    if
                                                                                                                        Y then
                                                                                                                      (1 :
                                                                                                                        Int)
                                                                                                                    else
                                                                                                                      (0 :
                                                                                                                        Int)) →
                                                                                                                ¬L1 ∨
                                                                                                                    Z = A1 →
                                                                                                                  ¬S1 ∨
                                                                                                                      S1 ∧
                                                                                                                        L1 →
                                                                                                                    ¬F2 ∨
                                                                                                                        F2 ∧
                                                                                                                          E2 →
                                                                                                                      F2 =
                                                                                                                          True →
                                                                                                                        C =
                                                                                                                            (A =
                                                                                                                              (0 :
                                                                                                                                Int)) →
                                                                                                                          r1) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r1) →
    (True) →
    False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_trex03_true-unreach-call_true-termination_000»
