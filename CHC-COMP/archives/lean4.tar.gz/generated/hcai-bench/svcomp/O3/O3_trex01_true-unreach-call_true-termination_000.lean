import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_trex01_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex01_true-unreach-call_true-termination_000.smt2":120:1-120:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex01_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex01_true-unreach-call_true-termination_000.smt2":18:1-39:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex01_true-unreach-call_true-termination_000.smt2":40:1-56:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex01_true-unreach-call_true-termination_000.smt2":57:1-81:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex01_true-unreach-call_true-termination_000.smt2":82:1-107:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_trex01_true-unreach-call_true-termination_000.smt2":108:1-118:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  (∀ (A B : Int),
  (True) →
  r2 A B) ∧
  ((∀ (A B : Int),
  ∀ (C : Prop),
  ∀ (D E F G : Int),
  ∀ (H I J K : Prop),
  ∀ (L M N : Int),
  (r2 B G) →
  (A = B) →
  (D = G) →
  (E = G) →
  (F = G) →
  (¬H ∨ ¬K ∨ I) →
  (¬K ∨ ¬J ∨ L = (1 : Int)) →
  (¬K ∨ ¬J ∨ M = L) →
  (¬J ∨ K ∧ J) →
  (¬K ∨ K ∧ H) →
  (¬C) →
  (J = True) →
  (¬(N ≤ (1 : Int)) = I) →
  r1 M N) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F G H : Int),
  (r1 A H) →
  (C = (2 : Int) * A) →
  (¬E ∨ ¬D ∨ F = C) →
  (¬E ∨ ¬D ∨ G = F) →
  (¬E ∨ ¬D ∨ B) →
  (¬D ∨ E ∧ D) →
  (D = True) →
  (¬(H ≤ C) = B) →
  r1 G H) ∧
  ((∀ (A B : Int),
  ∀ (C : Prop),
  ∀ (D E F G H : Int),
  ∀ (I J K L M N O P : Prop),
  (r2 B G) →
  (A = B) →
  (E = G) →
  (D = G) →
  (F = G) →
  (¬J ∨ M = K ∨ ¬O) →
  (¬J ∨ ¬I ∨ ¬O) →
  (¬J ∨ K ∨ ¬O) →
  (¬O ∨ ¬M = N) →
  (¬O ∨ J ∧ O) →
  (¬O ∨ N) →
  (¬P ∨ P ∧ O) →
  (¬L ∨ ¬O) →
  (¬C) →
  (P = True) →
  (¬(H ≤ (1 : Int)) = I) →
  r0) ∧
  ((∀ (A B : Int),
  ∀ (C : Prop),
  ∀ (D : Int),
  ∀ (E : Prop),
  ∀ (F G : Int),
  ∀ (H I J K L M N O : Prop),
  let a!1 := ¬I ∨ ¬(G ≤ (0 : Int)) = H;
  r1 D B →
    A = (2 : Int) * D →
      ¬I ∨ ¬E ∨ F = D →
        ¬I ∨ ¬E ∨ G = F →
          ¬I ∨ ¬E ∨ ¬C →
            ¬I ∨ ¬N ∨ J = H →
              ¬I ∨ L = J ∨ ¬N →
                ¬N ∨ ¬L = M →
                  ¬N ∨ I ∧ N →
                    ¬N ∨ M → ¬O ∨ O ∧ N → ¬I ∨ ¬(G ≤ (0 : Int)) = H → ¬I ∨ I ∧ E → ¬K ∨ ¬N → O = True → ¬(B ≤ A) = C → r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_trex01_true-unreach-call_true-termination_000»
