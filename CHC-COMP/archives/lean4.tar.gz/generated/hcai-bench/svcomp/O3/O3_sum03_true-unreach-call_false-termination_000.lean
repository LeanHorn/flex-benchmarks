import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_sum03_true-unreach-call_false-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum03_true-unreach-call_false-termination_000.smt2":126:1-126:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum03_true-unreach-call_false-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum03_true-unreach-call_false-termination_000.smt2":18:1-39:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum03_true-unreach-call_false-termination_000.smt2":40:1-66:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum03_true-unreach-call_false-termination_000.smt2":67:1-85:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum03_true-unreach-call_false-termination_000.smt2":86:1-113:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum03_true-unreach-call_false-termination_000.smt2":114:1-124:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop → Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  ∃ (r2 : Prop),
  (∀ (A : Int),
  (True) →
  r1 A) ∧
  ((∀ (A B C : Int),
  ∀ (D E F : Prop),
  ∀ (G : Int),
  ∀ (H I : Prop),
  ∀ (J : Int),
  ∀ (K : Prop),
  ∀ (L M : Int),
  (r1 C) →
  (B = C) →
  (¬I ∨ E ∨ ¬D) →
  (¬I ∨ ¬H ∨ K = F) →
  (¬I ∨ ¬H ∨ G = (1 : Int)) →
  (¬I ∨ ¬H ∨ J = (2 : Int)) →
  (¬I ∨ ¬H ∨ L = J) →
  (¬I ∨ ¬H ∨ M = G) →
  (¬I ∨ ¬H ∨ ¬F) →
  (¬H ∨ I ∧ H) →
  (¬I ∨ I ∧ D) →
  (H = True) →
  (A = C) →
  r0 K L M) ∧
  ((∀ (A : Prop),
  ∀ (B C D : Int),
  ∀ (E F G H I : Prop),
  ∀ (J K : Int),
  ∀ (L : Prop),
  ∀ (M : Int),
  ∀ (N O : Prop),
  ∀ (P : Int),
  ∀ (Q : Prop),
  ∀ (R S : Int),
  (r0 A B C) →
  (F = (K = D)) →
  (G = (F ∨ E)) →
  (¬G = I) →
  (D = (2 : Int) * J) →
  (J = (1 : Int) + C) →
  (K = (2 : Int) + B) →
  (¬O ∨ ¬N ∨ L = I) →
  (¬O ∨ ¬N ∨ Q = L) →
  (¬O ∨ ¬N ∨ M = J) →
  (¬O ∨ ¬N ∨ P = K) →
  (¬O ∨ ¬N ∨ R = P) →
  (¬O ∨ ¬N ∨ S = M) →
  (¬O ∨ ¬N ∨ H) →
  (¬N ∨ O ∧ N) →
  (¬A) →
  (N = True) →
  (E = (K = (0 : Int))) →
  r0 Q R S) ∧
  ((∀ (A B C : Int),
  ∀ (D E F G H I : Prop),
  (r1 C) →
  (B = C) →
  (¬H ∨ ¬E ∨ G = F) →
  (¬H ∨ ¬E ∨ ¬D) →
  (¬H ∨ ¬F ∨ ¬E) →
  (¬H ∨ H ∧ E) →
  (¬H ∨ G) →
  (¬I ∨ I ∧ H) →
  (I = True) →
  (A = C) →
  r2) ∧
  ((∀ (A : Prop),
  ∀ (B C D E F : Int),
  ∀ (G H I J K L M N O P Q R S : Prop),
  (r0 A B C) →
  (H = (F = E)) →
  (I = (H ∨ G)) →
  (¬I = K) →
  (E = (2 : Int) * D) →
  (F = (2 : Int) + B) →
  (D = (1 : Int) + C) →
  (¬O ∨ ¬L ∨ M = K) →
  (¬O ∨ ¬L ∨ N = M) →
  (¬O ∨ ¬L ∨ ¬J) →
  (¬R ∨ ¬O ∨ Q = P) →
  (¬R ∨ ¬O ∨ P = N) →
  (¬O ∨ O ∧ L) →
  (¬R ∨ R ∧ O) →
  (¬R ∨ Q) →
  (¬S ∨ S ∧ R) →
  (¬A) →
  (S = True) →
  (G = (F = (0 : Int))) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  (True) →
  False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_sum03_true-unreach-call_false-termination_000»
