import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_Addition01_true-unreach-call_true-no-overflow_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":158:1-158:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":18:1-42:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":43:1-78:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":79:1-104:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":105:1-145:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition01_true-unreach-call_true-no-overflow_true-termination_000.smt2":146:1-156:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  (∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r0) ∧
  ((∀ (A B C D : Prop),
  ∀ (E : Int),
  ∀ (F G : Prop),
  ∀ (H I J K L : Int),
  let a!1 := B = (¬I ≤ (1073741823 : Int) ∨ ¬I ≥ (0 : Int));
  let a!2 := A = (¬J ≤ (1073741823 : Int) ∨ ¬J ≥ (0 : Int));
  r0 →
    a!1 →
      D = (I = (0 : Int)) →
        ¬G ∨ ¬D ∨ ¬C →
          ¬G ∨ ¬F ∨ E = I →
            ¬G ∨ ¬F ∨ H = J →
              ¬G ∨ ¬F ∨ K = E → ¬G ∨ ¬F ∨ L = H → ¬F ∨ G ∧ F → ¬G ∨ G ∧ C → ¬A → ¬B → F = True → a!2 → r2 I J K L) ∧
  ((∀ (A B : Prop),
  ∀ (C D E F G H I : Int),
  ∀ (J : Prop),
  ∀ (K L : Int),
  ∀ (M : Prop),
  ∀ (N : Int),
  ∀ (O : Prop),
  ∀ (P Q R : Int),
  ∀ (S T : Prop),
  ∀ (U V W X Y : Int),
  (r2 V W D C) →
  (¬J ∨ ¬B ∨ ¬A) →
  (¬M ∨ B ∨ ¬A) →
  (¬T ∨ T ∧ M ∨ T ∧ J) →
  (¬T ∨ ¬J ∨ I = E) →
  (¬T ∨ ¬J ∨ K = F) →
  (¬T ∨ ¬J ∨ P = K) →
  (¬T ∨ ¬J ∨ Q = I) →
  (¬T ∨ ¬M ∨ L = G) →
  (¬T ∨ ¬M ∨ N = H) →
  (¬T ∨ ¬M ∨ P = N) →
  (¬T ∨ ¬M ∨ Q = L) →
  (¬T ∨ ¬S ∨ R = P) →
  (¬T ∨ ¬S ∨ U = Q) →
  (¬T ∨ ¬S ∨ X = R) →
  (¬T ∨ ¬S ∨ Y = U) →
  (¬T ∨ ¬S ∨ ¬O) →
  (¬J ∨ E = (-1 : Int) + C) →
  (¬J ∨ F = (1 : Int) + D) →
  (¬J ∨ J ∧ A) →
  (¬M ∨ G = (1 : Int) + C) →
  (¬M ∨ H = (-1 : Int) + D) →
  (¬M ∨ M ∧ A) →
  (¬S ∨ T ∧ S) →
  (¬T ∨ O = (P = (0 : Int))) →
  (S = True) →
  (¬(D ≤ (0 : Int)) = B) →
  r2 V W X Y) ∧
  ((∀ (A B C D : Prop),
  ∀ (E F G H I : Int),
  ∀ (J K L : Prop),
  let a!1 := B = (¬F ≤ (1073741823 : Int) ∨ ¬F ≥ (0 : Int));
  let a!2 := A = (¬G ≤ (1073741823 : Int) ∨ ¬G ≥ (0 : Int));
  r0 →
    a!1 →
      C = (F = (0 : Int)) →
        ¬D ∨ E = G ∨ ¬K →
          ¬D ∨ H = E ∨ ¬K →
            ¬D ∨ C ∨ ¬K →
              ¬K ∨ I = F + G → ¬K ∨ J = (H = I) → ¬K ∨ D ∧ K → ¬K ∨ ¬J → ¬L ∨ L ∧ K → L = True → ¬A → ¬B → a!2 → r1) ∧
  ((∀ (A B : Prop),
  ∀ (C D E F G H I : Int),
  ∀ (J : Prop),
  ∀ (K L : Int),
  ∀ (M : Prop),
  ∀ (N O : Int),
  ∀ (P : Prop),
  ∀ (Q : Int),
  ∀ (R : Prop),
  ∀ (S T : Int),
  ∀ (U : Prop),
  ∀ (V W X Y Z : Int),
  ∀ (A1 B1 C1 : Prop),
  (r2 W X D C) →
  (¬J ∨ ¬B ∨ ¬A) →
  (B ∨ ¬M ∨ ¬A) →
  (¬R ∨ R ∧ M ∨ R ∧ J) →
  (¬R ∨ ¬J ∨ Q = I) →
  (¬R ∨ ¬J ∨ I = E) →
  (¬R ∨ ¬J ∨ K = F) →
  (¬R ∨ ¬J ∨ O = K) →
  (¬R ∨ ¬M ∨ N = H) →
  (¬R ∨ ¬M ∨ Q = L) →
  (¬R ∨ ¬M ∨ L = G) →
  (¬R ∨ ¬M ∨ O = N) →
  (¬U ∨ V = T ∨ ¬B1) →
  (¬U ∨ Y = V ∨ ¬B1) →
  (¬U ∨ ¬R ∨ S = Q) →
  (¬U ∨ ¬R ∨ T = S) →
  (¬U ∨ ¬R ∨ P) →
  (¬J ∨ E = (-1 : Int) + C) →
  (¬J ∨ F = (1 : Int) + D) →
  (¬J ∨ J ∧ A) →
  (¬M ∨ G = (1 : Int) + C) →
  (¬M ∨ H = (-1 : Int) + D) →
  (¬M ∨ M ∧ A) →
  (¬B1 ∨ Z = W + X) →
  (¬B1 ∨ A1 = (Y = Z)) →
  (¬B1 ∨ U ∧ B1) →
  (¬B1 ∨ ¬A1) →
  (¬C1 ∨ C1 ∧ B1) →
  (¬R ∨ P = (O = (0 : Int))) →
  (¬U ∨ U ∧ R) →
  (C1 = True) →
  (¬(D ≤ (0 : Int)) = B) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_Addition01_true-unreach-call_true-no-overflow_true-termination_000»
