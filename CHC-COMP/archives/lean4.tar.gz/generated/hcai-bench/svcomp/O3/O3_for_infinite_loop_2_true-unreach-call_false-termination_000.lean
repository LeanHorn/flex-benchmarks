import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_for_infinite_loop_2_true-unreach-call_false-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_for_infinite_loop_2_true-unreach-call_false-termination_000.smt2":92:1-92:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_for_infinite_loop_2_true-unreach-call_false-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_for_infinite_loop_2_true-unreach-call_false-termination_000.smt2":18:1-34:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_for_infinite_loop_2_true-unreach-call_false-termination_000.smt2":35:1-45:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_for_infinite_loop_2_true-unreach-call_false-termination_000.smt2":46:1-63:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_for_infinite_loop_2_true-unreach-call_false-termination_000.smt2":64:1-79:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_for_infinite_loop_2_true-unreach-call_false-termination_000.smt2":80:1-90:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Prop),
  ∃ (r2 : Prop),
  (∀ (A : Int),
  (True) →
  r1 A) ∧
  ((∀ (A B C : Int),
  ∀ (D E F G H : Prop),
  (r1 B) →
  (A = B) →
  (¬G ∨ F ∨ ¬E) →
  (¬G ∨ G ∧ E) →
  (¬H ∨ H ∧ G) →
  (D = True) →
  (H = True) →
  (¬(C ≤ (0 : Int)) = D) →
  r0) ∧
  ((∀ (A B C : Prop),
  (r0) →
  (¬A ∨ B ∧ A) →
  (A = True) →
  (¬B ∨ C ∨ ¬A) →
  r0) ∧
  ((∀ (A B C : Int),
  ∀ (D E F G H : Prop),
  (r1 B) →
  (A = B) →
  (¬G ∨ ¬F ∨ ¬E) →
  (¬G ∨ G ∧ E) →
  (¬H ∨ H ∧ G) →
  (D = True) →
  (¬G) →
  (H = True) →
  (¬(C ≤ (0 : Int)) = D) →
  r2) ∧
  ((∀ (A B C D E : Prop),
  (r0) →
  (¬C ∨ C ∧ A) →
  (¬D ∨ D ∧ C) →
  (¬E ∨ E ∧ D) →
  (¬D) →
  (E = True) →
  (¬C ∨ ¬B ∨ ¬A) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  (True) →
  False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_for_infinite_loop_2_true-unreach-call_false-termination_000»
