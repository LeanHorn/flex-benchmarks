import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_fibo_2calls_10_true-unreach-call_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_2calls_10_true-unreach-call_000.smt2":190:1-190:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_2calls_10_true-unreach-call_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_2calls_10_true-unreach-call_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_2calls_10_true-unreach-call_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_2calls_10_true-unreach-call_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_2calls_10_true-unreach-call_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_2calls_10_true-unreach-call_000.smt2":61:1-142:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_2calls_10_true-unreach-call_000.smt2":143:1-152:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_2calls_10_true-unreach-call_000.smt2":153:1-177:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_2calls_10_true-unreach-call_000.smt2":178:1-188:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop → Prop → Prop → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  (∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = True) →
  (v_3 = True) →
  (v_4 = True) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = True) →
  (v_4 = True) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = False) →
  (v_4 = False) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (r4 B A) →
  (v_2 = True) →
  (v_3 = False) →
  (v_4 = False) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A : Int),
  (True) →
  r3 A) ∧
  ((∀ (A B C D E F G H I : Int),
  ∀ (J K : Prop),
  ∀ (L : Int),
  ∀ (M N : Prop),
  ∀ (O P : Int),
  ∀ (Q : Prop),
  ∀ (R S : Int),
  ∀ (T U : Prop),
  ∀ (V W : Int),
  ∀ (X Y : Prop),
  ∀ (Z A1 : Int),
  ∀ (B1 : Prop),
  ∀ (C1 D1 E1 F1 : Int),
  ∀ (G1 H1 I1 : Prop),
  ∀ (J1 : Int),
  ∀ (K1 L1 : Prop),
  ∀ (M1 : Int),
  ∀ (N1 O1 : Prop),
  ∀ (P1 : Int),
  ∀ (Q1 R1 : Prop),
  ∀ (S1 T1 : Int),
  ∀ (v_46 v_47 v_48 v_49 v_50 v_51 v_52 v_53 : Prop),
  let a!1 := ¬X ∨ ¬((1 : Int) ≤ E) = N;
  r3 T1 →
    r0 X v_46 v_47 A D →
      r0 X v_48 v_49 B C →
        r0 Q v_50 v_51 F I →
          r0 Q v_52 v_53 G H →
            v_46 = False →
              v_47 = False →
                v_48 = False →
                  v_49 = False →
                    v_50 = False →
                      v_51 = False →
                        v_52 = False →
                          v_53 = False →
                            ¬I1 ∨ I1 ∧ B1 ∨ I1 ∧ Q ∨ Y ∧ X ∨ U ∧ T →
                              ¬Q1 ∨ Q1 ∧ I1 ∨ O1 ∧ N1 ∨ L1 ∧ K1 →
                                ¬T ∨ ¬Q ∨ ¬M →
                                  ¬U ∨ ¬T ∨ S = O →
                                    ¬U ∨ ¬T ∨ V = (1 : Int) →
                                      ¬U ∨ ¬T ∨ D1 = V →
                                        ¬U ∨ ¬T ∨ E1 = S →
                                          ¬U ∨ ¬T ∨ M →
                                            ¬X ∨ ¬K ∨ ¬J →
                                              ¬X ∨ ¬T ∨ ¬N →
                                                ¬Y ∨ ¬X ∨ W = O →
                                                  ¬Y ∨ ¬X ∨ Z = (0 : Int) →
                                                    ¬Y ∨ ¬X ∨ D1 = Z →
                                                      ¬Y ∨ ¬X ∨ E1 = W →
                                                        ¬Y ∨ ¬X ∨ N →
                                                          ¬B1 ∨ ¬J ∨ K →
                                                            ¬I1 ∨ ¬Q ∨ P = O →
                                                              ¬I1 ∨ ¬Q ∨ R = L →
                                                                ¬I1 ∨ ¬Q ∨ D1 = R →
                                                                  ¬I1 ∨ ¬Q ∨ E1 = P →
                                                                    ¬I1 ∨ ¬B1 ∨ A1 = (1 : Int) →
                                                                      ¬I1 ∨ ¬B1 ∨ C1 = (0 : Int) →
                                                                        ¬I1 ∨ ¬B1 ∨ D1 = C1 →
                                                                          ¬I1 ∨ ¬B1 ∨ E1 = A1 →
                                                                            ¬K1 ∨ ¬G1 ∨ ¬J →
                                                                              ¬L1 ∨ ¬K1 ∨ M1 = (1 : Int) →
                                                                                ¬L1 ∨ ¬K1 ∨ S1 = M1 →
                                                                                  ¬L1 ∨ ¬K1 ∨ G1 →
                                                                                    ¬N1 ∨ ¬K1 ∨ ¬H1 →
                                                                                      ¬O1 ∨ ¬N1 ∨ P1 = (0 : Int) →
                                                                                        ¬O1 ∨ ¬N1 ∨ S1 = P1 →
                                                                                          ¬O1 ∨ ¬N1 ∨ H1 →
                                                                                            ¬Q1 ∨ ¬I1 ∨ J1 = F1 →
                                                                                              ¬Q1 ∨ ¬I1 ∨ S1 = J1 →
                                                                                                ¬J ∨
                                                                                                    K = (T1 = (2 : Int)) →
                                                                                                  ¬J ∨ K1 ∧ J →
                                                                                                    ¬Q ∨
                                                                                                        F =
                                                                                                          (-3 : Int) +
                                                                                                            T1 →
                                                                                                      ¬Q ∨
                                                                                                          G =
                                                                                                            (-4 : Int) +
                                                                                                              T1 →
                                                                                                        ¬Q ∨ L = H + I →
                                                                                                          ¬Q ∨ T ∧ Q →
                                                                                                            ¬T ∨
                                                                                                                M =
                                                                                                                  (E =
                                                                                                                    (1 :
                                                                                                                      Int)) →
                                                                                                              ¬T ∨ X ∧ T →
                                                                                                                ¬U ∨ T →
                                                                                                                  ¬X ∨
                                                                                                                      A =
                                                                                                                        (-2 :
                                                                                                                            Int) +
                                                                                                                          T1 →
                                                                                                                    ¬X ∨
                                                                                                                        B =
                                                                                                                          (-3 :
                                                                                                                              Int) +
                                                                                                                            T1 →
                                                                                                                      ¬X ∨
                                                                                                                          E =
                                                                                                                            (-2 :
                                                                                                                                Int) +
                                                                                                                              T1 →
                                                                                                                        ¬X ∨
                                                                                                                            O =
                                                                                                                              C +
                                                                                                                                D →
                                                                                                                          ¬X ∨
                                                                                                                              ¬((1 :
                                                                                                                                      Int) ≤
                                                                                                                                    E) =
                                                                                                                                  N →
                                                                                                                            ¬X ∨
                                                                                                                                X ∧
                                                                                                                                  J →
                                                                                                                              ¬Y ∨
                                                                                                                                  X →
                                                                                                                                ¬B1 ∨
                                                                                                                                    B1 ∧
                                                                                                                                      J →
                                                                                                                                  ¬I1 ∨
                                                                                                                                      F1 =
                                                                                                                                        D1 +
                                                                                                                                          E1 →
                                                                                                                                    ¬K1 ∨
                                                                                                                                        G1 =
                                                                                                                                          (T1 =
                                                                                                                                            (1 :
                                                                                                                                              Int)) →
                                                                                                                                      ¬K1 ∨
                                                                                                                                          N1 ∧
                                                                                                                                            K1 →
                                                                                                                                        ¬L1 ∨
                                                                                                                                            K1 →
                                                                                                                                          ¬O1 ∨
                                                                                                                                              N1 →
                                                                                                                                            ¬R1 ∨
                                                                                                                                                R1 ∧
                                                                                                                                                  Q1 →
                                                                                                                                              R1 =
                                                                                                                                                  True →
                                                                                                                                                ¬((1 :
                                                                                                                                                          Int) ≤
                                                                                                                                                        T1) =
                                                                                                                                                      H1 →
                                                                                                                                                  r4
                                                                                                                                                    S1
                                                                                                                                                    T1) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r1) ∧
  ((∀ (A B C : Int),
  ∀ (D E F v_6 v_7 v_8 : Prop),
  ∀ (v_9 : Int),
  ∀ (v_10 v_11 v_12 : Prop),
  ∀ (v_13 : Int),
  (r1) →
  (r0 v_6 v_7 v_8 v_9 B) →
  (r0 v_10 v_11 v_12 v_13 A) →
  (v_6 = True) →
  (v_7 = False) →
  (v_8 = False) →
  ((9 : Int) = v_9) →
  (v_10 = True) →
  (v_11 = False) →
  (v_12 = False) →
  ((8 : Int) = v_13) →
  (D = (C = (55 : Int))) →
  (¬F ∨ F ∧ E) →
  (¬D) →
  (F = True) →
  (C = A + B) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_fibo_2calls_10_true-unreach-call_000»
