import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_id2_i5_o5_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_i5_o5_true-unreach-call_true-termination_000.smt2":136:1-136:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_i5_o5_true-unreach-call_true-termination_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_i5_o5_true-unreach-call_true-termination_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_i5_o5_true-unreach-call_true-termination_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_i5_o5_true-unreach-call_true-termination_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_i5_o5_true-unreach-call_true-termination_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_i5_o5_true-unreach-call_true-termination_000.smt2":61:1-94:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_i5_o5_true-unreach-call_true-termination_000.smt2":95:1-104:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_i5_o5_true-unreach-call_true-termination_000.smt2":105:1-123:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_i5_o5_true-unreach-call_true-termination_000.smt2":124:1-134:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Prop → Prop → Prop → Int → Int → Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Int → Prop),
  (∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = True) →
  (v_3 = True) →
  (v_4 = True) →
  r2 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = True) →
  (v_4 = True) →
  r2 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = False) →
  (v_4 = False) →
  r2 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (r3 B A) →
  (v_2 = True) →
  (v_3 = False) →
  (v_4 = False) →
  r2 v_2 v_3 v_4 A B) ∧
  ((∀ (A : Int),
  (True) →
  r4 A) ∧
  ((∀ (A B C : Int),
  ∀ (D E F : Prop),
  ∀ (G : Int),
  ∀ (H I : Prop),
  ∀ (J : Int),
  ∀ (K L : Prop),
  ∀ (M : Int),
  ∀ (N O : Prop),
  ∀ (P Q : Int),
  ∀ (v_17 v_18 : Prop),
  (r4 Q) →
  (r2 F v_17 v_18 A B) →
  (v_17 = False) →
  (v_18 = False) →
  (¬N ∨ N ∧ F ∨ L ∧ K ∨ I ∧ H) →
  (¬H ∨ ¬F ∨ ¬D) →
  (¬I ∨ ¬H ∨ J = (1 : Int)) →
  (¬I ∨ ¬H ∨ P = J) →
  (¬I ∨ ¬H ∨ D) →
  (¬K ∨ ¬H ∨ ¬E) →
  (¬L ∨ ¬K ∨ M = (0 : Int)) →
  (¬L ∨ ¬K ∨ P = M) →
  (¬L ∨ ¬K ∨ E) →
  (¬N ∨ ¬F ∨ G = C) →
  (¬N ∨ ¬F ∨ P = G) →
  (¬F ∨ A = (-2 : Int) + Q) →
  (¬F ∨ C = (2 : Int) + B) →
  (¬F ∨ H ∧ F) →
  (¬H ∨ D = (Q = (1 : Int))) →
  (¬H ∨ K ∧ H) →
  (¬I ∨ H) →
  (¬L ∨ K) →
  (¬O ∨ O ∧ N) →
  (O = True) →
  (E = (Q = (0 : Int))) →
  r3 P Q) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r0) ∧
  ((∀ (A : Int),
  ∀ (B C D v_4 v_5 v_6 : Prop),
  ∀ (v_7 : Int),
  (r0) →
  (r2 v_4 v_5 v_6 v_7 A) →
  (v_4 = True) →
  (v_5 = False) →
  (v_6 = False) →
  ((5 : Int) = v_7) →
  (¬D ∨ D ∧ C) →
  (¬B) →
  (D = True) →
  (B = (A = (5 : Int))) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_id2_i5_o5_true-unreach-call_true-termination_000»
