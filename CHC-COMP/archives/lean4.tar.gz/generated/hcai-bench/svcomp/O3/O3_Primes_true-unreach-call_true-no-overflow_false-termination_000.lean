import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_Primes_true-unreach-call_true-no-overflow_false-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":417:1-417:12 (check-sat, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":14:1-23:2 (clause 1, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":24:1-33:2 (clause 2, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":34:1-43:2 (clause 3, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":44:1-54:2 (clause 4, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":55:1-64:2 (clause 5, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":65:1-78:2 (clause 6, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":79:1-95:2 (clause 7, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":96:1-139:2 (clause 8, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":140:1-149:2 (clause 9, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":150:1-173:2 (clause 10, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":174:1-206:2 (clause 11, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":207:1-255:2 (clause 12, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":256:1-314:2 (clause 13, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":315:1-331:2 (clause 14, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":332:1-373:2 (clause 15, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":374:1-387:2 (clause 16, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":388:1-404:2 (clause 17, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Primes_true-unreach-call_true-no-overflow_false-termination_000.smt2":405:1-415:2 (clause 18, command 28)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  ∃ (r3 : Prop),
  ∃ (r4 : Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Prop → Prop → Prop → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Prop),
  (∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = True) →
  (v_4 = True) →
  (v_5 = True) →
  r7 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = True) →
  (v_5 = True) →
  r7 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = False) →
  (v_5 = False) →
  r7 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (r5 C A B) →
  (v_3 = True) →
  (v_4 = False) →
  (v_5 = False) →
  r7 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B : Int),
  (True) →
  r4 A B) ∧
  ((∀ (A B : Prop),
  ∀ (C D E F : Int),
  (r4 D F) →
  (¬B ∨ ¬A ∨ E = C) →
  (¬A ∨ B ∧ A) →
  (A = True) →
  (¬B ∨ ¬A ∨ C = F) →
  r2 D E F) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F G H I : Int),
  (r2 G A I) →
  (C = (-1 : Int) * A) →
  (¬E ∨ ¬D ∨ F = C) →
  (¬E ∨ ¬D ∨ H = F) →
  (¬E ∨ ¬D ∨ B) →
  (¬D ∨ E ∧ D) →
  (D = True) →
  (¬((0 : Int) ≤ A) = B) →
  r2 G H I) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D : Prop),
  ∀ (E F G H : Int),
  ∀ (I J K L : Prop),
  ∀ (M : Int),
  ∀ (N O : Prop),
  ∀ (P Q R : Int),
  ∀ (S : Prop),
  ∀ (T : Int),
  ∀ (U : Prop),
  ∀ (V : Int),
  ∀ (W X : Prop),
  ∀ (Y Z A1 : Int),
  ∀ (v_27 v_28 : Prop),
  let a!1 := ¬N ∨ ¬((1 : Int) ≤ F) = J;
  r2 Z C A1 →
    r7 U v_27 v_28 Z G H →
      v_27 = False →
        v_28 = False →
          A = (-1 : Int) * C →
            ¬L ∨ ¬K ∨ M = (1 : Int) →
              ¬L ∨ ¬K ∨ Q = M →
                ¬L ∨ ¬K ∨ I →
                  ¬N ∨ ¬D ∨ E = C →
                    ¬N ∨ ¬D ∨ F = E →
                      ¬N ∨ ¬D ∨ ¬B →
                        ¬N ∨ ¬K ∨ ¬J →
                          ¬O ∨ ¬N ∨ P = (0 : Int) →
                            ¬O ∨ ¬N ∨ Q = P →
                              ¬O ∨ ¬N ∨ J →
                                ¬S ∨ O ∧ N ∨ L ∧ K →
                                  ¬U ∨ ¬K ∨ ¬I →
                                    ¬W ∨ W ∧ U ∨ W ∧ S →
                                      ¬W ∨ ¬S ∨ T = Q →
                                        ¬W ∨ ¬S ∨ Y = T →
                                          ¬W ∨ ¬U ∨ V = R →
                                            ¬W ∨ ¬U ∨ Y = V →
                                              ¬K ∨ I = (F = (1 : Int)) →
                                                ¬K ∨ N ∧ K →
                                                  ¬L ∨ K →
                                                    ¬N ∨ ¬((1 : Int) ≤ F) = J →
                                                      ¬N ∨ N ∧ D →
                                                        ¬O ∨ N →
                                                          ¬U ∨ G = (-1 : Int) + F →
                                                            ¬U ∨ R = H + Z →
                                                              ¬U ∨ U ∧ K →
                                                                ¬X ∨ W ∧ X → X = True → ¬((0 : Int) ≤ C) = B → r5 Y Z A1) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r1) ∧
  ((∀ (A : Int),
  ∀ (B C D E F G H : Prop),
  ∀ (I J K : Int),
  let a!1 := B = (¬A ≤ (46339 : Int) ∨ ¬A ≥ (0 : Int));
  r1 →
    a!1 →
      A = (-1 : Int) + J →
        ¬C ∨ ¬D ∨ ¬E →
          ¬H ∨ ¬F ∨ ¬E →
            ¬H ∨ ¬G ∨ I = J →
              ¬H ∨ ¬G ∨ K = I →
                ¬E ∨ F = (J = (2 : Int)) →
                  ¬E ∨ E ∧ C → ¬H ∨ H ∧ E → ¬G ∨ G ∧ H → ¬B → G = True → ¬((2 : Int) ≤ J) = D → r8 J K) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D : Prop),
  ∀ (E : Int),
  ∀ (F G : Prop),
  ∀ (H : Int),
  ∀ (I J : Prop),
  ∀ (K : Int),
  ∀ (L M : Prop),
  ∀ (N : Int),
  ∀ (O : Prop),
  ∀ (P : Int),
  ∀ (Q R : Prop),
  ∀ (S T U : Int),
  let a!1 := ¬F ∨ ¬((0 : Int) ≤ K) = G;
  let a!2 := ¬R ∨ ¬((4 : Int) ≤ N) = O;
  r0 T K N P C →
    A = (-1 : Int) * C →
      ¬F ∨ ¬D ∨ H = E →
        ¬F ∨ ¬D ∨ E = C →
          ¬F ∨ ¬D ∨ ¬B →
            ¬I ∨ ¬F ∨ ¬G →
              ¬I ∨ ¬L ∨ ¬J →
                ¬R ∨ ¬L ∨ M →
                  ¬R ∨ ¬Q ∨ S = P →
                    ¬R ∨ ¬Q ∨ U = S →
                      ¬R ∨ ¬Q ∨ ¬O →
                        ¬F ∨ ¬((0 : Int) ≤ K) = G →
                          ¬F ∨ F ∧ D →
                            ¬I ∨ J = (H = (0 : Int)) →
                              ¬I ∨ I ∧ F →
                                ¬R ∨ ¬((4 : Int) ≤ N) = O →
                                  ¬R ∨ L ∧ R →
                                    ¬L ∨ M = (K = (0 : Int)) →
                                      ¬L ∨ L ∧ I → ¬Q ∨ Q ∧ R → Q = True → ¬((0 : Int) ≤ C) = B → r8 T U) ∧
  ((∀ (A : Int),
  ∀ (B C D E F G H I J : Prop),
  ∀ (K : Int),
  ∀ (L : Prop),
  ∀ (M : Int),
  ∀ (N O P : Prop),
  ∀ (Q R S : Int),
  ∀ (T U : Prop),
  ∀ (V : Int),
  ∀ (W X Y Z A1 v_27 v_28 : Prop),
  let a!1 := B = (¬A ≤ (46339 : Int) ∨ ¬A ≥ (0 : Int));
  let a!2 := ¬Z ∨ ¬(V ≤ (1 : Int)) = W;
  let a!3 := ¬Z ∨ ¬(S ≤ (1 : Int)) = T;
  let a!4 := L = (¬K ≤ (46339 : Int) ∨ ¬K ≥ (0 : Int));
  let a!5 := O = (¬(46340 : Int) ≤ M ∧ M ≥ (0 : Int));
  r1 →
    r7 Z v_27 v_28 S V Q →
      v_27 = False →
        v_28 = False →
          a!1 →
            A = (-1 : Int) + R →
              ¬F ∨ ¬E ∨ N = G →
                ¬F ∨ ¬E ∨ C →
                  G ∨ ¬E ∨ ¬F →
                    ¬Z ∨ I ∧ H ∨ F ∧ E →
                      ¬D ∨ ¬H ∨ ¬E →
                        ¬I ∨ ¬H ∨ N = J →
                          ¬I ∨ D ∨ ¬H →
                            ¬J ∨ ¬I ∨ ¬H →
                              ¬E ∨ C = (R = (2 : Int)) →
                                ¬E ∨ H ∧ E →
                                  ¬F ∨ E →
                                    ¬Z ∨ ¬(V ≤ (1 : Int)) = W →
                                      ¬Z ∨ ¬(S ≤ (1 : Int)) = T →
                                        ¬Z ∨ P = (O ∧ N) →
                                          ¬Z ∨ Y = (W ∧ X) →
                                            ¬Z ∨ a!4 →
                                              ¬Z ∨ a!5 →
                                                ¬Z ∨ U = (Q = R) →
                                                  ¬Z ∨ X = (T ∧ U) →
                                                    ¬Z ∨ K = (-1 : Int) + S →
                                                      ¬Z ∨ M = (-1 : Int) + V →
                                                        ¬Z ∨ P →
                                                          ¬Z ∨ Y →
                                                            ¬A1 ∨ A1 ∧ Z →
                                                              ¬I ∨ H →
                                                                ¬L ∨ ¬Z → A1 = True → ¬B → ¬((2 : Int) ≤ R) = D → r3) ∧
  ((∀ (A B : Int),
  ∀ (C : Prop),
  ∀ (D : Int),
  ∀ (E : Prop),
  ∀ (F : Int),
  ∀ (G H : Prop),
  ∀ (I J : Int),
  ∀ (K L : Prop),
  ∀ (M : Int),
  ∀ (N O P Q R S T U : Prop),
  ∀ (V : Int),
  ∀ (W : Prop),
  ∀ (X : Int),
  ∀ (Y Z A1 : Prop),
  ∀ (B1 C1 D1 : Int),
  ∀ (E1 F1 : Prop),
  ∀ (G1 : Int),
  ∀ (H1 I1 J1 K1 L1 v_38 v_39 : Prop),
  let a!1 := ¬G ∨ ¬((0 : Int) ≤ J) = H;
  let a!2 := ¬N ∨ ¬((4 : Int) ≤ M) = O;
  let a!3 := ¬K1 ∨ ¬(G1 ≤ (1 : Int)) = H1;
  let a!4 := ¬K1 ∨ ¬(D1 ≤ (1 : Int)) = E1;
  let a!5 := W = (¬V ≤ (46339 : Int) ∨ ¬V ≥ (0 : Int));
  let a!6 := Z = (¬(46340 : Int) ≤ X ∧ X ≥ (0 : Int));
  r0 C1 J M A D →
    r7 K1 v_38 v_39 D1 G1 B1 →
      v_38 = False →
        v_39 = False →
          B = (-1 : Int) * D →
            ¬G ∨ ¬E ∨ F = D →
              ¬G ∨ ¬E ∨ I = F →
                ¬G ∨ ¬E ∨ ¬C →
                  ¬N ∨ ¬K ∨ L →
                    ¬P ∨ ¬H ∨ ¬G →
                      ¬Q ∨ ¬P ∨ ¬K →
                        K1 ∧ R ∨ ¬K1 ∨ T ∧ K1 →
                          ¬K1 ∨ ¬R ∨ Y = S →
                            S ∨ ¬R ∨ ¬K1 →
                              O ∨ ¬R ∨ ¬N →
                                ¬T ∨ Q ∨ ¬P →
                                  ¬T ∨ Y = U ∨ ¬K1 →
                                    ¬T ∨ ¬U ∨ ¬K1 →
                                      ¬G ∨ ¬((0 : Int) ≤ J) = H →
                                        ¬G ∨ G ∧ E →
                                          ¬K ∨ L = (J = (0 : Int)) →
                                            ¬K ∨ P ∧ K →
                                              ¬N ∨ ¬((4 : Int) ≤ M) = O →
                                                ¬N ∨ N ∧ K →
                                                  ¬P ∨ Q = (I = (0 : Int)) →
                                                    ¬P ∨ P ∧ G →
                                                      ¬R ∨ R ∧ N →
                                                        ¬K1 ∨ ¬(G1 ≤ (1 : Int)) = H1 →
                                                          ¬K1 ∨ ¬(D1 ≤ (1 : Int)) = E1 →
                                                            ¬K1 ∨ A1 = (Z ∧ Y) →
                                                              ¬K1 ∨ J1 = (H1 ∧ I1) →
                                                                ¬K1 ∨ a!5 →
                                                                  ¬K1 ∨ a!6 →
                                                                    ¬K1 ∨ F1 = (B1 = C1) →
                                                                      ¬K1 ∨ I1 = (E1 ∧ F1) →
                                                                        ¬K1 ∨ V = (-1 : Int) + D1 →
                                                                          ¬K1 ∨ X = (-1 : Int) + G1 →
                                                                            ¬K1 ∨ A1 →
                                                                              ¬K1 ∨ J1 →
                                                                                ¬L1 ∨ L1 ∧ K1 →
                                                                                  ¬T ∨ T ∧ P →
                                                                                    ¬W ∨ ¬K1 →
                                                                                      L1 = True →
                                                                                        ¬((0 : Int) ≤ D) = C → r3) ∧
  ((∀ (A : Int),
  ∀ (B C : Prop),
  ∀ (D E F G H I : Int),
  (r8 E H) →
  (¬B ∨ D = I ∨ ¬C) →
  (¬B ∨ A = E ∨ ¬C) →
  (¬B ∨ F = A ∨ ¬C) →
  (¬B ∨ G = D ∨ ¬C) →
  (¬B ∨ B ∧ C) →
  (B = True) →
  (I = (-1 : Int) + H) →
  r6 E F G H I) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D : Prop),
  ∀ (E : Int),
  ∀ (F G H I J K : Prop),
  ∀ (L M N : Int),
  ∀ (O : Prop),
  ∀ (P : Int),
  ∀ (Q : Prop),
  ∀ (R S T U : Int),
  ∀ (V W : Prop),
  ∀ (X Y Z A1 B1 C1 : Int),
  let a!1 := ¬O ∨ M = L + (-1 : Int) * T;
  let a!2 := ¬J ∨ ¬((0 : Int) ≤ L) = K;
  r0 Y L B1 C1 C →
    A = (-1 : Int) * C →
      ¬O ∨ ¬I ∨ ¬H →
        ¬D ∨ ¬J ∨ E = C →
          ¬D ∨ ¬J ∨ T = E →
            ¬D ∨ ¬J ∨ ¬B →
              ¬F ∨ ¬G ∨ ¬H →
                ¬K ∨ ¬F ∨ ¬J →
                  ¬Q ∨ K ∨ ¬J →
                    ¬W ∨ W ∧ Q ∨ W ∧ O →
                      ¬W ∨ ¬O ∨ P = M →
                        ¬W ∨ ¬O ∨ S = P →
                          ¬W ∨ ¬Q ∨ R = N →
                            ¬W ∨ ¬Q ∨ S = R →
                              ¬V ∨ X = T ∨ ¬W →
                                ¬V ∨ ¬W ∨ U = S →
                                  ¬V ∨ Z = U ∨ ¬W →
                                    ¬V ∨ A1 = X ∨ ¬W →
                                      ¬O ∨ M = L + (-1 : Int) * T →
                                        ¬O ∨ H ∧ O →
                                          ¬H ∨ I = (L = (0 : Int)) →
                                            ¬H ∨ F ∧ H →
                                              ¬J ∨ ¬((0 : Int) ≤ L) = K →
                                                ¬J ∨ D ∧ J →
                                                  ¬F ∨ G = (T = (0 : Int)) →
                                                    ¬F ∨ F ∧ J →
                                                      ¬Q ∨ N = (-1 : Int) * L →
                                                        ¬Q ∨ Q ∧ J →
                                                          ¬V ∨ V ∧ W → V = True → ¬((0 : Int) ≤ C) = B → r6 Y Z A1 B1 C1) ∧
  ((∀ (A : Int),
  ∀ (B C : Prop),
  ∀ (D E F G H I : Int),
  (r6 E F A G H) →
  (I = D ∨ ¬B ∨ ¬C) →
  (¬B ∨ B ∧ C) →
  (B = True) →
  (D = A ∨ ¬B ∨ ¬C) →
  r0 E F G H I) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F G H I J K : Int),
  (r0 G H I J A) →
  (C = (-1 : Int) * A) →
  (F = C ∨ ¬D ∨ ¬E) →
  (K = F ∨ ¬D ∨ ¬E) →
  (¬D ∨ B ∨ ¬E) →
  (¬D ∨ D ∧ E) →
  (D = True) →
  (¬((0 : Int) ≤ A) = B) →
  r0 G H I J K) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r3) →
  (True) →
  False)))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_Primes_true-unreach-call_true-no-overflow_false-termination_000»
