import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_id2_b5_o10_true-unreach-call_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_b5_o10_true-unreach-call_000.smt2":146:1-146:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_b5_o10_true-unreach-call_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_b5_o10_true-unreach-call_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_b5_o10_true-unreach-call_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_b5_o10_true-unreach-call_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_b5_o10_true-unreach-call_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_b5_o10_true-unreach-call_000.smt2":61:1-104:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_b5_o10_true-unreach-call_000.smt2":105:1-114:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_b5_o10_true-unreach-call_000.smt2":115:1-133:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id2_b5_o10_true-unreach-call_000.smt2":134:1-144:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Prop),
    ∃ (r1 : Prop → Prop → Prop → Int → Int → Prop),
    ∃ (r2 : Int → Prop),
    ∃ (r3 : Int → Int → Prop),
    ∃ (r4 : Int → Prop),
    (∀ (A B : Int),
    ∀ (v_2 v_3 v_4 : Prop),
    (True) →
    (v_2 = True) →
    (v_3 = True) →
    (v_4 = True) →
    r1 v_2 v_3 v_4 A B) ∧
    ((∀ (A B : Int),
    ∀ (v_2 v_3 v_4 : Prop),
    (True) →
    (v_2 = False) →
    (v_3 = True) →
    (v_4 = True) →
    r1 v_2 v_3 v_4 A B) ∧
    ((∀ (A B : Int),
    ∀ (v_2 v_3 v_4 : Prop),
    (True) →
    (v_2 = False) →
    (v_3 = False) →
    (v_4 = False) →
    r1 v_2 v_3 v_4 A B) ∧
    ((∀ (A B : Int),
    ∀ (v_2 v_3 v_4 : Prop),
    (r3 B A) →
    (v_2 = True) →
    (v_3 = False) →
    (v_4 = False) →
    r1 v_2 v_3 v_4 A B) ∧
    ((∀ (A : Int),
    (True) →
    r4 A) ∧
    ((∀ (A B : Int),
    ∀ (C : Prop),
    ∀ (D E : Int),
    ∀ (F G : Prop),
    ∀ (H : Int),
    ∀ (I J : Prop),
    ∀ (K L : Int),
    ∀ (M : Prop),
    ∀ (N O : Int),
    ∀ (P Q : Prop),
    ∀ (R : Int),
    ∀ (S T : Prop),
    ∀ (U : Int),
    ∀ (V W : Prop),
    ∀ (X Y : Int),
    ∀ (v_25 v_26 : Prop),
    let a!1 := ¬G ∨ ¬(B ≤ (4 : Int)) = C;
    let a!2 := ¬Q ∨ ¬(L ≤ (4 : Int)) = M;
    r4 Y →
      r1 G v_25 v_26 A B →
        v_25 = False →
          v_26 = False →
            ¬I ∨ ¬G ∨ ¬F →
              ¬J ∨ ¬I ∨ K = (0 : Int) →
                ¬J ∨ ¬I ∨ L = K →
                  ¬J ∨ ¬I ∨ F →
                    ¬Q ∨ Q ∧ G ∨ J ∧ I →
                      ¬Q ∨ ¬G ∨ H = E →
                        ¬Q ∨ ¬G ∨ L = H →
                          ¬S ∨ ¬P ∨ ¬I →
                            ¬T ∨ ¬S ∨ U = (0 : Int) →
                              ¬T ∨ ¬S ∨ X = U →
                                ¬T ∨ ¬S ∨ P →
                                  ¬V ∨ V ∧ Q ∨ T ∧ S →
                                    ¬V ∨ ¬Q ∨ R = O →
                                      ¬V ∨ ¬Q ∨ X = R →
                                        ¬G ∨ ¬(B ≤ (4 : Int)) = C →
                                          ¬G ∨ A = (-2 : Int) + Y →
                                            ¬G ∨ D = (1 : Int) + B →
                                              (¬G ∨ E = if C then (5 : Int) else D) →
                                                ¬G ∨ I ∧ G →
                                                  ¬I ∨ F = (Y = (1 : Int)) →
                                                    ¬I ∨ S ∧ I →
                                                      ¬J ∨ I →
                                                        ¬Q ∨ ¬(L ≤ (4 : Int)) = M →
                                                          ¬Q ∨ N = (1 : Int) + L →
                                                            (¬Q ∨ O = if M then (5 : Int) else N) →
                                                              ¬T ∨ S → ¬W ∨ W ∧ V → W = True → P = (Y = (0 : Int)) → r3 X Y) ∧
    ((∀ (A : Int),
    (True) →
    r2 A) ∧
    ((∀ (A B C D : Int),
    ∀ (E F G v_7 v_8 v_9 : Prop),
    (r2 B) →
    (r1 v_7 v_8 v_9 C D) →
    (v_7 = True) →
    (v_8 = False) →
    (v_9 = False) →
    (A = B) →
    (¬G ∨ G ∧ F) →
    (E = True) →
    (G = True) →
    (E = (D = (10 : Int))) →
    r0) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r0) →
    (True) →
    False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_id2_b5_o10_true-unreach-call_000»
