import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_Addition03_false-no-overflow_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_false-no-overflow_000.smt2":158:1-158:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_false-no-overflow_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_false-no-overflow_000.smt2":18:1-36:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_false-no-overflow_000.smt2":37:1-72:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_false-no-overflow_000.smt2":73:1-98:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_false-no-overflow_000.smt2":99:1-145:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Addition03_false-no-overflow_000.smt2":146:1-156:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  (∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r0) ∧
  ((∀ (A B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F G H I J : Int),
  (r0) →
  (¬E ∨ ¬B ∨ ¬A) →
  (¬E ∨ ¬D ∨ C = H) →
  (¬E ∨ ¬D ∨ F = G) →
  (¬E ∨ ¬D ∨ I = C) →
  (¬E ∨ ¬D ∨ J = F) →
  (¬D ∨ E ∧ D) →
  (¬E ∨ E ∧ A) →
  (D = True) →
  (B = (H = (0 : Int))) →
  r2 G H I J) ∧
  ((∀ (A B : Prop),
  ∀ (C D E F G H I : Int),
  ∀ (J : Prop),
  ∀ (K L : Int),
  ∀ (M : Prop),
  ∀ (N : Int),
  ∀ (O : Prop),
  ∀ (P Q R : Int),
  ∀ (S T : Prop),
  ∀ (U V W X Y : Int),
  (r2 V W D C) →
  (¬J ∨ ¬B ∨ ¬A) →
  (¬M ∨ ¬A ∨ B) →
  (¬T ∨ T ∧ M ∨ T ∧ J) →
  (¬T ∨ ¬J ∨ I = E) →
  (¬T ∨ ¬J ∨ K = F) →
  (¬T ∨ ¬J ∨ P = K) →
  (¬T ∨ ¬J ∨ Q = I) →
  (¬T ∨ ¬M ∨ L = G) →
  (¬T ∨ ¬M ∨ N = H) →
  (¬T ∨ ¬M ∨ P = N) →
  (¬T ∨ ¬M ∨ Q = L) →
  (¬T ∨ ¬S ∨ R = P) →
  (¬T ∨ ¬S ∨ U = Q) →
  (¬T ∨ ¬S ∨ X = R) →
  (¬T ∨ ¬S ∨ Y = U) →
  (¬T ∨ ¬S ∨ ¬O) →
  (¬J ∨ E = (-1 : Int) + C) →
  (¬J ∨ F = (1 : Int) + D) →
  (¬J ∨ J ∧ A) →
  (¬M ∨ G = (1 : Int) + C) →
  (¬M ∨ H = (-1 : Int) + D) →
  (¬M ∨ M ∧ A) →
  (¬S ∨ T ∧ S) →
  (¬T ∨ O = (P = (0 : Int))) →
  (S = True) →
  (¬(D ≤ (0 : Int)) = B) →
  r2 V W X Y) ∧
  ((∀ (A B : Prop),
  ∀ (C D E : Int),
  ∀ (F G : Prop),
  ∀ (H : Int),
  ∀ (I J K L M : Prop),
  let a!1 := ¬L ∨ ¬((100 : Int) ≤ D) = F;
  let a!2 := ¬L ∨ ¬((100 : Int) ≤ E) = G;
  let a!3 := ¬L ∨ ¬(H ≤ (199 : Int)) = J;
  r0 →
    ¬L ∨ ¬B ∨ C = D →
      ¬L ∨ ¬B ∨ H = C →
        ¬L ∨ ¬B ∨ A →
          ¬L ∨ ¬((100 : Int) ≤ D) = F →
            ¬L ∨ ¬((100 : Int) ≤ E) = G →
              ¬L ∨ ¬(H ≤ (199 : Int)) = J →
                ¬L ∨ I = (G ∨ F) →
                  ¬L ∨ K = (J ∨ I) → ¬L ∨ L ∧ B → ¬L ∨ ¬K → ¬M ∨ M ∧ L → M = True → A = (E = (0 : Int)) → r1) ∧
  ((∀ (A B : Prop),
  ∀ (C D E F G H I : Int),
  ∀ (J : Prop),
  ∀ (K L : Int),
  ∀ (M : Prop),
  ∀ (N O : Int),
  ∀ (P : Prop),
  ∀ (Q : Int),
  ∀ (R : Prop),
  ∀ (S T : Int),
  ∀ (U : Prop),
  ∀ (V W X : Int),
  ∀ (Y Z : Prop),
  ∀ (A1 : Int),
  ∀ (B1 C1 D1 E1 F1 : Prop),
  let a!1 := ¬E1 ∨ ¬((100 : Int) ≤ W) = Y;
  let a!2 := ¬E1 ∨ ¬((100 : Int) ≤ X) = Z;
  let a!3 := ¬E1 ∨ ¬(A1 ≤ (199 : Int)) = C1;
  r2 W X D C →
    ¬J ∨ ¬B ∨ ¬A →
      B ∨ ¬M ∨ ¬A →
        ¬R ∨ R ∧ M ∨ R ∧ J →
          ¬R ∨ ¬J ∨ I = E →
            ¬R ∨ ¬J ∨ Q = I →
              ¬R ∨ ¬J ∨ K = F →
                ¬R ∨ ¬J ∨ O = K →
                  ¬R ∨ ¬M ∨ Q = L →
                    ¬R ∨ ¬M ∨ L = G →
                      ¬R ∨ ¬M ∨ N = H →
                        ¬R ∨ ¬M ∨ O = N →
                          ¬U ∨ ¬R ∨ T = S →
                            ¬U ∨ ¬R ∨ S = Q →
                              ¬U ∨ ¬R ∨ P →
                                ¬E1 ∨ ¬U ∨ V = T →
                                  ¬E1 ∨ ¬U ∨ A1 = V →
                                    ¬J ∨ E = (-1 : Int) + C →
                                      ¬J ∨ F = (1 : Int) + D →
                                        ¬J ∨ J ∧ A →
                                          ¬M ∨ G = (1 : Int) + C →
                                            ¬M ∨ H = (-1 : Int) + D →
                                              ¬M ∨ M ∧ A →
                                                ¬R ∨ P = (O = (0 : Int)) →
                                                  ¬U ∨ U ∧ R →
                                                    ¬E1 ∨ ¬((100 : Int) ≤ W) = Y →
                                                      ¬E1 ∨ ¬((100 : Int) ≤ X) = Z →
                                                        ¬E1 ∨ ¬(A1 ≤ (199 : Int)) = C1 →
                                                          ¬E1 ∨ B1 = (Z ∨ Y) →
                                                            ¬E1 ∨ D1 = (C1 ∨ B1) →
                                                              ¬E1 ∨ E1 ∧ U →
                                                                ¬E1 ∨ ¬D1 →
                                                                  ¬F1 ∨ F1 ∧ E1 → F1 = True → ¬(D ≤ (0 : Int)) = B → r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_Addition03_false-no-overflow_000»
