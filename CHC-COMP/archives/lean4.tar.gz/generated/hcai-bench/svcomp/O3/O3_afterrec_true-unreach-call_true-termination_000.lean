import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_afterrec_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_afterrec_true-unreach-call_true-termination_000.smt2":85:1-85:12 (check-sat, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_afterrec_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_afterrec_true-unreach-call_true-termination_000.smt2":18:1-32:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_afterrec_true-unreach-call_true-termination_000.smt2":33:1-50:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_afterrec_true-unreach-call_true-termination_000.smt2":51:1-72:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_afterrec_true-unreach-call_true-termination_000.smt2":73:1-83:2 (clause 5, command 9)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Prop),
  (∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r0) ∧
  ((∀ (A B C : Prop),
  ∀ (D E : Int),
  (r0) →
  (¬C ∨ ¬B ∨ E = D) →
  (¬B ∨ C ∧ B) →
  (¬A) →
  (B = True) →
  (¬C ∨ ¬B ∨ D = (2 : Int)) →
  r2 E) ∧
  ((∀ (A : Prop),
  ∀ (B : Int),
  ∀ (C : Prop),
  ∀ (D : Int),
  ∀ (E F : Prop),
  ∀ (G H : Int),
  (r2 B) →
  (D = (-1 : Int) + B) →
  (¬F ∨ ¬E ∨ G = D) →
  (¬F ∨ ¬E ∨ H = G) →
  (¬F ∨ ¬E ∨ ¬C) →
  (¬E ∨ F ∧ E) →
  (¬A) →
  (E = True) →
  (¬((3 : Int) ≤ B) = A) →
  r2 H) ∧
  ((∀ (A : Prop),
  ∀ (B : Int),
  ∀ (C : Prop),
  ∀ (D : Int),
  ∀ (E : Prop),
  ∀ (F G : Int),
  ∀ (H I J : Prop),
  let a!1 := ¬I ∨ ¬((4 : Int) ≤ G) = H;
  r2 D →
    B = (-1 : Int) + D →
      ¬E ∨ G = F ∨ ¬I →
        ¬E ∨ F = D ∨ ¬I →
          ¬E ∨ C ∨ ¬I →
            ¬I ∨ ¬((4 : Int) ≤ G) = H → ¬I ∨ E ∧ I → ¬J ∨ J ∧ I → H ∨ ¬I → ¬A → J = True → ¬((3 : Int) ≤ D) = A → r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_afterrec_true-unreach-call_true-termination_000»
