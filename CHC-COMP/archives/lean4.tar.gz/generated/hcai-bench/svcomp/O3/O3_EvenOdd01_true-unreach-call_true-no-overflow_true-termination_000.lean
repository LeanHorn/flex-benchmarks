import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_EvenOdd01_true-unreach-call_true-no-overflow_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_EvenOdd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":117:1-117:12 (check-sat, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_EvenOdd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_EvenOdd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":18:1-33:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_EvenOdd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":34:1-62:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_EvenOdd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":63:1-104:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_EvenOdd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":105:1-115:2 (clause 5, command 9)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Prop),
  (∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r0) ∧
  ((∀ (A B C : Prop),
  ∀ (D E F : Int),
  (r0) →
  (¬C ∨ ¬B ∨ D = E) →
  (¬C ∨ ¬B ∨ F = D) →
  (¬B ∨ C ∧ B) →
  (¬A) →
  (B = True) →
  (¬((0 : Int) ≤ E) = A) →
  r2 E F) ∧
  ((∀ (A B C D E F G H : Prop),
  ∀ (I : Int),
  ∀ (J : Prop),
  ∀ (K : Int),
  ∀ (L M : Prop),
  ∀ (N O P : Int),
  (r2 O I) →
  (¬C ∨ B ∨ ¬A) →
  (¬E ∨ ¬D ∨ ¬C) →
  (¬F ∨ ¬B ∨ ¬A) →
  (¬H ∨ ¬G ∨ ¬F) →
  (¬M ∨ G ∧ F ∨ D ∧ C) →
  (¬M ∨ ¬L ∨ N = K) →
  (¬M ∨ ¬L ∨ P = N) →
  (¬M ∨ ¬L ∨ ¬J) →
  (¬C ∨ E = (I = (0 : Int))) →
  (¬C ∨ C ∧ A) →
  (¬D ∨ C) →
  (¬F ∨ H = (I = (1 : Int))) →
  (¬F ∨ F ∧ A) →
  (¬G ∨ F) →
  (¬L ∨ M ∧ L) →
  (¬M ∨ K = (-2 : Int) + I) →
  (¬M ∨ J = (I = (2 : Int))) →
  (L = True) →
  (¬((1 : Int) ≤ I) = B) →
  r2 O P) ∧
  ((∀ (A B C D : Prop),
  ∀ (E F : Int),
  ∀ (G H I J K : Prop),
  ∀ (L : Int),
  ∀ (M N : Prop),
  ∀ (O : Int),
  ∀ (P Q : Prop),
  ∀ (R S T U : Int),
  ∀ (V W X : Prop),
  (r2 S F) →
  (¬W ∨ P ∧ Q ∨ N ∧ M ∨ K ∧ J) →
  (¬J ∨ P ∧ D ∨ M ∧ C) →
  (¬K ∨ ¬J ∨ L = (0 : Int)) →
  (¬K ∨ ¬J ∨ T = L) →
  (¬K ∨ ¬J ∨ G) →
  (¬M ∨ B ∨ ¬A) →
  (¬M ∨ ¬H ∨ ¬C) →
  (¬N ∨ ¬M ∨ O = (0 : Int)) →
  (¬N ∨ ¬M ∨ T = O) →
  (¬N ∨ ¬M ∨ H) →
  (¬P ∨ ¬B ∨ ¬A) →
  (¬P ∨ ¬Q ∨ R = (1 : Int)) →
  (¬P ∨ ¬Q ∨ T = R) →
  (¬P ∨ ¬I ∨ ¬D) →
  (¬P ∨ I ∨ ¬Q) →
  (¬W ∨ U = S % (2 : Int)) →
  (¬W ∨ V = (T = U)) →
  (¬W ∨ ¬V) →
  (¬X ∨ X ∧ W) →
  (¬J ∨ E = (-2 : Int) + F) →
  (¬J ∨ G = (F = (2 : Int))) →
  (¬K ∨ J) →
  (¬M ∨ H = (F = (0 : Int))) →
  (¬M ∨ M ∧ A) →
  (M ∨ ¬C) →
  (¬N ∨ M) →
  (¬P ∨ I = (F = (1 : Int))) →
  (¬P ∨ P ∧ A) →
  (P ∨ ¬D) →
  (P ∨ ¬Q) →
  (X = True) →
  (¬((1 : Int) ≤ F) = B) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_EvenOdd01_true-unreach-call_true-no-overflow_true-termination_000»
