import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_sum01_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum01_true-unreach-call_true-termination_000.smt2":132:1-132:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum01_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum01_true-unreach-call_true-termination_000.smt2":18:1-41:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum01_true-unreach-call_true-termination_000.smt2":42:1-61:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum01_true-unreach-call_true-termination_000.smt2":62:1-90:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum01_true-unreach-call_true-termination_000.smt2":91:1-119:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum01_true-unreach-call_true-termination_000.smt2":120:1-130:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  (∀ (A : Int),
  (True) →
  r0 A) ∧
  ((∀ (A B C : Int),
  ∀ (D E F : Prop),
  ∀ (G : Int),
  ∀ (H I : Prop),
  ∀ (J K L M : Int),
  let a!1 := D = (¬(2000 : Int) ≤ C ∧ C ≥ (0 : Int));
  r0 B →
    a!1 →
      A = B →
        C = (1000 : Int) + K →
          ¬I ∨ ¬F ∨ ¬E →
            ¬I ∨ ¬H ∨ G = (1 : Int) →
              ¬I ∨ ¬H ∨ J = (0 : Int) →
                ¬I ∨ ¬H ∨ L = J →
                  ¬I ∨ ¬H ∨ M = G → ¬H ∨ I ∧ H → ¬I ∨ I ∧ E → D = True → H = True → ¬((1 : Int) ≤ K) = F → r2 K L M) ∧
  ((∀ (A B : Int),
  ∀ (C : Prop),
  ∀ (D E F : Int),
  ∀ (G H : Prop),
  ∀ (I J K L : Int),
  (r2 J A B) →
  (D = (1 : Int) + B) →
  (E = (2 : Int) + A) →
  (¬H ∨ ¬G ∨ F = D) →
  (¬H ∨ ¬G ∨ I = E) →
  (¬H ∨ ¬G ∨ K = I) →
  (¬H ∨ ¬G ∨ L = F) →
  (¬H ∨ ¬G ∨ C) →
  (¬G ∨ H ∧ G) →
  (G = True) →
  (¬(J ≤ B) = C) →
  r2 J K L) ∧
  ((∀ (A B C : Int),
  ∀ (D E F : Prop),
  ∀ (G H I J : Int),
  ∀ (K L M N O P Q : Prop),
  let a!1 := D = (¬(2000 : Int) ≤ C ∧ C ≥ (0 : Int));
  r0 B →
    a!1 →
      A = B →
        C = (1000 : Int) + H →
          ¬P ∨ ¬F ∨ J = G →
            ¬P ∨ ¬F ∨ G = (0 : Int) →
              ¬P ∨ ¬F ∨ E →
                ¬P ∨ K = (J = I) →
                  ¬P ∨ N = (L ∨ K) →
                    ¬P ∨ ¬N = O →
                      ¬P ∨ L = (J = (0 : Int)) →
                        ¬P ∨ I = (2 : Int) * H →
                          ¬P ∨ P ∧ F → ¬P ∨ O → ¬Q ∨ Q ∧ P → ¬M ∨ ¬P → D = True → Q = True → ¬((1 : Int) ≤ H) = E → r1) ∧
  ((∀ (A B C : Int),
  ∀ (D : Prop),
  ∀ (E : Int),
  ∀ (F : Prop),
  ∀ (G H : Int),
  ∀ (I : Prop),
  ∀ (J K L M : Int),
  ∀ (N O P Q R S T : Prop),
  (r2 K A C) →
  (B = (1 : Int) + C) →
  (E = (2 : Int) + A) →
  (¬I ∨ ¬F ∨ G = E) →
  (¬I ∨ ¬F ∨ H = G) →
  (¬I ∨ ¬F ∨ ¬D) →
  (¬S ∨ ¬I ∨ M = J) →
  (¬S ∨ ¬I ∨ J = H) →
  (¬I ∨ I ∧ F) →
  (¬S ∨ N = (M = L)) →
  (¬S ∨ Q = (O ∨ N)) →
  (¬S ∨ ¬Q = R) →
  (¬S ∨ O = (M = (0 : Int))) →
  (¬S ∨ L = (2 : Int) * K) →
  (¬S ∨ S ∧ I) →
  (¬S ∨ R) →
  (¬T ∨ T ∧ S) →
  (¬P ∨ ¬S) →
  (T = True) →
  (¬(K ≤ C) = D) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  (True) →
  False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_sum01_true-unreach-call_true-termination_000»
