import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_sum_non_eq_true-unreach-call_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_eq_true-unreach-call_000.smt2":114:1-114:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_eq_true-unreach-call_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_eq_true-unreach-call_000.smt2":18:1-36:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_eq_true-unreach-call_000.smt2":37:1-56:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_eq_true-unreach-call_000.smt2":57:1-76:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_eq_true-unreach-call_000.smt2":77:1-101:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_eq_true-unreach-call_000.smt2":102:1-112:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  (∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r0) ∧
  ((∀ (A B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F G H I J : Int),
  (r0) →
  (¬E ∨ ¬B ∨ ¬A) →
  (¬E ∨ ¬D ∨ C = G) →
  (¬E ∨ ¬D ∨ F = H) →
  (¬E ∨ ¬D ∨ I = F) →
  (¬E ∨ ¬D ∨ J = C) →
  (¬D ∨ E ∧ D) →
  (¬E ∨ E ∧ A) →
  (D = True) →
  (B = (H = (0 : Int))) →
  r1 G H I J) ∧
  ((∀ (A B : Int),
  ∀ (C : Prop),
  ∀ (D E F : Int),
  ∀ (G H : Prop),
  ∀ (I J K L M : Int),
  (r1 J K A B) →
  (D = (1 : Int) + B) →
  (E = (-1 : Int) + A) →
  (¬H ∨ ¬G ∨ F = D) →
  (¬H ∨ ¬G ∨ I = E) →
  (¬H ∨ ¬G ∨ L = I) →
  (¬H ∨ ¬G ∨ M = F) →
  (¬H ∨ ¬G ∨ ¬C) →
  (¬G ∨ H ∧ G) →
  (G = True) →
  (C = (E = (0 : Int))) →
  r1 J K L M) ∧
  ((∀ (A B : Prop),
  ∀ (C D E F G : Int),
  ∀ (H I J : Prop),
  (r0) →
  (¬B ∨ C = D ∨ ¬I) →
  (¬B ∨ F = C ∨ ¬I) →
  (¬B ∨ A ∨ ¬I) →
  (¬I ∨ H = (F = G)) →
  (¬I ∨ G = D + E) →
  (¬I ∨ B ∧ I) →
  (¬I ∨ ¬H) →
  (¬J ∨ J ∧ I) →
  (J = True) →
  (A = (E = (0 : Int))) →
  r2) ∧
  ((∀ (A B C : Int),
  ∀ (D : Prop),
  ∀ (E : Int),
  ∀ (F : Prop),
  ∀ (G H : Int),
  ∀ (I : Prop),
  ∀ (J K L M N : Int),
  ∀ (O P Q : Prop),
  (r1 K L A B) →
  (C = (-1 : Int) + A) →
  (E = (1 : Int) + B) →
  (¬I ∨ ¬F ∨ G = E) →
  (¬I ∨ ¬F ∨ H = G) →
  (¬I ∨ ¬F ∨ D) →
  (¬I ∨ J = H ∨ ¬P) →
  (¬I ∨ M = J ∨ ¬P) →
  (¬P ∨ O = (M = N)) →
  (¬P ∨ N = K + L) →
  (¬P ∨ I ∧ P) →
  (¬P ∨ ¬O) →
  (¬Q ∨ Q ∧ P) →
  (¬I ∨ I ∧ F) →
  (Q = True) →
  (D = (C = (0 : Int))) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  (True) →
  False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_sum_non_eq_true-unreach-call_000»
