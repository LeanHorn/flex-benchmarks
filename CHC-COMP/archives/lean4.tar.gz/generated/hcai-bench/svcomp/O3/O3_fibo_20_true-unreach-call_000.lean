import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_fibo_20_true-unreach-call_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_20_true-unreach-call_000.smt2":143:1-143:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_20_true-unreach-call_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_20_true-unreach-call_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_20_true-unreach-call_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_20_true-unreach-call_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_20_true-unreach-call_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_20_true-unreach-call_000.smt2":61:1-101:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_20_true-unreach-call_000.smt2":102:1-111:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_20_true-unreach-call_000.smt2":112:1-130:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_fibo_20_true-unreach-call_000.smt2":131:1-141:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop → Prop → Prop → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Int → Prop),
  (∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = True) →
  (v_3 = True) →
  (v_4 = True) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = True) →
  (v_4 = True) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = False) →
  (v_4 = False) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (r3 B A) →
  (v_2 = True) →
  (v_3 = False) →
  (v_4 = False) →
  r0 v_2 v_3 v_4 A B) ∧
  ((∀ (A : Int),
  (True) →
  r4 A) ∧
  ((∀ (A B C D : Int),
  ∀ (E F G H : Prop),
  ∀ (I : Int),
  ∀ (J K : Prop),
  ∀ (L M N : Int),
  ∀ (O : Prop),
  ∀ (P : Int),
  ∀ (Q : Prop),
  ∀ (R : Int),
  ∀ (S T : Prop),
  ∀ (U V : Int),
  ∀ (v_22 v_23 v_24 v_25 : Prop),
  (r4 V) →
  (r0 Q v_22 v_23 A D) →
  (r0 Q v_24 v_25 B C) →
  (v_22 = False) →
  (v_23 = False) →
  (v_24 = False) →
  (v_25 = False) →
  (¬H ∨ ¬G ∨ I = (1 : Int)) →
  (¬H ∨ ¬G ∨ M = I) →
  (¬H ∨ ¬G ∨ E) →
  (¬J ∨ ¬G ∨ ¬F) →
  (¬K ∨ ¬J ∨ L = (0 : Int)) →
  (¬K ∨ ¬J ∨ M = L) →
  (¬K ∨ ¬J ∨ F) →
  (¬O ∨ K ∧ J ∨ H ∧ G) →
  (¬Q ∨ ¬G ∨ ¬E) →
  (¬S ∨ S ∧ Q ∨ S ∧ O) →
  (¬S ∨ ¬O ∨ P = M) →
  (¬S ∨ ¬O ∨ U = P) →
  (¬S ∨ ¬Q ∨ R = N) →
  (¬S ∨ ¬Q ∨ U = R) →
  (¬G ∨ E = (V = (1 : Int))) →
  (¬G ∨ J ∧ G) →
  (¬H ∨ G) →
  (¬K ∨ J) →
  (¬Q ∨ A = (-1 : Int) + V) →
  (¬Q ∨ B = (-2 : Int) + V) →
  (¬Q ∨ N = C + D) →
  (¬Q ∨ Q ∧ G) →
  (¬T ∨ T ∧ S) →
  (T = True) →
  (¬((1 : Int) ≤ V) = F) →
  r3 U V) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r1) ∧
  ((∀ (A : Int),
  ∀ (B C D v_4 v_5 v_6 : Prop),
  ∀ (v_7 : Int),
  (r1) →
  (r0 v_4 v_5 v_6 v_7 A) →
  (v_4 = True) →
  (v_5 = False) →
  (v_6 = False) →
  ((20 : Int) = v_7) →
  (¬D ∨ D ∧ C) →
  (¬B) →
  (D = True) →
  (B = (A = (6765 : Int))) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_fibo_20_true-unreach-call_000»
