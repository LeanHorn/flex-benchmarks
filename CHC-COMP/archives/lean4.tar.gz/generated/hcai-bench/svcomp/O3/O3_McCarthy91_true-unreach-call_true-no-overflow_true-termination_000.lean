import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":189:1-189:12 (check-sat, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":11:1-20:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":21:1-30:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":31:1-40:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":41:1-51:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":52:1-61:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":62:1-78:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":79:1-99:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":100:1-117:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":118:1-143:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":144:1-153:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":154:1-176:2 (clause 11, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000.smt2":177:1-187:2 (clause 12, command 19)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Prop → Prop → Prop → Int → Int → Prop),
  ∃ (r5 : Int → Int → Prop),
  (∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = True) →
  (v_3 = True) →
  (v_4 = True) →
  r4 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = True) →
  (v_4 = True) →
  r4 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (True) →
  (v_2 = False) →
  (v_3 = False) →
  (v_4 = False) →
  r4 v_2 v_3 v_4 A B) ∧
  ((∀ (A B : Int),
  ∀ (v_2 v_3 v_4 : Prop),
  (r5 B A) →
  (v_2 = True) →
  (v_3 = False) →
  (v_4 = False) →
  r4 v_2 v_3 v_4 A B) ∧
  ((∀ (A : Int),
  (True) →
  r0 A) ∧
  ((∀ (A B C D : Prop),
  ∀ (E F G : Int),
  (r0 G) →
  (¬D ∨ ¬B ∨ ¬A) →
  (¬D ∨ ¬C ∨ E = G) →
  (¬D ∨ ¬C ∨ F = E) →
  (¬C ∨ D ∧ C) →
  (¬D ∨ D ∧ A) →
  (C = True) →
  (¬(G ≤ (100 : Int)) = B) →
  r3 F G) ∧
  ((∀ (A B : Int),
  ∀ (C : Prop),
  ∀ (D : Int),
  ∀ (E F : Prop),
  ∀ (G H I : Int),
  ∀ (v_9 v_10 v_11 : Prop),
  (r3 A I) →
  (r4 v_9 v_10 v_11 B D) →
  (v_9 = True) →
  (v_10 = False) →
  (v_11 = False) →
  (¬(D ≤ (100 : Int)) = C) →
  (¬F ∨ ¬E ∨ G = D) →
  (¬F ∨ ¬E ∨ H = G) →
  (¬F ∨ ¬E ∨ ¬C) →
  (¬E ∨ F ∧ E) →
  (E = True) →
  (B = (11 : Int) + A) →
  r3 H I) ∧
  ((∀ (A B : Prop),
  ∀ (C D : Int),
  ∀ (E F : Prop),
  ∀ (G H : Int),
  (r0 H) →
  (¬E ∨ ¬B ∨ C = H) →
  (¬E ∨ ¬B ∨ D = C) →
  (¬E ∨ ¬B ∨ A) →
  (¬F ∨ E ∧ F) →
  (¬E ∨ G = (-10 : Int) + D) →
  (¬E ∨ E ∧ B) →
  (F = True) →
  (¬(H ≤ (100 : Int)) = A) →
  r5 G H) ∧
  ((∀ (A B : Int),
  ∀ (C : Prop),
  ∀ (D : Int),
  ∀ (E : Prop),
  ∀ (F G : Int),
  ∀ (H : Prop),
  ∀ (I J : Int),
  ∀ (K L : Prop),
  ∀ (M N : Int),
  ∀ (v_14 v_15 v_16 : Prop),
  (r3 A N) →
  (r4 v_14 v_15 v_16 B D) →
  (v_14 = True) →
  (v_15 = False) →
  (v_16 = False) →
  (¬(D ≤ (100 : Int)) = C) →
  (¬H ∨ ¬E ∨ F = D) →
  (¬H ∨ ¬E ∨ G = F) →
  (¬H ∨ ¬E ∨ C) →
  (¬K ∨ ¬H ∨ I = G) →
  (¬K ∨ ¬H ∨ J = I) →
  (¬L ∨ K ∧ L) →
  (¬H ∨ H ∧ E) →
  (¬K ∨ M = (-10 : Int) + J) →
  (¬K ∨ K ∧ H) →
  (L = True) →
  (B = (11 : Int) + A) →
  r5 M N) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r1) ∧
  ((∀ (A : Prop),
  ∀ (B C D : Int),
  ∀ (E F G H I v_9 v_10 v_11 : Prop),
  (r1) →
  (r4 v_9 v_10 v_11 B C) →
  (v_9 = True) →
  (v_10 = False) →
  (v_11 = False) →
  (¬(B ≤ (101 : Int)) = E) →
  (A = (C = (91 : Int))) →
  (G = (F ∧ E)) →
  (F = (C = D)) →
  (¬I ∨ I ∧ H) →
  (¬A) →
  (I = True) →
  (¬G) →
  (D = (-10 : Int) + B) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  (True) →
  False)))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_McCarthy91_true-unreach-call_true-no-overflow_true-termination_000»
