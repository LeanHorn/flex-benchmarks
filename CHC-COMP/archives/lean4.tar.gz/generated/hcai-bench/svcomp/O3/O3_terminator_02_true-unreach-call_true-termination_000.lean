import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_terminator_02_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_02_true-unreach-call_true-termination_000.smt2":225:1-225:12 (check-sat, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_02_true-unreach-call_true-termination_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_02_true-unreach-call_true-termination_000.smt2":19:1-50:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_02_true-unreach-call_true-termination_000.smt2":51:1-79:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_02_true-unreach-call_true-termination_000.smt2":80:1-119:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_02_true-unreach-call_true-termination_000.smt2":120:1-177:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_02_true-unreach-call_true-termination_000.smt2":178:1-191:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_02_true-unreach-call_true-termination_000.smt2":192:1-212:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_terminator_02_true-unreach-call_true-termination_000.smt2":213:1-223:2 (clause 8, command 13)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Prop),
  (∀ (A B : Int),
  (True) →
  r3 A B) ∧
  ((∀ (A B C D E F : Int),
  ∀ (G H I J K L M : Prop),
  ∀ (N O P : Int),
  ∀ (Q R : Prop),
  ∀ (S T U V : Int),
  let a!1 := G = (¬(199 : Int) ≤ E ∧ E ≥ (0 : Int));
  let a!2 := H = (¬(199 : Int) ≤ F ∧ F ≥ (0 : Int));
  r3 V D →
    ¬(O ≤ (100 : Int)) = J →
      a!1 →
        a!2 →
          I = (H ∧ G) →
            M = (K ∧ J) →
              A = D →
                B = D →
                  C = D →
                    E = (99 : Int) + N →
                      F = (99 : Int) + O →
                        ¬L ∨ M ∨ ¬R →
                          ¬R ∨ ¬Q ∨ P = N →
                            ¬R ∨ ¬Q ∨ S = O →
                              ¬R ∨ ¬Q ∨ T = S →
                                ¬R ∨ ¬Q ∨ U = P →
                                  ¬Q ∨ R ∧ Q → ¬R ∨ R ∧ L → I = True → Q = True → ¬((100 : Int) ≤ N) = K → r0 T U V) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D : Prop),
  ∀ (E F G : Int),
  ∀ (H I J : Prop),
  ∀ (K L M : Int),
  ∀ (N O : Prop),
  ∀ (P Q R S : Int),
  let a!1 := ¬O ∨ ¬((101 : Int) ≤ G) = I;
  let a!2 := ¬O ∨ ¬(L ≤ (100 : Int)) = H;
  r1 C F S →
    ¬O ∨ ¬D ∨ E = C →
      ¬O ∨ ¬D ∨ G = E →
        ¬O ∨ ¬D ∨ ¬B →
          ¬O ∨ ¬N ∨ M = K →
            ¬O ∨ ¬N ∨ P = L →
              ¬O ∨ ¬N ∨ Q = P →
                ¬O ∨ ¬N ∨ R = M →
                  ¬O ∨ ¬N ∨ J →
                    ¬N ∨ O ∧ N →
                      ¬O ∨ ¬((101 : Int) ≤ G) = I →
                        ¬O ∨ ¬(L ≤ (100 : Int)) = H →
                          ¬O ∨ J = (I ∧ H) →
                            ¬O ∨ K = (-1 : Int) + G → ¬O ∨ L = (-1 : Int) + F → ¬O ∨ O ∧ D → N = True → A = S → r0 Q R S) ∧
  ((∀ (A B C D E F G : Int),
  ∀ (H I J K L M : Prop),
  ∀ (N O P : Int),
  ∀ (Q : Prop),
  ∀ (R S T : Int),
  ∀ (U V W X Y Z A1 : Prop),
  let a!1 := H = (¬(199 : Int) ≤ F ∧ F ≥ (0 : Int));
  let a!2 := I = (¬(199 : Int) ≤ G ∧ G ≥ (0 : Int));
  let a!3 := ¬Z ∨ ¬((101 : Int) ≤ T) = U;
  let a!4 := ¬Z ∨ ¬(S ≤ (99 : Int)) = V;
  r3 A E →
    ¬(N ≤ (100 : Int)) = K →
      a!1 →
        a!2 →
          J = (I ∧ H) →
            M = (L ∧ K) →
              B = E →
                C = E →
                  D = E →
                    F = (99 : Int) + O →
                      G = (99 : Int) + N →
                        ¬Q ∨ P = N ∨ ¬Z →
                          ¬Q ∨ R = O ∨ ¬Z →
                            ¬Q ∨ S = R ∨ ¬Z →
                              ¬Q ∨ T = P ∨ ¬Z →
                                ¬Q ∨ ¬M ∨ ¬Z →
                                  ¬Z ∨ ¬((101 : Int) ≤ T) = U →
                                    ¬Z ∨ ¬(S ≤ (99 : Int)) = V →
                                      ¬Z ∨ X = (V ∨ U) →
                                        ¬Z ∨ ¬X = Y →
                                          ¬Z ∨ Q ∧ Z →
                                            ¬Z ∨ Y →
                                              ¬A1 ∨ A1 ∧ Z → ¬W ∨ ¬Z → J = True → A1 = True → ¬((100 : Int) ≤ O) = L → r2) ∧
  ((∀ (A B C D : Int),
  ∀ (E F G : Prop),
  ∀ (H I J : Int),
  ∀ (K : Prop),
  ∀ (L : Int),
  ∀ (M N : Prop),
  ∀ (O : Int),
  ∀ (P : Prop),
  ∀ (Q R S : Int),
  ∀ (T : Prop),
  ∀ (U V W X Y Z : Int),
  ∀ (A1 : Prop),
  ∀ (B1 C1 : Int),
  ∀ (D1 : Prop),
  ∀ (E1 F1 G1 : Int),
  ∀ (H1 I1 J1 K1 L1 M1 N1 : Prop),
  let a!1 := ¬K ∨ ¬((101 : Int) ≤ D) = F;
  let a!2 := ¬K ∨ ¬(H ≤ (100 : Int)) = E;
  let a!3 := ¬T ∨ ¬((100 : Int) ≤ R) = P;
  let a!4 := ¬M1 ∨ ¬((101 : Int) ≤ G1) = H1;
  let a!5 := ¬M1 ∨ ¬(F1 ≤ (99 : Int)) = I1;
  r1 O Q B →
    ¬M ∨ ¬K ∨ C = O →
      ¬M ∨ ¬K ∨ D = C →
        ¬N ∨ ¬M ∨ ¬K →
          N ∨ ¬T ∨ ¬M →
            ¬M1 ∨ D1 ∧ M1 ∨ A1 ∧ M1 →
              ¬A1 ∨ ¬K ∨ J = H →
                ¬A1 ∨ ¬K ∨ L = I →
                  ¬A1 ∨ ¬K ∨ V = J →
                    ¬A1 ∨ ¬K ∨ W = L →
                      ¬A1 ∨ ¬K ∨ ¬G →
                        ¬M1 ∨ Z = V ∨ ¬A1 →
                          ¬M1 ∨ B1 = W ∨ ¬A1 →
                            ¬M1 ∨ F1 = B1 ∨ ¬A1 →
                              ¬M1 ∨ G1 = Z ∨ ¬A1 →
                                ¬D1 ∨ ¬T ∨ Y = U →
                                  ¬D1 ∨ ¬T ∨ S = Q →
                                    ¬D1 ∨ ¬T ∨ U = R →
                                      ¬D1 ∨ ¬T ∨ X = S →
                                        ¬D1 ∨ ¬T ∨ ¬P →
                                          ¬D1 ∨ ¬M1 ∨ C1 = X →
                                            ¬D1 ∨ ¬M1 ∨ E1 = Y →
                                              ¬D1 ∨ F1 = E1 ∨ ¬M1 →
                                                ¬D1 ∨ G1 = C1 ∨ ¬M1 →
                                                  ¬K ∨ ¬((101 : Int) ≤ D) = F →
                                                    ¬K ∨ ¬(H ≤ (100 : Int)) = E →
                                                      ¬K ∨ G = (F ∧ E) →
                                                        ¬K ∨ H = (-1 : Int) + Q →
                                                          ¬K ∨ I = (-1 : Int) + D →
                                                            ¬K ∨ M ∧ K →
                                                              ¬T ∨ ¬((100 : Int) ≤ R) = P →
                                                                ¬T ∨ R = (1 : Int) + O →
                                                                  ¬T ∨ T ∧ M →
                                                                    ¬M1 ∨ ¬((101 : Int) ≤ G1) = H1 →
                                                                      ¬M1 ∨ ¬(F1 ≤ (99 : Int)) = I1 →
                                                                        ¬M1 ∨ K1 = (I1 ∨ H1) →
                                                                          ¬M1 ∨ ¬K1 = L1 →
                                                                            ¬M1 ∨ L1 →
                                                                              ¬N1 ∨ N1 ∧ M1 →
                                                                                ¬A1 ∨ A1 ∧ K →
                                                                                  ¬D1 ∨ D1 ∧ T →
                                                                                    ¬J1 ∨ ¬M1 → N1 = True → A = B → r2) ∧
  ((∀ (A : Int),
  ∀ (B C : Prop),
  ∀ (D E F G : Int),
  (r0 F A G) →
  (¬C ∨ ¬B ∨ E = D) →
  (¬B ∨ C ∧ B) →
  (B = True) →
  (¬C ∨ ¬B ∨ D = A) →
  r1 E F G) ∧
  ((∀ (A : Int),
  ∀ (B C : Prop),
  ∀ (D : Int),
  ∀ (E : Prop),
  ∀ (F : Int),
  ∀ (G H : Prop),
  ∀ (I J K L : Int),
  let a!1 := ¬H ∨ ¬((100 : Int) ≤ F) = E;
  r1 D K L →
    ¬B ∨ C ∨ ¬H →
      ¬H ∨ ¬G ∨ I = F →
        ¬H ∨ ¬G ∨ J = I →
          ¬G ∨ E ∨ ¬H →
            ¬G ∨ H ∧ G → ¬H ∨ ¬((100 : Int) ≤ F) = E → ¬H ∨ F = (1 : Int) + D → ¬H ∨ H ∧ B → G = True → A = L → r1 J K L) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  (True) →
  False)))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_terminator_02_true-unreach-call_true-termination_000»
