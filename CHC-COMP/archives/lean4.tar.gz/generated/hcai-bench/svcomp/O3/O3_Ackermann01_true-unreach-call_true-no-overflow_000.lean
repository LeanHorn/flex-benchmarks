import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_Ackermann01_true-unreach-call_true-no-overflow_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":218:1-218:12 (check-sat, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":11:1-20:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":21:1-30:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":31:1-40:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":41:1-51:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":52:1-61:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":62:1-80:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":81:1-113:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":114:1-131:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":132:1-167:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":168:1-177:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":178:1-205:2 (clause 11, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_Ackermann01_true-unreach-call_true-no-overflow_000.smt2":206:1-216:2 (clause 12, command 19)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Int → Int → Prop),
  ∃ (r4 : Prop → Prop → Prop → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Prop),
  (∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = True) →
  (v_4 = True) →
  (v_5 = True) →
  r4 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = True) →
  (v_5 = True) →
  r4 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (True) →
  (v_3 = False) →
  (v_4 = False) →
  (v_5 = False) →
  r4 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B C : Int),
  ∀ (v_3 v_4 v_5 : Prop),
  (r5 C B A) →
  (v_3 = True) →
  (v_4 = False) →
  (v_5 = False) →
  r4 v_3 v_4 v_5 A B C) ∧
  ((∀ (A B : Int),
  (True) →
  r0 A B) ∧
  ((∀ (A B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F G H I J : Int),
  (r0 I J) →
  (¬E ∨ ¬B ∨ ¬A) →
  (¬E ∨ ¬D ∨ C = I) →
  (¬E ∨ ¬D ∨ F = J) →
  (¬E ∨ ¬D ∨ G = C) →
  (¬E ∨ ¬D ∨ H = F) →
  (¬D ∨ E ∧ D) →
  (¬E ∨ E ∧ A) →
  (D = True) →
  (B = (J = (0 : Int))) →
  r3 G H I J) ∧
  ((∀ (A B C D : Int),
  ∀ (E F : Prop),
  ∀ (G : Int),
  ∀ (H I : Prop),
  ∀ (J : Int),
  ∀ (K : Prop),
  ∀ (L M N : Int),
  ∀ (O P : Prop),
  ∀ (Q R S T U : Int),
  ∀ (v_21 v_22 : Prop),
  (r3 A B T U) →
  (r4 F v_21 v_22 B C D) →
  (v_21 = False) →
  (v_22 = False) →
  (M = (-1 : Int) + B) →
  (¬H ∨ ¬F ∨ ¬E) →
  (¬I ∨ ¬H ∨ J = (1 : Int)) →
  (¬I ∨ ¬H ∨ L = J) →
  (¬I ∨ ¬H ∨ E) →
  (¬P ∨ P ∧ F ∨ I ∧ H) →
  (¬P ∨ ¬F ∨ G = D) →
  (¬P ∨ ¬F ∨ L = G) →
  (¬P ∨ ¬O ∨ N = L) →
  (¬P ∨ ¬O ∨ Q = M) →
  (¬P ∨ ¬O ∨ R = N) →
  (¬P ∨ ¬O ∨ S = Q) →
  (¬P ∨ ¬O ∨ ¬K) →
  (¬F ∨ C = (-1 : Int) + A) →
  (¬F ∨ H ∧ F) →
  (¬I ∨ H) →
  (¬O ∨ P ∧ O) →
  (¬P ∨ K = (M = (0 : Int))) →
  (O = True) →
  (E = (A = (0 : Int))) →
  r3 R S T U) ∧
  ((∀ (A B : Prop),
  ∀ (C D : Int),
  ∀ (E F : Prop),
  ∀ (G H I : Int),
  (r0 H I) →
  (¬E ∨ ¬B ∨ C = H) →
  (¬E ∨ ¬B ∨ D = C) →
  (A ∨ ¬E ∨ ¬B) →
  (¬E ∨ G = (1 : Int) + D) →
  (¬E ∨ E ∧ B) →
  (¬F ∨ F ∧ E) →
  (F = True) →
  (A = (I = (0 : Int))) →
  r5 G H I) ∧
  ((∀ (A B C D : Int),
  ∀ (E F : Prop),
  ∀ (G : Int),
  ∀ (H I : Prop),
  ∀ (J K : Int),
  ∀ (L : Prop),
  ∀ (M : Int),
  ∀ (N : Prop),
  ∀ (O P : Int),
  ∀ (Q : Prop),
  ∀ (R S : Int),
  ∀ (T U : Prop),
  ∀ (V W X : Int),
  ∀ (v_24 v_25 : Prop),
  (r3 A B W X) →
  (r4 F v_24 v_25 B C D) →
  (v_24 = False) →
  (v_25 = False) →
  (K = (-1 : Int) + B) →
  (¬H ∨ ¬F ∨ ¬E) →
  (¬I ∨ ¬H ∨ J = (1 : Int)) →
  (¬I ∨ ¬H ∨ M = J) →
  (¬I ∨ ¬H ∨ E) →
  (¬N ∨ N ∧ F ∨ I ∧ H) →
  (¬N ∨ ¬F ∨ G = D) →
  (¬N ∨ ¬F ∨ M = G) →
  (¬Q ∨ ¬N ∨ O = M) →
  (¬Q ∨ ¬N ∨ P = O) →
  (¬Q ∨ ¬N ∨ L) →
  (¬T ∨ ¬Q ∨ R = P) →
  (¬T ∨ ¬Q ∨ S = R) →
  (¬F ∨ C = (-1 : Int) + A) →
  (¬F ∨ H ∧ F) →
  (¬I ∨ H) →
  (¬N ∨ L = (K = (0 : Int))) →
  (¬Q ∨ Q ∧ N) →
  (¬T ∨ V = (1 : Int) + S) →
  (¬T ∨ T ∧ Q) →
  (¬U ∨ U ∧ T) →
  (U = True) →
  (E = (A = (0 : Int))) →
  r5 V W X) ∧
  ((∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r1) ∧
  ((∀ (A B : Prop),
  ∀ (C D : Int),
  ∀ (E F : Prop),
  ∀ (G : Int),
  ∀ (H I J K L v_12 v_13 v_14 : Prop),
  let a!1 := A = (¬C ≤ (3 : Int) ∨ ¬C ≥ (0 : Int));
  let a!2 := B = (¬D ≤ (23 : Int) ∨ ¬D ≥ (0 : Int));
  r1 →
    r4 v_12 v_13 v_14 C D G →
      v_12 = True →
        v_13 = False →
          v_14 = False →
            ¬((0 : Int) ≤ D) = F →
              ¬(G ≤ (-1 : Int)) = I →
                a!1 → a!2 → J = (I ∨ H) → H = (F ∨ E) → ¬L ∨ L ∧ K → ¬A → ¬B → ¬J → L = True → ¬((0 : Int) ≤ C) = E → r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  (True) →
  False)))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_Ackermann01_true-unreach-call_true-no-overflow_000»
