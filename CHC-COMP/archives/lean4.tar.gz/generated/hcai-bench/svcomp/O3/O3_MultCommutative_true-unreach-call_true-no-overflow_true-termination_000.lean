import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000.smt2":230:1-230:12 (check-sat, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000.smt2":11:1-20:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000.smt2":21:1-42:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000.smt2":43:1-69:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000.smt2":70:1-83:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000.smt2":84:1-100:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000.smt2":101:1-127:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000.smt2":128:1-154:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000.smt2":155:1-168:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000.smt2":169:1-185:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000.smt2":186:1-217:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000.smt2":218:1-228:2 (clause 11, command 18)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Prop),
  (∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r1) ∧
  ((∀ (A B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F G H I J : Int),
  let a!1 := B = (¬H ≤ (46340 : Int) ∨ ¬H ≥ (0 : Int));
  let a!2 := A = (¬G ≤ (46340 : Int) ∨ ¬G ≥ (0 : Int));
  r1 →
    a!1 →
      ¬E ∨ ¬D ∨ C = (0 : Int) →
        ¬E ∨ ¬D ∨ F = H → ¬E ∨ ¬D ∨ I = C → ¬E ∨ ¬D ∨ J = F → ¬D ∨ E ∧ D → ¬A → ¬B → D = True → a!2 → r4 G H I J) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D : Prop),
  ∀ (E : Int),
  ∀ (F G : Prop),
  ∀ (H I J K L : Int),
  ∀ (M N : Prop),
  ∀ (O P Q R S : Int),
  (r2 P Q I C) →
  (¬((0 : Int) ≤ C) = B) →
  (¬F ∨ ¬D ∨ E = C) →
  (¬F ∨ ¬D ∨ H = E) →
  (¬F ∨ ¬D ∨ ¬B) →
  (¬N ∨ ¬G ∨ ¬F) →
  (¬N ∨ ¬M ∨ L = J) →
  (¬N ∨ ¬M ∨ O = K) →
  (¬N ∨ ¬M ∨ R = L) →
  (¬N ∨ ¬M ∨ S = O) →
  (¬F ∨ G = (H = (0 : Int))) →
  (¬F ∨ F ∧ D) →
  (¬M ∨ N ∧ M) →
  (¬N ∨ J = I + P) →
  (¬N ∨ K = (-1 : Int) + H) →
  (¬N ∨ N ∧ F) →
  (M = True) →
  (A = (-1 : Int) * C) →
  r4 P Q R S) ∧
  ((∀ (A : Int),
  ∀ (B C : Prop),
  ∀ (D E F G H : Int),
  (r4 E F G A) →
  (¬C ∨ ¬B ∨ H = D) →
  (¬B ∨ C ∧ B) →
  (B = True) →
  (¬C ∨ ¬B ∨ D = A) →
  r2 E F G H) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F G H I J : Int),
  (r2 G H I A) →
  (¬((0 : Int) ≤ A) = B) →
  (¬E ∨ ¬D ∨ F = C) →
  (¬E ∨ ¬D ∨ J = F) →
  (¬E ∨ ¬D ∨ B) →
  (¬D ∨ E ∧ D) →
  (D = True) →
  (C = (-1 : Int) * A) →
  r2 G H I J) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D : Prop),
  ∀ (E F : Int),
  ∀ (G : Prop),
  ∀ (H : Int),
  ∀ (I : Prop),
  ∀ (J K : Int),
  ∀ (L M : Prop),
  ∀ (N O P Q R S : Int),
  (r2 P Q H C) →
  (¬((0 : Int) ≤ C) = B) →
  (¬D ∨ F = E ∨ ¬I) →
  (E = C ∨ ¬D ∨ ¬I) →
  (¬B ∨ ¬D ∨ ¬I) →
  (¬M ∨ ¬I ∨ J = H) →
  (¬M ∨ ¬I ∨ O = J) →
  (¬M ∨ ¬L ∨ N = P) →
  (¬M ∨ ¬L ∨ K = (0 : Int)) →
  (¬M ∨ ¬L ∨ R = K) →
  (¬M ∨ ¬L ∨ S = N) →
  (¬M ∨ G ∨ ¬I) →
  (¬I ∨ G = (F = (0 : Int))) →
  (¬I ∨ D ∧ I) →
  (¬L ∨ M ∧ L) →
  (¬M ∨ M ∧ I) →
  (L = True) →
  (A = (-1 : Int) * C) →
  r3 O P Q R S) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D : Prop),
  ∀ (E : Int),
  ∀ (F G : Prop),
  ∀ (H I J K L : Int),
  ∀ (M N : Prop),
  ∀ (O P Q R S T : Int),
  (r5 P Q R I C) →
  (¬((0 : Int) ≤ C) = B) →
  (¬F ∨ ¬D ∨ E = C) →
  (¬F ∨ ¬D ∨ H = E) →
  (¬F ∨ ¬D ∨ ¬B) →
  (¬N ∨ ¬M ∨ O = K) →
  (¬N ∨ ¬M ∨ L = J) →
  (¬N ∨ ¬M ∨ S = L) →
  (¬N ∨ ¬M ∨ T = O) →
  (¬N ∨ ¬G ∨ ¬F) →
  (¬F ∨ G = (H = (0 : Int))) →
  (¬F ∨ F ∧ D) →
  (¬M ∨ N ∧ M) →
  (¬N ∨ J = I + R) →
  (¬N ∨ K = (-1 : Int) + H) →
  (¬N ∨ N ∧ F) →
  (M = True) →
  (A = (-1 : Int) * C) →
  r3 P Q R S T) ∧
  ((∀ (A : Int),
  ∀ (B C : Prop),
  ∀ (D E F G H I : Int),
  (r3 E F G H A) →
  (¬C ∨ ¬B ∨ I = D) →
  (¬B ∨ C ∧ B) →
  (B = True) →
  (¬C ∨ ¬B ∨ D = A) →
  r5 E F G H I) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F G H I J K : Int),
  (r5 G H I J A) →
  (¬((0 : Int) ≤ A) = B) →
  (¬E ∨ ¬D ∨ F = C) →
  (¬E ∨ ¬D ∨ K = F) →
  (¬E ∨ B ∨ ¬D) →
  (¬D ∨ E ∧ D) →
  (D = True) →
  (C = (-1 : Int) * A) →
  r5 G H I J K) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D : Prop),
  ∀ (E F : Int),
  ∀ (G : Prop),
  ∀ (H : Int),
  ∀ (I : Prop),
  ∀ (J K L M : Int),
  ∀ (N O : Prop),
  ∀ (P : Int),
  ∀ (Q R S T U : Prop),
  let a!1 := ¬T ∨ ¬(K = L) = O;
  let a!2 := ¬T ∨ ¬(P ≤ (0 : Int)) = Q;
  let a!3 := ¬T ∨ ¬(M ≤ (0 : Int)) = N;
  r5 K M P H C →
    ¬((0 : Int) ≤ C) = B →
      ¬I ∨ J = H ∨ ¬T →
        ¬I ∨ L = J ∨ ¬T →
          ¬I ∨ G ∨ ¬T →
            ¬I ∨ ¬D ∨ F = E →
              ¬I ∨ ¬D ∨ E = C →
                ¬I ∨ ¬D ∨ ¬B →
                  ¬T ∨ ¬(K = L) = O →
                    ¬T ∨ ¬(P ≤ (0 : Int)) = Q →
                      ¬T ∨ ¬(M ≤ (0 : Int)) = N →
                        ¬T ∨ R = (O ∧ N) →
                          ¬T ∨ S = (R ∧ Q) →
                            ¬T ∨ I ∧ T →
                              ¬T ∨ S →
                                ¬U ∨ U ∧ T → ¬I ∨ G = (F = (0 : Int)) → ¬I ∨ I ∧ D → U = True → A = (-1 : Int) * C → r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  (True) →
  False))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_MultCommutative_true-unreach-call_true-no-overflow_true-termination_000»
