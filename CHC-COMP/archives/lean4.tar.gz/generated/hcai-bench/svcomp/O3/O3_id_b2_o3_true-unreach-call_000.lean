import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_id_b2_o3_true-unreach-call_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id_b2_o3_true-unreach-call_000.smt2":132:1-132:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id_b2_o3_true-unreach-call_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id_b2_o3_true-unreach-call_000.smt2":20:1-29:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id_b2_o3_true-unreach-call_000.smt2":30:1-39:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id_b2_o3_true-unreach-call_000.smt2":40:1-50:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id_b2_o3_true-unreach-call_000.smt2":51:1-60:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id_b2_o3_true-unreach-call_000.smt2":61:1-90:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id_b2_o3_true-unreach-call_000.smt2":91:1-100:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id_b2_o3_true-unreach-call_000.smt2":101:1-119:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_id_b2_o3_true-unreach-call_000.smt2":120:1-130:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Int → Prop),
    ∃ (r1 : Prop),
    ∃ (r2 : Prop → Prop → Prop → Int → Int → Prop),
    ∃ (r3 : Int → Int → Prop),
    ∃ (r4 : Int → Prop),
    (∀ (A B : Int),
    ∀ (v_2 v_3 v_4 : Prop),
    (True) →
    (v_2 = True) →
    (v_3 = True) →
    (v_4 = True) →
    r2 v_2 v_3 v_4 A B) ∧
    ((∀ (A B : Int),
    ∀ (v_2 v_3 v_4 : Prop),
    (True) →
    (v_2 = False) →
    (v_3 = True) →
    (v_4 = True) →
    r2 v_2 v_3 v_4 A B) ∧
    ((∀ (A B : Int),
    ∀ (v_2 v_3 v_4 : Prop),
    (True) →
    (v_2 = False) →
    (v_3 = False) →
    (v_4 = False) →
    r2 v_2 v_3 v_4 A B) ∧
    ((∀ (A B : Int),
    ∀ (v_2 v_3 v_4 : Prop),
    (r3 B A) →
    (v_2 = True) →
    (v_3 = False) →
    (v_4 = False) →
    r2 v_2 v_3 v_4 A B) ∧
    ((∀ (A : Int),
    (True) →
    r4 A) ∧
    ((∀ (A B : Int),
    ∀ (C : Prop),
    ∀ (D : Int),
    ∀ (E F : Prop),
    ∀ (G : Int),
    ∀ (H : Prop),
    ∀ (I : Int),
    ∀ (J : Prop),
    ∀ (K : Int),
    ∀ (L M : Prop),
    ∀ (N O : Int),
    ∀ (v_15 v_16 : Prop),
    let a!1 := ¬J ∨ ¬(B ≤ (1 : Int)) = C;
    r4 O →
      r2 J v_15 v_16 A B →
        v_15 = False →
          v_16 = False →
            ¬H ∨ F ∨ ¬E →
              ¬J ∨ ¬F ∨ ¬E →
                ¬L ∨ L ∧ J ∨ L ∧ H →
                  ¬L ∨ ¬H ∨ I = (0 : Int) →
                    ¬L ∨ ¬H ∨ N = I →
                      ¬L ∨ ¬J ∨ K = G →
                        ¬L ∨ ¬J ∨ N = K →
                          ¬H ∨ H ∧ E →
                            ¬J ∨ ¬(B ≤ (1 : Int)) = C →
                              ¬J ∨ A = (-1 : Int) + O →
                                ¬J ∨ D = (1 : Int) + B →
                                  (¬J ∨ G = if C then (2 : Int) else D) →
                                    ¬J ∨ J ∧ E → ¬M ∨ M ∧ L → M = True → F = (O = (0 : Int)) → r3 N O) ∧
    ((∀ (A : Int),
    (True) →
    r0 A) ∧
    ((∀ (A B C D : Int),
    ∀ (E F G v_7 v_8 v_9 : Prop),
    (r0 B) →
    (r2 v_7 v_8 v_9 C D) →
    (v_7 = True) →
    (v_8 = False) →
    (v_9 = False) →
    (A = B) →
    (¬G ∨ G ∧ F) →
    (E = True) →
    (G = True) →
    (E = (D = (3 : Int))) →
    r1) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r1) →
    (True) →
    False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_id_b2_o3_true-unreach-call_000»
