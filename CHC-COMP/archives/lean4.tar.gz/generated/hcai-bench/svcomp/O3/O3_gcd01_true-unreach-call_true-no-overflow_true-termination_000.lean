import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_gcd01_true-unreach-call_true-no-overflow_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":218:1-218:12 (check-sat, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":19:1-41:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":42:1-76:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":77:1-106:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":107:1-165:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":166:1-179:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":180:1-205:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_gcd01_true-unreach-call_true-no-overflow_true-termination_000.smt2":206:1-216:2 (clause 8, command 13)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Int → Int → Prop),
  (∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r0) ∧
  ((∀ (A B C D : Prop),
  ∀ (E : Int),
  ∀ (F G : Prop),
  ∀ (H I J K L : Int),
  (r0) →
  (¬((1 : Int) ≤ J) = B) →
  (D = (B ∨ A)) →
  (¬G ∨ ¬D ∨ ¬C) →
  (¬G ∨ ¬F ∨ E = J) →
  (¬G ∨ ¬F ∨ H = I) →
  (¬G ∨ ¬F ∨ K = H) →
  (¬G ∨ ¬F ∨ L = E) →
  (¬F ∨ G ∧ F) →
  (¬G ∨ G ∧ C) →
  (¬A) →
  (¬B) →
  (F = True) →
  (¬((1 : Int) ≤ I) = A) →
  r3 I J K L) ∧
  ((∀ (A B : Prop),
  ∀ (C : Int),
  ∀ (D : Prop),
  ∀ (E : Int),
  ∀ (F : Prop),
  ∀ (G H : Int),
  ∀ (I J K : Prop),
  ∀ (L M N : Int),
  ∀ (O P : Prop),
  ∀ (Q R S T U : Int),
  let a!1 := ¬F ∨ C = E + (-1 : Int) * H;
  let a!2 := ¬F ∨ ¬(H ≤ E) = D;
  let a!3 := ¬P ∨ M = H + (-1 : Int) * L;
  let a!4 := ¬P ∨ ¬((1 : Int) ≤ L) = I;
  let a!5 := ¬P ∨ ¬((1 : Int) ≤ M) = J;
  r1 R S H E →
    ¬F ∨ ¬B ∨ ¬A →
      ¬P ∨ ¬F ∨ G = E →
        ¬P ∨ ¬F ∨ L = G →
          ¬P ∨ ¬F ∨ D →
            ¬P ∨ ¬O ∨ N = L →
              ¬P ∨ ¬O ∨ Q = M →
                ¬P ∨ ¬O ∨ T = Q →
                  ¬P ∨ ¬O ∨ U = N →
                    ¬P ∨ ¬O ∨ ¬K →
                      ¬F ∨ C = E + (-1 : Int) * H →
                        ¬F ∨ ¬(H ≤ E) = D →
                          ¬F ∨ F ∧ A →
                            ¬O ∨ P ∧ O →
                              ¬P ∨ M = H + (-1 : Int) * L →
                                ¬P ∨ ¬((1 : Int) ≤ L) = I →
                                  ¬P ∨ ¬((1 : Int) ≤ M) = J →
                                    ¬P ∨ K = (J ∨ I) → ¬P ∨ P ∧ F → O = True → B = (E = H) → r3 R S T U) ∧
  ((∀ (A B C D : Prop),
  ∀ (E F G : Int),
  ∀ (H I : Prop),
  ∀ (J : Int),
  ∀ (K L M N O : Prop),
  let a!1 := ¬N ∨ ¬((1 : Int) ≤ F) = I;
  let a!2 := ¬N ∨ ¬(G ≤ (0 : Int)) = H;
  let a!3 := ¬N ∨ ¬(J ≤ (0 : Int)) = K;
  r0 →
    ¬((1 : Int) ≤ J) = B →
      C = (B ∨ A) →
        ¬D ∨ E = (0 : Int) ∨ ¬N →
          ¬D ∨ F = E ∨ ¬N →
            ¬D ∨ C ∨ ¬N →
              ¬N ∨ ¬((1 : Int) ≤ F) = I →
                ¬N ∨ ¬(G ≤ (0 : Int)) = H →
                  ¬N ∨ ¬(J ≤ (0 : Int)) = K →
                    ¬N ∨ L = (I ∧ H) →
                      ¬N ∨ M = (L ∧ K) → ¬N ∨ D ∧ N → ¬N ∨ M → ¬O ∨ O ∧ N → ¬A → ¬B → O = True → ¬((1 : Int) ≤ G) = A → r2) ∧
  ((∀ (A : Int),
  ∀ (B : Prop),
  ∀ (C : Int),
  ∀ (D : Prop),
  ∀ (E F G : Int),
  ∀ (H I J K L : Prop),
  ∀ (M : Int),
  ∀ (N O P : Prop),
  ∀ (Q : Int),
  ∀ (R S : Prop),
  ∀ (T U : Int),
  ∀ (V : Prop),
  ∀ (W : Int),
  ∀ (X : Prop),
  ∀ (Y Z A1 : Int),
  ∀ (B1 C1 : Prop),
  ∀ (D1 : Int),
  ∀ (E1 F1 G1 H1 I1 : Prop),
  let a!1 := ¬D ∨ A = C + (-1 : Int) * M;
  let a!2 := ¬D ∨ ¬(M ≤ C) = B;
  let a!3 := ¬J ∨ F = M + (-1 : Int) * G;
  let a!4 := ¬J ∨ ¬((1 : Int) ≤ F) = I;
  let a!5 := ¬J ∨ ¬((1 : Int) ≤ G) = H;
  let a!6 := ¬R ∨ ¬((1 : Int) ≤ A) = N;
  let a!7 := ¬H1 ∨ ¬((1 : Int) ≤ Z) = C1;
  let a!8 := ¬H1 ∨ ¬(A1 ≤ (0 : Int)) = B1;
  let a!9 := ¬H1 ∨ ¬(D1 ≤ (0 : Int)) = E1;
  r1 A1 D1 M C →
    ¬J ∨ ¬D ∨ E = C →
      ¬J ∨ ¬D ∨ G = E →
        ¬J ∨ ¬D ∨ B →
          ¬O ∨ ¬L ∨ ¬D →
            ¬P ∨ ¬O ∨ Q = M →
              ¬P ∨ ¬O ∨ U = Q →
                ¬P ∨ ¬O ∨ L →
                  ¬R ∨ ¬D ∨ ¬B →
                    T = (0 : Int) ∨ ¬S ∨ ¬R →
                      U = T ∨ ¬S ∨ ¬R →
                        N ∨ ¬S ∨ ¬R →
                          ¬V ∨ K ∨ ¬J →
                            ¬H1 ∨ H1 ∧ V ∨ X ∧ H1 →
                              ¬H1 ∨ ¬V ∨ W = (0 : Int) →
                                ¬H1 ∨ ¬V ∨ Z = W →
                                  ¬X ∨ R ∧ S ∨ P ∧ O →
                                    ¬X ∨ ¬H1 ∨ Y = U →
                                      ¬X ∨ Z = Y ∨ ¬H1 →
                                        ¬D ∨ A = C + (-1 : Int) * M →
                                          ¬D ∨ ¬(M ≤ C) = B →
                                            ¬D ∨ O ∧ D →
                                              ¬J ∨ F = M + (-1 : Int) * G →
                                                ¬J ∨ ¬((1 : Int) ≤ F) = I →
                                                  ¬J ∨ ¬((1 : Int) ≤ G) = H →
                                                    ¬J ∨ K = (I ∨ H) →
                                                      ¬J ∨ J ∧ D →
                                                        ¬P ∨ O →
                                                          ¬R ∨ ¬((1 : Int) ≤ A) = N →
                                                            ¬R ∨ R ∧ D →
                                                              R ∨ ¬S →
                                                                ¬V ∨ V ∧ J →
                                                                  ¬H1 ∨ ¬((1 : Int) ≤ Z) = C1 →
                                                                    ¬H1 ∨ ¬(A1 ≤ (0 : Int)) = B1 →
                                                                      ¬H1 ∨ ¬(D1 ≤ (0 : Int)) = E1 →
                                                                        ¬H1 ∨ F1 = (C1 ∧ B1) →
                                                                          ¬H1 ∨ G1 = (F1 ∧ E1) →
                                                                            ¬H1 ∨ G1 →
                                                                              ¬I1 ∨ I1 ∧ H1 → I1 = True → L = (C = M) → r2) ∧
  ((∀ (A : Int),
  ∀ (B C : Prop),
  ∀ (D E F G H : Int),
  (r3 E F G A) →
  (¬C ∨ ¬B ∨ H = D) →
  (¬B ∨ C ∧ B) →
  (B = True) →
  (¬C ∨ ¬B ∨ D = A) →
  r1 E F G H) ∧
  ((∀ (A B : Prop),
  ∀ (C : Int),
  ∀ (D E F : Prop),
  ∀ (G : Int),
  ∀ (H I : Prop),
  ∀ (J K L M N : Int),
  let a!1 := ¬D ∨ G = C + (-1 : Int) * M;
  let a!2 := ¬D ∨ ¬(M ≤ C) = E;
  let a!3 := ¬I ∨ ¬((1 : Int) ≤ G) = F;
  r1 K L M C →
    ¬D ∨ ¬B ∨ ¬A →
      ¬I ∨ ¬E ∨ ¬D →
        ¬I ∨ ¬H ∨ J = G →
          ¬I ∨ ¬H ∨ N = J →
            ¬I ∨ ¬H ∨ ¬F →
              ¬D ∨ G = C + (-1 : Int) * M →
                ¬D ∨ ¬(M ≤ C) = E →
                  ¬D ∨ D ∧ A → ¬H ∨ I ∧ H → ¬I ∨ ¬((1 : Int) ≤ G) = F → ¬I ∨ I ∧ D → H = True → B = (C = M) → r1 K L M N) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  (True) →
  False)))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_gcd01_true-unreach-call_true-no-overflow_true-termination_000»
