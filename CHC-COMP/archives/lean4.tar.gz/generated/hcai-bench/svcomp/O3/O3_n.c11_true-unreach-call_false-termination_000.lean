import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_n.c11_true-unreach-call_false-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_n.c11_true-unreach-call_false-termination_000.smt2":114:1-114:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_n.c11_true-unreach-call_false-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_n.c11_true-unreach-call_false-termination_000.smt2":18:1-34:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_n.c11_true-unreach-call_false-termination_000.smt2":35:1-53:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_n.c11_true-unreach-call_false-termination_000.smt2":54:1-73:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_n.c11_true-unreach-call_false-termination_000.smt2":74:1-101:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_n.c11_true-unreach-call_false-termination_000.smt2":102:1-112:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
noncomputable def Problem : Prop := by
  classical
  exact
    ∃ (r0 : Prop),
    ∃ (r1 : Int → Prop),
    ∃ (r2 : Int → Int → Prop),
    (∀ (A : Int),
    (True) →
    r1 A) ∧
    ((∀ (A : Int),
    ∀ (B C D E : Prop),
    ∀ (F G H : Int),
    (r1 H) →
    (¬B ∨ ¬E ∨ C) →
    (¬E ∨ ¬D ∨ F = (0 : Int)) →
    (¬E ∨ ¬D ∨ G = F) →
    (¬D ∨ E ∧ D) →
    (¬E ∨ E ∧ B) →
    (D = True) →
    (A = H) →
    r2 G H) ∧
    ((∀ (A : Int),
    ∀ (B : Prop),
    ∀ (C D : Int),
    ∀ (E : Prop),
    ∀ (F : Int),
    ∀ (G H : Prop),
    ∀ (I J K : Int),
    (r2 A K) →
    (F = if B then (1 : Int) else C) →
    (C = (1 : Int) + A) →
    (D = K) →
    (¬H ∨ ¬G ∨ I = F) →
    (¬H ∨ ¬G ∨ J = I) →
    (¬H ∨ ¬G ∨ E) →
    (¬G ∨ H ∧ G) →
    (G = True) →
    (B = (A = (4 : Int))) →
    r2 J K) ∧
    ((∀ (A B : Int),
    ∀ (C D E F G H I J : Prop),
    (r1 B) →
    (¬D ∨ ¬I ∨ G = E) →
    (¬D ∨ ¬I ∨ ¬C) →
    (¬D ∨ E ∨ ¬I) →
    (¬I ∨ ¬G = H) →
    (¬I ∨ D ∧ I) →
    (¬I ∨ H) →
    (¬J ∨ J ∧ I) →
    (¬I ∨ ¬F) →
    (J = True) →
    (A = B) →
    r0) ∧
    ((∀ (A : Int),
    ∀ (B : Prop),
    ∀ (C D E : Int),
    ∀ (F : Prop),
    ∀ (G : Int),
    ∀ (H : Prop),
    ∀ (I J : Int),
    ∀ (K L M N O P Q R : Prop),
    let a!1 := K = (¬(5 : Int) ≤ J ∧ J ≥ (0 : Int));
    r2 A E →
      C = (1 : Int) + A →
        D = E →
          (G = if B then (1 : Int) else C) →
            ¬L ∨ ¬H ∨ I = G →
              ¬L ∨ ¬H ∨ J = I →
                ¬L ∨ ¬H ∨ ¬F →
                  ¬L ∨ ¬Q ∨ M = K →
                    ¬L ∨ ¬Q ∨ O = M →
                      ¬Q ∨ ¬O = P →
                        ¬Q ∨ L ∧ Q →
                          ¬Q ∨ P → ¬R ∨ R ∧ Q → ¬L ∨ a!1 → ¬L ∨ L ∧ H → ¬Q ∨ ¬N → R = True → B = (A = (4 : Int)) → r0) ∧
    (∀ (_CHC_COMP_UNUSED : Prop),
    (r0) →
    (True) →
    False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_n.c11_true-unreach-call_false-termination_000»
