import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_sum_non_true-unreach-call_true-termination_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_true-unreach-call_true-termination_000.smt2":122:1-122:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_true-unreach-call_true-termination_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_true-unreach-call_true-termination_000.smt2":18:1-36:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_true-unreach-call_true-termination_000.smt2":37:1-56:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_true-unreach-call_true-termination_000.smt2":57:1-79:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_true-unreach-call_true-termination_000.smt2":80:1-109:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/svcomp/O3/O3_sum_non_true-unreach-call_true-termination_000.smt2":110:1-120:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  (∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r0) ∧
  ((∀ (A B : Prop),
  ∀ (C : Int),
  ∀ (D E : Prop),
  ∀ (F G H I J : Int),
  (r0) →
  (¬E ∨ ¬B ∨ ¬A) →
  (¬E ∨ ¬D ∨ C = G) →
  (¬E ∨ ¬D ∨ F = H) →
  (¬E ∨ ¬D ∨ I = F) →
  (¬E ∨ ¬D ∨ J = C) →
  (¬D ∨ E ∧ D) →
  (¬E ∨ E ∧ A) →
  (D = True) →
  (¬((1 : Int) ≤ H) = B) →
  r1 G H I J) ∧
  ((∀ (A B : Int),
  ∀ (C : Prop),
  ∀ (D E F : Int),
  ∀ (G H : Prop),
  ∀ (I J K L M : Int),
  (r1 J K B A) →
  (E = (-1 : Int) + B) →
  (¬((2 : Int) ≤ B) = C) →
  (¬H ∨ ¬G ∨ F = D) →
  (¬H ∨ ¬G ∨ I = E) →
  (¬H ∨ ¬G ∨ L = I) →
  (¬H ∨ ¬G ∨ M = F) →
  (¬H ∨ ¬G ∨ ¬C) →
  (¬G ∨ H ∧ G) →
  (G = True) →
  (D = (1 : Int) + A) →
  r1 J K L M) ∧
  ((∀ (A : Prop),
  ∀ (B : Int),
  ∀ (C : Prop),
  ∀ (D E F G H I J : Int),
  ∀ (K L M : Prop),
  (r0) →
  (¬L ∨ ¬C ∨ B = G) →
  (¬L ∨ ¬C ∨ D = H) →
  (¬L ∨ ¬C ∨ E = D) →
  (¬L ∨ ¬C ∨ F = B) →
  (¬L ∨ ¬C ∨ A) →
  (¬L ∨ I = E + F) →
  (¬L ∨ J = G + H) →
  (¬L ∨ K = (I = J)) →
  (¬L ∨ L ∧ C) →
  (¬L ∨ ¬K) →
  (¬M ∨ M ∧ L) →
  (M = True) →
  (¬((1 : Int) ≤ H) = A) →
  r2) ∧
  ((∀ (A B : Int),
  ∀ (C : Prop),
  ∀ (D E F : Int),
  ∀ (G : Prop),
  ∀ (H I J K : Int),
  ∀ (L : Prop),
  ∀ (M N O P Q R S : Int),
  ∀ (T U V : Prop),
  (r1 P Q B A) →
  (E = (-1 : Int) + B) →
  (¬((2 : Int) ≤ B) = C) →
  (¬L ∨ ¬G ∨ F = D) →
  (¬L ∨ ¬G ∨ H = E) →
  (¬L ∨ ¬G ∨ I = F) →
  (¬L ∨ ¬G ∨ J = H) →
  (¬L ∨ ¬G ∨ C) →
  (¬U ∨ ¬L ∨ K = I) →
  (¬U ∨ ¬L ∨ M = J) →
  (¬U ∨ ¬L ∨ N = M) →
  (¬U ∨ ¬L ∨ O = K) →
  (¬L ∨ L ∧ G) →
  (¬U ∨ R = N + O) →
  (¬U ∨ S = P + Q) →
  (¬U ∨ T = (R = S)) →
  (¬U ∨ U ∧ L) →
  (¬U ∨ ¬T) →
  (¬V ∨ V ∧ U) →
  (V = True) →
  (D = (1 : Int) + A) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  (True) →
  False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«svcomp».«O3».«O3_sum_non_true-unreach-call_true-termination_000»
