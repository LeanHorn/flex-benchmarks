import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«arrays_orig».«array_fill1_even_odd_abstracted_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_even_odd_abstracted_000.smt2":108:1-108:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_even_odd_abstracted_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_even_odd_abstracted_000.smt2":20:1-30:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_even_odd_abstracted_000.smt2":31:1-41:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_even_odd_abstracted_000.smt2":42:1-52:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_even_odd_abstracted_000.smt2":53:1-63:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_even_odd_abstracted_000.smt2":64:1-74:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_even_odd_abstracted_000.smt2":75:1-85:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_even_odd_abstracted_000.smt2":86:1-96:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_even_odd_abstracted_000.smt2":97:1-106:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Prop),
  (∀ (A B C v_3 : Int),
  (¬A ≤ B) →
  ((0 : Int) ≤ B) →
  ((0 : Int) = v_3) →
  r4 A v_3 B C) ∧
  ((∀ (A B C D : Int),
  (r4 A B C D) →
  (¬A ≤ B) →
  r0 A B C D) ∧
  ((∀ (A B C D : Int),
  (r0 A B C D) →
  (¬B = C) →
  r2 A B C D) ∧
  ((∀ (A B C D E v_5 : Int),
  (r0 B C D E) →
  (A = C % (2 : Int)) →
  (v_5 = C) →
  r2 B C v_5 A) ∧
  ((∀ (A B C D E : Int),
  (r2 B C D E) →
  (A = (1 : Int) + C) →
  r4 B A D E) ∧
  ((∀ (A B C D : Int),
  (r4 A B C D) →
  (B ≥ A) →
  r3 A C D) ∧
  ((∀ (A B C D : Int),
  (r3 B A D) →
  (¬D = (0 : Int)) →
  (A = (2 : Int) * C) →
  r1) ∧
  ((∀ (A B C D : Int),
  (r3 B A D) →
  (¬D = (1 : Int)) →
  (A = (1 : Int) + (2 : Int) * C) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«arrays_orig».«array_fill1_even_odd_abstracted_000»
