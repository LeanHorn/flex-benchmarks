import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«arrays_orig».«array_reverse_once1_abstracted_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":180:1-180:12 (check-sat, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":13:1-22:2 (clause 1, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":23:1-32:2 (clause 2, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":33:1-43:2 (clause 3, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":44:1-54:2 (clause 4, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":55:1-66:2 (clause 5, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":67:1-77:2 (clause 6, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":78:1-90:2 (clause 7, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":91:1-101:2 (clause 8, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":102:1-112:2 (clause 9, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":113:1-123:2 (clause 10, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":124:1-134:2 (clause 11, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":135:1-145:2 (clause 12, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":146:1-156:2 (clause 13, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":157:1-167:2 (clause 14, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_reverse_once1_abstracted_000.smt2":168:1-178:2 (clause 15, command 24)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C v_3 v_4 : Int),
  (¬A ≤ B) →
  ((0 : Int) ≤ B) →
  (v_3 = B) →
  (v_4 = C) →
  r2 A B C v_3 v_4) ∧
  ((∀ (A B C D E : Int),
  ((0 : Int) ≤ B) →
  ((0 : Int) ≤ D) →
  (¬A ≤ B) →
  (¬A ≤ D) →
  (¬B = D) →
  r2 A B C D E) ∧
  ((∀ (A B C D E v_5 : Int),
  (r2 A B C D E) →
  ((0 : Int) = v_5) →
  r6 A v_5 B C D E) ∧
  ((∀ (A B C D E F : Int),
  (r6 A B C D E F) →
  (¬A + (-2 : Int) * B ≤ (1 : Int)) →
  r5 A B C D E F) ∧
  ((∀ (A B C D E F G v_7 : Int),
  (r5 A B v_7 C F G) →
  (r5 A B D E F G) →
  (v_7 = B) →
  (¬B = D) →
  r7 A B C D E F G) ∧
  ((∀ (A B C D E v_5 v_6 v_7 : Int),
  (r5 A B v_5 C D E) →
  (v_5 = B) →
  (v_6 = B) →
  (v_7 = C) →
  r7 A B C v_6 v_7 D E) ∧
  ((∀ (A B C D E F G H I : Int),
  let a!1 := ¬B + (-1 : Int) * C = (1 : Int) + F;
  r7 B C D A E H I →
    r7 B C D F G H I → A = (-1 : Int) + B + (-1 : Int) * C → ¬B + (-1 : Int) * C = (1 : Int) + F → r0 B C D E F G H I) ∧
  ((∀ (A B C D E F G H v_8 : Int),
  (r7 C D E A F G H) →
  (B = (-1 : Int) + C + (-1 : Int) * D) →
  (A = (-1 : Int) + C + (-1 : Int) * D) →
  (v_8 = F) →
  r0 C D E F B v_8 G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 A B C D E F G H) →
  (¬B = E) →
  r3 A B C E F G H) ∧
  ((∀ (A B C D E F G v_7 v_8 : Int),
  (r0 A B C D v_7 E F G) →
  (v_7 = B) →
  (v_8 = B) →
  r3 A B C v_8 D F G) ∧
  ((∀ (A B C D E F G : Int),
  (r3 A B C D E F G) →
  (¬A + (-1 : Int) * B = (1 : Int) + D) →
  r1 A B D E F G) ∧
  ((∀ (A B C D E F G H : Int),
  (r3 C D E A F G H) →
  (B = (-1 : Int) + C + (-1 : Int) * D) →
  (A = (-1 : Int) + C + (-1 : Int) * D) →
  r1 C D B E G H) ∧
  ((∀ (A B C D E F G : Int),
  (r1 B C D E F G) →
  (A = (1 : Int) + C) →
  r6 B A D E F G) ∧
  ((∀ (A B C D E F : Int),
  (r6 A B C D E F) →
  ((2 : Int) * B ≥ (-1 : Int) + A) →
  r4 A C D E F) ∧
  (∀ (A B C D E : Int),
  (r4 B C D A E) →
  (¬D = E) →
  (C ≥ (0 : Int)) →
  (¬B ≤ C) →
  (A = (-1 : Int) + B + (-1 : Int) * C) →
  False))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«arrays_orig».«array_reverse_once1_abstracted_000»
