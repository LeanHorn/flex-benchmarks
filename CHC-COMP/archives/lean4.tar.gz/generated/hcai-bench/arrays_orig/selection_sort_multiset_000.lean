import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«arrays_orig».«selection_sort_multiset_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":327:1-327:12 (check-sat, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":20:1-29:2 (clause 1, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":30:1-40:2 (clause 2, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":41:1-51:2 (clause 3, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":52:1-62:2 (clause 4, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":63:1-74:2 (clause 5, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":75:1-85:2 (clause 6, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":86:1-96:2 (clause 7, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":97:1-108:2 (clause 8, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":109:1-119:2 (clause 9, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":120:1-130:2 (clause 10, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":131:1-141:2 (clause 11, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":142:1-152:2 (clause 12, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":153:1-164:2 (clause 13, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":165:1-176:2 (clause 14, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":177:1-188:2 (clause 15, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":189:1-200:2 (clause 16, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":201:1-211:2 (clause 17, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":212:1-222:2 (clause 18, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":223:1-234:2 (clause 19, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":235:1-246:2 (clause 20, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":247:1-258:2 (clause 21, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":259:1-270:2 (clause 22, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":271:1-281:2 (clause 23, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":282:1-292:2 (clause 24, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":293:1-303:2 (clause 25, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":304:1-314:2 (clause 26, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/selection_sort_multiset_000.smt2":315:1-325:2 (clause 27, command 43)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E : Int),
  (True) →
  r5 A B C D E) ∧
  ((∀ (A B C D E F v_6 v_7 : Int),
  (r5 A B C E F) →
  (A ≤ B) →
  (v_6 = A) →
  (v_7 = F) →
  r11 A v_6 B C D E F v_7) ∧
  ((∀ (A B C D E F G H : Int),
  (r11 A B C D E F G H) →
  (¬C ≤ (1 : Int) + B) →
  r14 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r11 A B C D E F G H) →
  (B ≥ (-1 : Int) + C) →
  r0 A C D E F G H) ∧
  ((∀ (A B C D E F G H I J v_10 v_11 v_12 : Int),
  (r14 B C D F G H I J) →
  (r14 B C D v_10 E H I J) →
  (v_10 = C) →
  (¬F = C) →
  (A = (1 : Int) + C) →
  (v_11 = C) →
  (v_12 = E) →
  r3 B C D A v_11 E v_12 F G H I J) ∧
  ((∀ (A B C D E F G H v_8 v_9 v_10 v_11 v_12 : Int),
  (r14 B C D v_8 E F G H) →
  (v_8 = C) →
  (A = (1 : Int) + C) →
  (v_9 = C) →
  (v_10 = E) →
  (v_11 = C) →
  (v_12 = E) →
  r3 B C D A v_9 E v_10 v_11 v_12 F G H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A B C D E F G H I J K L) →
  (¬C ≤ D) →
  r6 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M v_13 : Int),
  (r6 A B C D E F G H I J K L) →
  (r6 A B C D E F G v_13 M J K L) →
  (v_13 = D) →
  (¬H = D) →
  r4 A B C D E F M G H I J K L) ∧
  ((∀ (A B C D E F G H I J K v_11 v_12 v_13 : Int),
  (r6 A B C D E F H v_11 G I J K) →
  (v_11 = D) →
  (v_12 = D) →
  (v_13 = G) →
  r4 A B C D E F G H v_12 v_13 I J K) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r4 B C D E F G H I J K L M N) →
  (¬G ≤ H) →
  (A = (1 : Int) + E) →
  r3 B C D A E H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r4 B C D E F G H I J K L M N) →
  (H ≥ G) →
  (A = (1 : Int) + E) →
  r3 B C D A F G I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A B C D E F G H I J K L) →
  (D ≥ C) →
  r13 A B C E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L v_12 : Int),
  (r13 A B C D E F G I J K L) →
  (r13 A B C D E F v_12 H J K L) →
  (v_12 = B) →
  (¬H = J) →
  r7 A B C D E F G I J K L) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 : Int),
  (r13 B C D E F G v_12 I v_13 K L) →
  (r13 B C D E F G H J I K L) →
  (v_12 = C) →
  (v_13 = I) →
  (A = (-1 : Int) + K) →
  r7 B C D E F G H J I A L) ∧
  ((∀ (A B C D E F G H I J K L v_12 : Int),
  (r7 A B C D E F G I J K L) →
  (r7 A B C D E F v_12 H J K L) →
  (v_12 = B) →
  (¬E = J) →
  r10 A B C D E F G I J K L) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 v_15 : Int),
  (r7 B C D E F G v_12 I v_13 K L) →
  (r7 B C D E F G H J v_14 K L) →
  (v_12 = C) →
  (v_13 = F) →
  (v_14 = F) →
  (A = (1 : Int) + K) →
  (v_15 = F) →
  r10 B C D E F G H J v_15 A L) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r10 A B C D E F G H I J K) →
  (¬B = G) →
  r2 A B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J v_10 v_11 v_12 : Int),
  (r10 A B C D E F v_10 G H I J) →
  (v_10 = B) →
  (v_11 = B) →
  (v_12 = E) →
  r2 A B C D E F v_11 v_12 H I J) ∧
  ((∀ (A B C D E F G H I J K L v_12 : Int),
  (r2 A B C D E F G I J K L) →
  (r2 A B C D E F v_12 H J K L) →
  (v_12 = D) →
  (¬H = J) →
  r12 A B C D E F G I J K L) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 : Int),
  (r2 B C D E F G v_12 I v_13 K L) →
  (r2 B C D E F G H J I K L) →
  (v_12 = E) →
  (v_13 = I) →
  (A = (-1 : Int) + K) →
  r12 B C D E F G H J I A L) ∧
  ((∀ (A B C D E F G H I J K L v_12 : Int),
  (r12 A B C D E F G I J K L) →
  (r12 A B C D E F v_12 H J K L) →
  (v_12 = D) →
  (¬F = J) →
  r8 A B C D E F G I J K L) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 v_15 : Int),
  (r12 B C D E F G v_12 I v_13 K L) →
  (r12 B C D E F G H J v_14 K L) →
  (v_12 = E) →
  (v_13 = G) →
  (v_14 = G) →
  (A = (1 : Int) + K) →
  (v_15 = G) →
  r8 B C D E F G H J v_15 A L) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r8 A B C D E F G H I J K) →
  (¬D = G) →
  r1 A B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J v_10 v_11 v_12 : Int),
  (r8 A B C D E F v_10 G H I J) →
  (v_10 = D) →
  (v_11 = D) →
  (v_12 = F) →
  r1 A B C D E F v_11 v_12 H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r1 A B C D E F G H I J K) →
  (True) →
  r9 A B C G H I J K) ∧
  ((∀ (A B C D E F G H I : Int),
  (r9 B C D E F G H I) →
  (A = (1 : Int) + C) →
  r11 B A D E F G H I) ∧
  (∀ (A B C D E F G : Int),
  (r0 A B C D E F G) →
  (¬F = G) →
  False))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«arrays_orig».«selection_sort_multiset_000»
