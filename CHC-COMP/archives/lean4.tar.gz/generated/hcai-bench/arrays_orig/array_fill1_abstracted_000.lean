import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«arrays_orig».«array_fill1_abstracted_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_abstracted_000.smt2":86:1-86:12 (check-sat, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_abstracted_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_abstracted_000.smt2":19:1-29:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_abstracted_000.smt2":30:1-40:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_abstracted_000.smt2":41:1-51:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_abstracted_000.smt2":52:1-62:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_abstracted_000.smt2":63:1-73:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill1_abstracted_000.smt2":74:1-84:2 (clause 7, command 12)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Prop),
  (∀ (A B C v_3 : Int),
  (¬A ≤ B) →
  ((0 : Int) ≤ B) →
  ((0 : Int) = v_3) →
  r2 A v_3 B C) ∧
  ((∀ (A B C D : Int),
  (r2 A B C D) →
  (¬A ≤ B) →
  r0 A B C D) ∧
  ((∀ (A B C D : Int),
  (r0 A B C D) →
  (¬B = C) →
  r3 A B C D) ∧
  ((∀ (A B C D v_4 v_5 : Int),
  (r0 A B C D) →
  (v_4 = B) →
  ((42 : Int) = v_5) →
  r3 A B v_4 v_5) ∧
  ((∀ (A B C D E : Int),
  (r3 B C D E) →
  (A = (1 : Int) + C) →
  r2 B A D E) ∧
  ((∀ (A B C D : Int),
  (r2 A B C D) →
  (B ≥ A) →
  r1 A C D) ∧
  (∀ (A B C : Int),
  (r1 A B C) →
  (B ≥ (0 : Int)) →
  (¬A ≤ B) →
  (¬C = (42 : Int)) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«arrays_orig».«array_fill1_abstracted_000»
