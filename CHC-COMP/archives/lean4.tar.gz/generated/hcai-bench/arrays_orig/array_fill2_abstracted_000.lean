import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hcai-bench».«arrays_orig».«array_fill2_abstracted_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill2_abstracted_000.smt2":133:1-133:12 (check-sat, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill2_abstracted_000.smt2":12:1-21:2 (clause 1, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill2_abstracted_000.smt2":22:1-32:2 (clause 2, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill2_abstracted_000.smt2":33:1-43:2 (clause 3, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill2_abstracted_000.smt2":44:1-54:2 (clause 4, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill2_abstracted_000.smt2":55:1-65:2 (clause 5, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill2_abstracted_000.smt2":66:1-76:2 (clause 6, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill2_abstracted_000.smt2":77:1-87:2 (clause 7, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill2_abstracted_000.smt2":88:1-98:2 (clause 8, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill2_abstracted_000.smt2":99:1-109:2 (clause 9, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill2_abstracted_000.smt2":110:1-120:2 (clause 10, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hcai-bench/arrays_orig/array_fill2_abstracted_000.smt2":121:1-131:2 (clause 11, command 19)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E : Int),
  ((0 : Int) ≤ C) →
  (¬B ≤ D) →
  (¬A ≤ C) →
  ((0 : Int) ≤ D) →
  r1 A B C D E) ∧
  ((∀ (A B C D E v_5 : Int),
  (r1 A B C D E) →
  ((0 : Int) = v_5) →
  r0 A B v_5 C D E) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r0 A B C D E F) →
  (¬A ≤ C) →
  ((0 : Int) = v_6) →
  r4 A B C v_6 D E F) ∧
  ((∀ (A B C D E F : Int),
  (r0 A B C D E F) →
  (C ≥ A) →
  r3 A B D E F) ∧
  ((∀ (A B C D E F G : Int),
  (r4 A B C D E F G) →
  (¬B ≤ D) →
  r2 A B C D E F G) ∧
  ((∀ (A B C D E F G : Int),
  (r4 A B C D E F G) →
  (D ≥ B) →
  r6 A B C E F G) ∧
  ((∀ (A B C D E F G : Int),
  (r2 A B C D E F G) →
  (¬C = E ∨ ¬D = F) →
  r5 A B C D E F G) ∧
  ((∀ (A B C D E v_5 v_6 v_7 v_8 v_9 : Int),
  (r2 A B C D v_5 v_6 E) →
  (v_5 = C) →
  (v_6 = D) →
  (v_7 = C) →
  (v_8 = D) →
  ((42 : Int) = v_9) →
  r5 A B C D v_7 v_8 v_9) ∧
  ((∀ (A B C D E F G H : Int),
  (r5 B C D E F G H) →
  (A = (1 : Int) + E) →
  r4 B C D A F G H) ∧
  ((∀ (A B C D E F G : Int),
  (r6 B C D E F G) →
  (A = (1 : Int) + D) →
  r0 B C A E F G) ∧
  (∀ (A B C D E : Int),
  (r3 A B C D E) →
  (¬E = (42 : Int)) →
  False))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hcai-bench».«arrays_orig».«array_fill2_abstracted_000»
