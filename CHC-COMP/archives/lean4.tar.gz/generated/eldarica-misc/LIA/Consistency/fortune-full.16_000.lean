import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«fortune-full.16_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":2023:1-2023:12 (check-sat, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":11:1-300:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":301:1-579:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":580:1-909:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":910:1-1212:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1213:1-1506:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1507:1-1517:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1518:1-1528:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1529:1-1539:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1540:1-1550:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1551:1-1561:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1562:1-1574:2 (clause 11, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1575:1-1587:2 (clause 12, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1588:1-1600:2 (clause 13, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1601:1-1615:2 (clause 14, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1616:1-1630:2 (clause 15, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1631:1-1645:2 (clause 16, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1646:1-1660:2 (clause 17, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1661:1-1675:2 (clause 18, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1676:1-1686:2 (clause 19, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1687:1-1697:2 (clause 20, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1698:1-1710:2 (clause 21, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1711:1-1723:2 (clause 22, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1724:1-1736:2 (clause 23, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1737:1-1751:2 (clause 24, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1752:1-1766:2 (clause 25, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1767:1-1781:2 (clause 26, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1782:1-1796:2 (clause 27, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1797:1-1811:2 (clause 28, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1812:1-1827:2 (clause 29, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1828:1-1843:2 (clause 30, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1844:1-1859:2 (clause 31, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1860:1-1875:2 (clause 32, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1876:1-1891:2 (clause 33, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1892:1-1907:2 (clause 34, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1908:1-1921:2 (clause 35, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1922:1-1935:2 (clause 36, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1936:1-1949:2 (clause 37, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1950:1-1963:2 (clause 38, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1964:1-1975:2 (clause 39, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1976:1-1987:2 (clause 40, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":1988:1-1999:2 (clause 41, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":2000:1-2011:2 (clause 42, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.16_000.smt2":2012:1-2021:2 (clause 43, command 50)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + O ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (1 : Int)) →
  ((-1 : Int) * N + K ≥ (2 : Int)) →
  ((-1 : Int) * N + B ≥ (1 : Int)) →
  ((-1 : Int) * M + O ≥ (0 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (0 : Int)) →
  ((-1 : Int) * M + K ≥ (1 : Int)) →
  ((-1 : Int) * M + B ≥ (0 : Int)) →
  ((-1 : Int) * K + O ≥ (-1 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * K + B ≥ (-1 : Int)) →
  ((-1 : Int) * J + O ≥ (2 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + B ≥ (2 : Int)) →
  ((-1 : Int) * J + A ≥ (0 : Int)) →
  ((-1 : Int) * J + S ≥ (-1 : Int)) →
  ((-1 : Int) * I + O ≥ (3 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (2 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + B ≥ (3 : Int)) →
  ((-1 : Int) * I + A ≥ (1 : Int)) →
  ((-1 : Int) * I + S ≥ (0 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + O ≥ (3 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (2 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (3 : Int)) →
  ((-1 : Int) * E + K ≥ (4 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (3 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (3 : Int)) →
  ((-1 : Int) * E + A ≥ (1 : Int)) →
  ((-1 : Int) * E + S ≥ (0 : Int)) →
  ((-1 : Int) * D + O ≥ (0 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (0 : Int)) →
  ((-1 : Int) * D + K ≥ (1 : Int)) →
  ((-1 : Int) * D + B ≥ (0 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + O ≥ (3 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (2 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (3 : Int)) →
  ((-1 : Int) * C + K ≥ (4 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (3 : Int)) →
  ((-1 : Int) * C + A ≥ (1 : Int)) →
  ((-1 : Int) * C + S ≥ (0 : Int)) →
  ((-1 : Int) * B + O ≥ (0 : Int)) →
  ((-1 : Int) * A + O ≥ (2 : Int)) →
  ((-1 : Int) * A + P ≥ (1 : Int)) →
  ((-1 : Int) * A + B ≥ (2 : Int)) →
  ((-1 : Int) * S + O ≥ (3 : Int)) →
  ((-1 : Int) * S + P ≥ (2 : Int)) →
  ((-1 : Int) * S + B ≥ (3 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  (Q + O ≥ (5 : Int)) →
  (Q + P ≥ (4 : Int)) →
  (P + O ≥ (7 : Int)) →
  (N + (-1 : Int) * O ≥ (-1 : Int)) →
  (N + (-1 : Int) * Q ≥ (1 : Int)) →
  (N + (-1 : Int) * P ≥ (0 : Int)) →
  (N + (-1 : Int) * K ≥ (-2 : Int)) →
  (N + (-1 : Int) * J ≥ (1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * B ≥ (-1 : Int)) →
  (N + (-1 : Int) * A ≥ (1 : Int)) →
  (N + (-1 : Int) * S ≥ (2 : Int)) →
  (N + O ≥ (7 : Int)) →
  (N + Q ≥ (4 : Int)) →
  (N + P ≥ (6 : Int)) →
  (N + L ≥ (7 : Int)) →
  (N + K ≥ (8 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + B ≥ (7 : Int)) →
  (N + A ≥ (5 : Int)) →
  (N + S ≥ (4 : Int)) →
  (M + (-1 : Int) * O ≥ (0 : Int)) →
  (M + (-1 : Int) * Q ≥ (2 : Int)) →
  (M + (-1 : Int) * P ≥ (1 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * K ≥ (-1 : Int)) →
  (M + (-1 : Int) * J ≥ (2 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * B ≥ (0 : Int)) →
  (M + (-1 : Int) * A ≥ (2 : Int)) →
  (M + (-1 : Int) * S ≥ (3 : Int)) →
  (M + O ≥ (8 : Int)) →
  (M + Q ≥ (5 : Int)) →
  (M + P ≥ (7 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (8 : Int)) →
  (M + K ≥ (9 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + B ≥ (8 : Int)) →
  (M + A ≥ (6 : Int)) →
  (M + S ≥ (5 : Int)) →
  (L + (-1 : Int) * O ≥ (0 : Int)) →
  (L + (-1 : Int) * Q ≥ (2 : Int)) →
  (L + (-1 : Int) * P ≥ (1 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (3 : Int)) →
  (L + (-1 : Int) * B ≥ (0 : Int)) →
  (L + (-1 : Int) * A ≥ (2 : Int)) →
  (L + (-1 : Int) * S ≥ (3 : Int)) →
  (L + O ≥ (8 : Int)) →
  (L + Q ≥ (5 : Int)) →
  (L + P ≥ (7 : Int)) →
  (L + J ≥ (6 : Int)) →
  (L + I ≥ (5 : Int)) →
  (L + B ≥ (8 : Int)) →
  (L + A ≥ (6 : Int)) →
  (L + S ≥ (5 : Int)) →
  (K + (-1 : Int) * O ≥ (1 : Int)) →
  (K + (-1 : Int) * Q ≥ (3 : Int)) →
  (K + (-1 : Int) * P ≥ (2 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (4 : Int)) →
  (K + (-1 : Int) * B ≥ (1 : Int)) →
  (K + (-1 : Int) * A ≥ (3 : Int)) →
  (K + (-1 : Int) * S ≥ (4 : Int)) →
  (K + O ≥ (9 : Int)) →
  (K + Q ≥ (6 : Int)) →
  (K + P ≥ (8 : Int)) →
  (K + L ≥ (9 : Int)) →
  (K + J ≥ (7 : Int)) →
  (K + I ≥ (6 : Int)) →
  (K + B ≥ (9 : Int)) →
  (K + A ≥ (7 : Int)) →
  (K + S ≥ (6 : Int)) →
  (J + (-1 : Int) * A ≥ (0 : Int)) →
  (J + (-1 : Int) * S ≥ (1 : Int)) →
  (J + O ≥ (6 : Int)) →
  (J + Q ≥ (3 : Int)) →
  (J + P ≥ (5 : Int)) →
  (J + B ≥ (6 : Int)) →
  (J + A ≥ (4 : Int)) →
  (J + S ≥ (3 : Int)) →
  (I + O ≥ (5 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (4 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + B ≥ (5 : Int)) →
  (I + A ≥ (3 : Int)) →
  (I + S ≥ (2 : Int)) →
  (F + (-1 : Int) * O ≥ (0 : Int)) →
  (F + (-1 : Int) * Q ≥ (2 : Int)) →
  (F + (-1 : Int) * P ≥ (1 : Int)) →
  (F + (-1 : Int) * N ≥ (1 : Int)) →
  (F + (-1 : Int) * M ≥ (0 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (3 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (2 : Int)) →
  (F + (-1 : Int) * S ≥ (3 : Int)) →
  (F + O ≥ (8 : Int)) →
  (F + Q ≥ (5 : Int)) →
  (F + P ≥ (7 : Int)) →
  (F + N ≥ (7 : Int)) →
  (F + M ≥ (8 : Int)) →
  (F + L ≥ (8 : Int)) →
  (F + K ≥ (9 : Int)) →
  (F + J ≥ (6 : Int)) →
  (F + I ≥ (5 : Int)) →
  (F + D ≥ (8 : Int)) →
  (F + C ≥ (5 : Int)) →
  (F + B ≥ (8 : Int)) →
  (F + A ≥ (6 : Int)) →
  (F + S ≥ (5 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + O ≥ (5 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (4 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (5 : Int)) →
  (E + K ≥ (6 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + F ≥ (5 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (5 : Int)) →
  (E + A ≥ (3 : Int)) →
  (E + S ≥ (2 : Int)) →
  (D + (-1 : Int) * O ≥ (0 : Int)) →
  (D + (-1 : Int) * Q ≥ (2 : Int)) →
  (D + (-1 : Int) * P ≥ (1 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * K ≥ (-1 : Int)) →
  (D + (-1 : Int) * J ≥ (2 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * B ≥ (0 : Int)) →
  (D + (-1 : Int) * A ≥ (2 : Int)) →
  (D + (-1 : Int) * S ≥ (3 : Int)) →
  (D + O ≥ (8 : Int)) →
  (D + Q ≥ (5 : Int)) →
  (D + P ≥ (7 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (8 : Int)) →
  (D + K ≥ (9 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + B ≥ (8 : Int)) →
  (D + A ≥ (6 : Int)) →
  (D + S ≥ (5 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + O ≥ (5 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (4 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (5 : Int)) →
  (C + K ≥ (6 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (5 : Int)) →
  (C + A ≥ (3 : Int)) →
  (C + S ≥ (2 : Int)) →
  (B + (-1 : Int) * O ≥ (0 : Int)) →
  (B + (-1 : Int) * Q ≥ (2 : Int)) →
  (B + (-1 : Int) * P ≥ (1 : Int)) →
  (B + O ≥ (8 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (7 : Int)) →
  (A + O ≥ (6 : Int)) →
  (A + Q ≥ (3 : Int)) →
  (A + P ≥ (5 : Int)) →
  (A + B ≥ (6 : Int)) →
  (S + (-1 : Int) * A ≥ (-1 : Int)) →
  (S + O ≥ (5 : Int)) →
  (S + Q ≥ (2 : Int)) →
  (S + P ≥ (4 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (3 : Int)) →
  (O ≥ (4 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (3 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (4 : Int)) →
  (K ≥ (5 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (F ≥ (4 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (4 : Int)) →
  (A ≥ (2 : Int)) →
  (S ≥ (1 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (1 : Int)) →
  ((-1 : Int) * N + K ≥ (2 : Int)) →
  ((-1 : Int) * N + B ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (0 : Int)) →
  ((-1 : Int) * M + K ≥ (1 : Int)) →
  ((-1 : Int) * M + B ≥ (0 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * K + B ≥ (-1 : Int)) →
  ((-1 : Int) * J + B ≥ (2 : Int)) →
  ((-1 : Int) * J + A ≥ (0 : Int)) →
  ((-1 : Int) * J + S ≥ (-1 : Int)) →
  ((-1 : Int) * I + O ≥ (2 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + B ≥ (3 : Int)) →
  ((-1 : Int) * I + A ≥ (1 : Int)) →
  ((-1 : Int) * I + S ≥ (0 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + O ≥ (2 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (1 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (3 : Int)) →
  ((-1 : Int) * E + K ≥ (4 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (3 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (3 : Int)) →
  ((-1 : Int) * E + A ≥ (1 : Int)) →
  ((-1 : Int) * E + S ≥ (0 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (0 : Int)) →
  ((-1 : Int) * D + K ≥ (1 : Int)) →
  ((-1 : Int) * D + B ≥ (0 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + O ≥ (2 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (3 : Int)) →
  ((-1 : Int) * C + K ≥ (4 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (3 : Int)) →
  ((-1 : Int) * C + A ≥ (1 : Int)) →
  ((-1 : Int) * C + S ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (2 : Int)) →
  ((-1 : Int) * S + B ≥ (3 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  (Q + O ≥ (4 : Int)) →
  (Q + P ≥ (3 : Int)) →
  (P + O ≥ (5 : Int)) →
  (N + (-1 : Int) * O ≥ (0 : Int)) →
  (N + (-1 : Int) * Q ≥ (2 : Int)) →
  (N + (-1 : Int) * P ≥ (1 : Int)) →
  (N + (-1 : Int) * K ≥ (-2 : Int)) →
  (N + (-1 : Int) * J ≥ (1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * B ≥ (-1 : Int)) →
  (N + (-1 : Int) * A ≥ (1 : Int)) →
  (N + (-1 : Int) * S ≥ (2 : Int)) →
  (N + O ≥ (6 : Int)) →
  (N + Q ≥ (4 : Int)) →
  (N + P ≥ (5 : Int)) →
  (N + L ≥ (7 : Int)) →
  (N + K ≥ (8 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + B ≥ (7 : Int)) →
  (N + A ≥ (5 : Int)) →
  (N + S ≥ (4 : Int)) →
  (M + (-1 : Int) * O ≥ (1 : Int)) →
  (M + (-1 : Int) * Q ≥ (3 : Int)) →
  (M + (-1 : Int) * P ≥ (2 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * K ≥ (-1 : Int)) →
  (M + (-1 : Int) * J ≥ (2 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * B ≥ (0 : Int)) →
  (M + (-1 : Int) * A ≥ (2 : Int)) →
  (M + (-1 : Int) * S ≥ (3 : Int)) →
  (M + O ≥ (7 : Int)) →
  (M + Q ≥ (5 : Int)) →
  (M + P ≥ (6 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (8 : Int)) →
  (M + K ≥ (9 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + B ≥ (8 : Int)) →
  (M + A ≥ (6 : Int)) →
  (M + S ≥ (5 : Int)) →
  (L + (-1 : Int) * O ≥ (1 : Int)) →
  (L + (-1 : Int) * Q ≥ (3 : Int)) →
  (L + (-1 : Int) * P ≥ (2 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (3 : Int)) →
  (L + (-1 : Int) * B ≥ (0 : Int)) →
  (L + (-1 : Int) * A ≥ (2 : Int)) →
  (L + (-1 : Int) * S ≥ (3 : Int)) →
  (L + O ≥ (7 : Int)) →
  (L + Q ≥ (5 : Int)) →
  (L + P ≥ (6 : Int)) →
  (L + J ≥ (6 : Int)) →
  (L + I ≥ (5 : Int)) →
  (L + B ≥ (8 : Int)) →
  (L + A ≥ (6 : Int)) →
  (L + S ≥ (5 : Int)) →
  (K + (-1 : Int) * O ≥ (2 : Int)) →
  (K + (-1 : Int) * Q ≥ (4 : Int)) →
  (K + (-1 : Int) * P ≥ (3 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (4 : Int)) →
  (K + (-1 : Int) * B ≥ (1 : Int)) →
  (K + (-1 : Int) * A ≥ (3 : Int)) →
  (K + (-1 : Int) * S ≥ (4 : Int)) →
  (K + O ≥ (8 : Int)) →
  (K + Q ≥ (6 : Int)) →
  (K + P ≥ (7 : Int)) →
  (K + L ≥ (9 : Int)) →
  (K + J ≥ (7 : Int)) →
  (K + I ≥ (6 : Int)) →
  (K + B ≥ (9 : Int)) →
  (K + A ≥ (7 : Int)) →
  (K + S ≥ (6 : Int)) →
  (J + (-1 : Int) * A ≥ (0 : Int)) →
  (J + (-1 : Int) * S ≥ (1 : Int)) →
  (J + O ≥ (5 : Int)) →
  (J + Q ≥ (3 : Int)) →
  (J + P ≥ (4 : Int)) →
  (J + B ≥ (6 : Int)) →
  (J + A ≥ (4 : Int)) →
  (J + S ≥ (3 : Int)) →
  (I + O ≥ (4 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (3 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + B ≥ (5 : Int)) →
  (I + A ≥ (3 : Int)) →
  (I + S ≥ (2 : Int)) →
  (F + (-1 : Int) * O ≥ (1 : Int)) →
  (F + (-1 : Int) * Q ≥ (3 : Int)) →
  (F + (-1 : Int) * P ≥ (2 : Int)) →
  (F + (-1 : Int) * N ≥ (1 : Int)) →
  (F + (-1 : Int) * M ≥ (0 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (3 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (2 : Int)) →
  (F + (-1 : Int) * S ≥ (3 : Int)) →
  (F + O ≥ (7 : Int)) →
  (F + Q ≥ (5 : Int)) →
  (F + P ≥ (6 : Int)) →
  (F + N ≥ (7 : Int)) →
  (F + M ≥ (8 : Int)) →
  (F + L ≥ (8 : Int)) →
  (F + K ≥ (9 : Int)) →
  (F + J ≥ (6 : Int)) →
  (F + I ≥ (5 : Int)) →
  (F + D ≥ (8 : Int)) →
  (F + C ≥ (5 : Int)) →
  (F + B ≥ (8 : Int)) →
  (F + A ≥ (6 : Int)) →
  (F + S ≥ (5 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + O ≥ (4 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (5 : Int)) →
  (E + K ≥ (6 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + F ≥ (5 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (5 : Int)) →
  (E + A ≥ (3 : Int)) →
  (E + S ≥ (2 : Int)) →
  (D + (-1 : Int) * O ≥ (1 : Int)) →
  (D + (-1 : Int) * Q ≥ (3 : Int)) →
  (D + (-1 : Int) * P ≥ (2 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * K ≥ (-1 : Int)) →
  (D + (-1 : Int) * J ≥ (2 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * B ≥ (0 : Int)) →
  (D + (-1 : Int) * A ≥ (2 : Int)) →
  (D + (-1 : Int) * S ≥ (3 : Int)) →
  (D + O ≥ (7 : Int)) →
  (D + Q ≥ (5 : Int)) →
  (D + P ≥ (6 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (8 : Int)) →
  (D + K ≥ (9 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + B ≥ (8 : Int)) →
  (D + A ≥ (6 : Int)) →
  (D + S ≥ (5 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + O ≥ (4 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (5 : Int)) →
  (C + K ≥ (6 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (5 : Int)) →
  (C + A ≥ (3 : Int)) →
  (C + S ≥ (2 : Int)) →
  (B + (-1 : Int) * O ≥ (1 : Int)) →
  (B + (-1 : Int) * Q ≥ (3 : Int)) →
  (B + (-1 : Int) * P ≥ (2 : Int)) →
  (B + O ≥ (7 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (6 : Int)) →
  (A + O ≥ (5 : Int)) →
  (A + Q ≥ (3 : Int)) →
  (A + P ≥ (4 : Int)) →
  (A + B ≥ (6 : Int)) →
  (S + (-1 : Int) * A ≥ (-1 : Int)) →
  (S + O ≥ (4 : Int)) →
  (S + Q ≥ (2 : Int)) →
  (S + P ≥ (3 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (3 : Int)) →
  (O ≥ (3 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (2 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (4 : Int)) →
  (K ≥ (5 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (F ≥ (4 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (4 : Int)) →
  (A ≥ (2 : Int)) →
  (S ≥ (1 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + O ≥ (-1 : Int)) →
  ((-1 : Int) * N + L ≥ (1 : Int)) →
  ((-1 : Int) * N + K ≥ (2 : Int)) →
  ((-1 : Int) * N + J ≥ (0 : Int)) →
  ((-1 : Int) * N + B ≥ (1 : Int)) →
  ((-1 : Int) * N + A ≥ (0 : Int)) →
  ((-1 : Int) * M + O ≥ (-2 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (0 : Int)) →
  ((-1 : Int) * M + K ≥ (1 : Int)) →
  ((-1 : Int) * M + J ≥ (-1 : Int)) →
  ((-1 : Int) * M + B ≥ (0 : Int)) →
  ((-1 : Int) * M + A ≥ (-1 : Int)) →
  ((-1 : Int) * K + O ≥ (-3 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * K + J ≥ (-2 : Int)) →
  ((-1 : Int) * K + B ≥ (-1 : Int)) →
  ((-1 : Int) * K + A ≥ (-2 : Int)) →
  ((-1 : Int) * J + O ≥ (-1 : Int)) →
  ((-1 : Int) * J + B ≥ (1 : Int)) →
  ((-1 : Int) * J + A ≥ (0 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * Q ≥ (-2 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * I + O ≥ (2 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (2 : Int)) →
  ((-1 : Int) * I + B ≥ (3 : Int)) →
  ((-1 : Int) * I + A ≥ (2 : Int)) →
  ((-1 : Int) * I + S ≥ (0 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * Q ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * E + O ≥ (2 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (1 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (3 : Int)) →
  ((-1 : Int) * E + K ≥ (4 : Int)) →
  ((-1 : Int) * E + J ≥ (2 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (3 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (3 : Int)) →
  ((-1 : Int) * E + A ≥ (2 : Int)) →
  ((-1 : Int) * E + S ≥ (0 : Int)) →
  ((-1 : Int) * D + O ≥ (-2 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (0 : Int)) →
  ((-1 : Int) * D + K ≥ (1 : Int)) →
  ((-1 : Int) * D + J ≥ (-1 : Int)) →
  ((-1 : Int) * D + B ≥ (0 : Int)) →
  ((-1 : Int) * D + A ≥ (-1 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * Q ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * C + O ≥ (2 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (3 : Int)) →
  ((-1 : Int) * C + K ≥ (4 : Int)) →
  ((-1 : Int) * C + J ≥ (2 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (3 : Int)) →
  ((-1 : Int) * C + A ≥ (2 : Int)) →
  ((-1 : Int) * C + S ≥ (0 : Int)) →
  ((-1 : Int) * B + O ≥ (-2 : Int)) →
  ((-1 : Int) * A + O ≥ (-1 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  ((-1 : Int) * S + (-1 : Int) * Q ≥ (-2 : Int)) →
  ((-1 : Int) * S + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * S + O ≥ (2 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + B ≥ (3 : Int)) →
  ((-1 : Int) * S + A ≥ (2 : Int)) →
  (Q + (-1 : Int) * P ≥ (-1 : Int)) →
  (Q + O ≥ (4 : Int)) →
  (Q + P ≥ (3 : Int)) →
  (P + O ≥ (5 : Int)) →
  (N + (-1 : Int) * O ≥ (0 : Int)) →
  (N + (-1 : Int) * Q ≥ (2 : Int)) →
  (N + (-1 : Int) * P ≥ (1 : Int)) →
  (N + (-1 : Int) * K ≥ (-2 : Int)) →
  (N + (-1 : Int) * J ≥ (0 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * B ≥ (-1 : Int)) →
  (N + (-1 : Int) * A ≥ (0 : Int)) →
  (N + (-1 : Int) * S ≥ (2 : Int)) →
  (N + O ≥ (6 : Int)) →
  (N + Q ≥ (4 : Int)) →
  (N + P ≥ (5 : Int)) →
  (N + L ≥ (7 : Int)) →
  (N + K ≥ (8 : Int)) →
  (N + J ≥ (6 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + B ≥ (7 : Int)) →
  (N + A ≥ (6 : Int)) →
  (N + S ≥ (4 : Int)) →
  (M + (-1 : Int) * O ≥ (1 : Int)) →
  (M + (-1 : Int) * Q ≥ (3 : Int)) →
  (M + (-1 : Int) * P ≥ (2 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * K ≥ (-1 : Int)) →
  (M + (-1 : Int) * J ≥ (1 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * B ≥ (0 : Int)) →
  (M + (-1 : Int) * A ≥ (1 : Int)) →
  (M + (-1 : Int) * S ≥ (3 : Int)) →
  (M + O ≥ (7 : Int)) →
  (M + Q ≥ (5 : Int)) →
  (M + P ≥ (6 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (8 : Int)) →
  (M + K ≥ (9 : Int)) →
  (M + J ≥ (7 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + B ≥ (8 : Int)) →
  (M + A ≥ (7 : Int)) →
  (M + S ≥ (5 : Int)) →
  (L + (-1 : Int) * O ≥ (1 : Int)) →
  (L + (-1 : Int) * Q ≥ (3 : Int)) →
  (L + (-1 : Int) * P ≥ (2 : Int)) →
  (L + (-1 : Int) * J ≥ (1 : Int)) →
  (L + (-1 : Int) * I ≥ (3 : Int)) →
  (L + (-1 : Int) * B ≥ (0 : Int)) →
  (L + (-1 : Int) * A ≥ (1 : Int)) →
  (L + (-1 : Int) * S ≥ (3 : Int)) →
  (L + O ≥ (7 : Int)) →
  (L + Q ≥ (5 : Int)) →
  (L + P ≥ (6 : Int)) →
  (L + J ≥ (7 : Int)) →
  (L + I ≥ (5 : Int)) →
  (L + B ≥ (8 : Int)) →
  (L + A ≥ (7 : Int)) →
  (L + S ≥ (5 : Int)) →
  (K + (-1 : Int) * O ≥ (2 : Int)) →
  (K + (-1 : Int) * Q ≥ (4 : Int)) →
  (K + (-1 : Int) * P ≥ (3 : Int)) →
  (K + (-1 : Int) * J ≥ (2 : Int)) →
  (K + (-1 : Int) * I ≥ (4 : Int)) →
  (K + (-1 : Int) * B ≥ (1 : Int)) →
  (K + (-1 : Int) * A ≥ (2 : Int)) →
  (K + (-1 : Int) * S ≥ (4 : Int)) →
  (K + O ≥ (8 : Int)) →
  (K + Q ≥ (6 : Int)) →
  (K + P ≥ (7 : Int)) →
  (K + L ≥ (9 : Int)) →
  (K + J ≥ (8 : Int)) →
  (K + I ≥ (6 : Int)) →
  (K + B ≥ (9 : Int)) →
  (K + A ≥ (8 : Int)) →
  (K + S ≥ (6 : Int)) →
  (J + (-1 : Int) * O ≥ (0 : Int)) →
  (J + (-1 : Int) * Q ≥ (2 : Int)) →
  (J + (-1 : Int) * P ≥ (1 : Int)) →
  (J + (-1 : Int) * B ≥ (-1 : Int)) →
  (J + (-1 : Int) * A ≥ (0 : Int)) →
  (J + (-1 : Int) * S ≥ (2 : Int)) →
  (J + O ≥ (6 : Int)) →
  (J + Q ≥ (4 : Int)) →
  (J + P ≥ (5 : Int)) →
  (J + B ≥ (7 : Int)) →
  (J + A ≥ (6 : Int)) →
  (J + S ≥ (4 : Int)) →
  (I + (-1 : Int) * Q ≥ (0 : Int)) →
  (I + (-1 : Int) * P ≥ (-1 : Int)) →
  (I + (-1 : Int) * S ≥ (0 : Int)) →
  (I + O ≥ (4 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (3 : Int)) →
  (I + J ≥ (4 : Int)) →
  (I + B ≥ (5 : Int)) →
  (I + A ≥ (4 : Int)) →
  (I + S ≥ (2 : Int)) →
  (F + (-1 : Int) * O ≥ (1 : Int)) →
  (F + (-1 : Int) * Q ≥ (3 : Int)) →
  (F + (-1 : Int) * P ≥ (2 : Int)) →
  (F + (-1 : Int) * N ≥ (1 : Int)) →
  (F + (-1 : Int) * M ≥ (0 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (1 : Int)) →
  (F + (-1 : Int) * I ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (3 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (1 : Int)) →
  (F + (-1 : Int) * S ≥ (3 : Int)) →
  (F + O ≥ (7 : Int)) →
  (F + Q ≥ (5 : Int)) →
  (F + P ≥ (6 : Int)) →
  (F + N ≥ (7 : Int)) →
  (F + M ≥ (8 : Int)) →
  (F + L ≥ (8 : Int)) →
  (F + K ≥ (9 : Int)) →
  (F + J ≥ (7 : Int)) →
  (F + I ≥ (5 : Int)) →
  (F + D ≥ (8 : Int)) →
  (F + C ≥ (5 : Int)) →
  (F + B ≥ (8 : Int)) →
  (F + A ≥ (7 : Int)) →
  (F + S ≥ (5 : Int)) →
  (E + (-1 : Int) * Q ≥ (0 : Int)) →
  (E + (-1 : Int) * P ≥ (-1 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + (-1 : Int) * S ≥ (0 : Int)) →
  (E + O ≥ (4 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (5 : Int)) →
  (E + K ≥ (6 : Int)) →
  (E + J ≥ (4 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + F ≥ (5 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (5 : Int)) →
  (E + A ≥ (4 : Int)) →
  (E + S ≥ (2 : Int)) →
  (D + (-1 : Int) * O ≥ (1 : Int)) →
  (D + (-1 : Int) * Q ≥ (3 : Int)) →
  (D + (-1 : Int) * P ≥ (2 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * K ≥ (-1 : Int)) →
  (D + (-1 : Int) * J ≥ (1 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * B ≥ (0 : Int)) →
  (D + (-1 : Int) * A ≥ (1 : Int)) →
  (D + (-1 : Int) * S ≥ (3 : Int)) →
  (D + O ≥ (7 : Int)) →
  (D + Q ≥ (5 : Int)) →
  (D + P ≥ (6 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (8 : Int)) →
  (D + K ≥ (9 : Int)) →
  (D + J ≥ (7 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + B ≥ (8 : Int)) →
  (D + A ≥ (7 : Int)) →
  (D + S ≥ (5 : Int)) →
  (C + (-1 : Int) * Q ≥ (0 : Int)) →
  (C + (-1 : Int) * P ≥ (-1 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * S ≥ (0 : Int)) →
  (C + O ≥ (4 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (5 : Int)) →
  (C + K ≥ (6 : Int)) →
  (C + J ≥ (4 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (5 : Int)) →
  (C + A ≥ (4 : Int)) →
  (C + S ≥ (2 : Int)) →
  (B + (-1 : Int) * O ≥ (1 : Int)) →
  (B + (-1 : Int) * Q ≥ (3 : Int)) →
  (B + (-1 : Int) * P ≥ (2 : Int)) →
  (B + O ≥ (7 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (6 : Int)) →
  (A + (-1 : Int) * O ≥ (0 : Int)) →
  (A + (-1 : Int) * Q ≥ (2 : Int)) →
  (A + (-1 : Int) * P ≥ (1 : Int)) →
  (A + (-1 : Int) * B ≥ (-1 : Int)) →
  (A + O ≥ (6 : Int)) →
  (A + Q ≥ (4 : Int)) →
  (A + P ≥ (5 : Int)) →
  (A + B ≥ (7 : Int)) →
  (S + (-1 : Int) * Q ≥ (0 : Int)) →
  (S + (-1 : Int) * P ≥ (-1 : Int)) →
  (S + O ≥ (4 : Int)) →
  (S + Q ≥ (2 : Int)) →
  (S + P ≥ (3 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (4 : Int)) →
  (O ≥ (3 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (2 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (4 : Int)) →
  (K ≥ (5 : Int)) →
  (J ≥ (3 : Int)) →
  (I ≥ (1 : Int)) →
  (F ≥ (4 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (4 : Int)) →
  (A ≥ (3 : Int)) →
  (S ≥ (1 : Int)) →
  (Q ≤ (1 : Int)) →
  (P ≤ (2 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  (S ≤ (1 : Int)) →
  ((-1 : Int) * Q + (-1 : Int) * P ≥ (-3 : Int)) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (1 : Int)) →
  ((-1 : Int) * N + K ≥ (2 : Int)) →
  ((-1 : Int) * N + J ≥ (0 : Int)) →
  ((-1 : Int) * N + B ≥ (1 : Int)) →
  ((-1 : Int) * N + A ≥ (0 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (0 : Int)) →
  ((-1 : Int) * M + K ≥ (1 : Int)) →
  ((-1 : Int) * M + J ≥ (-1 : Int)) →
  ((-1 : Int) * M + B ≥ (0 : Int)) →
  ((-1 : Int) * M + A ≥ (-1 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * K + J ≥ (-2 : Int)) →
  ((-1 : Int) * K + B ≥ (-1 : Int)) →
  ((-1 : Int) * K + A ≥ (-2 : Int)) →
  ((-1 : Int) * J + B ≥ (1 : Int)) →
  ((-1 : Int) * J + A ≥ (0 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * I + O ≥ (2 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (4 : Int)) →
  ((-1 : Int) * I + A ≥ (3 : Int)) →
  ((-1 : Int) * I + S ≥ (0 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * E + O ≥ (2 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (1 : Int)) →
  ((-1 : Int) * E + N ≥ (3 : Int)) →
  ((-1 : Int) * E + M ≥ (4 : Int)) →
  ((-1 : Int) * E + L ≥ (4 : Int)) →
  ((-1 : Int) * E + K ≥ (5 : Int)) →
  ((-1 : Int) * E + J ≥ (3 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (4 : Int)) →
  ((-1 : Int) * E + D ≥ (4 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (4 : Int)) →
  ((-1 : Int) * E + A ≥ (3 : Int)) →
  ((-1 : Int) * E + S ≥ (0 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (0 : Int)) →
  ((-1 : Int) * D + K ≥ (1 : Int)) →
  ((-1 : Int) * D + J ≥ (-1 : Int)) →
  ((-1 : Int) * D + B ≥ (0 : Int)) →
  ((-1 : Int) * D + A ≥ (-1 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * C + O ≥ (2 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + N ≥ (3 : Int)) →
  ((-1 : Int) * C + M ≥ (4 : Int)) →
  ((-1 : Int) * C + L ≥ (4 : Int)) →
  ((-1 : Int) * C + K ≥ (5 : Int)) →
  ((-1 : Int) * C + J ≥ (3 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + D ≥ (4 : Int)) →
  ((-1 : Int) * C + B ≥ (4 : Int)) →
  ((-1 : Int) * C + A ≥ (3 : Int)) →
  ((-1 : Int) * C + S ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  ((-1 : Int) * S + O ≥ (2 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + B ≥ (4 : Int)) →
  ((-1 : Int) * S + A ≥ (3 : Int)) →
  (Q + O ≥ (4 : Int)) →
  (Q + P ≥ (3 : Int)) →
  (P + O ≥ (5 : Int)) →
  (N + (-1 : Int) * O ≥ (0 : Int)) →
  (N + (-1 : Int) * Q ≥ (2 : Int)) →
  (N + (-1 : Int) * P ≥ (1 : Int)) →
  (N + (-1 : Int) * K ≥ (-2 : Int)) →
  (N + (-1 : Int) * J ≥ (0 : Int)) →
  (N + (-1 : Int) * I ≥ (3 : Int)) →
  (N + (-1 : Int) * B ≥ (-1 : Int)) →
  (N + (-1 : Int) * A ≥ (0 : Int)) →
  (N + (-1 : Int) * S ≥ (3 : Int)) →
  (N + O ≥ (7 : Int)) →
  (N + Q ≥ (5 : Int)) →
  (N + P ≥ (6 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (8 : Int)) →
  (N + I ≥ (5 : Int)) →
  (N + B ≥ (9 : Int)) →
  (N + A ≥ (8 : Int)) →
  (N + S ≥ (5 : Int)) →
  (M + (-1 : Int) * O ≥ (1 : Int)) →
  (M + (-1 : Int) * Q ≥ (3 : Int)) →
  (M + (-1 : Int) * P ≥ (2 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * K ≥ (-1 : Int)) →
  (M + (-1 : Int) * J ≥ (1 : Int)) →
  (M + (-1 : Int) * I ≥ (4 : Int)) →
  (M + (-1 : Int) * B ≥ (0 : Int)) →
  (M + (-1 : Int) * A ≥ (1 : Int)) →
  (M + (-1 : Int) * S ≥ (4 : Int)) →
  (M + O ≥ (8 : Int)) →
  (M + Q ≥ (6 : Int)) →
  (M + P ≥ (7 : Int)) →
  (M + N ≥ (9 : Int)) →
  (M + L ≥ (10 : Int)) →
  (M + K ≥ (11 : Int)) →
  (M + J ≥ (9 : Int)) →
  (M + I ≥ (6 : Int)) →
  (M + B ≥ (10 : Int)) →
  (M + A ≥ (9 : Int)) →
  (M + S ≥ (6 : Int)) →
  (L + (-1 : Int) * O ≥ (1 : Int)) →
  (L + (-1 : Int) * Q ≥ (3 : Int)) →
  (L + (-1 : Int) * P ≥ (2 : Int)) →
  (L + (-1 : Int) * J ≥ (1 : Int)) →
  (L + (-1 : Int) * I ≥ (4 : Int)) →
  (L + (-1 : Int) * B ≥ (0 : Int)) →
  (L + (-1 : Int) * A ≥ (1 : Int)) →
  (L + (-1 : Int) * S ≥ (4 : Int)) →
  (L + O ≥ (8 : Int)) →
  (L + Q ≥ (6 : Int)) →
  (L + P ≥ (7 : Int)) →
  (L + J ≥ (9 : Int)) →
  (L + I ≥ (6 : Int)) →
  (L + B ≥ (10 : Int)) →
  (L + A ≥ (9 : Int)) →
  (L + S ≥ (6 : Int)) →
  (K + (-1 : Int) * O ≥ (2 : Int)) →
  (K + (-1 : Int) * Q ≥ (4 : Int)) →
  (K + (-1 : Int) * P ≥ (3 : Int)) →
  (K + (-1 : Int) * J ≥ (2 : Int)) →
  (K + (-1 : Int) * I ≥ (5 : Int)) →
  (K + (-1 : Int) * B ≥ (1 : Int)) →
  (K + (-1 : Int) * A ≥ (2 : Int)) →
  (K + (-1 : Int) * S ≥ (5 : Int)) →
  (K + O ≥ (9 : Int)) →
  (K + Q ≥ (7 : Int)) →
  (K + P ≥ (8 : Int)) →
  (K + L ≥ (11 : Int)) →
  (K + J ≥ (10 : Int)) →
  (K + I ≥ (7 : Int)) →
  (K + B ≥ (11 : Int)) →
  (K + A ≥ (10 : Int)) →
  (K + S ≥ (7 : Int)) →
  (J + (-1 : Int) * O ≥ (0 : Int)) →
  (J + (-1 : Int) * Q ≥ (2 : Int)) →
  (J + (-1 : Int) * P ≥ (1 : Int)) →
  (J + (-1 : Int) * B ≥ (-1 : Int)) →
  (J + (-1 : Int) * A ≥ (0 : Int)) →
  (J + (-1 : Int) * S ≥ (3 : Int)) →
  (J + O ≥ (7 : Int)) →
  (J + Q ≥ (5 : Int)) →
  (J + P ≥ (6 : Int)) →
  (J + B ≥ (9 : Int)) →
  (J + A ≥ (8 : Int)) →
  (J + S ≥ (5 : Int)) →
  (I + (-1 : Int) * S ≥ (0 : Int)) →
  (I + O ≥ (4 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (3 : Int)) →
  (I + J ≥ (5 : Int)) →
  (I + B ≥ (6 : Int)) →
  (I + A ≥ (5 : Int)) →
  (I + S ≥ (2 : Int)) →
  (F + (-1 : Int) * O ≥ (1 : Int)) →
  (F + (-1 : Int) * Q ≥ (3 : Int)) →
  (F + (-1 : Int) * P ≥ (2 : Int)) →
  (F + (-1 : Int) * N ≥ (1 : Int)) →
  (F + (-1 : Int) * M ≥ (0 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (1 : Int)) →
  (F + (-1 : Int) * I ≥ (4 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (4 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (1 : Int)) →
  (F + (-1 : Int) * S ≥ (4 : Int)) →
  (F + O ≥ (8 : Int)) →
  (F + Q ≥ (6 : Int)) →
  (F + P ≥ (7 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (10 : Int)) →
  (F + L ≥ (10 : Int)) →
  (F + K ≥ (11 : Int)) →
  (F + J ≥ (9 : Int)) →
  (F + I ≥ (6 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (6 : Int)) →
  (F + B ≥ (10 : Int)) →
  (F + A ≥ (9 : Int)) →
  (F + S ≥ (6 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + (-1 : Int) * S ≥ (0 : Int)) →
  (E + O ≥ (4 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + N ≥ (5 : Int)) →
  (E + M ≥ (6 : Int)) →
  (E + L ≥ (6 : Int)) →
  (E + K ≥ (7 : Int)) →
  (E + J ≥ (5 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + F ≥ (6 : Int)) →
  (E + D ≥ (6 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (6 : Int)) →
  (E + A ≥ (5 : Int)) →
  (E + S ≥ (2 : Int)) →
  (D + (-1 : Int) * O ≥ (1 : Int)) →
  (D + (-1 : Int) * Q ≥ (3 : Int)) →
  (D + (-1 : Int) * P ≥ (2 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * K ≥ (-1 : Int)) →
  (D + (-1 : Int) * J ≥ (1 : Int)) →
  (D + (-1 : Int) * I ≥ (4 : Int)) →
  (D + (-1 : Int) * B ≥ (0 : Int)) →
  (D + (-1 : Int) * A ≥ (1 : Int)) →
  (D + (-1 : Int) * S ≥ (4 : Int)) →
  (D + O ≥ (8 : Int)) →
  (D + Q ≥ (6 : Int)) →
  (D + P ≥ (7 : Int)) →
  (D + N ≥ (9 : Int)) →
  (D + M ≥ (10 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (9 : Int)) →
  (D + I ≥ (6 : Int)) →
  (D + B ≥ (10 : Int)) →
  (D + A ≥ (9 : Int)) →
  (D + S ≥ (6 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * S ≥ (0 : Int)) →
  (C + O ≥ (4 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + N ≥ (5 : Int)) →
  (C + M ≥ (6 : Int)) →
  (C + L ≥ (6 : Int)) →
  (C + K ≥ (7 : Int)) →
  (C + J ≥ (5 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + D ≥ (6 : Int)) →
  (C + B ≥ (6 : Int)) →
  (C + A ≥ (5 : Int)) →
  (C + S ≥ (2 : Int)) →
  (B + (-1 : Int) * O ≥ (1 : Int)) →
  (B + (-1 : Int) * Q ≥ (3 : Int)) →
  (B + (-1 : Int) * P ≥ (2 : Int)) →
  (B + O ≥ (8 : Int)) →
  (B + Q ≥ (6 : Int)) →
  (B + P ≥ (7 : Int)) →
  (A + (-1 : Int) * O ≥ (0 : Int)) →
  (A + (-1 : Int) * Q ≥ (2 : Int)) →
  (A + (-1 : Int) * P ≥ (1 : Int)) →
  (A + (-1 : Int) * B ≥ (-1 : Int)) →
  (A + O ≥ (7 : Int)) →
  (A + Q ≥ (5 : Int)) →
  (A + P ≥ (6 : Int)) →
  (A + B ≥ (9 : Int)) →
  (S + O ≥ (4 : Int)) →
  (S + Q ≥ (2 : Int)) →
  (S + P ≥ (3 : Int)) →
  (S + B ≥ (6 : Int)) →
  (S + A ≥ (5 : Int)) →
  (O ≥ (3 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (2 : Int)) →
  (N ≥ (4 : Int)) →
  (M ≥ (5 : Int)) →
  (L ≥ (5 : Int)) →
  (K ≥ (6 : Int)) →
  (J ≥ (4 : Int)) →
  (I ≥ (1 : Int)) →
  (F ≥ (5 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (5 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (5 : Int)) →
  (A ≥ (4 : Int)) →
  (S ≥ (1 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  (S ≤ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + O ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (1 : Int)) →
  ((-1 : Int) * N + K ≥ (2 : Int)) →
  ((-1 : Int) * N + B ≥ (1 : Int)) →
  ((-1 : Int) * M + O ≥ (0 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (0 : Int)) →
  ((-1 : Int) * M + K ≥ (1 : Int)) →
  ((-1 : Int) * M + B ≥ (0 : Int)) →
  ((-1 : Int) * K + O ≥ (-1 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * K + B ≥ (-1 : Int)) →
  ((-1 : Int) * J + O ≥ (1 : Int)) →
  ((-1 : Int) * J + P ≥ (0 : Int)) →
  ((-1 : Int) * J + B ≥ (1 : Int)) →
  ((-1 : Int) * J + A ≥ (0 : Int)) →
  ((-1 : Int) * I + O ≥ (3 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + B ≥ (3 : Int)) →
  ((-1 : Int) * I + A ≥ (1 : Int)) →
  ((-1 : Int) * I + S ≥ (0 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + O ≥ (3 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (1 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (3 : Int)) →
  ((-1 : Int) * E + K ≥ (4 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (3 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (3 : Int)) →
  ((-1 : Int) * E + A ≥ (1 : Int)) →
  ((-1 : Int) * E + S ≥ (0 : Int)) →
  ((-1 : Int) * D + O ≥ (0 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (0 : Int)) →
  ((-1 : Int) * D + K ≥ (1 : Int)) →
  ((-1 : Int) * D + B ≥ (0 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + O ≥ (3 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (3 : Int)) →
  ((-1 : Int) * C + K ≥ (4 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (3 : Int)) →
  ((-1 : Int) * C + A ≥ (1 : Int)) →
  ((-1 : Int) * C + S ≥ (0 : Int)) →
  ((-1 : Int) * B + O ≥ (0 : Int)) →
  ((-1 : Int) * A + O ≥ (1 : Int)) →
  ((-1 : Int) * A + P ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  ((-1 : Int) * S + O ≥ (2 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + B ≥ (2 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  (Q + O ≥ (5 : Int)) →
  (Q + P ≥ (3 : Int)) →
  (P + O ≥ (6 : Int)) →
  (N + (-1 : Int) * O ≥ (-1 : Int)) →
  (N + (-1 : Int) * Q ≥ (1 : Int)) →
  (N + (-1 : Int) * P ≥ (0 : Int)) →
  (N + (-1 : Int) * K ≥ (-2 : Int)) →
  (N + (-1 : Int) * J ≥ (0 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * B ≥ (-1 : Int)) →
  (N + (-1 : Int) * A ≥ (0 : Int)) →
  (N + (-1 : Int) * S ≥ (1 : Int)) →
  (N + O ≥ (7 : Int)) →
  (N + Q ≥ (4 : Int)) →
  (N + P ≥ (5 : Int)) →
  (N + L ≥ (7 : Int)) →
  (N + K ≥ (8 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + B ≥ (7 : Int)) →
  (N + A ≥ (5 : Int)) →
  (N + S ≥ (4 : Int)) →
  (M + (-1 : Int) * O ≥ (0 : Int)) →
  (M + (-1 : Int) * Q ≥ (2 : Int)) →
  (M + (-1 : Int) * P ≥ (1 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * K ≥ (-1 : Int)) →
  (M + (-1 : Int) * J ≥ (1 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * B ≥ (0 : Int)) →
  (M + (-1 : Int) * A ≥ (1 : Int)) →
  (M + (-1 : Int) * S ≥ (2 : Int)) →
  (M + O ≥ (8 : Int)) →
  (M + Q ≥ (5 : Int)) →
  (M + P ≥ (6 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (8 : Int)) →
  (M + K ≥ (9 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + B ≥ (8 : Int)) →
  (M + A ≥ (6 : Int)) →
  (M + S ≥ (5 : Int)) →
  (L + (-1 : Int) * O ≥ (0 : Int)) →
  (L + (-1 : Int) * Q ≥ (2 : Int)) →
  (L + (-1 : Int) * P ≥ (1 : Int)) →
  (L + (-1 : Int) * J ≥ (1 : Int)) →
  (L + (-1 : Int) * I ≥ (3 : Int)) →
  (L + (-1 : Int) * B ≥ (0 : Int)) →
  (L + (-1 : Int) * A ≥ (1 : Int)) →
  (L + (-1 : Int) * S ≥ (2 : Int)) →
  (L + O ≥ (8 : Int)) →
  (L + Q ≥ (5 : Int)) →
  (L + P ≥ (6 : Int)) →
  (L + J ≥ (6 : Int)) →
  (L + I ≥ (5 : Int)) →
  (L + B ≥ (8 : Int)) →
  (L + A ≥ (6 : Int)) →
  (L + S ≥ (5 : Int)) →
  (K + (-1 : Int) * O ≥ (1 : Int)) →
  (K + (-1 : Int) * Q ≥ (3 : Int)) →
  (K + (-1 : Int) * P ≥ (2 : Int)) →
  (K + (-1 : Int) * J ≥ (2 : Int)) →
  (K + (-1 : Int) * I ≥ (4 : Int)) →
  (K + (-1 : Int) * B ≥ (1 : Int)) →
  (K + (-1 : Int) * A ≥ (2 : Int)) →
  (K + (-1 : Int) * S ≥ (3 : Int)) →
  (K + O ≥ (9 : Int)) →
  (K + Q ≥ (6 : Int)) →
  (K + P ≥ (7 : Int)) →
  (K + L ≥ (9 : Int)) →
  (K + J ≥ (7 : Int)) →
  (K + I ≥ (6 : Int)) →
  (K + B ≥ (9 : Int)) →
  (K + A ≥ (7 : Int)) →
  (K + S ≥ (6 : Int)) →
  (J + (-1 : Int) * Q ≥ (1 : Int)) →
  (J + (-1 : Int) * P ≥ (0 : Int)) →
  (J + (-1 : Int) * A ≥ (0 : Int)) →
  (J + (-1 : Int) * S ≥ (1 : Int)) →
  (J + O ≥ (6 : Int)) →
  (J + Q ≥ (3 : Int)) →
  (J + P ≥ (4 : Int)) →
  (J + B ≥ (6 : Int)) →
  (J + A ≥ (4 : Int)) →
  (J + S ≥ (3 : Int)) →
  (I + O ≥ (5 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (3 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + B ≥ (5 : Int)) →
  (I + A ≥ (3 : Int)) →
  (I + S ≥ (2 : Int)) →
  (F + (-1 : Int) * O ≥ (0 : Int)) →
  (F + (-1 : Int) * Q ≥ (2 : Int)) →
  (F + (-1 : Int) * P ≥ (1 : Int)) →
  (F + (-1 : Int) * N ≥ (1 : Int)) →
  (F + (-1 : Int) * M ≥ (0 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (1 : Int)) →
  (F + (-1 : Int) * I ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (3 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (1 : Int)) →
  (F + (-1 : Int) * S ≥ (2 : Int)) →
  (F + O ≥ (8 : Int)) →
  (F + Q ≥ (5 : Int)) →
  (F + P ≥ (6 : Int)) →
  (F + N ≥ (7 : Int)) →
  (F + M ≥ (8 : Int)) →
  (F + L ≥ (8 : Int)) →
  (F + K ≥ (9 : Int)) →
  (F + J ≥ (6 : Int)) →
  (F + I ≥ (5 : Int)) →
  (F + D ≥ (8 : Int)) →
  (F + C ≥ (5 : Int)) →
  (F + B ≥ (8 : Int)) →
  (F + A ≥ (6 : Int)) →
  (F + S ≥ (5 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + O ≥ (5 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (5 : Int)) →
  (E + K ≥ (6 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + F ≥ (5 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (5 : Int)) →
  (E + A ≥ (3 : Int)) →
  (E + S ≥ (2 : Int)) →
  (D + (-1 : Int) * O ≥ (0 : Int)) →
  (D + (-1 : Int) * Q ≥ (2 : Int)) →
  (D + (-1 : Int) * P ≥ (1 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * K ≥ (-1 : Int)) →
  (D + (-1 : Int) * J ≥ (1 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * B ≥ (0 : Int)) →
  (D + (-1 : Int) * A ≥ (1 : Int)) →
  (D + (-1 : Int) * S ≥ (2 : Int)) →
  (D + O ≥ (8 : Int)) →
  (D + Q ≥ (5 : Int)) →
  (D + P ≥ (6 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (8 : Int)) →
  (D + K ≥ (9 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + B ≥ (8 : Int)) →
  (D + A ≥ (6 : Int)) →
  (D + S ≥ (5 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + O ≥ (5 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (5 : Int)) →
  (C + K ≥ (6 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (5 : Int)) →
  (C + A ≥ (3 : Int)) →
  (C + S ≥ (2 : Int)) →
  (B + (-1 : Int) * O ≥ (0 : Int)) →
  (B + (-1 : Int) * Q ≥ (2 : Int)) →
  (B + (-1 : Int) * P ≥ (1 : Int)) →
  (B + O ≥ (8 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (6 : Int)) →
  (A + (-1 : Int) * Q ≥ (1 : Int)) →
  (A + (-1 : Int) * P ≥ (0 : Int)) →
  (A + O ≥ (6 : Int)) →
  (A + Q ≥ (3 : Int)) →
  (A + P ≥ (4 : Int)) →
  (A + B ≥ (6 : Int)) →
  (S + (-1 : Int) * Q ≥ (0 : Int)) →
  (S + O ≥ (5 : Int)) →
  (S + Q ≥ (2 : Int)) →
  (S + P ≥ (3 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (3 : Int)) →
  (O ≥ (4 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (2 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (4 : Int)) →
  (K ≥ (5 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (F ≥ (4 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (4 : Int)) →
  (A ≥ (2 : Int)) →
  (S ≥ (1 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  r3 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r1 S A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r4 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r2 S A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r4 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 S A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r2 P A B C D E F G H I J K L M N R Q S O) →
  (True) →
  r1 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 P A B C D E F G H I J K L M N S Q R O) →
  (True) →
  r1 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r2 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r1 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r2 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r1 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r2 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r1 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r2 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r1 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r2 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r1 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r2 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r1 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r2 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r1 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r2 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r1 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r2 P A B C D E F G H I J K L M N R Q S O) →
  (True) →
  r2 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 P A B C D E F G H I J K L M N S Q R O) →
  (True) →
  r2 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r2 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r2 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r2 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r2 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r2 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r2 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r2 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r2 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r2 Q A B C D E F G H I J K L M N P R S O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r2 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N P R S O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N P R S O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r2 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N P R S O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r2 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N P R S O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r2 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N P R S O) →
  (r2 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r2 P A B C D E F G H I J K L M N S Q R O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r2 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N S Q R O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N S Q R O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r2 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N S Q R O) →
  (r2 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r4 P A B C D E F G H I J K L M N S R Q O) →
  (r2 P A B C D E F G H I J K L M N S Q R O) →
  (True) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r2 P A B C D E F G H I J K L M N S R Q O) →
  (r4 P A B C D E F G H I J K L M N S Q R O) →
  (True) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r0 P A B C D E F G H I J K L M N S R Q O) →
  (r2 P A B C D E F G H I J K L M N S R Q O) →
  (True) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 P A B C D E F G H I J K L M N S R Q O) →
  (r4 P A B C D E F G H I J K L M N S R Q O) →
  (True) →
  r5) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r5) →
  False))))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«fortune-full.16_000»
