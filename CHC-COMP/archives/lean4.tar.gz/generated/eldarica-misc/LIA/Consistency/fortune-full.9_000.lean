import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«fortune-full.9_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3366:1-3366:12 (check-sat, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":9:1-360:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":361:1-769:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":770:1-1113:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":1114:1-1483:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":1484:1-1842:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":1843:1-2202:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":2203:1-2550:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":2551:1-2906:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":2907:1-2917:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":2918:1-2928:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":2929:1-2939:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":2940:1-2952:2 (clause 12, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":2953:1-2965:2 (clause 13, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":2966:1-2978:2 (clause 14, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":2979:1-2993:2 (clause 15, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":2994:1-3008:2 (clause 16, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3009:1-3023:2 (clause 17, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3024:1-3038:2 (clause 18, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3039:1-3053:2 (clause 19, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3054:1-3064:2 (clause 20, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3065:1-3077:2 (clause 21, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3078:1-3090:2 (clause 22, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3091:1-3103:2 (clause 23, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3104:1-3118:2 (clause 24, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3119:1-3133:2 (clause 25, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3134:1-3148:2 (clause 26, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3149:1-3163:2 (clause 27, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3164:1-3178:2 (clause 28, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3179:1-3194:2 (clause 29, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3195:1-3210:2 (clause 30, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3211:1-3226:2 (clause 31, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3227:1-3242:2 (clause 32, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3243:1-3258:2 (clause 33, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3259:1-3274:2 (clause 34, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3275:1-3288:2 (clause 35, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3289:1-3302:2 (clause 36, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3303:1-3316:2 (clause 37, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3317:1-3330:2 (clause 38, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3331:1-3342:2 (clause 39, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3343:1-3354:2 (clause 40, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.9_000.smt2":3355:1-3364:2 (clause 41, command 46)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + H ≥ (1 : Int)) →
  ((-1 : Int) * S + B ≥ (3 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  ((-1 : Int) * S + O ≥ (3 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * N + Q ≥ (1 : Int)) →
  ((-1 : Int) * N + P ≥ (3 : Int)) →
  ((-1 : Int) * N + L ≥ (4 : Int)) →
  ((-1 : Int) * N + K ≥ (4 : Int)) →
  ((-1 : Int) * N + H ≥ (2 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + B ≥ (4 : Int)) →
  ((-1 : Int) * N + A ≥ (2 : Int)) →
  ((-1 : Int) * N + O ≥ (4 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * M + Q ≥ (0 : Int)) →
  ((-1 : Int) * M + P ≥ (2 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (3 : Int)) →
  ((-1 : Int) * M + K ≥ (3 : Int)) →
  ((-1 : Int) * M + H ≥ (1 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + B ≥ (3 : Int)) →
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * M + O ≥ (3 : Int)) →
  ((-1 : Int) * K + L ≥ (0 : Int)) →
  ((-1 : Int) * K + B ≥ (0 : Int)) →
  ((-1 : Int) * K + O ≥ (0 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * J + Q ≥ (0 : Int)) →
  ((-1 : Int) * J + P ≥ (2 : Int)) →
  ((-1 : Int) * J + H ≥ (1 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + B ≥ (3 : Int)) →
  ((-1 : Int) * J + A ≥ (1 : Int)) →
  ((-1 : Int) * J + O ≥ (3 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * I + Q ≥ (3 : Int)) →
  ((-1 : Int) * I + P ≥ (5 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (4 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (6 : Int)) →
  ((-1 : Int) * I + A ≥ (4 : Int)) →
  ((-1 : Int) * I + O ≥ (6 : Int)) →
  ((-1 : Int) * H + P ≥ (1 : Int)) →
  ((-1 : Int) * H + O ≥ (2 : Int)) →
  ((-1 : Int) * G + Q ≥ (0 : Int)) →
  ((-1 : Int) * G + P ≥ (2 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * G + O ≥ (3 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * E + Q ≥ (3 : Int)) →
  ((-1 : Int) * E + P ≥ (5 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (6 : Int)) →
  ((-1 : Int) * E + K ≥ (6 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (4 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (6 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (6 : Int)) →
  ((-1 : Int) * E + A ≥ (4 : Int)) →
  ((-1 : Int) * E + O ≥ (6 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * D + Q ≥ (0 : Int)) →
  ((-1 : Int) * D + P ≥ (2 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (3 : Int)) →
  ((-1 : Int) * D + K ≥ (3 : Int)) →
  ((-1 : Int) * D + H ≥ (1 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + B ≥ (3 : Int)) →
  ((-1 : Int) * D + A ≥ (1 : Int)) →
  ((-1 : Int) * D + O ≥ (3 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * C + Q ≥ (3 : Int)) →
  ((-1 : Int) * C + P ≥ (5 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (6 : Int)) →
  ((-1 : Int) * C + K ≥ (6 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (4 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (6 : Int)) →
  ((-1 : Int) * C + A ≥ (4 : Int)) →
  ((-1 : Int) * C + O ≥ (6 : Int)) →
  ((-1 : Int) * B + O ≥ (0 : Int)) →
  ((-1 : Int) * A + P ≥ (1 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (2 : Int)) →
  ((-1 : Int) * A + O ≥ (2 : Int)) →
  (S + (-1 : Int) * H ≥ (-1 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + (-1 : Int) * A ≥ (-1 : Int)) →
  (S + Q ≥ (8 : Int)) →
  (S + P ≥ (10 : Int)) →
  (S + H ≥ (9 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (11 : Int)) →
  (S + A ≥ (9 : Int)) →
  (S + O ≥ (11 : Int)) →
  (Q + P ≥ (10 : Int)) →
  (Q + O ≥ (11 : Int)) →
  (P + O ≥ (13 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + S ≥ (7 : Int)) →
  (N + Q ≥ (7 : Int)) →
  (N + P ≥ (9 : Int)) →
  (N + L ≥ (10 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (8 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (10 : Int)) →
  (N + A ≥ (8 : Int)) →
  (N + O ≥ (10 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + S ≥ (8 : Int)) →
  (M + Q ≥ (8 : Int)) →
  (M + P ≥ (10 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (11 : Int)) →
  (M + K ≥ (11 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (9 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (11 : Int)) →
  (M + A ≥ (9 : Int)) →
  (M + O ≥ (11 : Int)) →
  (L + (-1 : Int) * S ≥ (3 : Int)) →
  (L + (-1 : Int) * Q ≥ (2 : Int)) →
  (L + (-1 : Int) * P ≥ (1 : Int)) →
  (L + (-1 : Int) * J ≥ (3 : Int)) →
  (L + (-1 : Int) * I ≥ (6 : Int)) →
  (L + (-1 : Int) * H ≥ (2 : Int)) →
  (L + (-1 : Int) * G ≥ (3 : Int)) →
  (L + (-1 : Int) * B ≥ (0 : Int)) →
  (L + (-1 : Int) * A ≥ (2 : Int)) →
  (L + (-1 : Int) * O ≥ (0 : Int)) →
  (L + S ≥ (11 : Int)) →
  (L + Q ≥ (11 : Int)) →
  (L + P ≥ (13 : Int)) →
  (L + J ≥ (9 : Int)) →
  (L + I ≥ (8 : Int)) →
  (L + H ≥ (12 : Int)) →
  (L + G ≥ (11 : Int)) →
  (L + B ≥ (14 : Int)) →
  (L + A ≥ (12 : Int)) →
  (L + O ≥ (14 : Int)) →
  (K + (-1 : Int) * S ≥ (3 : Int)) →
  (K + (-1 : Int) * Q ≥ (2 : Int)) →
  (K + (-1 : Int) * P ≥ (1 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (6 : Int)) →
  (K + (-1 : Int) * H ≥ (2 : Int)) →
  (K + (-1 : Int) * G ≥ (3 : Int)) →
  (K + (-1 : Int) * B ≥ (0 : Int)) →
  (K + (-1 : Int) * A ≥ (2 : Int)) →
  (K + (-1 : Int) * O ≥ (0 : Int)) →
  (K + S ≥ (11 : Int)) →
  (K + Q ≥ (11 : Int)) →
  (K + P ≥ (13 : Int)) →
  (K + L ≥ (14 : Int)) →
  (K + J ≥ (9 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + H ≥ (12 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + B ≥ (14 : Int)) →
  (K + A ≥ (12 : Int)) →
  (K + O ≥ (14 : Int)) →
  (J + S ≥ (6 : Int)) →
  (J + Q ≥ (6 : Int)) →
  (J + P ≥ (8 : Int)) →
  (J + H ≥ (7 : Int)) →
  (J + G ≥ (6 : Int)) →
  (J + B ≥ (9 : Int)) →
  (J + A ≥ (7 : Int)) →
  (J + O ≥ (9 : Int)) →
  (I + S ≥ (5 : Int)) →
  (I + Q ≥ (5 : Int)) →
  (I + P ≥ (7 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (8 : Int)) →
  (I + A ≥ (6 : Int)) →
  (I + O ≥ (8 : Int)) →
  (H + Q ≥ (9 : Int)) →
  (H + P ≥ (11 : Int)) →
  (H + O ≥ (12 : Int)) →
  (G + Q ≥ (8 : Int)) →
  (G + P ≥ (10 : Int)) →
  (G + H ≥ (9 : Int)) →
  (G + O ≥ (11 : Int)) →
  (F + (-1 : Int) * S ≥ (3 : Int)) →
  (F + (-1 : Int) * Q ≥ (2 : Int)) →
  (F + (-1 : Int) * P ≥ (1 : Int)) →
  (F + (-1 : Int) * N ≥ (4 : Int)) →
  (F + (-1 : Int) * M ≥ (3 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (0 : Int)) →
  (F + (-1 : Int) * J ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (6 : Int)) →
  (F + (-1 : Int) * H ≥ (2 : Int)) →
  (F + (-1 : Int) * G ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (3 : Int)) →
  (F + (-1 : Int) * C ≥ (6 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (2 : Int)) →
  (F + (-1 : Int) * O ≥ (0 : Int)) →
  (F + S ≥ (11 : Int)) →
  (F + Q ≥ (11 : Int)) →
  (F + P ≥ (13 : Int)) →
  (F + N ≥ (10 : Int)) →
  (F + M ≥ (11 : Int)) →
  (F + L ≥ (14 : Int)) →
  (F + K ≥ (14 : Int)) →
  (F + J ≥ (9 : Int)) →
  (F + I ≥ (8 : Int)) →
  (F + H ≥ (12 : Int)) →
  (F + G ≥ (11 : Int)) →
  (F + D ≥ (11 : Int)) →
  (F + C ≥ (8 : Int)) →
  (F + B ≥ (14 : Int)) →
  (F + A ≥ (12 : Int)) →
  (F + O ≥ (14 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + S ≥ (5 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (7 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (8 : Int)) →
  (E + K ≥ (8 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (8 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (8 : Int)) →
  (E + A ≥ (6 : Int)) →
  (E + O ≥ (8 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + S ≥ (8 : Int)) →
  (D + Q ≥ (8 : Int)) →
  (D + P ≥ (10 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (11 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (9 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (11 : Int)) →
  (D + A ≥ (9 : Int)) →
  (D + O ≥ (11 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + S ≥ (5 : Int)) →
  (C + Q ≥ (5 : Int)) →
  (C + P ≥ (7 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (8 : Int)) →
  (C + K ≥ (8 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (8 : Int)) →
  (C + A ≥ (6 : Int)) →
  (C + O ≥ (8 : Int)) →
  (B + (-1 : Int) * Q ≥ (2 : Int)) →
  (B + (-1 : Int) * P ≥ (1 : Int)) →
  (B + (-1 : Int) * H ≥ (2 : Int)) →
  (B + (-1 : Int) * G ≥ (3 : Int)) →
  (B + (-1 : Int) * O ≥ (0 : Int)) →
  (B + Q ≥ (11 : Int)) →
  (B + P ≥ (13 : Int)) →
  (B + H ≥ (12 : Int)) →
  (B + G ≥ (11 : Int)) →
  (B + O ≥ (14 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (1 : Int)) →
  (A + Q ≥ (9 : Int)) →
  (A + P ≥ (11 : Int)) →
  (A + H ≥ (10 : Int)) →
  (A + G ≥ (9 : Int)) →
  (A + B ≥ (12 : Int)) →
  (A + O ≥ (12 : Int)) →
  (S ≥ (4 : Int)) →
  (Q ≥ (4 : Int)) →
  (P ≥ (6 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (7 : Int)) →
  (K ≥ (7 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (5 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (7 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (7 : Int)) →
  (A ≥ (5 : Int)) →
  (O ≥ (7 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * S + P ≥ (2 : Int)) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + H ≥ (1 : Int)) →
  ((-1 : Int) * S + G ≥ (0 : Int)) →
  ((-1 : Int) * S + B ≥ (3 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  ((-1 : Int) * S + O ≥ (2 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * N + Q ≥ (1 : Int)) →
  ((-1 : Int) * N + P ≥ (2 : Int)) →
  ((-1 : Int) * N + L ≥ (4 : Int)) →
  ((-1 : Int) * N + K ≥ (4 : Int)) →
  ((-1 : Int) * N + H ≥ (2 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + B ≥ (4 : Int)) →
  ((-1 : Int) * N + A ≥ (2 : Int)) →
  ((-1 : Int) * N + O ≥ (3 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * M + Q ≥ (0 : Int)) →
  ((-1 : Int) * M + P ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (3 : Int)) →
  ((-1 : Int) * M + K ≥ (3 : Int)) →
  ((-1 : Int) * M + H ≥ (1 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + B ≥ (3 : Int)) →
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * M + O ≥ (2 : Int)) →
  ((-1 : Int) * K + S ≥ (-3 : Int)) →
  ((-1 : Int) * K + Q ≥ (-3 : Int)) →
  ((-1 : Int) * K + P ≥ (-2 : Int)) →
  ((-1 : Int) * K + L ≥ (0 : Int)) →
  ((-1 : Int) * K + H ≥ (-2 : Int)) →
  ((-1 : Int) * K + G ≥ (-3 : Int)) →
  ((-1 : Int) * K + B ≥ (0 : Int)) →
  ((-1 : Int) * K + A ≥ (-2 : Int)) →
  ((-1 : Int) * K + O ≥ (-1 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * J + Q ≥ (0 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + H ≥ (1 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + B ≥ (3 : Int)) →
  ((-1 : Int) * J + A ≥ (1 : Int)) →
  ((-1 : Int) * J + O ≥ (2 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * I + Q ≥ (3 : Int)) →
  ((-1 : Int) * I + P ≥ (4 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (4 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (6 : Int)) →
  ((-1 : Int) * I + A ≥ (4 : Int)) →
  ((-1 : Int) * I + O ≥ (5 : Int)) →
  ((-1 : Int) * H + Q ≥ (-1 : Int)) →
  ((-1 : Int) * H + P ≥ (0 : Int)) →
  ((-1 : Int) * H + O ≥ (1 : Int)) →
  ((-1 : Int) * G + Q ≥ (0 : Int)) →
  ((-1 : Int) * G + P ≥ (1 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * G + O ≥ (2 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * E + Q ≥ (3 : Int)) →
  ((-1 : Int) * E + P ≥ (4 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (6 : Int)) →
  ((-1 : Int) * E + K ≥ (6 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (4 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (6 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (6 : Int)) →
  ((-1 : Int) * E + A ≥ (4 : Int)) →
  ((-1 : Int) * E + O ≥ (5 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * D + Q ≥ (0 : Int)) →
  ((-1 : Int) * D + P ≥ (1 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (3 : Int)) →
  ((-1 : Int) * D + K ≥ (3 : Int)) →
  ((-1 : Int) * D + H ≥ (1 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + B ≥ (3 : Int)) →
  ((-1 : Int) * D + A ≥ (1 : Int)) →
  ((-1 : Int) * D + O ≥ (2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * C + Q ≥ (3 : Int)) →
  ((-1 : Int) * C + P ≥ (4 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (6 : Int)) →
  ((-1 : Int) * C + K ≥ (6 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (4 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (6 : Int)) →
  ((-1 : Int) * C + A ≥ (4 : Int)) →
  ((-1 : Int) * C + O ≥ (5 : Int)) →
  ((-1 : Int) * B + Q ≥ (-3 : Int)) →
  ((-1 : Int) * B + P ≥ (-2 : Int)) →
  ((-1 : Int) * B + H ≥ (-2 : Int)) →
  ((-1 : Int) * B + G ≥ (-3 : Int)) →
  ((-1 : Int) * B + O ≥ (-1 : Int)) →
  ((-1 : Int) * A + Q ≥ (-1 : Int)) →
  ((-1 : Int) * A + P ≥ (0 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * A + G ≥ (-1 : Int)) →
  ((-1 : Int) * A + B ≥ (2 : Int)) →
  ((-1 : Int) * A + O ≥ (1 : Int)) →
  (S + (-1 : Int) * Q ≥ (0 : Int)) →
  (S + (-1 : Int) * P ≥ (-1 : Int)) →
  (S + (-1 : Int) * H ≥ (-1 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + (-1 : Int) * B ≥ (-3 : Int)) →
  (S + (-1 : Int) * A ≥ (-1 : Int)) →
  (S + (-1 : Int) * O ≥ (-2 : Int)) →
  (S + Q ≥ (8 : Int)) →
  (S + P ≥ (9 : Int)) →
  (S + H ≥ (9 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (11 : Int)) →
  (S + A ≥ (9 : Int)) →
  (S + O ≥ (10 : Int)) →
  (Q + (-1 : Int) * P ≥ (-1 : Int)) →
  (Q + (-1 : Int) * O ≥ (-2 : Int)) →
  (Q + P ≥ (9 : Int)) →
  (Q + O ≥ (10 : Int)) →
  (P + (-1 : Int) * O ≥ (-1 : Int)) →
  (P + O ≥ (11 : Int)) →
  (N + (-1 : Int) * S ≥ (-1 : Int)) →
  (N + (-1 : Int) * Q ≥ (-1 : Int)) →
  (N + (-1 : Int) * P ≥ (-2 : Int)) →
  (N + (-1 : Int) * K ≥ (-4 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * H ≥ (-2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + (-1 : Int) * B ≥ (-4 : Int)) →
  (N + (-1 : Int) * A ≥ (-2 : Int)) →
  (N + (-1 : Int) * O ≥ (-3 : Int)) →
  (N + S ≥ (7 : Int)) →
  (N + Q ≥ (7 : Int)) →
  (N + P ≥ (8 : Int)) →
  (N + L ≥ (10 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (8 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (10 : Int)) →
  (N + A ≥ (8 : Int)) →
  (N + O ≥ (9 : Int)) →
  (M + (-1 : Int) * S ≥ (0 : Int)) →
  (M + (-1 : Int) * Q ≥ (0 : Int)) →
  (M + (-1 : Int) * P ≥ (-1 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * K ≥ (-3 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * H ≥ (-1 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + (-1 : Int) * B ≥ (-3 : Int)) →
  (M + (-1 : Int) * A ≥ (-1 : Int)) →
  (M + (-1 : Int) * O ≥ (-2 : Int)) →
  (M + S ≥ (8 : Int)) →
  (M + Q ≥ (8 : Int)) →
  (M + P ≥ (9 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (11 : Int)) →
  (M + K ≥ (11 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (9 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (11 : Int)) →
  (M + A ≥ (9 : Int)) →
  (M + O ≥ (10 : Int)) →
  (L + (-1 : Int) * S ≥ (3 : Int)) →
  (L + (-1 : Int) * Q ≥ (3 : Int)) →
  (L + (-1 : Int) * P ≥ (2 : Int)) →
  (L + (-1 : Int) * J ≥ (3 : Int)) →
  (L + (-1 : Int) * I ≥ (6 : Int)) →
  (L + (-1 : Int) * H ≥ (2 : Int)) →
  (L + (-1 : Int) * G ≥ (3 : Int)) →
  (L + (-1 : Int) * B ≥ (0 : Int)) →
  (L + (-1 : Int) * A ≥ (2 : Int)) →
  (L + (-1 : Int) * O ≥ (1 : Int)) →
  (L + S ≥ (11 : Int)) →
  (L + Q ≥ (11 : Int)) →
  (L + P ≥ (12 : Int)) →
  (L + J ≥ (9 : Int)) →
  (L + I ≥ (8 : Int)) →
  (L + H ≥ (12 : Int)) →
  (L + G ≥ (11 : Int)) →
  (L + B ≥ (14 : Int)) →
  (L + A ≥ (12 : Int)) →
  (L + O ≥ (13 : Int)) →
  (K + (-1 : Int) * S ≥ (3 : Int)) →
  (K + (-1 : Int) * Q ≥ (3 : Int)) →
  (K + (-1 : Int) * P ≥ (2 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (6 : Int)) →
  (K + (-1 : Int) * H ≥ (2 : Int)) →
  (K + (-1 : Int) * G ≥ (3 : Int)) →
  (K + (-1 : Int) * B ≥ (0 : Int)) →
  (K + (-1 : Int) * A ≥ (2 : Int)) →
  (K + (-1 : Int) * O ≥ (1 : Int)) →
  (K + S ≥ (11 : Int)) →
  (K + Q ≥ (11 : Int)) →
  (K + P ≥ (12 : Int)) →
  (K + L ≥ (14 : Int)) →
  (K + J ≥ (9 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + H ≥ (12 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + B ≥ (14 : Int)) →
  (K + A ≥ (12 : Int)) →
  (K + O ≥ (13 : Int)) →
  (J + S ≥ (6 : Int)) →
  (J + Q ≥ (6 : Int)) →
  (J + P ≥ (7 : Int)) →
  (J + H ≥ (7 : Int)) →
  (J + G ≥ (6 : Int)) →
  (J + B ≥ (9 : Int)) →
  (J + A ≥ (7 : Int)) →
  (J + O ≥ (8 : Int)) →
  (I + S ≥ (5 : Int)) →
  (I + Q ≥ (5 : Int)) →
  (I + P ≥ (6 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (8 : Int)) →
  (I + A ≥ (6 : Int)) →
  (I + O ≥ (7 : Int)) →
  (H + (-1 : Int) * Q ≥ (1 : Int)) →
  (H + (-1 : Int) * P ≥ (0 : Int)) →
  (H + (-1 : Int) * O ≥ (-1 : Int)) →
  (H + Q ≥ (9 : Int)) →
  (H + P ≥ (10 : Int)) →
  (H + O ≥ (11 : Int)) →
  (G + (-1 : Int) * Q ≥ (0 : Int)) →
  (G + (-1 : Int) * P ≥ (-1 : Int)) →
  (G + (-1 : Int) * H ≥ (-1 : Int)) →
  (G + (-1 : Int) * O ≥ (-2 : Int)) →
  (G + Q ≥ (8 : Int)) →
  (G + P ≥ (9 : Int)) →
  (G + H ≥ (9 : Int)) →
  (G + O ≥ (10 : Int)) →
  (F + (-1 : Int) * S ≥ (3 : Int)) →
  (F + (-1 : Int) * Q ≥ (3 : Int)) →
  (F + (-1 : Int) * P ≥ (2 : Int)) →
  (F + (-1 : Int) * N ≥ (4 : Int)) →
  (F + (-1 : Int) * M ≥ (3 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (0 : Int)) →
  (F + (-1 : Int) * J ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (6 : Int)) →
  (F + (-1 : Int) * H ≥ (2 : Int)) →
  (F + (-1 : Int) * G ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (3 : Int)) →
  (F + (-1 : Int) * C ≥ (6 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (2 : Int)) →
  (F + (-1 : Int) * O ≥ (1 : Int)) →
  (F + S ≥ (11 : Int)) →
  (F + Q ≥ (11 : Int)) →
  (F + P ≥ (12 : Int)) →
  (F + N ≥ (10 : Int)) →
  (F + M ≥ (11 : Int)) →
  (F + L ≥ (14 : Int)) →
  (F + K ≥ (14 : Int)) →
  (F + J ≥ (9 : Int)) →
  (F + I ≥ (8 : Int)) →
  (F + H ≥ (12 : Int)) →
  (F + G ≥ (11 : Int)) →
  (F + D ≥ (11 : Int)) →
  (F + C ≥ (8 : Int)) →
  (F + B ≥ (14 : Int)) →
  (F + A ≥ (12 : Int)) →
  (F + O ≥ (13 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + S ≥ (5 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (6 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (8 : Int)) →
  (E + K ≥ (8 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (8 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (8 : Int)) →
  (E + A ≥ (6 : Int)) →
  (E + O ≥ (7 : Int)) →
  (D + (-1 : Int) * S ≥ (0 : Int)) →
  (D + (-1 : Int) * Q ≥ (0 : Int)) →
  (D + (-1 : Int) * P ≥ (-1 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * K ≥ (-3 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * H ≥ (-1 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + (-1 : Int) * B ≥ (-3 : Int)) →
  (D + (-1 : Int) * A ≥ (-1 : Int)) →
  (D + (-1 : Int) * O ≥ (-2 : Int)) →
  (D + S ≥ (8 : Int)) →
  (D + Q ≥ (8 : Int)) →
  (D + P ≥ (9 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (11 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (9 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (11 : Int)) →
  (D + A ≥ (9 : Int)) →
  (D + O ≥ (10 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + S ≥ (5 : Int)) →
  (C + Q ≥ (5 : Int)) →
  (C + P ≥ (6 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (8 : Int)) →
  (C + K ≥ (8 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (8 : Int)) →
  (C + A ≥ (6 : Int)) →
  (C + O ≥ (7 : Int)) →
  (B + (-1 : Int) * Q ≥ (3 : Int)) →
  (B + (-1 : Int) * P ≥ (2 : Int)) →
  (B + (-1 : Int) * H ≥ (2 : Int)) →
  (B + (-1 : Int) * G ≥ (3 : Int)) →
  (B + (-1 : Int) * O ≥ (1 : Int)) →
  (B + Q ≥ (11 : Int)) →
  (B + P ≥ (12 : Int)) →
  (B + H ≥ (12 : Int)) →
  (B + G ≥ (11 : Int)) →
  (B + O ≥ (13 : Int)) →
  (A + (-1 : Int) * Q ≥ (1 : Int)) →
  (A + (-1 : Int) * P ≥ (0 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (1 : Int)) →
  (A + (-1 : Int) * B ≥ (-2 : Int)) →
  (A + (-1 : Int) * O ≥ (-1 : Int)) →
  (A + Q ≥ (9 : Int)) →
  (A + P ≥ (10 : Int)) →
  (A + H ≥ (10 : Int)) →
  (A + G ≥ (9 : Int)) →
  (A + B ≥ (12 : Int)) →
  (A + O ≥ (11 : Int)) →
  (S ≥ (4 : Int)) →
  (Q ≥ (4 : Int)) →
  (P ≥ (5 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (7 : Int)) →
  (K ≥ (7 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (5 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (7 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (7 : Int)) →
  (A ≥ (5 : Int)) →
  (O ≥ (6 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + B ≥ (3 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * N + Q ≥ (1 : Int)) →
  ((-1 : Int) * N + P ≥ (2 : Int)) →
  ((-1 : Int) * N + L ≥ (4 : Int)) →
  ((-1 : Int) * N + K ≥ (4 : Int)) →
  ((-1 : Int) * N + H ≥ (2 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + B ≥ (4 : Int)) →
  ((-1 : Int) * N + A ≥ (2 : Int)) →
  ((-1 : Int) * N + O ≥ (3 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * M + Q ≥ (0 : Int)) →
  ((-1 : Int) * M + P ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (3 : Int)) →
  ((-1 : Int) * M + K ≥ (3 : Int)) →
  ((-1 : Int) * M + H ≥ (1 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + B ≥ (3 : Int)) →
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * M + O ≥ (2 : Int)) →
  ((-1 : Int) * K + L ≥ (0 : Int)) →
  ((-1 : Int) * K + B ≥ (0 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * J + Q ≥ (0 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + H ≥ (1 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + B ≥ (3 : Int)) →
  ((-1 : Int) * J + A ≥ (1 : Int)) →
  ((-1 : Int) * J + O ≥ (2 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * I + Q ≥ (3 : Int)) →
  ((-1 : Int) * I + P ≥ (4 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (4 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (6 : Int)) →
  ((-1 : Int) * I + A ≥ (4 : Int)) →
  ((-1 : Int) * I + O ≥ (5 : Int)) →
  ((-1 : Int) * G + Q ≥ (0 : Int)) →
  ((-1 : Int) * G + P ≥ (1 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * G + O ≥ (2 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * E + Q ≥ (3 : Int)) →
  ((-1 : Int) * E + P ≥ (4 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (6 : Int)) →
  ((-1 : Int) * E + K ≥ (6 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (4 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (6 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (6 : Int)) →
  ((-1 : Int) * E + A ≥ (4 : Int)) →
  ((-1 : Int) * E + O ≥ (5 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * D + Q ≥ (0 : Int)) →
  ((-1 : Int) * D + P ≥ (1 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (3 : Int)) →
  ((-1 : Int) * D + K ≥ (3 : Int)) →
  ((-1 : Int) * D + H ≥ (1 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + B ≥ (3 : Int)) →
  ((-1 : Int) * D + A ≥ (1 : Int)) →
  ((-1 : Int) * D + O ≥ (2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * C + Q ≥ (3 : Int)) →
  ((-1 : Int) * C + P ≥ (4 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (6 : Int)) →
  ((-1 : Int) * C + K ≥ (6 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (4 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (6 : Int)) →
  ((-1 : Int) * C + A ≥ (4 : Int)) →
  ((-1 : Int) * C + O ≥ (5 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (2 : Int)) →
  (S + (-1 : Int) * H ≥ (-1 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + (-1 : Int) * A ≥ (-1 : Int)) →
  (S + Q ≥ (8 : Int)) →
  (S + P ≥ (9 : Int)) →
  (S + H ≥ (9 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (11 : Int)) →
  (S + A ≥ (9 : Int)) →
  (S + O ≥ (10 : Int)) →
  (Q + P ≥ (9 : Int)) →
  (Q + O ≥ (10 : Int)) →
  (P + O ≥ (11 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + S ≥ (7 : Int)) →
  (N + Q ≥ (7 : Int)) →
  (N + P ≥ (8 : Int)) →
  (N + L ≥ (10 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (8 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (10 : Int)) →
  (N + A ≥ (8 : Int)) →
  (N + O ≥ (9 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + S ≥ (8 : Int)) →
  (M + Q ≥ (8 : Int)) →
  (M + P ≥ (9 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (11 : Int)) →
  (M + K ≥ (11 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (9 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (11 : Int)) →
  (M + A ≥ (9 : Int)) →
  (M + O ≥ (10 : Int)) →
  (L + (-1 : Int) * S ≥ (3 : Int)) →
  (L + (-1 : Int) * Q ≥ (3 : Int)) →
  (L + (-1 : Int) * P ≥ (2 : Int)) →
  (L + (-1 : Int) * J ≥ (3 : Int)) →
  (L + (-1 : Int) * I ≥ (6 : Int)) →
  (L + (-1 : Int) * H ≥ (2 : Int)) →
  (L + (-1 : Int) * G ≥ (3 : Int)) →
  (L + (-1 : Int) * B ≥ (0 : Int)) →
  (L + (-1 : Int) * A ≥ (2 : Int)) →
  (L + (-1 : Int) * O ≥ (1 : Int)) →
  (L + S ≥ (11 : Int)) →
  (L + Q ≥ (11 : Int)) →
  (L + P ≥ (12 : Int)) →
  (L + J ≥ (9 : Int)) →
  (L + I ≥ (8 : Int)) →
  (L + H ≥ (12 : Int)) →
  (L + G ≥ (11 : Int)) →
  (L + B ≥ (14 : Int)) →
  (L + A ≥ (12 : Int)) →
  (L + O ≥ (13 : Int)) →
  (K + (-1 : Int) * S ≥ (3 : Int)) →
  (K + (-1 : Int) * Q ≥ (3 : Int)) →
  (K + (-1 : Int) * P ≥ (2 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (6 : Int)) →
  (K + (-1 : Int) * H ≥ (2 : Int)) →
  (K + (-1 : Int) * G ≥ (3 : Int)) →
  (K + (-1 : Int) * B ≥ (0 : Int)) →
  (K + (-1 : Int) * A ≥ (2 : Int)) →
  (K + (-1 : Int) * O ≥ (1 : Int)) →
  (K + S ≥ (11 : Int)) →
  (K + Q ≥ (11 : Int)) →
  (K + P ≥ (12 : Int)) →
  (K + L ≥ (14 : Int)) →
  (K + J ≥ (9 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + H ≥ (12 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + B ≥ (14 : Int)) →
  (K + A ≥ (12 : Int)) →
  (K + O ≥ (13 : Int)) →
  (J + S ≥ (6 : Int)) →
  (J + Q ≥ (6 : Int)) →
  (J + P ≥ (7 : Int)) →
  (J + H ≥ (7 : Int)) →
  (J + G ≥ (6 : Int)) →
  (J + B ≥ (9 : Int)) →
  (J + A ≥ (7 : Int)) →
  (J + O ≥ (8 : Int)) →
  (I + S ≥ (5 : Int)) →
  (I + Q ≥ (5 : Int)) →
  (I + P ≥ (6 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (8 : Int)) →
  (I + A ≥ (6 : Int)) →
  (I + O ≥ (7 : Int)) →
  (H + Q ≥ (9 : Int)) →
  (H + P ≥ (10 : Int)) →
  (H + O ≥ (11 : Int)) →
  (G + Q ≥ (8 : Int)) →
  (G + P ≥ (9 : Int)) →
  (G + H ≥ (9 : Int)) →
  (G + O ≥ (10 : Int)) →
  (F + (-1 : Int) * S ≥ (3 : Int)) →
  (F + (-1 : Int) * Q ≥ (3 : Int)) →
  (F + (-1 : Int) * P ≥ (2 : Int)) →
  (F + (-1 : Int) * N ≥ (4 : Int)) →
  (F + (-1 : Int) * M ≥ (3 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (0 : Int)) →
  (F + (-1 : Int) * J ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (6 : Int)) →
  (F + (-1 : Int) * H ≥ (2 : Int)) →
  (F + (-1 : Int) * G ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (3 : Int)) →
  (F + (-1 : Int) * C ≥ (6 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (2 : Int)) →
  (F + (-1 : Int) * O ≥ (1 : Int)) →
  (F + S ≥ (11 : Int)) →
  (F + Q ≥ (11 : Int)) →
  (F + P ≥ (12 : Int)) →
  (F + N ≥ (10 : Int)) →
  (F + M ≥ (11 : Int)) →
  (F + L ≥ (14 : Int)) →
  (F + K ≥ (14 : Int)) →
  (F + J ≥ (9 : Int)) →
  (F + I ≥ (8 : Int)) →
  (F + H ≥ (12 : Int)) →
  (F + G ≥ (11 : Int)) →
  (F + D ≥ (11 : Int)) →
  (F + C ≥ (8 : Int)) →
  (F + B ≥ (14 : Int)) →
  (F + A ≥ (12 : Int)) →
  (F + O ≥ (13 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + S ≥ (5 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (6 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (8 : Int)) →
  (E + K ≥ (8 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (8 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (8 : Int)) →
  (E + A ≥ (6 : Int)) →
  (E + O ≥ (7 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + S ≥ (8 : Int)) →
  (D + Q ≥ (8 : Int)) →
  (D + P ≥ (9 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (11 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (9 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (11 : Int)) →
  (D + A ≥ (9 : Int)) →
  (D + O ≥ (10 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + S ≥ (5 : Int)) →
  (C + Q ≥ (5 : Int)) →
  (C + P ≥ (6 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (8 : Int)) →
  (C + K ≥ (8 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (8 : Int)) →
  (C + A ≥ (6 : Int)) →
  (C + O ≥ (7 : Int)) →
  (B + (-1 : Int) * Q ≥ (3 : Int)) →
  (B + (-1 : Int) * P ≥ (2 : Int)) →
  (B + (-1 : Int) * H ≥ (2 : Int)) →
  (B + (-1 : Int) * G ≥ (3 : Int)) →
  (B + (-1 : Int) * O ≥ (1 : Int)) →
  (B + Q ≥ (11 : Int)) →
  (B + P ≥ (12 : Int)) →
  (B + H ≥ (12 : Int)) →
  (B + G ≥ (11 : Int)) →
  (B + O ≥ (13 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (1 : Int)) →
  (A + Q ≥ (9 : Int)) →
  (A + P ≥ (10 : Int)) →
  (A + H ≥ (10 : Int)) →
  (A + G ≥ (9 : Int)) →
  (A + B ≥ (12 : Int)) →
  (A + O ≥ (11 : Int)) →
  (S ≥ (4 : Int)) →
  (Q ≥ (4 : Int)) →
  (P ≥ (5 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (7 : Int)) →
  (K ≥ (7 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (5 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (7 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (7 : Int)) →
  (A ≥ (5 : Int)) →
  (O ≥ (6 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * S + H ≥ (1 : Int)) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + H ≥ (2 : Int)) →
  ((-1 : Int) * S + G ≥ (0 : Int)) →
  ((-1 : Int) * S + B ≥ (3 : Int)) →
  ((-1 : Int) * S + A ≥ (2 : Int)) →
  ((-1 : Int) * S + O ≥ (2 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * N + Q ≥ (1 : Int)) →
  ((-1 : Int) * N + P ≥ (2 : Int)) →
  ((-1 : Int) * N + L ≥ (4 : Int)) →
  ((-1 : Int) * N + K ≥ (4 : Int)) →
  ((-1 : Int) * N + H ≥ (3 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + B ≥ (4 : Int)) →
  ((-1 : Int) * N + A ≥ (3 : Int)) →
  ((-1 : Int) * N + O ≥ (3 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * M + Q ≥ (0 : Int)) →
  ((-1 : Int) * M + P ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (3 : Int)) →
  ((-1 : Int) * M + K ≥ (3 : Int)) →
  ((-1 : Int) * M + H ≥ (2 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + B ≥ (3 : Int)) →
  ((-1 : Int) * M + A ≥ (2 : Int)) →
  ((-1 : Int) * M + O ≥ (2 : Int)) →
  ((-1 : Int) * K + L ≥ (0 : Int)) →
  ((-1 : Int) * K + H ≥ (-1 : Int)) →
  ((-1 : Int) * K + B ≥ (0 : Int)) →
  ((-1 : Int) * K + A ≥ (-1 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * J + Q ≥ (0 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + H ≥ (2 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + B ≥ (3 : Int)) →
  ((-1 : Int) * J + A ≥ (2 : Int)) →
  ((-1 : Int) * J + O ≥ (2 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * I + Q ≥ (3 : Int)) →
  ((-1 : Int) * I + P ≥ (4 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (5 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (6 : Int)) →
  ((-1 : Int) * I + A ≥ (5 : Int)) →
  ((-1 : Int) * I + O ≥ (5 : Int)) →
  ((-1 : Int) * G + Q ≥ (0 : Int)) →
  ((-1 : Int) * G + P ≥ (1 : Int)) →
  ((-1 : Int) * G + H ≥ (2 : Int)) →
  ((-1 : Int) * G + O ≥ (2 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * E + Q ≥ (3 : Int)) →
  ((-1 : Int) * E + P ≥ (4 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (6 : Int)) →
  ((-1 : Int) * E + K ≥ (6 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (5 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (6 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (6 : Int)) →
  ((-1 : Int) * E + A ≥ (5 : Int)) →
  ((-1 : Int) * E + O ≥ (5 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * D + Q ≥ (0 : Int)) →
  ((-1 : Int) * D + P ≥ (1 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (3 : Int)) →
  ((-1 : Int) * D + K ≥ (3 : Int)) →
  ((-1 : Int) * D + H ≥ (2 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + B ≥ (3 : Int)) →
  ((-1 : Int) * D + A ≥ (2 : Int)) →
  ((-1 : Int) * D + O ≥ (2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * C + Q ≥ (3 : Int)) →
  ((-1 : Int) * C + P ≥ (4 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (6 : Int)) →
  ((-1 : Int) * C + K ≥ (6 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (5 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (6 : Int)) →
  ((-1 : Int) * C + A ≥ (5 : Int)) →
  ((-1 : Int) * C + O ≥ (5 : Int)) →
  ((-1 : Int) * B + H ≥ (-1 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  (S + (-1 : Int) * Q ≥ (0 : Int)) →
  (S + (-1 : Int) * P ≥ (-1 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + Q ≥ (8 : Int)) →
  (S + P ≥ (9 : Int)) →
  (S + H ≥ (10 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (11 : Int)) →
  (S + A ≥ (10 : Int)) →
  (S + O ≥ (10 : Int)) →
  (Q + (-1 : Int) * P ≥ (-1 : Int)) →
  (Q + P ≥ (9 : Int)) →
  (Q + O ≥ (10 : Int)) →
  (P + O ≥ (11 : Int)) →
  (N + (-1 : Int) * S ≥ (-1 : Int)) →
  (N + (-1 : Int) * Q ≥ (-1 : Int)) →
  (N + (-1 : Int) * P ≥ (-2 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + S ≥ (7 : Int)) →
  (N + Q ≥ (7 : Int)) →
  (N + P ≥ (8 : Int)) →
  (N + L ≥ (10 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (9 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (10 : Int)) →
  (N + A ≥ (9 : Int)) →
  (N + O ≥ (9 : Int)) →
  (M + (-1 : Int) * S ≥ (0 : Int)) →
  (M + (-1 : Int) * Q ≥ (0 : Int)) →
  (M + (-1 : Int) * P ≥ (-1 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + S ≥ (8 : Int)) →
  (M + Q ≥ (8 : Int)) →
  (M + P ≥ (9 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (11 : Int)) →
  (M + K ≥ (11 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (10 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (11 : Int)) →
  (M + A ≥ (10 : Int)) →
  (M + O ≥ (10 : Int)) →
  (L + (-1 : Int) * S ≥ (3 : Int)) →
  (L + (-1 : Int) * Q ≥ (3 : Int)) →
  (L + (-1 : Int) * P ≥ (2 : Int)) →
  (L + (-1 : Int) * J ≥ (3 : Int)) →
  (L + (-1 : Int) * I ≥ (6 : Int)) →
  (L + (-1 : Int) * H ≥ (1 : Int)) →
  (L + (-1 : Int) * G ≥ (3 : Int)) →
  (L + (-1 : Int) * B ≥ (0 : Int)) →
  (L + (-1 : Int) * A ≥ (1 : Int)) →
  (L + (-1 : Int) * O ≥ (1 : Int)) →
  (L + S ≥ (11 : Int)) →
  (L + Q ≥ (11 : Int)) →
  (L + P ≥ (12 : Int)) →
  (L + J ≥ (9 : Int)) →
  (L + I ≥ (8 : Int)) →
  (L + H ≥ (13 : Int)) →
  (L + G ≥ (11 : Int)) →
  (L + B ≥ (14 : Int)) →
  (L + A ≥ (13 : Int)) →
  (L + O ≥ (13 : Int)) →
  (K + (-1 : Int) * S ≥ (3 : Int)) →
  (K + (-1 : Int) * Q ≥ (3 : Int)) →
  (K + (-1 : Int) * P ≥ (2 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (6 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * G ≥ (3 : Int)) →
  (K + (-1 : Int) * B ≥ (0 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + (-1 : Int) * O ≥ (1 : Int)) →
  (K + S ≥ (11 : Int)) →
  (K + Q ≥ (11 : Int)) →
  (K + P ≥ (12 : Int)) →
  (K + L ≥ (14 : Int)) →
  (K + J ≥ (9 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + H ≥ (13 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + B ≥ (14 : Int)) →
  (K + A ≥ (13 : Int)) →
  (K + O ≥ (13 : Int)) →
  (J + S ≥ (6 : Int)) →
  (J + Q ≥ (6 : Int)) →
  (J + P ≥ (7 : Int)) →
  (J + H ≥ (8 : Int)) →
  (J + G ≥ (6 : Int)) →
  (J + B ≥ (9 : Int)) →
  (J + A ≥ (8 : Int)) →
  (J + O ≥ (8 : Int)) →
  (I + S ≥ (5 : Int)) →
  (I + Q ≥ (5 : Int)) →
  (I + P ≥ (6 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + H ≥ (7 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (8 : Int)) →
  (I + A ≥ (7 : Int)) →
  (I + O ≥ (7 : Int)) →
  (H + (-1 : Int) * Q ≥ (2 : Int)) →
  (H + (-1 : Int) * P ≥ (1 : Int)) →
  (H + (-1 : Int) * O ≥ (0 : Int)) →
  (H + Q ≥ (10 : Int)) →
  (H + P ≥ (11 : Int)) →
  (H + O ≥ (12 : Int)) →
  (G + (-1 : Int) * Q ≥ (0 : Int)) →
  (G + (-1 : Int) * P ≥ (-1 : Int)) →
  (G + Q ≥ (8 : Int)) →
  (G + P ≥ (9 : Int)) →
  (G + H ≥ (10 : Int)) →
  (G + O ≥ (10 : Int)) →
  (F + (-1 : Int) * S ≥ (3 : Int)) →
  (F + (-1 : Int) * Q ≥ (3 : Int)) →
  (F + (-1 : Int) * P ≥ (2 : Int)) →
  (F + (-1 : Int) * N ≥ (4 : Int)) →
  (F + (-1 : Int) * M ≥ (3 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (0 : Int)) →
  (F + (-1 : Int) * J ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (6 : Int)) →
  (F + (-1 : Int) * H ≥ (1 : Int)) →
  (F + (-1 : Int) * G ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (3 : Int)) →
  (F + (-1 : Int) * C ≥ (6 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (1 : Int)) →
  (F + (-1 : Int) * O ≥ (1 : Int)) →
  (F + S ≥ (11 : Int)) →
  (F + Q ≥ (11 : Int)) →
  (F + P ≥ (12 : Int)) →
  (F + N ≥ (10 : Int)) →
  (F + M ≥ (11 : Int)) →
  (F + L ≥ (14 : Int)) →
  (F + K ≥ (14 : Int)) →
  (F + J ≥ (9 : Int)) →
  (F + I ≥ (8 : Int)) →
  (F + H ≥ (13 : Int)) →
  (F + G ≥ (11 : Int)) →
  (F + D ≥ (11 : Int)) →
  (F + C ≥ (8 : Int)) →
  (F + B ≥ (14 : Int)) →
  (F + A ≥ (13 : Int)) →
  (F + O ≥ (13 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + S ≥ (5 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (6 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (8 : Int)) →
  (E + K ≥ (8 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (7 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (8 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (8 : Int)) →
  (E + A ≥ (7 : Int)) →
  (E + O ≥ (7 : Int)) →
  (D + (-1 : Int) * S ≥ (0 : Int)) →
  (D + (-1 : Int) * Q ≥ (0 : Int)) →
  (D + (-1 : Int) * P ≥ (-1 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + S ≥ (8 : Int)) →
  (D + Q ≥ (8 : Int)) →
  (D + P ≥ (9 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (11 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (10 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (11 : Int)) →
  (D + A ≥ (10 : Int)) →
  (D + O ≥ (10 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + S ≥ (5 : Int)) →
  (C + Q ≥ (5 : Int)) →
  (C + P ≥ (6 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (8 : Int)) →
  (C + K ≥ (8 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (7 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (8 : Int)) →
  (C + A ≥ (7 : Int)) →
  (C + O ≥ (7 : Int)) →
  (B + (-1 : Int) * Q ≥ (3 : Int)) →
  (B + (-1 : Int) * P ≥ (2 : Int)) →
  (B + (-1 : Int) * H ≥ (1 : Int)) →
  (B + (-1 : Int) * G ≥ (3 : Int)) →
  (B + (-1 : Int) * O ≥ (1 : Int)) →
  (B + Q ≥ (11 : Int)) →
  (B + P ≥ (12 : Int)) →
  (B + H ≥ (13 : Int)) →
  (B + G ≥ (11 : Int)) →
  (B + O ≥ (13 : Int)) →
  (A + (-1 : Int) * Q ≥ (2 : Int)) →
  (A + (-1 : Int) * P ≥ (1 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (-1 : Int)) →
  (A + (-1 : Int) * O ≥ (0 : Int)) →
  (A + Q ≥ (10 : Int)) →
  (A + P ≥ (11 : Int)) →
  (A + H ≥ (12 : Int)) →
  (A + G ≥ (10 : Int)) →
  (A + B ≥ (13 : Int)) →
  (A + O ≥ (12 : Int)) →
  (S ≥ (4 : Int)) →
  (Q ≥ (4 : Int)) →
  (P ≥ (5 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (7 : Int)) →
  (K ≥ (7 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (6 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (7 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (7 : Int)) →
  (A ≥ (6 : Int)) →
  (O ≥ (6 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + H ≥ (3 : Int)) →
  ((-1 : Int) * S + G ≥ (0 : Int)) →
  ((-1 : Int) * S + B ≥ (4 : Int)) →
  ((-1 : Int) * S + A ≥ (3 : Int)) →
  ((-1 : Int) * S + O ≥ (2 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * N + Q ≥ (1 : Int)) →
  ((-1 : Int) * N + P ≥ (2 : Int)) →
  ((-1 : Int) * N + L ≥ (5 : Int)) →
  ((-1 : Int) * N + K ≥ (5 : Int)) →
  ((-1 : Int) * N + H ≥ (4 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + B ≥ (5 : Int)) →
  ((-1 : Int) * N + A ≥ (4 : Int)) →
  ((-1 : Int) * N + O ≥ (3 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * M + Q ≥ (0 : Int)) →
  ((-1 : Int) * M + P ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (4 : Int)) →
  ((-1 : Int) * M + K ≥ (4 : Int)) →
  ((-1 : Int) * M + H ≥ (3 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + B ≥ (4 : Int)) →
  ((-1 : Int) * M + A ≥ (3 : Int)) →
  ((-1 : Int) * M + O ≥ (2 : Int)) →
  ((-1 : Int) * K + L ≥ (0 : Int)) →
  ((-1 : Int) * K + H ≥ (-1 : Int)) →
  ((-1 : Int) * K + B ≥ (0 : Int)) →
  ((-1 : Int) * K + A ≥ (-1 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * J + Q ≥ (0 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + H ≥ (3 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + B ≥ (4 : Int)) →
  ((-1 : Int) * J + A ≥ (3 : Int)) →
  ((-1 : Int) * J + O ≥ (2 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * I + Q ≥ (3 : Int)) →
  ((-1 : Int) * I + P ≥ (4 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (6 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (7 : Int)) →
  ((-1 : Int) * I + A ≥ (6 : Int)) →
  ((-1 : Int) * I + O ≥ (5 : Int)) →
  ((-1 : Int) * G + Q ≥ (0 : Int)) →
  ((-1 : Int) * G + P ≥ (1 : Int)) →
  ((-1 : Int) * G + H ≥ (3 : Int)) →
  ((-1 : Int) * G + O ≥ (2 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * E + Q ≥ (3 : Int)) →
  ((-1 : Int) * E + P ≥ (4 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (7 : Int)) →
  ((-1 : Int) * E + K ≥ (7 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (6 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (7 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (7 : Int)) →
  ((-1 : Int) * E + A ≥ (6 : Int)) →
  ((-1 : Int) * E + O ≥ (5 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * D + Q ≥ (0 : Int)) →
  ((-1 : Int) * D + P ≥ (1 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (4 : Int)) →
  ((-1 : Int) * D + K ≥ (4 : Int)) →
  ((-1 : Int) * D + H ≥ (3 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + B ≥ (4 : Int)) →
  ((-1 : Int) * D + A ≥ (3 : Int)) →
  ((-1 : Int) * D + O ≥ (2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * C + Q ≥ (3 : Int)) →
  ((-1 : Int) * C + P ≥ (4 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (7 : Int)) →
  ((-1 : Int) * C + K ≥ (7 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (6 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (7 : Int)) →
  ((-1 : Int) * C + A ≥ (6 : Int)) →
  ((-1 : Int) * C + O ≥ (5 : Int)) →
  ((-1 : Int) * B + H ≥ (-1 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + Q ≥ (8 : Int)) →
  (S + P ≥ (9 : Int)) →
  (S + H ≥ (11 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (12 : Int)) →
  (S + A ≥ (11 : Int)) →
  (S + O ≥ (10 : Int)) →
  (Q + P ≥ (9 : Int)) →
  (Q + O ≥ (10 : Int)) →
  (P + O ≥ (11 : Int)) →
  (N + (-1 : Int) * S ≥ (-1 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + S ≥ (7 : Int)) →
  (N + Q ≥ (7 : Int)) →
  (N + P ≥ (8 : Int)) →
  (N + L ≥ (11 : Int)) →
  (N + K ≥ (11 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (10 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (11 : Int)) →
  (N + A ≥ (10 : Int)) →
  (N + O ≥ (9 : Int)) →
  (M + (-1 : Int) * S ≥ (0 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + S ≥ (8 : Int)) →
  (M + Q ≥ (8 : Int)) →
  (M + P ≥ (9 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (12 : Int)) →
  (M + K ≥ (12 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (11 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (12 : Int)) →
  (M + A ≥ (11 : Int)) →
  (M + O ≥ (10 : Int)) →
  (L + (-1 : Int) * S ≥ (4 : Int)) →
  (L + (-1 : Int) * Q ≥ (3 : Int)) →
  (L + (-1 : Int) * P ≥ (2 : Int)) →
  (L + (-1 : Int) * J ≥ (4 : Int)) →
  (L + (-1 : Int) * I ≥ (7 : Int)) →
  (L + (-1 : Int) * H ≥ (1 : Int)) →
  (L + (-1 : Int) * G ≥ (4 : Int)) →
  (L + (-1 : Int) * B ≥ (0 : Int)) →
  (L + (-1 : Int) * A ≥ (1 : Int)) →
  (L + (-1 : Int) * O ≥ (1 : Int)) →
  (L + S ≥ (12 : Int)) →
  (L + Q ≥ (12 : Int)) →
  (L + P ≥ (13 : Int)) →
  (L + J ≥ (10 : Int)) →
  (L + I ≥ (9 : Int)) →
  (L + H ≥ (15 : Int)) →
  (L + G ≥ (12 : Int)) →
  (L + B ≥ (16 : Int)) →
  (L + A ≥ (15 : Int)) →
  (L + O ≥ (14 : Int)) →
  (K + (-1 : Int) * S ≥ (4 : Int)) →
  (K + (-1 : Int) * Q ≥ (3 : Int)) →
  (K + (-1 : Int) * P ≥ (2 : Int)) →
  (K + (-1 : Int) * J ≥ (4 : Int)) →
  (K + (-1 : Int) * I ≥ (7 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * G ≥ (4 : Int)) →
  (K + (-1 : Int) * B ≥ (0 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + (-1 : Int) * O ≥ (1 : Int)) →
  (K + S ≥ (12 : Int)) →
  (K + Q ≥ (12 : Int)) →
  (K + P ≥ (13 : Int)) →
  (K + L ≥ (16 : Int)) →
  (K + J ≥ (10 : Int)) →
  (K + I ≥ (9 : Int)) →
  (K + H ≥ (15 : Int)) →
  (K + G ≥ (12 : Int)) →
  (K + B ≥ (16 : Int)) →
  (K + A ≥ (15 : Int)) →
  (K + O ≥ (14 : Int)) →
  (J + S ≥ (6 : Int)) →
  (J + Q ≥ (6 : Int)) →
  (J + P ≥ (7 : Int)) →
  (J + H ≥ (9 : Int)) →
  (J + G ≥ (6 : Int)) →
  (J + B ≥ (10 : Int)) →
  (J + A ≥ (9 : Int)) →
  (J + O ≥ (8 : Int)) →
  (I + S ≥ (5 : Int)) →
  (I + Q ≥ (5 : Int)) →
  (I + P ≥ (6 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + H ≥ (8 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (9 : Int)) →
  (I + A ≥ (8 : Int)) →
  (I + O ≥ (7 : Int)) →
  (H + (-1 : Int) * Q ≥ (2 : Int)) →
  (H + (-1 : Int) * P ≥ (1 : Int)) →
  (H + (-1 : Int) * O ≥ (0 : Int)) →
  (H + Q ≥ (11 : Int)) →
  (H + P ≥ (12 : Int)) →
  (H + O ≥ (13 : Int)) →
  (G + Q ≥ (8 : Int)) →
  (G + P ≥ (9 : Int)) →
  (G + H ≥ (11 : Int)) →
  (G + O ≥ (10 : Int)) →
  (F + (-1 : Int) * S ≥ (4 : Int)) →
  (F + (-1 : Int) * Q ≥ (3 : Int)) →
  (F + (-1 : Int) * P ≥ (2 : Int)) →
  (F + (-1 : Int) * N ≥ (5 : Int)) →
  (F + (-1 : Int) * M ≥ (4 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (0 : Int)) →
  (F + (-1 : Int) * J ≥ (4 : Int)) →
  (F + (-1 : Int) * I ≥ (7 : Int)) →
  (F + (-1 : Int) * H ≥ (1 : Int)) →
  (F + (-1 : Int) * G ≥ (4 : Int)) →
  (F + (-1 : Int) * D ≥ (4 : Int)) →
  (F + (-1 : Int) * C ≥ (7 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (1 : Int)) →
  (F + (-1 : Int) * O ≥ (1 : Int)) →
  (F + S ≥ (12 : Int)) →
  (F + Q ≥ (12 : Int)) →
  (F + P ≥ (13 : Int)) →
  (F + N ≥ (11 : Int)) →
  (F + M ≥ (12 : Int)) →
  (F + L ≥ (16 : Int)) →
  (F + K ≥ (16 : Int)) →
  (F + J ≥ (10 : Int)) →
  (F + I ≥ (9 : Int)) →
  (F + H ≥ (15 : Int)) →
  (F + G ≥ (12 : Int)) →
  (F + D ≥ (12 : Int)) →
  (F + C ≥ (9 : Int)) →
  (F + B ≥ (16 : Int)) →
  (F + A ≥ (15 : Int)) →
  (F + O ≥ (14 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + S ≥ (5 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (6 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (9 : Int)) →
  (E + K ≥ (9 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (8 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (9 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (9 : Int)) →
  (E + A ≥ (8 : Int)) →
  (E + O ≥ (7 : Int)) →
  (D + (-1 : Int) * S ≥ (0 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + S ≥ (8 : Int)) →
  (D + Q ≥ (8 : Int)) →
  (D + P ≥ (9 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (12 : Int)) →
  (D + K ≥ (12 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (11 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (12 : Int)) →
  (D + A ≥ (11 : Int)) →
  (D + O ≥ (10 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + S ≥ (5 : Int)) →
  (C + Q ≥ (5 : Int)) →
  (C + P ≥ (6 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (9 : Int)) →
  (C + K ≥ (9 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (8 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (9 : Int)) →
  (C + A ≥ (8 : Int)) →
  (C + O ≥ (7 : Int)) →
  (B + (-1 : Int) * Q ≥ (3 : Int)) →
  (B + (-1 : Int) * P ≥ (2 : Int)) →
  (B + (-1 : Int) * H ≥ (1 : Int)) →
  (B + (-1 : Int) * G ≥ (4 : Int)) →
  (B + (-1 : Int) * O ≥ (1 : Int)) →
  (B + Q ≥ (12 : Int)) →
  (B + P ≥ (13 : Int)) →
  (B + H ≥ (15 : Int)) →
  (B + G ≥ (12 : Int)) →
  (B + O ≥ (14 : Int)) →
  (A + (-1 : Int) * Q ≥ (2 : Int)) →
  (A + (-1 : Int) * P ≥ (1 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (3 : Int)) →
  (A + (-1 : Int) * B ≥ (-1 : Int)) →
  (A + (-1 : Int) * O ≥ (0 : Int)) →
  (A + Q ≥ (11 : Int)) →
  (A + P ≥ (12 : Int)) →
  (A + H ≥ (14 : Int)) →
  (A + G ≥ (11 : Int)) →
  (A + B ≥ (15 : Int)) →
  (A + O ≥ (13 : Int)) →
  (S ≥ (4 : Int)) →
  (Q ≥ (4 : Int)) →
  (P ≥ (5 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (8 : Int)) →
  (K ≥ (8 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (7 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (8 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (8 : Int)) →
  (A ≥ (7 : Int)) →
  (O ≥ (6 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + B ≥ (2 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (3 : Int)) →
  ((-1 : Int) * N + K ≥ (3 : Int)) →
  ((-1 : Int) * N + J ≥ (1 : Int)) →
  ((-1 : Int) * N + H ≥ (2 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + B ≥ (3 : Int)) →
  ((-1 : Int) * N + A ≥ (2 : Int)) →
  ((-1 : Int) * N + O ≥ (1 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (2 : Int)) →
  ((-1 : Int) * M + K ≥ (2 : Int)) →
  ((-1 : Int) * M + J ≥ (0 : Int)) →
  ((-1 : Int) * M + H ≥ (1 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + B ≥ (2 : Int)) →
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * M + O ≥ (0 : Int)) →
  ((-1 : Int) * K + L ≥ (0 : Int)) →
  ((-1 : Int) * K + B ≥ (0 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * J + H ≥ (1 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + B ≥ (2 : Int)) →
  ((-1 : Int) * J + A ≥ (1 : Int)) →
  ((-1 : Int) * J + O ≥ (0 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (3 : Int)) →
  ((-1 : Int) * I + H ≥ (4 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (5 : Int)) →
  ((-1 : Int) * I + A ≥ (4 : Int)) →
  ((-1 : Int) * I + O ≥ (3 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * G + O ≥ (0 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (1 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (5 : Int)) →
  ((-1 : Int) * E + K ≥ (5 : Int)) →
  ((-1 : Int) * E + J ≥ (3 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (4 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (5 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (5 : Int)) →
  ((-1 : Int) * E + A ≥ (4 : Int)) →
  ((-1 : Int) * E + O ≥ (3 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (2 : Int)) →
  ((-1 : Int) * D + K ≥ (2 : Int)) →
  ((-1 : Int) * D + J ≥ (0 : Int)) →
  ((-1 : Int) * D + H ≥ (1 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + B ≥ (2 : Int)) →
  ((-1 : Int) * D + A ≥ (1 : Int)) →
  ((-1 : Int) * D + O ≥ (0 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (5 : Int)) →
  ((-1 : Int) * C + K ≥ (5 : Int)) →
  ((-1 : Int) * C + J ≥ (3 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (4 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (5 : Int)) →
  ((-1 : Int) * C + A ≥ (4 : Int)) →
  ((-1 : Int) * C + O ≥ (3 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  (S + (-1 : Int) * Q ≥ (2 : Int)) →
  (S + (-1 : Int) * P ≥ (1 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + (-1 : Int) * O ≥ (0 : Int)) →
  (S + Q ≥ (5 : Int)) →
  (S + P ≥ (6 : Int)) →
  (S + H ≥ (9 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (10 : Int)) →
  (S + A ≥ (9 : Int)) →
  (S + O ≥ (8 : Int)) →
  (Q + P ≥ (3 : Int)) →
  (Q + O ≥ (5 : Int)) →
  (P + O ≥ (6 : Int)) →
  (N + (-1 : Int) * Q ≥ (1 : Int)) →
  (N + (-1 : Int) * P ≥ (0 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + (-1 : Int) * O ≥ (-1 : Int)) →
  (N + S ≥ (7 : Int)) →
  (N + Q ≥ (4 : Int)) →
  (N + P ≥ (5 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (9 : Int)) →
  (N + J ≥ (7 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (8 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (9 : Int)) →
  (N + A ≥ (8 : Int)) →
  (N + O ≥ (7 : Int)) →
  (M + (-1 : Int) * Q ≥ (2 : Int)) →
  (M + (-1 : Int) * P ≥ (1 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + (-1 : Int) * O ≥ (0 : Int)) →
  (M + S ≥ (8 : Int)) →
  (M + Q ≥ (5 : Int)) →
  (M + P ≥ (6 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (10 : Int)) →
  (M + K ≥ (10 : Int)) →
  (M + J ≥ (8 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (9 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (10 : Int)) →
  (M + A ≥ (9 : Int)) →
  (M + O ≥ (8 : Int)) →
  (L + (-1 : Int) * S ≥ (2 : Int)) →
  (L + (-1 : Int) * Q ≥ (4 : Int)) →
  (L + (-1 : Int) * P ≥ (3 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (5 : Int)) →
  (L + (-1 : Int) * H ≥ (1 : Int)) →
  (L + (-1 : Int) * G ≥ (2 : Int)) →
  (L + (-1 : Int) * B ≥ (0 : Int)) →
  (L + (-1 : Int) * A ≥ (1 : Int)) →
  (L + (-1 : Int) * O ≥ (2 : Int)) →
  (L + S ≥ (10 : Int)) →
  (L + Q ≥ (7 : Int)) →
  (L + P ≥ (8 : Int)) →
  (L + J ≥ (10 : Int)) →
  (L + I ≥ (7 : Int)) →
  (L + H ≥ (11 : Int)) →
  (L + G ≥ (10 : Int)) →
  (L + B ≥ (12 : Int)) →
  (L + A ≥ (11 : Int)) →
  (L + O ≥ (10 : Int)) →
  (K + (-1 : Int) * S ≥ (2 : Int)) →
  (K + (-1 : Int) * Q ≥ (4 : Int)) →
  (K + (-1 : Int) * P ≥ (3 : Int)) →
  (K + (-1 : Int) * J ≥ (2 : Int)) →
  (K + (-1 : Int) * I ≥ (5 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * G ≥ (2 : Int)) →
  (K + (-1 : Int) * B ≥ (0 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + (-1 : Int) * O ≥ (2 : Int)) →
  (K + S ≥ (10 : Int)) →
  (K + Q ≥ (7 : Int)) →
  (K + P ≥ (8 : Int)) →
  (K + L ≥ (12 : Int)) →
  (K + J ≥ (10 : Int)) →
  (K + I ≥ (7 : Int)) →
  (K + H ≥ (11 : Int)) →
  (K + G ≥ (10 : Int)) →
  (K + B ≥ (12 : Int)) →
  (K + A ≥ (11 : Int)) →
  (K + O ≥ (10 : Int)) →
  (J + (-1 : Int) * Q ≥ (2 : Int)) →
  (J + (-1 : Int) * P ≥ (1 : Int)) →
  (J + (-1 : Int) * G ≥ (0 : Int)) →
  (J + (-1 : Int) * O ≥ (0 : Int)) →
  (J + S ≥ (8 : Int)) →
  (J + Q ≥ (5 : Int)) →
  (J + P ≥ (6 : Int)) →
  (J + H ≥ (9 : Int)) →
  (J + G ≥ (8 : Int)) →
  (J + B ≥ (10 : Int)) →
  (J + A ≥ (9 : Int)) →
  (J + O ≥ (8 : Int)) →
  (I + S ≥ (5 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (3 : Int)) →
  (I + J ≥ (5 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (7 : Int)) →
  (I + A ≥ (6 : Int)) →
  (I + O ≥ (5 : Int)) →
  (H + (-1 : Int) * Q ≥ (3 : Int)) →
  (H + (-1 : Int) * P ≥ (2 : Int)) →
  (H + (-1 : Int) * O ≥ (1 : Int)) →
  (H + Q ≥ (6 : Int)) →
  (H + P ≥ (7 : Int)) →
  (H + O ≥ (9 : Int)) →
  (G + (-1 : Int) * Q ≥ (2 : Int)) →
  (G + (-1 : Int) * P ≥ (1 : Int)) →
  (G + (-1 : Int) * O ≥ (0 : Int)) →
  (G + Q ≥ (5 : Int)) →
  (G + P ≥ (6 : Int)) →
  (G + H ≥ (9 : Int)) →
  (G + O ≥ (8 : Int)) →
  (F + (-1 : Int) * S ≥ (2 : Int)) →
  (F + (-1 : Int) * Q ≥ (4 : Int)) →
  (F + (-1 : Int) * P ≥ (3 : Int)) →
  (F + (-1 : Int) * N ≥ (3 : Int)) →
  (F + (-1 : Int) * M ≥ (2 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (0 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (5 : Int)) →
  (F + (-1 : Int) * H ≥ (1 : Int)) →
  (F + (-1 : Int) * G ≥ (2 : Int)) →
  (F + (-1 : Int) * D ≥ (2 : Int)) →
  (F + (-1 : Int) * C ≥ (5 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (1 : Int)) →
  (F + (-1 : Int) * O ≥ (2 : Int)) →
  (F + S ≥ (10 : Int)) →
  (F + Q ≥ (7 : Int)) →
  (F + P ≥ (8 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (10 : Int)) →
  (F + L ≥ (12 : Int)) →
  (F + K ≥ (12 : Int)) →
  (F + J ≥ (10 : Int)) →
  (F + I ≥ (7 : Int)) →
  (F + H ≥ (11 : Int)) →
  (F + G ≥ (10 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (7 : Int)) →
  (F + B ≥ (12 : Int)) →
  (F + A ≥ (11 : Int)) →
  (F + O ≥ (10 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + S ≥ (5 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (7 : Int)) →
  (E + K ≥ (7 : Int)) →
  (E + J ≥ (5 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (7 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (7 : Int)) →
  (E + A ≥ (6 : Int)) →
  (E + O ≥ (5 : Int)) →
  (D + (-1 : Int) * Q ≥ (2 : Int)) →
  (D + (-1 : Int) * P ≥ (1 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + (-1 : Int) * O ≥ (0 : Int)) →
  (D + S ≥ (8 : Int)) →
  (D + Q ≥ (5 : Int)) →
  (D + P ≥ (6 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (10 : Int)) →
  (D + J ≥ (8 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (9 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (10 : Int)) →
  (D + A ≥ (9 : Int)) →
  (D + O ≥ (8 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + S ≥ (5 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (7 : Int)) →
  (C + K ≥ (7 : Int)) →
  (C + J ≥ (5 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (7 : Int)) →
  (C + A ≥ (6 : Int)) →
  (C + O ≥ (5 : Int)) →
  (B + (-1 : Int) * Q ≥ (4 : Int)) →
  (B + (-1 : Int) * P ≥ (3 : Int)) →
  (B + (-1 : Int) * H ≥ (1 : Int)) →
  (B + (-1 : Int) * G ≥ (2 : Int)) →
  (B + (-1 : Int) * O ≥ (2 : Int)) →
  (B + Q ≥ (7 : Int)) →
  (B + P ≥ (8 : Int)) →
  (B + H ≥ (11 : Int)) →
  (B + G ≥ (10 : Int)) →
  (B + O ≥ (10 : Int)) →
  (A + (-1 : Int) * Q ≥ (3 : Int)) →
  (A + (-1 : Int) * P ≥ (2 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (1 : Int)) →
  (A + (-1 : Int) * O ≥ (1 : Int)) →
  (A + Q ≥ (6 : Int)) →
  (A + P ≥ (7 : Int)) →
  (A + H ≥ (10 : Int)) →
  (A + G ≥ (9 : Int)) →
  (A + B ≥ (11 : Int)) →
  (A + O ≥ (9 : Int)) →
  (S ≥ (4 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (2 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (6 : Int)) →
  (K ≥ (6 : Int)) →
  (J ≥ (4 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (5 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (6 : Int)) →
  (A ≥ (5 : Int)) →
  (O ≥ (4 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * S + H ≥ (1 : Int)) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + B ≥ (2 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (3 : Int)) →
  ((-1 : Int) * N + K ≥ (3 : Int)) →
  ((-1 : Int) * N + H ≥ (2 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + B ≥ (3 : Int)) →
  ((-1 : Int) * N + A ≥ (2 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (2 : Int)) →
  ((-1 : Int) * M + K ≥ (2 : Int)) →
  ((-1 : Int) * M + H ≥ (1 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + B ≥ (2 : Int)) →
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * K + L ≥ (0 : Int)) →
  ((-1 : Int) * K + B ≥ (0 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * J + H ≥ (1 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + B ≥ (2 : Int)) →
  ((-1 : Int) * J + A ≥ (1 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (4 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (5 : Int)) →
  ((-1 : Int) * I + A ≥ (4 : Int)) →
  ((-1 : Int) * I + O ≥ (2 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (1 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (5 : Int)) →
  ((-1 : Int) * E + K ≥ (5 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (4 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (5 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (5 : Int)) →
  ((-1 : Int) * E + A ≥ (4 : Int)) →
  ((-1 : Int) * E + O ≥ (2 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (2 : Int)) →
  ((-1 : Int) * D + K ≥ (2 : Int)) →
  ((-1 : Int) * D + H ≥ (1 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + B ≥ (2 : Int)) →
  ((-1 : Int) * D + A ≥ (1 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (5 : Int)) →
  ((-1 : Int) * C + K ≥ (5 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (4 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (5 : Int)) →
  ((-1 : Int) * C + A ≥ (4 : Int)) →
  ((-1 : Int) * C + O ≥ (2 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  (S + (-1 : Int) * Q ≥ (3 : Int)) →
  (S + (-1 : Int) * P ≥ (2 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + (-1 : Int) * O ≥ (1 : Int)) →
  (S + Q ≥ (5 : Int)) →
  (S + P ≥ (6 : Int)) →
  (S + H ≥ (9 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (10 : Int)) →
  (S + A ≥ (9 : Int)) →
  (S + O ≥ (7 : Int)) →
  (Q + P ≥ (3 : Int)) →
  (Q + O ≥ (4 : Int)) →
  (P + O ≥ (5 : Int)) →
  (N + (-1 : Int) * Q ≥ (2 : Int)) →
  (N + (-1 : Int) * P ≥ (1 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + (-1 : Int) * O ≥ (0 : Int)) →
  (N + S ≥ (7 : Int)) →
  (N + Q ≥ (4 : Int)) →
  (N + P ≥ (5 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (9 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (8 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (9 : Int)) →
  (N + A ≥ (8 : Int)) →
  (N + O ≥ (6 : Int)) →
  (M + (-1 : Int) * Q ≥ (3 : Int)) →
  (M + (-1 : Int) * P ≥ (2 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + (-1 : Int) * O ≥ (1 : Int)) →
  (M + S ≥ (8 : Int)) →
  (M + Q ≥ (5 : Int)) →
  (M + P ≥ (6 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (10 : Int)) →
  (M + K ≥ (10 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (9 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (10 : Int)) →
  (M + A ≥ (9 : Int)) →
  (M + O ≥ (7 : Int)) →
  (L + (-1 : Int) * S ≥ (2 : Int)) →
  (L + (-1 : Int) * Q ≥ (5 : Int)) →
  (L + (-1 : Int) * P ≥ (4 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (5 : Int)) →
  (L + (-1 : Int) * H ≥ (1 : Int)) →
  (L + (-1 : Int) * G ≥ (2 : Int)) →
  (L + (-1 : Int) * B ≥ (0 : Int)) →
  (L + (-1 : Int) * A ≥ (1 : Int)) →
  (L + (-1 : Int) * O ≥ (3 : Int)) →
  (L + S ≥ (10 : Int)) →
  (L + Q ≥ (7 : Int)) →
  (L + P ≥ (8 : Int)) →
  (L + J ≥ (8 : Int)) →
  (L + I ≥ (7 : Int)) →
  (L + H ≥ (11 : Int)) →
  (L + G ≥ (10 : Int)) →
  (L + B ≥ (12 : Int)) →
  (L + A ≥ (11 : Int)) →
  (L + O ≥ (9 : Int)) →
  (K + (-1 : Int) * S ≥ (2 : Int)) →
  (K + (-1 : Int) * Q ≥ (5 : Int)) →
  (K + (-1 : Int) * P ≥ (4 : Int)) →
  (K + (-1 : Int) * J ≥ (2 : Int)) →
  (K + (-1 : Int) * I ≥ (5 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * G ≥ (2 : Int)) →
  (K + (-1 : Int) * B ≥ (0 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + (-1 : Int) * O ≥ (3 : Int)) →
  (K + S ≥ (10 : Int)) →
  (K + Q ≥ (7 : Int)) →
  (K + P ≥ (8 : Int)) →
  (K + L ≥ (12 : Int)) →
  (K + J ≥ (8 : Int)) →
  (K + I ≥ (7 : Int)) →
  (K + H ≥ (11 : Int)) →
  (K + G ≥ (10 : Int)) →
  (K + B ≥ (12 : Int)) →
  (K + A ≥ (11 : Int)) →
  (K + O ≥ (9 : Int)) →
  (J + S ≥ (6 : Int)) →
  (J + Q ≥ (3 : Int)) →
  (J + P ≥ (4 : Int)) →
  (J + H ≥ (7 : Int)) →
  (J + G ≥ (6 : Int)) →
  (J + B ≥ (8 : Int)) →
  (J + A ≥ (7 : Int)) →
  (J + O ≥ (5 : Int)) →
  (I + S ≥ (5 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (3 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (7 : Int)) →
  (I + A ≥ (6 : Int)) →
  (I + O ≥ (4 : Int)) →
  (H + (-1 : Int) * Q ≥ (4 : Int)) →
  (H + (-1 : Int) * P ≥ (3 : Int)) →
  (H + (-1 : Int) * O ≥ (2 : Int)) →
  (H + Q ≥ (6 : Int)) →
  (H + P ≥ (7 : Int)) →
  (H + O ≥ (8 : Int)) →
  (G + (-1 : Int) * Q ≥ (3 : Int)) →
  (G + (-1 : Int) * P ≥ (2 : Int)) →
  (G + (-1 : Int) * O ≥ (1 : Int)) →
  (G + Q ≥ (5 : Int)) →
  (G + P ≥ (6 : Int)) →
  (G + H ≥ (9 : Int)) →
  (G + O ≥ (7 : Int)) →
  (F + (-1 : Int) * S ≥ (2 : Int)) →
  (F + (-1 : Int) * Q ≥ (5 : Int)) →
  (F + (-1 : Int) * P ≥ (4 : Int)) →
  (F + (-1 : Int) * N ≥ (3 : Int)) →
  (F + (-1 : Int) * M ≥ (2 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (0 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (5 : Int)) →
  (F + (-1 : Int) * H ≥ (1 : Int)) →
  (F + (-1 : Int) * G ≥ (2 : Int)) →
  (F + (-1 : Int) * D ≥ (2 : Int)) →
  (F + (-1 : Int) * C ≥ (5 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (1 : Int)) →
  (F + (-1 : Int) * O ≥ (3 : Int)) →
  (F + S ≥ (10 : Int)) →
  (F + Q ≥ (7 : Int)) →
  (F + P ≥ (8 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (10 : Int)) →
  (F + L ≥ (12 : Int)) →
  (F + K ≥ (12 : Int)) →
  (F + J ≥ (8 : Int)) →
  (F + I ≥ (7 : Int)) →
  (F + H ≥ (11 : Int)) →
  (F + G ≥ (10 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (7 : Int)) →
  (F + B ≥ (12 : Int)) →
  (F + A ≥ (11 : Int)) →
  (F + O ≥ (9 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + S ≥ (5 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (7 : Int)) →
  (E + K ≥ (7 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (7 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (7 : Int)) →
  (E + A ≥ (6 : Int)) →
  (E + O ≥ (4 : Int)) →
  (D + (-1 : Int) * Q ≥ (3 : Int)) →
  (D + (-1 : Int) * P ≥ (2 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + (-1 : Int) * O ≥ (1 : Int)) →
  (D + S ≥ (8 : Int)) →
  (D + Q ≥ (5 : Int)) →
  (D + P ≥ (6 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (10 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (9 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (10 : Int)) →
  (D + A ≥ (9 : Int)) →
  (D + O ≥ (7 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + S ≥ (5 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (7 : Int)) →
  (C + K ≥ (7 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (7 : Int)) →
  (C + A ≥ (6 : Int)) →
  (C + O ≥ (4 : Int)) →
  (B + (-1 : Int) * Q ≥ (5 : Int)) →
  (B + (-1 : Int) * P ≥ (4 : Int)) →
  (B + (-1 : Int) * H ≥ (1 : Int)) →
  (B + (-1 : Int) * G ≥ (2 : Int)) →
  (B + (-1 : Int) * O ≥ (3 : Int)) →
  (B + Q ≥ (7 : Int)) →
  (B + P ≥ (8 : Int)) →
  (B + H ≥ (11 : Int)) →
  (B + G ≥ (10 : Int)) →
  (B + O ≥ (9 : Int)) →
  (A + (-1 : Int) * Q ≥ (4 : Int)) →
  (A + (-1 : Int) * P ≥ (3 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (1 : Int)) →
  (A + (-1 : Int) * O ≥ (2 : Int)) →
  (A + Q ≥ (6 : Int)) →
  (A + P ≥ (7 : Int)) →
  (A + H ≥ (10 : Int)) →
  (A + G ≥ (9 : Int)) →
  (A + B ≥ (11 : Int)) →
  (A + O ≥ (8 : Int)) →
  (S ≥ (4 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (2 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (6 : Int)) →
  (K ≥ (6 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (5 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (6 : Int)) →
  (A ≥ (5 : Int)) →
  (O ≥ (3 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * S + H ≥ (1 : Int)) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + H ≥ (1 : Int)) →
  ((-1 : Int) * S + B ≥ (2 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  ((-1 : Int) * S + O ≥ (2 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * N + Q ≥ (1 : Int)) →
  ((-1 : Int) * N + P ≥ (2 : Int)) →
  ((-1 : Int) * N + L ≥ (3 : Int)) →
  ((-1 : Int) * N + K ≥ (3 : Int)) →
  ((-1 : Int) * N + H ≥ (2 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + B ≥ (3 : Int)) →
  ((-1 : Int) * N + A ≥ (2 : Int)) →
  ((-1 : Int) * N + O ≥ (3 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * M + Q ≥ (0 : Int)) →
  ((-1 : Int) * M + P ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (2 : Int)) →
  ((-1 : Int) * M + K ≥ (2 : Int)) →
  ((-1 : Int) * M + H ≥ (1 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + B ≥ (2 : Int)) →
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * M + O ≥ (2 : Int)) →
  ((-1 : Int) * K + L ≥ (0 : Int)) →
  ((-1 : Int) * K + B ≥ (0 : Int)) →
  ((-1 : Int) * K + O ≥ (0 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * J + Q ≥ (0 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + H ≥ (1 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + B ≥ (2 : Int)) →
  ((-1 : Int) * J + A ≥ (1 : Int)) →
  ((-1 : Int) * J + O ≥ (2 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * I + Q ≥ (3 : Int)) →
  ((-1 : Int) * I + P ≥ (4 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (4 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (5 : Int)) →
  ((-1 : Int) * I + A ≥ (4 : Int)) →
  ((-1 : Int) * I + O ≥ (5 : Int)) →
  ((-1 : Int) * H + P ≥ (0 : Int)) →
  ((-1 : Int) * H + O ≥ (1 : Int)) →
  ((-1 : Int) * G + Q ≥ (0 : Int)) →
  ((-1 : Int) * G + P ≥ (1 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * G + O ≥ (2 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * E + Q ≥ (3 : Int)) →
  ((-1 : Int) * E + P ≥ (4 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (5 : Int)) →
  ((-1 : Int) * E + K ≥ (5 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (4 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (5 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (5 : Int)) →
  ((-1 : Int) * E + A ≥ (4 : Int)) →
  ((-1 : Int) * E + O ≥ (5 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * D + Q ≥ (0 : Int)) →
  ((-1 : Int) * D + P ≥ (1 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (2 : Int)) →
  ((-1 : Int) * D + K ≥ (2 : Int)) →
  ((-1 : Int) * D + H ≥ (1 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + B ≥ (2 : Int)) →
  ((-1 : Int) * D + A ≥ (1 : Int)) →
  ((-1 : Int) * D + O ≥ (2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * C + Q ≥ (3 : Int)) →
  ((-1 : Int) * C + P ≥ (4 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (5 : Int)) →
  ((-1 : Int) * C + K ≥ (5 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (4 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (5 : Int)) →
  ((-1 : Int) * C + A ≥ (4 : Int)) →
  ((-1 : Int) * C + O ≥ (5 : Int)) →
  ((-1 : Int) * B + O ≥ (0 : Int)) →
  ((-1 : Int) * A + P ≥ (0 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  ((-1 : Int) * A + O ≥ (1 : Int)) →
  (S + (-1 : Int) * Q ≥ (0 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + Q ≥ (8 : Int)) →
  (S + P ≥ (9 : Int)) →
  (S + H ≥ (9 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (10 : Int)) →
  (S + A ≥ (9 : Int)) →
  (S + O ≥ (10 : Int)) →
  (Q + P ≥ (9 : Int)) →
  (Q + O ≥ (10 : Int)) →
  (P + O ≥ (11 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + S ≥ (7 : Int)) →
  (N + Q ≥ (7 : Int)) →
  (N + P ≥ (8 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (9 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (8 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (9 : Int)) →
  (N + A ≥ (8 : Int)) →
  (N + O ≥ (9 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + S ≥ (8 : Int)) →
  (M + Q ≥ (8 : Int)) →
  (M + P ≥ (9 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (10 : Int)) →
  (M + K ≥ (10 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (9 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (10 : Int)) →
  (M + A ≥ (9 : Int)) →
  (M + O ≥ (10 : Int)) →
  (L + (-1 : Int) * S ≥ (2 : Int)) →
  (L + (-1 : Int) * Q ≥ (2 : Int)) →
  (L + (-1 : Int) * P ≥ (1 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (5 : Int)) →
  (L + (-1 : Int) * H ≥ (1 : Int)) →
  (L + (-1 : Int) * G ≥ (2 : Int)) →
  (L + (-1 : Int) * B ≥ (0 : Int)) →
  (L + (-1 : Int) * A ≥ (1 : Int)) →
  (L + (-1 : Int) * O ≥ (0 : Int)) →
  (L + S ≥ (10 : Int)) →
  (L + Q ≥ (10 : Int)) →
  (L + P ≥ (11 : Int)) →
  (L + J ≥ (8 : Int)) →
  (L + I ≥ (7 : Int)) →
  (L + H ≥ (11 : Int)) →
  (L + G ≥ (10 : Int)) →
  (L + B ≥ (12 : Int)) →
  (L + A ≥ (11 : Int)) →
  (L + O ≥ (12 : Int)) →
  (K + (-1 : Int) * S ≥ (2 : Int)) →
  (K + (-1 : Int) * Q ≥ (2 : Int)) →
  (K + (-1 : Int) * P ≥ (1 : Int)) →
  (K + (-1 : Int) * J ≥ (2 : Int)) →
  (K + (-1 : Int) * I ≥ (5 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * G ≥ (2 : Int)) →
  (K + (-1 : Int) * B ≥ (0 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + (-1 : Int) * O ≥ (0 : Int)) →
  (K + S ≥ (10 : Int)) →
  (K + Q ≥ (10 : Int)) →
  (K + P ≥ (11 : Int)) →
  (K + L ≥ (12 : Int)) →
  (K + J ≥ (8 : Int)) →
  (K + I ≥ (7 : Int)) →
  (K + H ≥ (11 : Int)) →
  (K + G ≥ (10 : Int)) →
  (K + B ≥ (12 : Int)) →
  (K + A ≥ (11 : Int)) →
  (K + O ≥ (12 : Int)) →
  (J + S ≥ (6 : Int)) →
  (J + Q ≥ (6 : Int)) →
  (J + P ≥ (7 : Int)) →
  (J + H ≥ (7 : Int)) →
  (J + G ≥ (6 : Int)) →
  (J + B ≥ (8 : Int)) →
  (J + A ≥ (7 : Int)) →
  (J + O ≥ (8 : Int)) →
  (I + S ≥ (5 : Int)) →
  (I + Q ≥ (5 : Int)) →
  (I + P ≥ (6 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (7 : Int)) →
  (I + A ≥ (6 : Int)) →
  (I + O ≥ (7 : Int)) →
  (H + (-1 : Int) * Q ≥ (1 : Int)) →
  (H + (-1 : Int) * P ≥ (0 : Int)) →
  (H + Q ≥ (9 : Int)) →
  (H + P ≥ (10 : Int)) →
  (H + O ≥ (11 : Int)) →
  (G + Q ≥ (8 : Int)) →
  (G + P ≥ (9 : Int)) →
  (G + H ≥ (9 : Int)) →
  (G + O ≥ (10 : Int)) →
  (F + (-1 : Int) * S ≥ (2 : Int)) →
  (F + (-1 : Int) * Q ≥ (2 : Int)) →
  (F + (-1 : Int) * P ≥ (1 : Int)) →
  (F + (-1 : Int) * N ≥ (3 : Int)) →
  (F + (-1 : Int) * M ≥ (2 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (0 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (5 : Int)) →
  (F + (-1 : Int) * H ≥ (1 : Int)) →
  (F + (-1 : Int) * G ≥ (2 : Int)) →
  (F + (-1 : Int) * D ≥ (2 : Int)) →
  (F + (-1 : Int) * C ≥ (5 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (1 : Int)) →
  (F + (-1 : Int) * O ≥ (0 : Int)) →
  (F + S ≥ (10 : Int)) →
  (F + Q ≥ (10 : Int)) →
  (F + P ≥ (11 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (10 : Int)) →
  (F + L ≥ (12 : Int)) →
  (F + K ≥ (12 : Int)) →
  (F + J ≥ (8 : Int)) →
  (F + I ≥ (7 : Int)) →
  (F + H ≥ (11 : Int)) →
  (F + G ≥ (10 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (7 : Int)) →
  (F + B ≥ (12 : Int)) →
  (F + A ≥ (11 : Int)) →
  (F + O ≥ (12 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + S ≥ (5 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (6 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (7 : Int)) →
  (E + K ≥ (7 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (7 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (7 : Int)) →
  (E + A ≥ (6 : Int)) →
  (E + O ≥ (7 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + S ≥ (8 : Int)) →
  (D + Q ≥ (8 : Int)) →
  (D + P ≥ (9 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (10 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (9 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (10 : Int)) →
  (D + A ≥ (9 : Int)) →
  (D + O ≥ (10 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + S ≥ (5 : Int)) →
  (C + Q ≥ (5 : Int)) →
  (C + P ≥ (6 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (7 : Int)) →
  (C + K ≥ (7 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (7 : Int)) →
  (C + A ≥ (6 : Int)) →
  (C + O ≥ (7 : Int)) →
  (B + (-1 : Int) * Q ≥ (2 : Int)) →
  (B + (-1 : Int) * P ≥ (1 : Int)) →
  (B + (-1 : Int) * H ≥ (1 : Int)) →
  (B + (-1 : Int) * G ≥ (2 : Int)) →
  (B + (-1 : Int) * O ≥ (0 : Int)) →
  (B + Q ≥ (10 : Int)) →
  (B + P ≥ (11 : Int)) →
  (B + H ≥ (11 : Int)) →
  (B + G ≥ (10 : Int)) →
  (B + O ≥ (12 : Int)) →
  (A + (-1 : Int) * Q ≥ (1 : Int)) →
  (A + (-1 : Int) * P ≥ (0 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (1 : Int)) →
  (A + Q ≥ (9 : Int)) →
  (A + P ≥ (10 : Int)) →
  (A + H ≥ (10 : Int)) →
  (A + G ≥ (9 : Int)) →
  (A + B ≥ (11 : Int)) →
  (A + O ≥ (11 : Int)) →
  (S ≥ (4 : Int)) →
  (Q ≥ (4 : Int)) →
  (P ≥ (5 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (6 : Int)) →
  (K ≥ (6 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (5 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (6 : Int)) →
  (A ≥ (5 : Int)) →
  (O ≥ (6 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  r3 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r0 S A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 S A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 P A B C D E F G H I J K L M N R Q S O) →
  (True) →
  r0 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r3 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r0 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r3 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r0 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r3 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r0 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r3 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r0 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r3 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r0 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r3 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r0 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r3 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r0 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r3 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r0 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 P A B C D E F G H I J K L M N R Q S O) →
  (True) →
  r3 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r3 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r3 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r3 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r3 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r3 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r3 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r3 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r3 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r3 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r3 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r3 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r3 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r3 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r3 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r3 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r3 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r3 Q A B C D E F G H I J K L M N P R S O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r3 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N P R S O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N P R S O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r3 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N P R S O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r3 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N P R S O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r3 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N P R S O) →
  (r3 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r3 P A B C D E F G H I J K L M N S Q R O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r3 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N S Q R O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N S Q R O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r3 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N S Q R O) →
  (r3 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r1 P A B C D E F G H I J K L M N S R Q O) →
  (r3 P A B C D E F G H I J K L M N S Q R O) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 P A B C D E F G H I J K L M N S R Q O) →
  (r1 P A B C D E F G H I J K L M N S Q R O) →
  (True) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  False))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«fortune-full.9_000»
