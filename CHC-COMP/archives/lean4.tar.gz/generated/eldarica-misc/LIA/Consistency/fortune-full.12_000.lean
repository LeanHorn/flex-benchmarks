import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«fortune-full.12_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":3095:1-3095:12 (check-sat, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":11:1-377:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":378:1-729:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":730:1-1114:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":1115:1-1483:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":1484:1-1851:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":1852:1-2207:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2208:1-2578:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2579:1-2589:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2590:1-2600:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2601:1-2611:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2612:1-2622:2 (clause 11, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2623:1-2633:2 (clause 12, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2634:1-2646:2 (clause 13, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2647:1-2659:2 (clause 14, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2660:1-2672:2 (clause 15, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2673:1-2687:2 (clause 16, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2688:1-2702:2 (clause 17, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2703:1-2717:2 (clause 18, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2718:1-2732:2 (clause 19, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2733:1-2747:2 (clause 20, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2748:1-2758:2 (clause 21, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2759:1-2769:2 (clause 22, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2770:1-2782:2 (clause 23, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2783:1-2795:2 (clause 24, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2796:1-2808:2 (clause 25, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2809:1-2823:2 (clause 26, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2824:1-2838:2 (clause 27, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2839:1-2853:2 (clause 28, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2854:1-2868:2 (clause 29, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2869:1-2883:2 (clause 30, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2884:1-2899:2 (clause 31, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2900:1-2915:2 (clause 32, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2916:1-2931:2 (clause 33, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2932:1-2947:2 (clause 34, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2948:1-2963:2 (clause 35, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2964:1-2979:2 (clause 36, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2980:1-2993:2 (clause 37, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":2994:1-3007:2 (clause 38, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":3008:1-3021:2 (clause 39, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":3022:1-3035:2 (clause 40, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":3036:1-3047:2 (clause 41, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":3048:1-3059:2 (clause 42, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":3060:1-3071:2 (clause 43, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":3072:1-3083:2 (clause 44, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.12_000.smt2":3084:1-3093:2 (clause 45, command 52)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * N + Q ≥ (1 : Int)) →
  ((-1 : Int) * N + P ≥ (3 : Int)) →
  ((-1 : Int) * N + L ≥ (3 : Int)) →
  ((-1 : Int) * N + K ≥ (4 : Int)) →
  ((-1 : Int) * N + H ≥ (2 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + A ≥ (2 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * M + Q ≥ (0 : Int)) →
  ((-1 : Int) * M + P ≥ (2 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (2 : Int)) →
  ((-1 : Int) * M + K ≥ (3 : Int)) →
  ((-1 : Int) * M + H ≥ (1 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * J + Q ≥ (0 : Int)) →
  ((-1 : Int) * J + P ≥ (2 : Int)) →
  ((-1 : Int) * J + H ≥ (1 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + A ≥ (1 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * O ≥ (-2 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * I + O ≥ (0 : Int)) →
  ((-1 : Int) * I + Q ≥ (3 : Int)) →
  ((-1 : Int) * I + P ≥ (5 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (4 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (0 : Int)) →
  ((-1 : Int) * I + A ≥ (4 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * H + P ≥ (1 : Int)) →
  ((-1 : Int) * G + Q ≥ (0 : Int)) →
  ((-1 : Int) * G + P ≥ (2 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * F + K ≥ (1 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * O ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * E + O ≥ (0 : Int)) →
  ((-1 : Int) * E + Q ≥ (3 : Int)) →
  ((-1 : Int) * E + P ≥ (5 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (5 : Int)) →
  ((-1 : Int) * E + K ≥ (6 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (4 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (5 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (0 : Int)) →
  ((-1 : Int) * E + A ≥ (4 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * D + Q ≥ (0 : Int)) →
  ((-1 : Int) * D + P ≥ (2 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (2 : Int)) →
  ((-1 : Int) * D + K ≥ (3 : Int)) →
  ((-1 : Int) * D + H ≥ (1 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + A ≥ (1 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * O ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * C + O ≥ (0 : Int)) →
  ((-1 : Int) * C + Q ≥ (3 : Int)) →
  ((-1 : Int) * C + P ≥ (5 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (5 : Int)) →
  ((-1 : Int) * C + K ≥ (6 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (4 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (0 : Int)) →
  ((-1 : Int) * C + A ≥ (4 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * O ≥ (-2 : Int)) →
  ((-1 : Int) * B + O ≥ (0 : Int)) →
  ((-1 : Int) * B + Q ≥ (3 : Int)) →
  ((-1 : Int) * B + P ≥ (5 : Int)) →
  ((-1 : Int) * B + H ≥ (4 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * A + P ≥ (1 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * S + P ≥ (2 : Int)) →
  ((-1 : Int) * S + H ≥ (1 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  (Q + (-1 : Int) * O ≥ (3 : Int)) →
  (Q + O ≥ (5 : Int)) →
  (Q + P ≥ (10 : Int)) →
  (P + (-1 : Int) * O ≥ (5 : Int)) →
  (P + O ≥ (7 : Int)) →
  (N + (-1 : Int) * O ≥ (2 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + (-1 : Int) * B ≥ (2 : Int)) →
  (N + O ≥ (4 : Int)) →
  (N + Q ≥ (7 : Int)) →
  (N + P ≥ (9 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (8 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (4 : Int)) →
  (N + A ≥ (8 : Int)) →
  (N + S ≥ (7 : Int)) →
  (M + (-1 : Int) * O ≥ (3 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + (-1 : Int) * B ≥ (3 : Int)) →
  (M + O ≥ (5 : Int)) →
  (M + Q ≥ (8 : Int)) →
  (M + P ≥ (10 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (10 : Int)) →
  (M + K ≥ (11 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (9 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (5 : Int)) →
  (M + A ≥ (9 : Int)) →
  (M + S ≥ (8 : Int)) →
  (L + (-1 : Int) * O ≥ (5 : Int)) →
  (L + (-1 : Int) * Q ≥ (1 : Int)) →
  (L + (-1 : Int) * P ≥ (0 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (5 : Int)) →
  (L + (-1 : Int) * H ≥ (1 : Int)) →
  (L + (-1 : Int) * G ≥ (2 : Int)) →
  (L + (-1 : Int) * B ≥ (5 : Int)) →
  (L + (-1 : Int) * A ≥ (1 : Int)) →
  (L + (-1 : Int) * S ≥ (2 : Int)) →
  (L + O ≥ (7 : Int)) →
  (L + Q ≥ (10 : Int)) →
  (L + P ≥ (12 : Int)) →
  (L + J ≥ (8 : Int)) →
  (L + I ≥ (7 : Int)) →
  (L + H ≥ (11 : Int)) →
  (L + G ≥ (10 : Int)) →
  (L + B ≥ (7 : Int)) →
  (L + A ≥ (11 : Int)) →
  (L + S ≥ (10 : Int)) →
  (K + (-1 : Int) * O ≥ (6 : Int)) →
  (K + (-1 : Int) * Q ≥ (2 : Int)) →
  (K + (-1 : Int) * P ≥ (1 : Int)) →
  (K + (-1 : Int) * L ≥ (1 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (6 : Int)) →
  (K + (-1 : Int) * H ≥ (2 : Int)) →
  (K + (-1 : Int) * G ≥ (3 : Int)) →
  (K + (-1 : Int) * B ≥ (6 : Int)) →
  (K + (-1 : Int) * A ≥ (2 : Int)) →
  (K + (-1 : Int) * S ≥ (3 : Int)) →
  (K + O ≥ (8 : Int)) →
  (K + Q ≥ (11 : Int)) →
  (K + P ≥ (13 : Int)) →
  (K + L ≥ (13 : Int)) →
  (K + J ≥ (9 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + H ≥ (12 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + B ≥ (8 : Int)) →
  (K + A ≥ (12 : Int)) →
  (K + S ≥ (11 : Int)) →
  (J + (-1 : Int) * O ≥ (1 : Int)) →
  (J + (-1 : Int) * B ≥ (1 : Int)) →
  (J + O ≥ (3 : Int)) →
  (J + Q ≥ (6 : Int)) →
  (J + P ≥ (8 : Int)) →
  (J + H ≥ (7 : Int)) →
  (J + G ≥ (6 : Int)) →
  (J + B ≥ (3 : Int)) →
  (J + A ≥ (7 : Int)) →
  (J + S ≥ (6 : Int)) →
  (I + (-1 : Int) * O ≥ (0 : Int)) →
  (I + (-1 : Int) * B ≥ (0 : Int)) →
  (I + O ≥ (2 : Int)) →
  (I + Q ≥ (5 : Int)) →
  (I + P ≥ (7 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (2 : Int)) →
  (I + A ≥ (6 : Int)) →
  (I + S ≥ (5 : Int)) →
  (H + (-1 : Int) * O ≥ (4 : Int)) →
  (H + O ≥ (6 : Int)) →
  (H + Q ≥ (9 : Int)) →
  (H + P ≥ (11 : Int)) →
  (G + (-1 : Int) * O ≥ (3 : Int)) →
  (G + O ≥ (5 : Int)) →
  (G + Q ≥ (8 : Int)) →
  (G + P ≥ (10 : Int)) →
  (G + H ≥ (9 : Int)) →
  (F + (-1 : Int) * O ≥ (5 : Int)) →
  (F + (-1 : Int) * Q ≥ (1 : Int)) →
  (F + (-1 : Int) * P ≥ (0 : Int)) →
  (F + (-1 : Int) * N ≥ (3 : Int)) →
  (F + (-1 : Int) * M ≥ (2 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (5 : Int)) →
  (F + (-1 : Int) * H ≥ (1 : Int)) →
  (F + (-1 : Int) * G ≥ (2 : Int)) →
  (F + (-1 : Int) * D ≥ (2 : Int)) →
  (F + (-1 : Int) * C ≥ (5 : Int)) →
  (F + (-1 : Int) * B ≥ (5 : Int)) →
  (F + (-1 : Int) * A ≥ (1 : Int)) →
  (F + (-1 : Int) * S ≥ (2 : Int)) →
  (F + O ≥ (7 : Int)) →
  (F + Q ≥ (10 : Int)) →
  (F + P ≥ (12 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (10 : Int)) →
  (F + L ≥ (12 : Int)) →
  (F + K ≥ (13 : Int)) →
  (F + J ≥ (8 : Int)) →
  (F + I ≥ (7 : Int)) →
  (F + H ≥ (11 : Int)) →
  (F + G ≥ (10 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (7 : Int)) →
  (F + B ≥ (7 : Int)) →
  (F + A ≥ (11 : Int)) →
  (F + S ≥ (10 : Int)) →
  (E + (-1 : Int) * O ≥ (0 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + O ≥ (2 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (7 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (7 : Int)) →
  (E + K ≥ (8 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (7 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (2 : Int)) →
  (E + A ≥ (6 : Int)) →
  (E + S ≥ (5 : Int)) →
  (D + (-1 : Int) * O ≥ (3 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + (-1 : Int) * B ≥ (3 : Int)) →
  (D + O ≥ (5 : Int)) →
  (D + Q ≥ (8 : Int)) →
  (D + P ≥ (10 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (9 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (5 : Int)) →
  (D + A ≥ (9 : Int)) →
  (D + S ≥ (8 : Int)) →
  (C + (-1 : Int) * O ≥ (0 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * B ≥ (0 : Int)) →
  (C + O ≥ (2 : Int)) →
  (C + Q ≥ (5 : Int)) →
  (C + P ≥ (7 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (7 : Int)) →
  (C + K ≥ (8 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (2 : Int)) →
  (C + A ≥ (6 : Int)) →
  (C + S ≥ (5 : Int)) →
  (B + (-1 : Int) * O ≥ (0 : Int)) →
  (B + O ≥ (2 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (7 : Int)) →
  (B + H ≥ (6 : Int)) →
  (B + G ≥ (5 : Int)) →
  (A + (-1 : Int) * O ≥ (4 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (1 : Int)) →
  (A + (-1 : Int) * B ≥ (4 : Int)) →
  (A + O ≥ (6 : Int)) →
  (A + Q ≥ (9 : Int)) →
  (A + P ≥ (11 : Int)) →
  (A + H ≥ (10 : Int)) →
  (A + G ≥ (9 : Int)) →
  (A + B ≥ (6 : Int)) →
  (S + (-1 : Int) * O ≥ (3 : Int)) →
  (S + (-1 : Int) * H ≥ (-1 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + (-1 : Int) * B ≥ (3 : Int)) →
  (S + (-1 : Int) * A ≥ (-1 : Int)) →
  (S + O ≥ (5 : Int)) →
  (S + Q ≥ (8 : Int)) →
  (S + P ≥ (10 : Int)) →
  (S + H ≥ (9 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (9 : Int)) →
  (O ≥ (1 : Int)) →
  (Q ≥ (4 : Int)) →
  (P ≥ (6 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (6 : Int)) →
  (K ≥ (7 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (5 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (1 : Int)) →
  (A ≥ (5 : Int)) →
  (S ≥ (4 : Int)) →
  (O ≤ (1 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  (B ≤ (1 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + O ≥ (3 : Int)) →
  ((-1 : Int) * N + Q ≥ (1 : Int)) →
  ((-1 : Int) * N + P ≥ (2 : Int)) →
  ((-1 : Int) * N + L ≥ (3 : Int)) →
  ((-1 : Int) * N + K ≥ (4 : Int)) →
  ((-1 : Int) * N + H ≥ (2 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + A ≥ (2 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * M + O ≥ (2 : Int)) →
  ((-1 : Int) * M + Q ≥ (0 : Int)) →
  ((-1 : Int) * M + P ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (2 : Int)) →
  ((-1 : Int) * M + K ≥ (3 : Int)) →
  ((-1 : Int) * M + H ≥ (1 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * J + O ≥ (2 : Int)) →
  ((-1 : Int) * J + Q ≥ (0 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + H ≥ (1 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + A ≥ (1 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * I + O ≥ (5 : Int)) →
  ((-1 : Int) * I + Q ≥ (3 : Int)) →
  ((-1 : Int) * I + P ≥ (4 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (4 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (0 : Int)) →
  ((-1 : Int) * I + A ≥ (4 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * G + O ≥ (2 : Int)) →
  ((-1 : Int) * G + Q ≥ (0 : Int)) →
  ((-1 : Int) * G + P ≥ (1 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * F + K ≥ (1 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * E + O ≥ (5 : Int)) →
  ((-1 : Int) * E + Q ≥ (3 : Int)) →
  ((-1 : Int) * E + P ≥ (4 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (5 : Int)) →
  ((-1 : Int) * E + K ≥ (6 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (4 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (5 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (0 : Int)) →
  ((-1 : Int) * E + A ≥ (4 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * D + O ≥ (2 : Int)) →
  ((-1 : Int) * D + Q ≥ (0 : Int)) →
  ((-1 : Int) * D + P ≥ (1 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (2 : Int)) →
  ((-1 : Int) * D + K ≥ (3 : Int)) →
  ((-1 : Int) * D + H ≥ (1 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + A ≥ (1 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * C + O ≥ (5 : Int)) →
  ((-1 : Int) * C + Q ≥ (3 : Int)) →
  ((-1 : Int) * C + P ≥ (4 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (5 : Int)) →
  ((-1 : Int) * C + K ≥ (6 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (4 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (0 : Int)) →
  ((-1 : Int) * C + A ≥ (4 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * B + O ≥ (5 : Int)) →
  ((-1 : Int) * B + Q ≥ (3 : Int)) →
  ((-1 : Int) * B + P ≥ (4 : Int)) →
  ((-1 : Int) * B + H ≥ (4 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * S + H ≥ (1 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  (Q + O ≥ (10 : Int)) →
  (Q + P ≥ (9 : Int)) →
  (P + O ≥ (11 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + (-1 : Int) * B ≥ (2 : Int)) →
  (N + O ≥ (9 : Int)) →
  (N + Q ≥ (7 : Int)) →
  (N + P ≥ (8 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (8 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (4 : Int)) →
  (N + A ≥ (8 : Int)) →
  (N + S ≥ (7 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + (-1 : Int) * B ≥ (3 : Int)) →
  (M + O ≥ (10 : Int)) →
  (M + Q ≥ (8 : Int)) →
  (M + P ≥ (9 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (10 : Int)) →
  (M + K ≥ (11 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (9 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (5 : Int)) →
  (M + A ≥ (9 : Int)) →
  (M + S ≥ (8 : Int)) →
  (L + (-1 : Int) * O ≥ (0 : Int)) →
  (L + (-1 : Int) * Q ≥ (2 : Int)) →
  (L + (-1 : Int) * P ≥ (1 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (5 : Int)) →
  (L + (-1 : Int) * H ≥ (1 : Int)) →
  (L + (-1 : Int) * G ≥ (2 : Int)) →
  (L + (-1 : Int) * B ≥ (5 : Int)) →
  (L + (-1 : Int) * A ≥ (1 : Int)) →
  (L + (-1 : Int) * S ≥ (2 : Int)) →
  (L + O ≥ (12 : Int)) →
  (L + Q ≥ (10 : Int)) →
  (L + P ≥ (11 : Int)) →
  (L + J ≥ (8 : Int)) →
  (L + I ≥ (7 : Int)) →
  (L + H ≥ (11 : Int)) →
  (L + G ≥ (10 : Int)) →
  (L + B ≥ (7 : Int)) →
  (L + A ≥ (11 : Int)) →
  (L + S ≥ (10 : Int)) →
  (K + (-1 : Int) * O ≥ (1 : Int)) →
  (K + (-1 : Int) * Q ≥ (3 : Int)) →
  (K + (-1 : Int) * P ≥ (2 : Int)) →
  (K + (-1 : Int) * L ≥ (1 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (6 : Int)) →
  (K + (-1 : Int) * H ≥ (2 : Int)) →
  (K + (-1 : Int) * G ≥ (3 : Int)) →
  (K + (-1 : Int) * B ≥ (6 : Int)) →
  (K + (-1 : Int) * A ≥ (2 : Int)) →
  (K + (-1 : Int) * S ≥ (3 : Int)) →
  (K + O ≥ (13 : Int)) →
  (K + Q ≥ (11 : Int)) →
  (K + P ≥ (12 : Int)) →
  (K + L ≥ (13 : Int)) →
  (K + J ≥ (9 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + H ≥ (12 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + B ≥ (8 : Int)) →
  (K + A ≥ (12 : Int)) →
  (K + S ≥ (11 : Int)) →
  (J + (-1 : Int) * B ≥ (1 : Int)) →
  (J + O ≥ (8 : Int)) →
  (J + Q ≥ (6 : Int)) →
  (J + P ≥ (7 : Int)) →
  (J + H ≥ (7 : Int)) →
  (J + G ≥ (6 : Int)) →
  (J + B ≥ (3 : Int)) →
  (J + A ≥ (7 : Int)) →
  (J + S ≥ (6 : Int)) →
  (I + (-1 : Int) * B ≥ (0 : Int)) →
  (I + O ≥ (7 : Int)) →
  (I + Q ≥ (5 : Int)) →
  (I + P ≥ (6 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (2 : Int)) →
  (I + A ≥ (6 : Int)) →
  (I + S ≥ (5 : Int)) →
  (H + O ≥ (11 : Int)) →
  (H + Q ≥ (9 : Int)) →
  (H + P ≥ (10 : Int)) →
  (G + O ≥ (10 : Int)) →
  (G + Q ≥ (8 : Int)) →
  (G + P ≥ (9 : Int)) →
  (G + H ≥ (9 : Int)) →
  (F + (-1 : Int) * O ≥ (0 : Int)) →
  (F + (-1 : Int) * Q ≥ (2 : Int)) →
  (F + (-1 : Int) * P ≥ (1 : Int)) →
  (F + (-1 : Int) * N ≥ (3 : Int)) →
  (F + (-1 : Int) * M ≥ (2 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (5 : Int)) →
  (F + (-1 : Int) * H ≥ (1 : Int)) →
  (F + (-1 : Int) * G ≥ (2 : Int)) →
  (F + (-1 : Int) * D ≥ (2 : Int)) →
  (F + (-1 : Int) * C ≥ (5 : Int)) →
  (F + (-1 : Int) * B ≥ (5 : Int)) →
  (F + (-1 : Int) * A ≥ (1 : Int)) →
  (F + (-1 : Int) * S ≥ (2 : Int)) →
  (F + O ≥ (12 : Int)) →
  (F + Q ≥ (10 : Int)) →
  (F + P ≥ (11 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (10 : Int)) →
  (F + L ≥ (12 : Int)) →
  (F + K ≥ (13 : Int)) →
  (F + J ≥ (8 : Int)) →
  (F + I ≥ (7 : Int)) →
  (F + H ≥ (11 : Int)) →
  (F + G ≥ (10 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (7 : Int)) →
  (F + B ≥ (7 : Int)) →
  (F + A ≥ (11 : Int)) →
  (F + S ≥ (10 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + O ≥ (7 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (6 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (7 : Int)) →
  (E + K ≥ (8 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (7 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (2 : Int)) →
  (E + A ≥ (6 : Int)) →
  (E + S ≥ (5 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + (-1 : Int) * B ≥ (3 : Int)) →
  (D + O ≥ (10 : Int)) →
  (D + Q ≥ (8 : Int)) →
  (D + P ≥ (9 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (9 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (5 : Int)) →
  (D + A ≥ (9 : Int)) →
  (D + S ≥ (8 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * B ≥ (0 : Int)) →
  (C + O ≥ (7 : Int)) →
  (C + Q ≥ (5 : Int)) →
  (C + P ≥ (6 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (7 : Int)) →
  (C + K ≥ (8 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (2 : Int)) →
  (C + A ≥ (6 : Int)) →
  (C + S ≥ (5 : Int)) →
  (B + O ≥ (7 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (6 : Int)) →
  (B + H ≥ (6 : Int)) →
  (B + G ≥ (5 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (1 : Int)) →
  (A + (-1 : Int) * B ≥ (4 : Int)) →
  (A + O ≥ (11 : Int)) →
  (A + Q ≥ (9 : Int)) →
  (A + P ≥ (10 : Int)) →
  (A + H ≥ (10 : Int)) →
  (A + G ≥ (9 : Int)) →
  (A + B ≥ (6 : Int)) →
  (S + (-1 : Int) * H ≥ (-1 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + (-1 : Int) * B ≥ (3 : Int)) →
  (S + (-1 : Int) * A ≥ (-1 : Int)) →
  (S + O ≥ (10 : Int)) →
  (S + Q ≥ (8 : Int)) →
  (S + P ≥ (9 : Int)) →
  (S + H ≥ (9 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (9 : Int)) →
  (O ≥ (6 : Int)) →
  (Q ≥ (4 : Int)) →
  (P ≥ (5 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (6 : Int)) →
  (K ≥ (7 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (5 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (1 : Int)) →
  (A ≥ (5 : Int)) →
  (S ≥ (4 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  (B ≤ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + O ≥ (3 : Int)) →
  ((-1 : Int) * N + Q ≥ (1 : Int)) →
  ((-1 : Int) * N + P ≥ (2 : Int)) →
  ((-1 : Int) * N + L ≥ (3 : Int)) →
  ((-1 : Int) * N + K ≥ (4 : Int)) →
  ((-1 : Int) * N + H ≥ (3 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + A ≥ (3 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * M + O ≥ (2 : Int)) →
  ((-1 : Int) * M + Q ≥ (0 : Int)) →
  ((-1 : Int) * M + P ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (2 : Int)) →
  ((-1 : Int) * M + K ≥ (3 : Int)) →
  ((-1 : Int) * M + H ≥ (2 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + A ≥ (2 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * L + O ≥ (-1 : Int)) →
  ((-1 : Int) * L + H ≥ (0 : Int)) →
  ((-1 : Int) * L + A ≥ (0 : Int)) →
  ((-1 : Int) * K + O ≥ (-2 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * K + H ≥ (-1 : Int)) →
  ((-1 : Int) * K + A ≥ (-1 : Int)) →
  ((-1 : Int) * J + O ≥ (2 : Int)) →
  ((-1 : Int) * J + Q ≥ (0 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + H ≥ (2 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + A ≥ (2 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * I + O ≥ (5 : Int)) →
  ((-1 : Int) * I + Q ≥ (3 : Int)) →
  ((-1 : Int) * I + P ≥ (4 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (5 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (0 : Int)) →
  ((-1 : Int) * I + A ≥ (5 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * H + O ≥ (-1 : Int)) →
  ((-1 : Int) * G + O ≥ (2 : Int)) →
  ((-1 : Int) * G + Q ≥ (0 : Int)) →
  ((-1 : Int) * G + P ≥ (1 : Int)) →
  ((-1 : Int) * G + H ≥ (2 : Int)) →
  ((-1 : Int) * F + O ≥ (-1 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * F + K ≥ (1 : Int)) →
  ((-1 : Int) * F + H ≥ (0 : Int)) →
  ((-1 : Int) * F + A ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * E + O ≥ (5 : Int)) →
  ((-1 : Int) * E + Q ≥ (3 : Int)) →
  ((-1 : Int) * E + P ≥ (4 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (5 : Int)) →
  ((-1 : Int) * E + K ≥ (6 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (5 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (5 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (0 : Int)) →
  ((-1 : Int) * E + A ≥ (5 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * D + O ≥ (2 : Int)) →
  ((-1 : Int) * D + Q ≥ (0 : Int)) →
  ((-1 : Int) * D + P ≥ (1 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (2 : Int)) →
  ((-1 : Int) * D + K ≥ (3 : Int)) →
  ((-1 : Int) * D + H ≥ (2 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + A ≥ (2 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * C + O ≥ (5 : Int)) →
  ((-1 : Int) * C + Q ≥ (3 : Int)) →
  ((-1 : Int) * C + P ≥ (4 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (5 : Int)) →
  ((-1 : Int) * C + K ≥ (6 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (5 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (0 : Int)) →
  ((-1 : Int) * C + A ≥ (5 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * B + O ≥ (5 : Int)) →
  ((-1 : Int) * B + Q ≥ (3 : Int)) →
  ((-1 : Int) * B + P ≥ (4 : Int)) →
  ((-1 : Int) * B + H ≥ (5 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * A + O ≥ (-1 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * S + O ≥ (2 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + H ≥ (2 : Int)) →
  ((-1 : Int) * S + G ≥ (0 : Int)) →
  ((-1 : Int) * S + A ≥ (2 : Int)) →
  (Q + (-1 : Int) * P ≥ (-1 : Int)) →
  (Q + O ≥ (10 : Int)) →
  (Q + P ≥ (9 : Int)) →
  (P + O ≥ (11 : Int)) →
  (N + (-1 : Int) * Q ≥ (-1 : Int)) →
  (N + (-1 : Int) * P ≥ (-2 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + (-1 : Int) * B ≥ (2 : Int)) →
  (N + (-1 : Int) * S ≥ (-1 : Int)) →
  (N + O ≥ (9 : Int)) →
  (N + Q ≥ (7 : Int)) →
  (N + P ≥ (8 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (9 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (4 : Int)) →
  (N + A ≥ (9 : Int)) →
  (N + S ≥ (7 : Int)) →
  (M + (-1 : Int) * Q ≥ (0 : Int)) →
  (M + (-1 : Int) * P ≥ (-1 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + (-1 : Int) * B ≥ (3 : Int)) →
  (M + (-1 : Int) * S ≥ (0 : Int)) →
  (M + O ≥ (10 : Int)) →
  (M + Q ≥ (8 : Int)) →
  (M + P ≥ (9 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (10 : Int)) →
  (M + K ≥ (11 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (10 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (5 : Int)) →
  (M + A ≥ (10 : Int)) →
  (M + S ≥ (8 : Int)) →
  (L + (-1 : Int) * O ≥ (0 : Int)) →
  (L + (-1 : Int) * Q ≥ (2 : Int)) →
  (L + (-1 : Int) * P ≥ (1 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (5 : Int)) →
  (L + (-1 : Int) * H ≥ (0 : Int)) →
  (L + (-1 : Int) * G ≥ (2 : Int)) →
  (L + (-1 : Int) * B ≥ (5 : Int)) →
  (L + (-1 : Int) * A ≥ (0 : Int)) →
  (L + (-1 : Int) * S ≥ (2 : Int)) →
  (L + O ≥ (12 : Int)) →
  (L + Q ≥ (10 : Int)) →
  (L + P ≥ (11 : Int)) →
  (L + J ≥ (8 : Int)) →
  (L + I ≥ (7 : Int)) →
  (L + H ≥ (12 : Int)) →
  (L + G ≥ (10 : Int)) →
  (L + B ≥ (7 : Int)) →
  (L + A ≥ (12 : Int)) →
  (L + S ≥ (10 : Int)) →
  (K + (-1 : Int) * O ≥ (1 : Int)) →
  (K + (-1 : Int) * Q ≥ (3 : Int)) →
  (K + (-1 : Int) * P ≥ (2 : Int)) →
  (K + (-1 : Int) * L ≥ (1 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (6 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * G ≥ (3 : Int)) →
  (K + (-1 : Int) * B ≥ (6 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + (-1 : Int) * S ≥ (3 : Int)) →
  (K + O ≥ (13 : Int)) →
  (K + Q ≥ (11 : Int)) →
  (K + P ≥ (12 : Int)) →
  (K + L ≥ (13 : Int)) →
  (K + J ≥ (9 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + H ≥ (13 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + B ≥ (8 : Int)) →
  (K + A ≥ (13 : Int)) →
  (K + S ≥ (11 : Int)) →
  (J + (-1 : Int) * B ≥ (1 : Int)) →
  (J + O ≥ (8 : Int)) →
  (J + Q ≥ (6 : Int)) →
  (J + P ≥ (7 : Int)) →
  (J + H ≥ (8 : Int)) →
  (J + G ≥ (6 : Int)) →
  (J + B ≥ (3 : Int)) →
  (J + A ≥ (8 : Int)) →
  (J + S ≥ (6 : Int)) →
  (I + (-1 : Int) * B ≥ (0 : Int)) →
  (I + O ≥ (7 : Int)) →
  (I + Q ≥ (5 : Int)) →
  (I + P ≥ (6 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + H ≥ (7 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (2 : Int)) →
  (I + A ≥ (7 : Int)) →
  (I + S ≥ (5 : Int)) →
  (H + (-1 : Int) * O ≥ (0 : Int)) →
  (H + (-1 : Int) * Q ≥ (2 : Int)) →
  (H + (-1 : Int) * P ≥ (1 : Int)) →
  (H + O ≥ (12 : Int)) →
  (H + Q ≥ (10 : Int)) →
  (H + P ≥ (11 : Int)) →
  (G + (-1 : Int) * Q ≥ (0 : Int)) →
  (G + (-1 : Int) * P ≥ (-1 : Int)) →
  (G + O ≥ (10 : Int)) →
  (G + Q ≥ (8 : Int)) →
  (G + P ≥ (9 : Int)) →
  (G + H ≥ (10 : Int)) →
  (F + (-1 : Int) * O ≥ (0 : Int)) →
  (F + (-1 : Int) * Q ≥ (2 : Int)) →
  (F + (-1 : Int) * P ≥ (1 : Int)) →
  (F + (-1 : Int) * N ≥ (3 : Int)) →
  (F + (-1 : Int) * M ≥ (2 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (5 : Int)) →
  (F + (-1 : Int) * H ≥ (0 : Int)) →
  (F + (-1 : Int) * G ≥ (2 : Int)) →
  (F + (-1 : Int) * D ≥ (2 : Int)) →
  (F + (-1 : Int) * C ≥ (5 : Int)) →
  (F + (-1 : Int) * B ≥ (5 : Int)) →
  (F + (-1 : Int) * A ≥ (0 : Int)) →
  (F + (-1 : Int) * S ≥ (2 : Int)) →
  (F + O ≥ (12 : Int)) →
  (F + Q ≥ (10 : Int)) →
  (F + P ≥ (11 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (10 : Int)) →
  (F + L ≥ (12 : Int)) →
  (F + K ≥ (13 : Int)) →
  (F + J ≥ (8 : Int)) →
  (F + I ≥ (7 : Int)) →
  (F + H ≥ (12 : Int)) →
  (F + G ≥ (10 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (7 : Int)) →
  (F + B ≥ (7 : Int)) →
  (F + A ≥ (12 : Int)) →
  (F + S ≥ (10 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + O ≥ (7 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (6 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (7 : Int)) →
  (E + K ≥ (8 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (7 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (7 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (2 : Int)) →
  (E + A ≥ (7 : Int)) →
  (E + S ≥ (5 : Int)) →
  (D + (-1 : Int) * Q ≥ (0 : Int)) →
  (D + (-1 : Int) * P ≥ (-1 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + (-1 : Int) * B ≥ (3 : Int)) →
  (D + (-1 : Int) * S ≥ (0 : Int)) →
  (D + O ≥ (10 : Int)) →
  (D + Q ≥ (8 : Int)) →
  (D + P ≥ (9 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (10 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (5 : Int)) →
  (D + A ≥ (10 : Int)) →
  (D + S ≥ (8 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * B ≥ (0 : Int)) →
  (C + O ≥ (7 : Int)) →
  (C + Q ≥ (5 : Int)) →
  (C + P ≥ (6 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (7 : Int)) →
  (C + K ≥ (8 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (7 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (2 : Int)) →
  (C + A ≥ (7 : Int)) →
  (C + S ≥ (5 : Int)) →
  (B + O ≥ (7 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (6 : Int)) →
  (B + H ≥ (7 : Int)) →
  (B + G ≥ (5 : Int)) →
  (A + (-1 : Int) * O ≥ (0 : Int)) →
  (A + (-1 : Int) * Q ≥ (2 : Int)) →
  (A + (-1 : Int) * P ≥ (1 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (5 : Int)) →
  (A + O ≥ (12 : Int)) →
  (A + Q ≥ (10 : Int)) →
  (A + P ≥ (11 : Int)) →
  (A + H ≥ (12 : Int)) →
  (A + G ≥ (10 : Int)) →
  (A + B ≥ (7 : Int)) →
  (S + (-1 : Int) * Q ≥ (0 : Int)) →
  (S + (-1 : Int) * P ≥ (-1 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + (-1 : Int) * B ≥ (3 : Int)) →
  (S + O ≥ (10 : Int)) →
  (S + Q ≥ (8 : Int)) →
  (S + P ≥ (9 : Int)) →
  (S + H ≥ (10 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (10 : Int)) →
  (O ≥ (6 : Int)) →
  (Q ≥ (4 : Int)) →
  (P ≥ (5 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (6 : Int)) →
  (K ≥ (7 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (6 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (1 : Int)) →
  (A ≥ (6 : Int)) →
  (S ≥ (4 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  (B ≤ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + O ≥ (3 : Int)) →
  ((-1 : Int) * N + Q ≥ (1 : Int)) →
  ((-1 : Int) * N + P ≥ (2 : Int)) →
  ((-1 : Int) * N + L ≥ (4 : Int)) →
  ((-1 : Int) * N + K ≥ (5 : Int)) →
  ((-1 : Int) * N + H ≥ (4 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + A ≥ (4 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * M + O ≥ (2 : Int)) →
  ((-1 : Int) * M + Q ≥ (0 : Int)) →
  ((-1 : Int) * M + P ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (3 : Int)) →
  ((-1 : Int) * M + K ≥ (4 : Int)) →
  ((-1 : Int) * M + H ≥ (3 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + A ≥ (3 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * L + H ≥ (0 : Int)) →
  ((-1 : Int) * L + A ≥ (0 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * K + H ≥ (-1 : Int)) →
  ((-1 : Int) * K + A ≥ (-1 : Int)) →
  ((-1 : Int) * J + O ≥ (2 : Int)) →
  ((-1 : Int) * J + Q ≥ (0 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + H ≥ (3 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + A ≥ (3 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * I + O ≥ (5 : Int)) →
  ((-1 : Int) * I + Q ≥ (3 : Int)) →
  ((-1 : Int) * I + P ≥ (4 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (6 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (0 : Int)) →
  ((-1 : Int) * I + A ≥ (6 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * G + O ≥ (2 : Int)) →
  ((-1 : Int) * G + Q ≥ (0 : Int)) →
  ((-1 : Int) * G + P ≥ (1 : Int)) →
  ((-1 : Int) * G + H ≥ (3 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * F + K ≥ (1 : Int)) →
  ((-1 : Int) * F + H ≥ (0 : Int)) →
  ((-1 : Int) * F + A ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * E + O ≥ (5 : Int)) →
  ((-1 : Int) * E + Q ≥ (3 : Int)) →
  ((-1 : Int) * E + P ≥ (4 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (6 : Int)) →
  ((-1 : Int) * E + K ≥ (7 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (6 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (6 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (0 : Int)) →
  ((-1 : Int) * E + A ≥ (6 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * D + O ≥ (2 : Int)) →
  ((-1 : Int) * D + Q ≥ (0 : Int)) →
  ((-1 : Int) * D + P ≥ (1 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (3 : Int)) →
  ((-1 : Int) * D + K ≥ (4 : Int)) →
  ((-1 : Int) * D + H ≥ (3 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + A ≥ (3 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * C + O ≥ (5 : Int)) →
  ((-1 : Int) * C + Q ≥ (3 : Int)) →
  ((-1 : Int) * C + P ≥ (4 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (6 : Int)) →
  ((-1 : Int) * C + K ≥ (7 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (6 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (0 : Int)) →
  ((-1 : Int) * C + A ≥ (6 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * B + O ≥ (5 : Int)) →
  ((-1 : Int) * B + Q ≥ (3 : Int)) →
  ((-1 : Int) * B + P ≥ (4 : Int)) →
  ((-1 : Int) * B + H ≥ (6 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * S + O ≥ (2 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + H ≥ (3 : Int)) →
  ((-1 : Int) * S + G ≥ (0 : Int)) →
  ((-1 : Int) * S + A ≥ (3 : Int)) →
  (Q + O ≥ (10 : Int)) →
  (Q + P ≥ (9 : Int)) →
  (P + O ≥ (11 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + (-1 : Int) * B ≥ (2 : Int)) →
  (N + (-1 : Int) * S ≥ (-1 : Int)) →
  (N + O ≥ (9 : Int)) →
  (N + Q ≥ (7 : Int)) →
  (N + P ≥ (8 : Int)) →
  (N + L ≥ (10 : Int)) →
  (N + K ≥ (11 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (10 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (4 : Int)) →
  (N + A ≥ (10 : Int)) →
  (N + S ≥ (7 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + (-1 : Int) * B ≥ (3 : Int)) →
  (M + (-1 : Int) * S ≥ (0 : Int)) →
  (M + O ≥ (10 : Int)) →
  (M + Q ≥ (8 : Int)) →
  (M + P ≥ (9 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (11 : Int)) →
  (M + K ≥ (12 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (11 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (5 : Int)) →
  (M + A ≥ (11 : Int)) →
  (M + S ≥ (8 : Int)) →
  (L + (-1 : Int) * O ≥ (0 : Int)) →
  (L + (-1 : Int) * Q ≥ (2 : Int)) →
  (L + (-1 : Int) * P ≥ (1 : Int)) →
  (L + (-1 : Int) * J ≥ (3 : Int)) →
  (L + (-1 : Int) * I ≥ (6 : Int)) →
  (L + (-1 : Int) * H ≥ (0 : Int)) →
  (L + (-1 : Int) * G ≥ (3 : Int)) →
  (L + (-1 : Int) * B ≥ (6 : Int)) →
  (L + (-1 : Int) * A ≥ (0 : Int)) →
  (L + (-1 : Int) * S ≥ (3 : Int)) →
  (L + O ≥ (13 : Int)) →
  (L + Q ≥ (11 : Int)) →
  (L + P ≥ (12 : Int)) →
  (L + J ≥ (9 : Int)) →
  (L + I ≥ (8 : Int)) →
  (L + H ≥ (14 : Int)) →
  (L + G ≥ (11 : Int)) →
  (L + B ≥ (8 : Int)) →
  (L + A ≥ (14 : Int)) →
  (L + S ≥ (11 : Int)) →
  (K + (-1 : Int) * O ≥ (1 : Int)) →
  (K + (-1 : Int) * Q ≥ (3 : Int)) →
  (K + (-1 : Int) * P ≥ (2 : Int)) →
  (K + (-1 : Int) * L ≥ (1 : Int)) →
  (K + (-1 : Int) * J ≥ (4 : Int)) →
  (K + (-1 : Int) * I ≥ (7 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * G ≥ (4 : Int)) →
  (K + (-1 : Int) * B ≥ (7 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + (-1 : Int) * S ≥ (4 : Int)) →
  (K + O ≥ (14 : Int)) →
  (K + Q ≥ (12 : Int)) →
  (K + P ≥ (13 : Int)) →
  (K + L ≥ (15 : Int)) →
  (K + J ≥ (10 : Int)) →
  (K + I ≥ (9 : Int)) →
  (K + H ≥ (15 : Int)) →
  (K + G ≥ (12 : Int)) →
  (K + B ≥ (9 : Int)) →
  (K + A ≥ (15 : Int)) →
  (K + S ≥ (12 : Int)) →
  (J + (-1 : Int) * B ≥ (1 : Int)) →
  (J + O ≥ (8 : Int)) →
  (J + Q ≥ (6 : Int)) →
  (J + P ≥ (7 : Int)) →
  (J + H ≥ (9 : Int)) →
  (J + G ≥ (6 : Int)) →
  (J + B ≥ (3 : Int)) →
  (J + A ≥ (9 : Int)) →
  (J + S ≥ (6 : Int)) →
  (I + (-1 : Int) * B ≥ (0 : Int)) →
  (I + O ≥ (7 : Int)) →
  (I + Q ≥ (5 : Int)) →
  (I + P ≥ (6 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + H ≥ (8 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (2 : Int)) →
  (I + A ≥ (8 : Int)) →
  (I + S ≥ (5 : Int)) →
  (H + (-1 : Int) * O ≥ (0 : Int)) →
  (H + (-1 : Int) * Q ≥ (2 : Int)) →
  (H + (-1 : Int) * P ≥ (1 : Int)) →
  (H + O ≥ (13 : Int)) →
  (H + Q ≥ (11 : Int)) →
  (H + P ≥ (12 : Int)) →
  (G + O ≥ (10 : Int)) →
  (G + Q ≥ (8 : Int)) →
  (G + P ≥ (9 : Int)) →
  (G + H ≥ (11 : Int)) →
  (F + (-1 : Int) * O ≥ (0 : Int)) →
  (F + (-1 : Int) * Q ≥ (2 : Int)) →
  (F + (-1 : Int) * P ≥ (1 : Int)) →
  (F + (-1 : Int) * N ≥ (4 : Int)) →
  (F + (-1 : Int) * M ≥ (3 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (6 : Int)) →
  (F + (-1 : Int) * H ≥ (0 : Int)) →
  (F + (-1 : Int) * G ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (3 : Int)) →
  (F + (-1 : Int) * C ≥ (6 : Int)) →
  (F + (-1 : Int) * B ≥ (6 : Int)) →
  (F + (-1 : Int) * A ≥ (0 : Int)) →
  (F + (-1 : Int) * S ≥ (3 : Int)) →
  (F + O ≥ (13 : Int)) →
  (F + Q ≥ (11 : Int)) →
  (F + P ≥ (12 : Int)) →
  (F + N ≥ (10 : Int)) →
  (F + M ≥ (11 : Int)) →
  (F + L ≥ (14 : Int)) →
  (F + K ≥ (15 : Int)) →
  (F + J ≥ (9 : Int)) →
  (F + I ≥ (8 : Int)) →
  (F + H ≥ (14 : Int)) →
  (F + G ≥ (11 : Int)) →
  (F + D ≥ (11 : Int)) →
  (F + C ≥ (8 : Int)) →
  (F + B ≥ (8 : Int)) →
  (F + A ≥ (14 : Int)) →
  (F + S ≥ (11 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + O ≥ (7 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (6 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (8 : Int)) →
  (E + K ≥ (9 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (8 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (8 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (2 : Int)) →
  (E + A ≥ (8 : Int)) →
  (E + S ≥ (5 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + (-1 : Int) * B ≥ (3 : Int)) →
  (D + (-1 : Int) * S ≥ (0 : Int)) →
  (D + O ≥ (10 : Int)) →
  (D + Q ≥ (8 : Int)) →
  (D + P ≥ (9 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (11 : Int)) →
  (D + K ≥ (12 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (11 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (5 : Int)) →
  (D + A ≥ (11 : Int)) →
  (D + S ≥ (8 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * B ≥ (0 : Int)) →
  (C + O ≥ (7 : Int)) →
  (C + Q ≥ (5 : Int)) →
  (C + P ≥ (6 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (8 : Int)) →
  (C + K ≥ (9 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (8 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (2 : Int)) →
  (C + A ≥ (8 : Int)) →
  (C + S ≥ (5 : Int)) →
  (B + O ≥ (7 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (6 : Int)) →
  (B + H ≥ (8 : Int)) →
  (B + G ≥ (5 : Int)) →
  (A + (-1 : Int) * O ≥ (0 : Int)) →
  (A + (-1 : Int) * Q ≥ (2 : Int)) →
  (A + (-1 : Int) * P ≥ (1 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (3 : Int)) →
  (A + (-1 : Int) * B ≥ (6 : Int)) →
  (A + O ≥ (13 : Int)) →
  (A + Q ≥ (11 : Int)) →
  (A + P ≥ (12 : Int)) →
  (A + H ≥ (14 : Int)) →
  (A + G ≥ (11 : Int)) →
  (A + B ≥ (8 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + (-1 : Int) * B ≥ (3 : Int)) →
  (S + O ≥ (10 : Int)) →
  (S + Q ≥ (8 : Int)) →
  (S + P ≥ (9 : Int)) →
  (S + H ≥ (11 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (11 : Int)) →
  (O ≥ (6 : Int)) →
  (Q ≥ (4 : Int)) →
  (P ≥ (5 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (7 : Int)) →
  (K ≥ (8 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (7 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (7 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (1 : Int)) →
  (A ≥ (7 : Int)) →
  (S ≥ (4 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  (B ≤ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + O ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (3 : Int)) →
  ((-1 : Int) * N + K ≥ (4 : Int)) →
  ((-1 : Int) * N + J ≥ (1 : Int)) →
  ((-1 : Int) * N + H ≥ (2 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + A ≥ (2 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * M + O ≥ (0 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (2 : Int)) →
  ((-1 : Int) * M + K ≥ (3 : Int)) →
  ((-1 : Int) * M + J ≥ (0 : Int)) →
  ((-1 : Int) * M + H ≥ (1 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * J + O ≥ (0 : Int)) →
  ((-1 : Int) * J + H ≥ (1 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + A ≥ (1 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * I + O ≥ (3 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (3 : Int)) →
  ((-1 : Int) * I + H ≥ (4 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (0 : Int)) →
  ((-1 : Int) * I + A ≥ (4 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * G + O ≥ (0 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * F + K ≥ (1 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * E + O ≥ (3 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (1 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (5 : Int)) →
  ((-1 : Int) * E + K ≥ (6 : Int)) →
  ((-1 : Int) * E + J ≥ (3 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (4 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (5 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (0 : Int)) →
  ((-1 : Int) * E + A ≥ (4 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * D + O ≥ (0 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (2 : Int)) →
  ((-1 : Int) * D + K ≥ (3 : Int)) →
  ((-1 : Int) * D + J ≥ (0 : Int)) →
  ((-1 : Int) * D + H ≥ (1 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + A ≥ (1 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * C + O ≥ (3 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (5 : Int)) →
  ((-1 : Int) * C + K ≥ (6 : Int)) →
  ((-1 : Int) * C + J ≥ (3 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (4 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (0 : Int)) →
  ((-1 : Int) * C + A ≥ (4 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * B + O ≥ (3 : Int)) →
  ((-1 : Int) * B + Q ≥ (0 : Int)) →
  ((-1 : Int) * B + P ≥ (1 : Int)) →
  ((-1 : Int) * B + H ≥ (4 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * S + H ≥ (1 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  (Q + O ≥ (5 : Int)) →
  (Q + P ≥ (3 : Int)) →
  (P + O ≥ (6 : Int)) →
  (N + (-1 : Int) * O ≥ (-1 : Int)) →
  (N + (-1 : Int) * Q ≥ (1 : Int)) →
  (N + (-1 : Int) * P ≥ (0 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + (-1 : Int) * B ≥ (2 : Int)) →
  (N + O ≥ (7 : Int)) →
  (N + Q ≥ (4 : Int)) →
  (N + P ≥ (5 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (7 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (8 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (4 : Int)) →
  (N + A ≥ (8 : Int)) →
  (N + S ≥ (7 : Int)) →
  (M + (-1 : Int) * O ≥ (0 : Int)) →
  (M + (-1 : Int) * Q ≥ (2 : Int)) →
  (M + (-1 : Int) * P ≥ (1 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + (-1 : Int) * B ≥ (3 : Int)) →
  (M + O ≥ (8 : Int)) →
  (M + Q ≥ (5 : Int)) →
  (M + P ≥ (6 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (10 : Int)) →
  (M + K ≥ (11 : Int)) →
  (M + J ≥ (8 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (9 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (5 : Int)) →
  (M + A ≥ (9 : Int)) →
  (M + S ≥ (8 : Int)) →
  (L + (-1 : Int) * O ≥ (2 : Int)) →
  (L + (-1 : Int) * Q ≥ (4 : Int)) →
  (L + (-1 : Int) * P ≥ (3 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (5 : Int)) →
  (L + (-1 : Int) * H ≥ (0 : Int)) →
  (L + (-1 : Int) * G ≥ (2 : Int)) →
  (L + (-1 : Int) * B ≥ (5 : Int)) →
  (L + (-1 : Int) * A ≥ (0 : Int)) →
  (L + (-1 : Int) * S ≥ (1 : Int)) →
  (L + O ≥ (10 : Int)) →
  (L + Q ≥ (7 : Int)) →
  (L + P ≥ (8 : Int)) →
  (L + J ≥ (10 : Int)) →
  (L + I ≥ (7 : Int)) →
  (L + H ≥ (11 : Int)) →
  (L + G ≥ (10 : Int)) →
  (L + B ≥ (7 : Int)) →
  (L + A ≥ (11 : Int)) →
  (L + S ≥ (10 : Int)) →
  (K + (-1 : Int) * O ≥ (3 : Int)) →
  (K + (-1 : Int) * Q ≥ (5 : Int)) →
  (K + (-1 : Int) * P ≥ (4 : Int)) →
  (K + (-1 : Int) * L ≥ (1 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (6 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * G ≥ (3 : Int)) →
  (K + (-1 : Int) * B ≥ (6 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + (-1 : Int) * S ≥ (2 : Int)) →
  (K + O ≥ (11 : Int)) →
  (K + Q ≥ (8 : Int)) →
  (K + P ≥ (9 : Int)) →
  (K + L ≥ (13 : Int)) →
  (K + J ≥ (11 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + H ≥ (12 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + B ≥ (8 : Int)) →
  (K + A ≥ (12 : Int)) →
  (K + S ≥ (11 : Int)) →
  (J + (-1 : Int) * O ≥ (0 : Int)) →
  (J + (-1 : Int) * Q ≥ (2 : Int)) →
  (J + (-1 : Int) * P ≥ (1 : Int)) →
  (J + (-1 : Int) * G ≥ (0 : Int)) →
  (J + (-1 : Int) * B ≥ (3 : Int)) →
  (J + O ≥ (8 : Int)) →
  (J + Q ≥ (5 : Int)) →
  (J + P ≥ (6 : Int)) →
  (J + H ≥ (9 : Int)) →
  (J + G ≥ (8 : Int)) →
  (J + B ≥ (5 : Int)) →
  (J + A ≥ (9 : Int)) →
  (J + S ≥ (8 : Int)) →
  (I + (-1 : Int) * B ≥ (0 : Int)) →
  (I + O ≥ (5 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (3 : Int)) →
  (I + J ≥ (5 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (2 : Int)) →
  (I + A ≥ (6 : Int)) →
  (I + S ≥ (5 : Int)) →
  (H + (-1 : Int) * O ≥ (1 : Int)) →
  (H + (-1 : Int) * Q ≥ (3 : Int)) →
  (H + (-1 : Int) * P ≥ (2 : Int)) →
  (H + O ≥ (9 : Int)) →
  (H + Q ≥ (6 : Int)) →
  (H + P ≥ (7 : Int)) →
  (G + (-1 : Int) * O ≥ (0 : Int)) →
  (G + (-1 : Int) * Q ≥ (2 : Int)) →
  (G + (-1 : Int) * P ≥ (1 : Int)) →
  (G + O ≥ (8 : Int)) →
  (G + Q ≥ (5 : Int)) →
  (G + P ≥ (6 : Int)) →
  (G + H ≥ (9 : Int)) →
  (F + (-1 : Int) * O ≥ (2 : Int)) →
  (F + (-1 : Int) * Q ≥ (4 : Int)) →
  (F + (-1 : Int) * P ≥ (3 : Int)) →
  (F + (-1 : Int) * N ≥ (3 : Int)) →
  (F + (-1 : Int) * M ≥ (2 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (5 : Int)) →
  (F + (-1 : Int) * H ≥ (0 : Int)) →
  (F + (-1 : Int) * G ≥ (2 : Int)) →
  (F + (-1 : Int) * D ≥ (2 : Int)) →
  (F + (-1 : Int) * C ≥ (5 : Int)) →
  (F + (-1 : Int) * B ≥ (5 : Int)) →
  (F + (-1 : Int) * A ≥ (0 : Int)) →
  (F + (-1 : Int) * S ≥ (1 : Int)) →
  (F + O ≥ (10 : Int)) →
  (F + Q ≥ (7 : Int)) →
  (F + P ≥ (8 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (10 : Int)) →
  (F + L ≥ (12 : Int)) →
  (F + K ≥ (13 : Int)) →
  (F + J ≥ (10 : Int)) →
  (F + I ≥ (7 : Int)) →
  (F + H ≥ (11 : Int)) →
  (F + G ≥ (10 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (7 : Int)) →
  (F + B ≥ (7 : Int)) →
  (F + A ≥ (11 : Int)) →
  (F + S ≥ (10 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + O ≥ (5 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (7 : Int)) →
  (E + K ≥ (8 : Int)) →
  (E + J ≥ (5 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (7 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (2 : Int)) →
  (E + A ≥ (6 : Int)) →
  (E + S ≥ (5 : Int)) →
  (D + (-1 : Int) * O ≥ (0 : Int)) →
  (D + (-1 : Int) * Q ≥ (2 : Int)) →
  (D + (-1 : Int) * P ≥ (1 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + (-1 : Int) * B ≥ (3 : Int)) →
  (D + O ≥ (8 : Int)) →
  (D + Q ≥ (5 : Int)) →
  (D + P ≥ (6 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (8 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (9 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (5 : Int)) →
  (D + A ≥ (9 : Int)) →
  (D + S ≥ (8 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * B ≥ (0 : Int)) →
  (C + O ≥ (5 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (7 : Int)) →
  (C + K ≥ (8 : Int)) →
  (C + J ≥ (5 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (2 : Int)) →
  (C + A ≥ (6 : Int)) →
  (C + S ≥ (5 : Int)) →
  (B + O ≥ (5 : Int)) →
  (B + Q ≥ (2 : Int)) →
  (B + P ≥ (3 : Int)) →
  (B + H ≥ (6 : Int)) →
  (B + G ≥ (5 : Int)) →
  (A + (-1 : Int) * O ≥ (1 : Int)) →
  (A + (-1 : Int) * Q ≥ (3 : Int)) →
  (A + (-1 : Int) * P ≥ (2 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (1 : Int)) →
  (A + (-1 : Int) * B ≥ (4 : Int)) →
  (A + O ≥ (9 : Int)) →
  (A + Q ≥ (6 : Int)) →
  (A + P ≥ (7 : Int)) →
  (A + H ≥ (10 : Int)) →
  (A + G ≥ (9 : Int)) →
  (A + B ≥ (6 : Int)) →
  (S + (-1 : Int) * O ≥ (0 : Int)) →
  (S + (-1 : Int) * Q ≥ (2 : Int)) →
  (S + (-1 : Int) * P ≥ (1 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + (-1 : Int) * B ≥ (3 : Int)) →
  (S + O ≥ (8 : Int)) →
  (S + Q ≥ (5 : Int)) →
  (S + P ≥ (6 : Int)) →
  (S + H ≥ (9 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (9 : Int)) →
  (O ≥ (4 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (2 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (6 : Int)) →
  (K ≥ (7 : Int)) →
  (J ≥ (4 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (5 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (1 : Int)) →
  (A ≥ (5 : Int)) →
  (S ≥ (4 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  (B ≤ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (3 : Int)) →
  ((-1 : Int) * N + K ≥ (4 : Int)) →
  ((-1 : Int) * N + H ≥ (2 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + A ≥ (2 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (2 : Int)) →
  ((-1 : Int) * M + K ≥ (3 : Int)) →
  ((-1 : Int) * M + H ≥ (1 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * J + H ≥ (1 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + A ≥ (1 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * I + O ≥ (2 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (4 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (0 : Int)) →
  ((-1 : Int) * I + A ≥ (4 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * F + K ≥ (1 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * E + O ≥ (2 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (1 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (5 : Int)) →
  ((-1 : Int) * E + K ≥ (6 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (4 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (5 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (0 : Int)) →
  ((-1 : Int) * E + A ≥ (4 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (2 : Int)) →
  ((-1 : Int) * D + K ≥ (3 : Int)) →
  ((-1 : Int) * D + H ≥ (1 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + A ≥ (1 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * C + O ≥ (2 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (5 : Int)) →
  ((-1 : Int) * C + K ≥ (6 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (4 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (0 : Int)) →
  ((-1 : Int) * C + A ≥ (4 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * B + O ≥ (2 : Int)) →
  ((-1 : Int) * B + Q ≥ (0 : Int)) →
  ((-1 : Int) * B + P ≥ (1 : Int)) →
  ((-1 : Int) * B + H ≥ (4 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * S + H ≥ (1 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  (Q + O ≥ (4 : Int)) →
  (Q + P ≥ (3 : Int)) →
  (P + O ≥ (5 : Int)) →
  (N + (-1 : Int) * O ≥ (0 : Int)) →
  (N + (-1 : Int) * Q ≥ (2 : Int)) →
  (N + (-1 : Int) * P ≥ (1 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + (-1 : Int) * B ≥ (2 : Int)) →
  (N + O ≥ (6 : Int)) →
  (N + Q ≥ (4 : Int)) →
  (N + P ≥ (5 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (8 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (4 : Int)) →
  (N + A ≥ (8 : Int)) →
  (N + S ≥ (7 : Int)) →
  (M + (-1 : Int) * O ≥ (1 : Int)) →
  (M + (-1 : Int) * Q ≥ (3 : Int)) →
  (M + (-1 : Int) * P ≥ (2 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + (-1 : Int) * B ≥ (3 : Int)) →
  (M + O ≥ (7 : Int)) →
  (M + Q ≥ (5 : Int)) →
  (M + P ≥ (6 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (10 : Int)) →
  (M + K ≥ (11 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (9 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (5 : Int)) →
  (M + A ≥ (9 : Int)) →
  (M + S ≥ (8 : Int)) →
  (L + (-1 : Int) * O ≥ (3 : Int)) →
  (L + (-1 : Int) * Q ≥ (5 : Int)) →
  (L + (-1 : Int) * P ≥ (4 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (5 : Int)) →
  (L + (-1 : Int) * H ≥ (0 : Int)) →
  (L + (-1 : Int) * G ≥ (2 : Int)) →
  (L + (-1 : Int) * B ≥ (5 : Int)) →
  (L + (-1 : Int) * A ≥ (0 : Int)) →
  (L + (-1 : Int) * S ≥ (1 : Int)) →
  (L + O ≥ (9 : Int)) →
  (L + Q ≥ (7 : Int)) →
  (L + P ≥ (8 : Int)) →
  (L + J ≥ (8 : Int)) →
  (L + I ≥ (7 : Int)) →
  (L + H ≥ (11 : Int)) →
  (L + G ≥ (10 : Int)) →
  (L + B ≥ (7 : Int)) →
  (L + A ≥ (11 : Int)) →
  (L + S ≥ (10 : Int)) →
  (K + (-1 : Int) * O ≥ (4 : Int)) →
  (K + (-1 : Int) * Q ≥ (6 : Int)) →
  (K + (-1 : Int) * P ≥ (5 : Int)) →
  (K + (-1 : Int) * L ≥ (1 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (6 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * G ≥ (3 : Int)) →
  (K + (-1 : Int) * B ≥ (6 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + (-1 : Int) * S ≥ (2 : Int)) →
  (K + O ≥ (10 : Int)) →
  (K + Q ≥ (8 : Int)) →
  (K + P ≥ (9 : Int)) →
  (K + L ≥ (13 : Int)) →
  (K + J ≥ (9 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + H ≥ (12 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + B ≥ (8 : Int)) →
  (K + A ≥ (12 : Int)) →
  (K + S ≥ (11 : Int)) →
  (J + (-1 : Int) * B ≥ (1 : Int)) →
  (J + O ≥ (5 : Int)) →
  (J + Q ≥ (3 : Int)) →
  (J + P ≥ (4 : Int)) →
  (J + H ≥ (7 : Int)) →
  (J + G ≥ (6 : Int)) →
  (J + B ≥ (3 : Int)) →
  (J + A ≥ (7 : Int)) →
  (J + S ≥ (6 : Int)) →
  (I + (-1 : Int) * B ≥ (0 : Int)) →
  (I + O ≥ (4 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (3 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (2 : Int)) →
  (I + A ≥ (6 : Int)) →
  (I + S ≥ (5 : Int)) →
  (H + (-1 : Int) * O ≥ (2 : Int)) →
  (H + (-1 : Int) * Q ≥ (4 : Int)) →
  (H + (-1 : Int) * P ≥ (3 : Int)) →
  (H + O ≥ (8 : Int)) →
  (H + Q ≥ (6 : Int)) →
  (H + P ≥ (7 : Int)) →
  (G + (-1 : Int) * O ≥ (1 : Int)) →
  (G + (-1 : Int) * Q ≥ (3 : Int)) →
  (G + (-1 : Int) * P ≥ (2 : Int)) →
  (G + O ≥ (7 : Int)) →
  (G + Q ≥ (5 : Int)) →
  (G + P ≥ (6 : Int)) →
  (G + H ≥ (9 : Int)) →
  (F + (-1 : Int) * O ≥ (3 : Int)) →
  (F + (-1 : Int) * Q ≥ (5 : Int)) →
  (F + (-1 : Int) * P ≥ (4 : Int)) →
  (F + (-1 : Int) * N ≥ (3 : Int)) →
  (F + (-1 : Int) * M ≥ (2 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (5 : Int)) →
  (F + (-1 : Int) * H ≥ (0 : Int)) →
  (F + (-1 : Int) * G ≥ (2 : Int)) →
  (F + (-1 : Int) * D ≥ (2 : Int)) →
  (F + (-1 : Int) * C ≥ (5 : Int)) →
  (F + (-1 : Int) * B ≥ (5 : Int)) →
  (F + (-1 : Int) * A ≥ (0 : Int)) →
  (F + (-1 : Int) * S ≥ (1 : Int)) →
  (F + O ≥ (9 : Int)) →
  (F + Q ≥ (7 : Int)) →
  (F + P ≥ (8 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (10 : Int)) →
  (F + L ≥ (12 : Int)) →
  (F + K ≥ (13 : Int)) →
  (F + J ≥ (8 : Int)) →
  (F + I ≥ (7 : Int)) →
  (F + H ≥ (11 : Int)) →
  (F + G ≥ (10 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (7 : Int)) →
  (F + B ≥ (7 : Int)) →
  (F + A ≥ (11 : Int)) →
  (F + S ≥ (10 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + O ≥ (4 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (7 : Int)) →
  (E + K ≥ (8 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (7 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (2 : Int)) →
  (E + A ≥ (6 : Int)) →
  (E + S ≥ (5 : Int)) →
  (D + (-1 : Int) * O ≥ (1 : Int)) →
  (D + (-1 : Int) * Q ≥ (3 : Int)) →
  (D + (-1 : Int) * P ≥ (2 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + (-1 : Int) * B ≥ (3 : Int)) →
  (D + O ≥ (7 : Int)) →
  (D + Q ≥ (5 : Int)) →
  (D + P ≥ (6 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (9 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (5 : Int)) →
  (D + A ≥ (9 : Int)) →
  (D + S ≥ (8 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * B ≥ (0 : Int)) →
  (C + O ≥ (4 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (7 : Int)) →
  (C + K ≥ (8 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (2 : Int)) →
  (C + A ≥ (6 : Int)) →
  (C + S ≥ (5 : Int)) →
  (B + O ≥ (4 : Int)) →
  (B + Q ≥ (2 : Int)) →
  (B + P ≥ (3 : Int)) →
  (B + H ≥ (6 : Int)) →
  (B + G ≥ (5 : Int)) →
  (A + (-1 : Int) * O ≥ (2 : Int)) →
  (A + (-1 : Int) * Q ≥ (4 : Int)) →
  (A + (-1 : Int) * P ≥ (3 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (1 : Int)) →
  (A + (-1 : Int) * B ≥ (4 : Int)) →
  (A + O ≥ (8 : Int)) →
  (A + Q ≥ (6 : Int)) →
  (A + P ≥ (7 : Int)) →
  (A + H ≥ (10 : Int)) →
  (A + G ≥ (9 : Int)) →
  (A + B ≥ (6 : Int)) →
  (S + (-1 : Int) * O ≥ (1 : Int)) →
  (S + (-1 : Int) * Q ≥ (3 : Int)) →
  (S + (-1 : Int) * P ≥ (2 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + (-1 : Int) * B ≥ (3 : Int)) →
  (S + O ≥ (7 : Int)) →
  (S + Q ≥ (5 : Int)) →
  (S + P ≥ (6 : Int)) →
  (S + H ≥ (9 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (9 : Int)) →
  (O ≥ (3 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (2 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (6 : Int)) →
  (K ≥ (7 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (5 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (1 : Int)) →
  (A ≥ (5 : Int)) →
  (S ≥ (4 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  (B ≤ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * N + Q ≥ (1 : Int)) →
  ((-1 : Int) * N + P ≥ (2 : Int)) →
  ((-1 : Int) * N + L ≥ (3 : Int)) →
  ((-1 : Int) * N + K ≥ (4 : Int)) →
  ((-1 : Int) * N + H ≥ (2 : Int)) →
  ((-1 : Int) * N + G ≥ (1 : Int)) →
  ((-1 : Int) * N + A ≥ (2 : Int)) →
  ((-1 : Int) * N + S ≥ (1 : Int)) →
  ((-1 : Int) * M + Q ≥ (0 : Int)) →
  ((-1 : Int) * M + P ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (-1 : Int)) →
  ((-1 : Int) * M + L ≥ (2 : Int)) →
  ((-1 : Int) * M + K ≥ (3 : Int)) →
  ((-1 : Int) * M + H ≥ (1 : Int)) →
  ((-1 : Int) * M + G ≥ (0 : Int)) →
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * M + S ≥ (0 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * J + Q ≥ (0 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + H ≥ (1 : Int)) →
  ((-1 : Int) * J + G ≥ (0 : Int)) →
  ((-1 : Int) * J + A ≥ (1 : Int)) →
  ((-1 : Int) * J + S ≥ (0 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * O ≥ (-2 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * I + O ≥ (0 : Int)) →
  ((-1 : Int) * I + Q ≥ (3 : Int)) →
  ((-1 : Int) * I + P ≥ (4 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (4 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (0 : Int)) →
  ((-1 : Int) * I + A ≥ (4 : Int)) →
  ((-1 : Int) * I + S ≥ (3 : Int)) →
  ((-1 : Int) * H + P ≥ (0 : Int)) →
  ((-1 : Int) * G + Q ≥ (0 : Int)) →
  ((-1 : Int) * G + P ≥ (1 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * F + K ≥ (1 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * O ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * E + O ≥ (0 : Int)) →
  ((-1 : Int) * E + Q ≥ (3 : Int)) →
  ((-1 : Int) * E + P ≥ (4 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (5 : Int)) →
  ((-1 : Int) * E + K ≥ (6 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + H ≥ (4 : Int)) →
  ((-1 : Int) * E + G ≥ (3 : Int)) →
  ((-1 : Int) * E + F ≥ (5 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (0 : Int)) →
  ((-1 : Int) * E + A ≥ (4 : Int)) →
  ((-1 : Int) * E + S ≥ (3 : Int)) →
  ((-1 : Int) * D + Q ≥ (0 : Int)) →
  ((-1 : Int) * D + P ≥ (1 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + M ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (2 : Int)) →
  ((-1 : Int) * D + K ≥ (3 : Int)) →
  ((-1 : Int) * D + H ≥ (1 : Int)) →
  ((-1 : Int) * D + G ≥ (0 : Int)) →
  ((-1 : Int) * D + A ≥ (1 : Int)) →
  ((-1 : Int) * D + S ≥ (0 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * O ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * C + O ≥ (0 : Int)) →
  ((-1 : Int) * C + Q ≥ (3 : Int)) →
  ((-1 : Int) * C + P ≥ (4 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (5 : Int)) →
  ((-1 : Int) * C + K ≥ (6 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (4 : Int)) →
  ((-1 : Int) * C + G ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (0 : Int)) →
  ((-1 : Int) * C + A ≥ (4 : Int)) →
  ((-1 : Int) * C + S ≥ (3 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * O ≥ (-2 : Int)) →
  ((-1 : Int) * B + O ≥ (0 : Int)) →
  ((-1 : Int) * B + Q ≥ (3 : Int)) →
  ((-1 : Int) * B + P ≥ (4 : Int)) →
  ((-1 : Int) * B + H ≥ (4 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * A + P ≥ (0 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + H ≥ (1 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  (Q + (-1 : Int) * O ≥ (3 : Int)) →
  (Q + O ≥ (5 : Int)) →
  (Q + P ≥ (9 : Int)) →
  (P + (-1 : Int) * O ≥ (4 : Int)) →
  (P + O ≥ (6 : Int)) →
  (N + (-1 : Int) * O ≥ (2 : Int)) →
  (N + (-1 : Int) * J ≥ (-1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * G ≥ (-1 : Int)) →
  (N + (-1 : Int) * B ≥ (2 : Int)) →
  (N + O ≥ (4 : Int)) →
  (N + Q ≥ (7 : Int)) →
  (N + P ≥ (8 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + H ≥ (8 : Int)) →
  (N + G ≥ (7 : Int)) →
  (N + B ≥ (4 : Int)) →
  (N + A ≥ (8 : Int)) →
  (N + S ≥ (7 : Int)) →
  (M + (-1 : Int) * O ≥ (3 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (0 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * G ≥ (0 : Int)) →
  (M + (-1 : Int) * B ≥ (3 : Int)) →
  (M + O ≥ (5 : Int)) →
  (M + Q ≥ (8 : Int)) →
  (M + P ≥ (9 : Int)) →
  (M + N ≥ (7 : Int)) →
  (M + L ≥ (10 : Int)) →
  (M + K ≥ (11 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + H ≥ (9 : Int)) →
  (M + G ≥ (8 : Int)) →
  (M + B ≥ (5 : Int)) →
  (M + A ≥ (9 : Int)) →
  (M + S ≥ (8 : Int)) →
  (L + (-1 : Int) * O ≥ (5 : Int)) →
  (L + (-1 : Int) * Q ≥ (1 : Int)) →
  (L + (-1 : Int) * P ≥ (0 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (5 : Int)) →
  (L + (-1 : Int) * H ≥ (0 : Int)) →
  (L + (-1 : Int) * G ≥ (2 : Int)) →
  (L + (-1 : Int) * B ≥ (5 : Int)) →
  (L + (-1 : Int) * A ≥ (0 : Int)) →
  (L + (-1 : Int) * S ≥ (1 : Int)) →
  (L + O ≥ (7 : Int)) →
  (L + Q ≥ (10 : Int)) →
  (L + P ≥ (11 : Int)) →
  (L + J ≥ (8 : Int)) →
  (L + I ≥ (7 : Int)) →
  (L + H ≥ (11 : Int)) →
  (L + G ≥ (10 : Int)) →
  (L + B ≥ (7 : Int)) →
  (L + A ≥ (11 : Int)) →
  (L + S ≥ (10 : Int)) →
  (K + (-1 : Int) * O ≥ (6 : Int)) →
  (K + (-1 : Int) * Q ≥ (2 : Int)) →
  (K + (-1 : Int) * P ≥ (1 : Int)) →
  (K + (-1 : Int) * L ≥ (1 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (6 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * G ≥ (3 : Int)) →
  (K + (-1 : Int) * B ≥ (6 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + (-1 : Int) * S ≥ (2 : Int)) →
  (K + O ≥ (8 : Int)) →
  (K + Q ≥ (11 : Int)) →
  (K + P ≥ (12 : Int)) →
  (K + L ≥ (13 : Int)) →
  (K + J ≥ (9 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + H ≥ (12 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + B ≥ (8 : Int)) →
  (K + A ≥ (12 : Int)) →
  (K + S ≥ (11 : Int)) →
  (J + (-1 : Int) * O ≥ (1 : Int)) →
  (J + (-1 : Int) * B ≥ (1 : Int)) →
  (J + O ≥ (3 : Int)) →
  (J + Q ≥ (6 : Int)) →
  (J + P ≥ (7 : Int)) →
  (J + H ≥ (7 : Int)) →
  (J + G ≥ (6 : Int)) →
  (J + B ≥ (3 : Int)) →
  (J + A ≥ (7 : Int)) →
  (J + S ≥ (6 : Int)) →
  (I + (-1 : Int) * O ≥ (0 : Int)) →
  (I + (-1 : Int) * B ≥ (0 : Int)) →
  (I + O ≥ (2 : Int)) →
  (I + Q ≥ (5 : Int)) →
  (I + P ≥ (6 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (5 : Int)) →
  (I + B ≥ (2 : Int)) →
  (I + A ≥ (6 : Int)) →
  (I + S ≥ (5 : Int)) →
  (H + (-1 : Int) * O ≥ (4 : Int)) →
  (H + (-1 : Int) * Q ≥ (1 : Int)) →
  (H + (-1 : Int) * P ≥ (0 : Int)) →
  (H + O ≥ (6 : Int)) →
  (H + Q ≥ (9 : Int)) →
  (H + P ≥ (10 : Int)) →
  (G + (-1 : Int) * O ≥ (3 : Int)) →
  (G + O ≥ (5 : Int)) →
  (G + Q ≥ (8 : Int)) →
  (G + P ≥ (9 : Int)) →
  (G + H ≥ (9 : Int)) →
  (F + (-1 : Int) * O ≥ (5 : Int)) →
  (F + (-1 : Int) * Q ≥ (1 : Int)) →
  (F + (-1 : Int) * P ≥ (0 : Int)) →
  (F + (-1 : Int) * N ≥ (3 : Int)) →
  (F + (-1 : Int) * M ≥ (2 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (5 : Int)) →
  (F + (-1 : Int) * H ≥ (0 : Int)) →
  (F + (-1 : Int) * G ≥ (2 : Int)) →
  (F + (-1 : Int) * D ≥ (2 : Int)) →
  (F + (-1 : Int) * C ≥ (5 : Int)) →
  (F + (-1 : Int) * B ≥ (5 : Int)) →
  (F + (-1 : Int) * A ≥ (0 : Int)) →
  (F + (-1 : Int) * S ≥ (1 : Int)) →
  (F + O ≥ (7 : Int)) →
  (F + Q ≥ (10 : Int)) →
  (F + P ≥ (11 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (10 : Int)) →
  (F + L ≥ (12 : Int)) →
  (F + K ≥ (13 : Int)) →
  (F + J ≥ (8 : Int)) →
  (F + I ≥ (7 : Int)) →
  (F + H ≥ (11 : Int)) →
  (F + G ≥ (10 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (7 : Int)) →
  (F + B ≥ (7 : Int)) →
  (F + A ≥ (11 : Int)) →
  (F + S ≥ (10 : Int)) →
  (E + (-1 : Int) * O ≥ (0 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + O ≥ (2 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (6 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (7 : Int)) →
  (E + K ≥ (8 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (7 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (2 : Int)) →
  (E + A ≥ (6 : Int)) →
  (E + S ≥ (5 : Int)) →
  (D + (-1 : Int) * O ≥ (3 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (0 : Int)) →
  (D + (-1 : Int) * J ≥ (0 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (0 : Int)) →
  (D + (-1 : Int) * B ≥ (3 : Int)) →
  (D + O ≥ (5 : Int)) →
  (D + Q ≥ (8 : Int)) →
  (D + P ≥ (9 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (8 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + H ≥ (9 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + B ≥ (5 : Int)) →
  (D + A ≥ (9 : Int)) →
  (D + S ≥ (8 : Int)) →
  (C + (-1 : Int) * O ≥ (0 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * B ≥ (0 : Int)) →
  (C + O ≥ (2 : Int)) →
  (C + Q ≥ (5 : Int)) →
  (C + P ≥ (6 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (7 : Int)) →
  (C + K ≥ (8 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + G ≥ (5 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (2 : Int)) →
  (C + A ≥ (6 : Int)) →
  (C + S ≥ (5 : Int)) →
  (B + (-1 : Int) * O ≥ (0 : Int)) →
  (B + O ≥ (2 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (6 : Int)) →
  (B + H ≥ (6 : Int)) →
  (B + G ≥ (5 : Int)) →
  (A + (-1 : Int) * O ≥ (4 : Int)) →
  (A + (-1 : Int) * Q ≥ (1 : Int)) →
  (A + (-1 : Int) * P ≥ (0 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * G ≥ (1 : Int)) →
  (A + (-1 : Int) * B ≥ (4 : Int)) →
  (A + O ≥ (6 : Int)) →
  (A + Q ≥ (9 : Int)) →
  (A + P ≥ (10 : Int)) →
  (A + H ≥ (10 : Int)) →
  (A + G ≥ (9 : Int)) →
  (A + B ≥ (6 : Int)) →
  (S + (-1 : Int) * O ≥ (3 : Int)) →
  (S + (-1 : Int) * Q ≥ (0 : Int)) →
  (S + (-1 : Int) * G ≥ (0 : Int)) →
  (S + (-1 : Int) * B ≥ (3 : Int)) →
  (S + O ≥ (5 : Int)) →
  (S + Q ≥ (8 : Int)) →
  (S + P ≥ (9 : Int)) →
  (S + H ≥ (9 : Int)) →
  (S + G ≥ (8 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (9 : Int)) →
  (O ≥ (1 : Int)) →
  (Q ≥ (4 : Int)) →
  (P ≥ (5 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (6 : Int)) →
  (K ≥ (7 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (H ≥ (5 : Int)) →
  (G ≥ (4 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (1 : Int)) →
  (A ≥ (5 : Int)) →
  (S ≥ (4 : Int)) →
  (O ≤ (1 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  (B ≤ (1 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  r3 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r1 S A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r4 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r2 S A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r4 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 S A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r2 P A B C D E F G H I J K L M N R Q S O) →
  (True) →
  r1 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 P A B C D E F G H I J K L M N S Q R O) →
  (True) →
  r1 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r2 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r1 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r2 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r1 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r2 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r1 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r2 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r1 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r2 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r1 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r2 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r1 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r2 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r1 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r2 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r1 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r2 P A B C D E F G H I J K L M N R Q S O) →
  (True) →
  r2 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 P A B C D E F G H I J K L M N S Q R O) →
  (True) →
  r2 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r2 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r2 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r2 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r2 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r2 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r2 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r2 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r2 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r2 Q A B C D E F G H I J K L M N P R S O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r2 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N P R S O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N P R S O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r2 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N P R S O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r2 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N P R S O) →
  (r4 Q A B C D E F G H I J K L M N T S R O) →
  (r2 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r4 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r4 Q A B C D E F G H I J K L M N P R S O) →
  (r2 Q A B C D E F G H I J K L M N T S R O) →
  (r4 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r4 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r4 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r2 P A B C D E F G H I J K L M N S Q R O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r2 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N S Q R O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N S Q R O) →
  (r4 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r2 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r4 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r4 P A B C D E F G H I J K L M N S Q R O) →
  (r2 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r4 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r4 P A B C D E F G H I J K L M N S R Q O) →
  (r2 P A B C D E F G H I J K L M N S Q R O) →
  (True) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r2 P A B C D E F G H I J K L M N S R Q O) →
  (r4 P A B C D E F G H I J K L M N S Q R O) →
  (True) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r0 P A B C D E F G H I J K L M N S R Q O) →
  (r2 P A B C D E F G H I J K L M N S R Q O) →
  (True) →
  r5) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 P A B C D E F G H I J K L M N S R Q O) →
  (r4 P A B C D E F G H I J K L M N S R Q O) →
  (True) →
  r5) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r5) →
  False))))))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«fortune-full.12_000»
