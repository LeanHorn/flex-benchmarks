import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«graham-scan.30_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":809:1-809:12 (check-sat, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":11:1-153:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":154:1-292:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":293:1-303:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":304:1-314:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":315:1-325:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":326:1-336:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":337:1-347:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":348:1-360:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":361:1-373:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":374:1-386:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":387:1-401:2 (clause 11, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":402:1-416:2 (clause 12, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":417:1-431:2 (clause 13, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":432:1-446:2 (clause 14, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":447:1-461:2 (clause 15, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":462:1-472:2 (clause 16, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":473:1-483:2 (clause 17, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":484:1-496:2 (clause 18, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":497:1-509:2 (clause 19, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":510:1-522:2 (clause 20, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":523:1-537:2 (clause 21, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":538:1-552:2 (clause 22, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":553:1-567:2 (clause 23, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":568:1-582:2 (clause 24, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":583:1-597:2 (clause 25, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":598:1-613:2 (clause 26, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":614:1-629:2 (clause 27, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":630:1-645:2 (clause 28, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":646:1-661:2 (clause 29, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":662:1-677:2 (clause 30, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":678:1-693:2 (clause 31, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":694:1-707:2 (clause 32, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":708:1-721:2 (clause 33, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":722:1-735:2 (clause 34, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":736:1-749:2 (clause 35, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":750:1-761:2 (clause 36, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":762:1-773:2 (clause 37, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":774:1-785:2 (clause 38, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":786:1-797:2 (clause 39, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan.30_000.smt2":798:1-807:2 (clause 40, command 47)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L : Int),
  ((-1 : Int) * J + H ≥ (2 : Int)) →
  ((-1 : Int) * I + H ≥ (1 : Int)) →
  ((-1 : Int) * G + L ≥ (-1 : Int)) →
  ((-1 : Int) * G + C ≥ (1 : Int)) →
  ((-1 : Int) * G + B ≥ (0 : Int)) →
  ((-1 : Int) * F + L ≥ (1 : Int)) →
  ((-1 : Int) * F + J ≥ (0 : Int)) →
  ((-1 : Int) * F + I ≥ (1 : Int)) →
  ((-1 : Int) * F + G ≥ (2 : Int)) →
  ((-1 : Int) * F + C ≥ (3 : Int)) →
  ((-1 : Int) * F + B ≥ (2 : Int)) →
  ((-1 : Int) * F + H ≥ (2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * D + L ≥ (-3 : Int)) →
  ((-1 : Int) * D + G ≥ (-2 : Int)) →
  ((-1 : Int) * D + E ≥ (-1 : Int)) →
  ((-1 : Int) * D + C ≥ (-1 : Int)) →
  ((-1 : Int) * D + B ≥ (-2 : Int)) →
  ((-1 : Int) * D + A ≥ (-1 : Int)) →
  ((-1 : Int) * C + L ≥ (-2 : Int)) →
  ((-1 : Int) * C + B ≥ (-1 : Int)) →
  ((-1 : Int) * B + L ≥ (-1 : Int)) →
  (L + (-1 : Int) * J ≥ (1 : Int)) →
  (L + (-1 : Int) * I ≥ (0 : Int)) →
  (L + (-1 : Int) * H ≥ (-1 : Int)) →
  (L + J ≥ (3 : Int)) →
  (L + I ≥ (4 : Int)) →
  (L + H ≥ (5 : Int)) →
  (J + (-1 : Int) * I ≥ (-1 : Int)) →
  (J + I ≥ (3 : Int)) →
  (J + H ≥ (4 : Int)) →
  (I + H ≥ (5 : Int)) →
  (G + (-1 : Int) * L ≥ (1 : Int)) →
  (G + (-1 : Int) * J ≥ (2 : Int)) →
  (G + (-1 : Int) * I ≥ (1 : Int)) →
  (G + (-1 : Int) * C ≥ (-1 : Int)) →
  (G + (-1 : Int) * B ≥ (0 : Int)) →
  (G + (-1 : Int) * H ≥ (0 : Int)) →
  (G + L ≥ (5 : Int)) →
  (G + J ≥ (4 : Int)) →
  (G + I ≥ (5 : Int)) →
  (G + C ≥ (7 : Int)) →
  (G + B ≥ (6 : Int)) →
  (G + H ≥ (6 : Int)) →
  (F + L ≥ (3 : Int)) →
  (F + J ≥ (2 : Int)) →
  (F + I ≥ (3 : Int)) →
  (F + G ≥ (4 : Int)) →
  (F + C ≥ (5 : Int)) →
  (F + B ≥ (4 : Int)) →
  (F + H ≥ (4 : Int)) →
  (E + (-1 : Int) * L ≥ (2 : Int)) →
  (E + (-1 : Int) * J ≥ (3 : Int)) →
  (E + (-1 : Int) * I ≥ (2 : Int)) →
  (E + (-1 : Int) * G ≥ (1 : Int)) →
  (E + (-1 : Int) * F ≥ (4 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + (-1 : Int) * B ≥ (1 : Int)) →
  (E + (-1 : Int) * A ≥ (0 : Int)) →
  (E + (-1 : Int) * H ≥ (1 : Int)) →
  (E + L ≥ (7 : Int)) →
  (E + J ≥ (6 : Int)) →
  (E + I ≥ (7 : Int)) →
  (E + G ≥ (8 : Int)) →
  (E + F ≥ (6 : Int)) →
  (E + C ≥ (9 : Int)) →
  (E + B ≥ (8 : Int)) →
  (E + A ≥ (10 : Int)) →
  (E + H ≥ (8 : Int)) →
  (D + (-1 : Int) * L ≥ (3 : Int)) →
  (D + (-1 : Int) * J ≥ (4 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * G ≥ (2 : Int)) →
  (D + (-1 : Int) * F ≥ (4 : Int)) →
  (D + (-1 : Int) * C ≥ (1 : Int)) →
  (D + (-1 : Int) * B ≥ (2 : Int)) →
  (D + (-1 : Int) * H ≥ (2 : Int)) →
  (D + L ≥ (7 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (7 : Int)) →
  (D + G ≥ (8 : Int)) →
  (D + F ≥ (6 : Int)) →
  (D + E ≥ (10 : Int)) →
  (D + C ≥ (9 : Int)) →
  (D + B ≥ (8 : Int)) →
  (D + A ≥ (10 : Int)) →
  (D + H ≥ (8 : Int)) →
  (C + (-1 : Int) * L ≥ (2 : Int)) →
  (C + (-1 : Int) * J ≥ (3 : Int)) →
  (C + (-1 : Int) * I ≥ (2 : Int)) →
  (C + (-1 : Int) * B ≥ (1 : Int)) →
  (C + (-1 : Int) * H ≥ (1 : Int)) →
  (C + L ≥ (6 : Int)) →
  (C + J ≥ (5 : Int)) →
  (C + I ≥ (6 : Int)) →
  (C + B ≥ (7 : Int)) →
  (C + H ≥ (7 : Int)) →
  (B + (-1 : Int) * L ≥ (1 : Int)) →
  (B + (-1 : Int) * J ≥ (2 : Int)) →
  (B + (-1 : Int) * I ≥ (1 : Int)) →
  (B + (-1 : Int) * H ≥ (0 : Int)) →
  (B + L ≥ (5 : Int)) →
  (B + J ≥ (4 : Int)) →
  (B + I ≥ (5 : Int)) →
  (B + H ≥ (6 : Int)) →
  (A + (-1 : Int) * L ≥ (2 : Int)) →
  (A + (-1 : Int) * J ≥ (3 : Int)) →
  (A + (-1 : Int) * I ≥ (2 : Int)) →
  (A + (-1 : Int) * G ≥ (1 : Int)) →
  (A + (-1 : Int) * F ≥ (4 : Int)) →
  (A + (-1 : Int) * C ≥ (0 : Int)) →
  (A + (-1 : Int) * B ≥ (1 : Int)) →
  (A + (-1 : Int) * H ≥ (1 : Int)) →
  (A + L ≥ (7 : Int)) →
  (A + J ≥ (6 : Int)) →
  (A + I ≥ (7 : Int)) →
  (A + G ≥ (8 : Int)) →
  (A + F ≥ (6 : Int)) →
  (A + C ≥ (9 : Int)) →
  (A + B ≥ (8 : Int)) →
  (A + H ≥ (8 : Int)) →
  (L ≥ (2 : Int)) →
  (J ≥ (1 : Int)) →
  (I ≥ (2 : Int)) →
  (G ≥ (3 : Int)) →
  (F ≥ (1 : Int)) →
  (E ≥ (5 : Int)) →
  (D ≥ (5 : Int)) →
  (C ≥ (4 : Int)) →
  (B ≥ (3 : Int)) →
  (A ≥ (5 : Int)) →
  (H ≥ (3 : Int)) →
  (F ≤ (1 : Int)) →
  ((-1 : Int) * J + I ≥ (1 : Int)) →
  r2 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  ((-1 : Int) * L + I ≥ (1 : Int)) →
  ((-1 : Int) * L + H ≥ (2 : Int)) →
  ((-1 : Int) * J + I ≥ (1 : Int)) →
  ((-1 : Int) * J + H ≥ (2 : Int)) →
  ((-1 : Int) * I + H ≥ (1 : Int)) →
  ((-1 : Int) * G + L ≥ (-1 : Int)) →
  ((-1 : Int) * G + J ≥ (-1 : Int)) →
  ((-1 : Int) * G + I ≥ (0 : Int)) →
  ((-1 : Int) * G + C ≥ (1 : Int)) →
  ((-1 : Int) * G + B ≥ (0 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * F + J ≥ (0 : Int)) →
  ((-1 : Int) * F + I ≥ (1 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + C ≥ (2 : Int)) →
  ((-1 : Int) * F + B ≥ (1 : Int)) →
  ((-1 : Int) * F + H ≥ (2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * D + C ≥ (-1 : Int)) →
  ((-1 : Int) * D + H ≥ (-1 : Int)) →
  ((-1 : Int) * C + H ≥ (0 : Int)) →
  ((-1 : Int) * B + L ≥ (-1 : Int)) →
  ((-1 : Int) * B + J ≥ (-1 : Int)) →
  ((-1 : Int) * B + I ≥ (0 : Int)) →
  ((-1 : Int) * B + H ≥ (1 : Int)) →
  (L + (-1 : Int) * J ≥ (0 : Int)) →
  (L + (-1 : Int) * I ≥ (-1 : Int)) →
  (L + J ≥ (2 : Int)) →
  (L + I ≥ (3 : Int)) →
  (L + H ≥ (4 : Int)) →
  (J + (-1 : Int) * I ≥ (-1 : Int)) →
  (J + I ≥ (3 : Int)) →
  (J + H ≥ (4 : Int)) →
  (I + H ≥ (5 : Int)) →
  (G + (-1 : Int) * L ≥ (1 : Int)) →
  (G + (-1 : Int) * J ≥ (1 : Int)) →
  (G + (-1 : Int) * I ≥ (0 : Int)) →
  (G + (-1 : Int) * B ≥ (0 : Int)) →
  (G + L ≥ (3 : Int)) →
  (G + J ≥ (3 : Int)) →
  (G + I ≥ (4 : Int)) →
  (G + C ≥ (5 : Int)) →
  (G + B ≥ (4 : Int)) →
  (G + H ≥ (5 : Int)) →
  (F + L ≥ (2 : Int)) →
  (F + J ≥ (2 : Int)) →
  (F + I ≥ (3 : Int)) →
  (F + G ≥ (3 : Int)) →
  (F + C ≥ (4 : Int)) →
  (F + B ≥ (3 : Int)) →
  (F + H ≥ (4 : Int)) →
  (E + (-1 : Int) * L ≥ (2 : Int)) →
  (E + (-1 : Int) * J ≥ (2 : Int)) →
  (E + (-1 : Int) * I ≥ (1 : Int)) →
  (E + (-1 : Int) * G ≥ (1 : Int)) →
  (E + (-1 : Int) * F ≥ (4 : Int)) →
  (E + (-1 : Int) * B ≥ (1 : Int)) →
  (E + (-1 : Int) * A ≥ (0 : Int)) →
  (E + L ≥ (6 : Int)) →
  (E + J ≥ (6 : Int)) →
  (E + I ≥ (7 : Int)) →
  (E + G ≥ (7 : Int)) →
  (E + F ≥ (6 : Int)) →
  (E + C ≥ (8 : Int)) →
  (E + B ≥ (7 : Int)) →
  (E + A ≥ (10 : Int)) →
  (E + H ≥ (8 : Int)) →
  (D + (-1 : Int) * L ≥ (3 : Int)) →
  (D + (-1 : Int) * J ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (2 : Int)) →
  (D + (-1 : Int) * G ≥ (2 : Int)) →
  (D + (-1 : Int) * F ≥ (3 : Int)) →
  (D + (-1 : Int) * C ≥ (1 : Int)) →
  (D + (-1 : Int) * B ≥ (2 : Int)) →
  (D + (-1 : Int) * H ≥ (1 : Int)) →
  (D + L ≥ (5 : Int)) →
  (D + J ≥ (5 : Int)) →
  (D + I ≥ (6 : Int)) →
  (D + G ≥ (6 : Int)) →
  (D + F ≥ (5 : Int)) →
  (D + E ≥ (9 : Int)) →
  (D + C ≥ (7 : Int)) →
  (D + B ≥ (6 : Int)) →
  (D + A ≥ (9 : Int)) →
  (D + H ≥ (7 : Int)) →
  (C + (-1 : Int) * L ≥ (2 : Int)) →
  (C + (-1 : Int) * J ≥ (2 : Int)) →
  (C + (-1 : Int) * I ≥ (1 : Int)) →
  (C + (-1 : Int) * B ≥ (1 : Int)) →
  (C + (-1 : Int) * H ≥ (0 : Int)) →
  (C + L ≥ (4 : Int)) →
  (C + J ≥ (4 : Int)) →
  (C + I ≥ (5 : Int)) →
  (C + B ≥ (5 : Int)) →
  (C + H ≥ (6 : Int)) →
  (B + (-1 : Int) * L ≥ (1 : Int)) →
  (B + (-1 : Int) * J ≥ (1 : Int)) →
  (B + (-1 : Int) * I ≥ (0 : Int)) →
  (B + L ≥ (3 : Int)) →
  (B + J ≥ (3 : Int)) →
  (B + I ≥ (4 : Int)) →
  (B + H ≥ (5 : Int)) →
  (A + (-1 : Int) * L ≥ (2 : Int)) →
  (A + (-1 : Int) * J ≥ (2 : Int)) →
  (A + (-1 : Int) * I ≥ (1 : Int)) →
  (A + (-1 : Int) * G ≥ (1 : Int)) →
  (A + (-1 : Int) * F ≥ (4 : Int)) →
  (A + (-1 : Int) * B ≥ (1 : Int)) →
  (A + L ≥ (6 : Int)) →
  (A + J ≥ (6 : Int)) →
  (A + I ≥ (7 : Int)) →
  (A + G ≥ (7 : Int)) →
  (A + F ≥ (6 : Int)) →
  (A + C ≥ (8 : Int)) →
  (A + B ≥ (7 : Int)) →
  (A + H ≥ (8 : Int)) →
  (L ≥ (1 : Int)) →
  (J ≥ (1 : Int)) →
  (I ≥ (2 : Int)) →
  (G ≥ (2 : Int)) →
  (F ≥ (1 : Int)) →
  (E ≥ (5 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (3 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (5 : Int)) →
  (H ≥ (3 : Int)) →
  (F ≤ (1 : Int)) →
  ((-1 : Int) * L + J ≥ (0 : Int)) →
  r1 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A L B C D E F G H I J K) →
  (True) →
  r0 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r5 A L B C D E F G H I J K) →
  (True) →
  r0 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A L B C D E F G H I J K) →
  (True) →
  r4 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r5 A I B C D E F G K J L H) →
  (True) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A I B C D E F G L J K H) →
  (True) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r5 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r5 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r5 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r5 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r5 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r5 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r5 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r5 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r5 A I B C D E F G K J L H) →
  (True) →
  r5 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A I B C D E F G L J K H) →
  (True) →
  r5 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r5 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r5 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r5 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r5 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r5 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r5 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r5 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r5 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r5 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r5 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r5 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r5 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r5 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r5 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r5 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r5 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r5 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r5 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r5 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r5 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r5 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r5 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r5 A I B C D E F G L J K H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r5 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G L J K H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G L J K H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r5 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G L J K H) →
  (r5 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A I B C D E F G L K J H) →
  (r5 A I B C D E F G L J K H) →
  (True) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r5 A I B C D E F G L K J H) →
  (r0 A I B C D E F G L J K H) →
  (True) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r4 A I B C D E F G L K J H) →
  (r5 A I B C D E F G L K J H) →
  (True) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A I B C D E F G L K J H) →
  (r0 A I B C D E F G L K J H) →
  (True) →
  r3) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r3) →
  False)))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«graham-scan.30_000»
