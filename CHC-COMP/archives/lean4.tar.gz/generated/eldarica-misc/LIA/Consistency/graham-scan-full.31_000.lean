import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«graham-scan-full.31_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":910:1-910:12 (check-sat, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":9:1-143:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":144:1-293:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":294:1-450:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":451:1-461:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":462:1-472:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":473:1-483:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":484:1-496:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":497:1-509:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":510:1-522:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":523:1-537:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":538:1-552:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":553:1-567:2 (clause 12, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":568:1-582:2 (clause 13, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":583:1-597:2 (clause 14, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":598:1-608:2 (clause 15, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":609:1-621:2 (clause 16, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":622:1-634:2 (clause 17, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":635:1-647:2 (clause 18, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":648:1-662:2 (clause 19, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":663:1-677:2 (clause 20, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":678:1-692:2 (clause 21, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":693:1-707:2 (clause 22, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":708:1-722:2 (clause 23, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":723:1-738:2 (clause 24, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":739:1-754:2 (clause 25, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":755:1-770:2 (clause 26, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":771:1-786:2 (clause 27, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":787:1-802:2 (clause 28, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":803:1-818:2 (clause 29, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":819:1-832:2 (clause 30, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":833:1-846:2 (clause 31, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":847:1-860:2 (clause 32, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":861:1-874:2 (clause 33, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":875:1-886:2 (clause 34, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":887:1-898:2 (clause 35, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.31_000.smt2":899:1-908:2 (clause 36, command 41)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L : Int),
  ((-1 : Int) * J + I ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (1 : Int)) →
  ((-1 : Int) * G + B ≥ (0 : Int)) →
  ((-1 : Int) * G + L ≥ (-1 : Int)) →
  ((-1 : Int) * F + (-1 : Int) * C ≥ (-1 : Int)) →
  ((-1 : Int) * F + H ≥ (2 : Int)) →
  ((-1 : Int) * F + J ≥ (0 : Int)) →
  ((-1 : Int) * F + I ≥ (1 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + C ≥ (-1 : Int)) →
  ((-1 : Int) * F + B ≥ (1 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * D + E ≥ (-1 : Int)) →
  ((-1 : Int) * C + H ≥ (3 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (2 : Int)) →
  ((-1 : Int) * C + B ≥ (2 : Int)) →
  ((-1 : Int) * C + L ≥ (1 : Int)) →
  ((-1 : Int) * B + L ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * F ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * C ≥ (0 : Int)) →
  ((-1 : Int) * A + H ≥ (3 : Int)) →
  ((-1 : Int) * A + J ≥ (1 : Int)) →
  ((-1 : Int) * A + I ≥ (2 : Int)) →
  ((-1 : Int) * A + G ≥ (2 : Int)) →
  ((-1 : Int) * A + F ≥ (1 : Int)) →
  ((-1 : Int) * A + C ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (2 : Int)) →
  ((-1 : Int) * A + L ≥ (1 : Int)) →
  (J + (-1 : Int) * I ≥ (-1 : Int)) →
  (J + H ≥ (4 : Int)) →
  (J + I ≥ (3 : Int)) →
  (I + H ≥ (5 : Int)) →
  (G + (-1 : Int) * C ≥ (2 : Int)) →
  (G + (-1 : Int) * B ≥ (0 : Int)) →
  (G + (-1 : Int) * L ≥ (1 : Int)) →
  (G + H ≥ (5 : Int)) →
  (G + J ≥ (3 : Int)) →
  (G + I ≥ (4 : Int)) →
  (G + C ≥ (2 : Int)) →
  (G + B ≥ (4 : Int)) →
  (G + L ≥ (3 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + H ≥ (4 : Int)) →
  (F + J ≥ (2 : Int)) →
  (F + I ≥ (3 : Int)) →
  (F + G ≥ (3 : Int)) →
  (F + C ≥ (1 : Int)) →
  (F + B ≥ (3 : Int)) →
  (F + L ≥ (2 : Int)) →
  (E + (-1 : Int) * H ≥ (0 : Int)) →
  (E + (-1 : Int) * J ≥ (2 : Int)) →
  (E + (-1 : Int) * I ≥ (1 : Int)) →
  (E + (-1 : Int) * G ≥ (1 : Int)) →
  (E + (-1 : Int) * F ≥ (2 : Int)) →
  (E + (-1 : Int) * C ≥ (3 : Int)) →
  (E + (-1 : Int) * B ≥ (1 : Int)) →
  (E + (-1 : Int) * A ≥ (3 : Int)) →
  (E + (-1 : Int) * L ≥ (2 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + J ≥ (4 : Int)) →
  (E + I ≥ (5 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (4 : Int)) →
  (E + C ≥ (3 : Int)) →
  (E + B ≥ (5 : Int)) →
  (E + A ≥ (3 : Int)) →
  (E + L ≥ (4 : Int)) →
  (D + (-1 : Int) * H ≥ (1 : Int)) →
  (D + (-1 : Int) * J ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (2 : Int)) →
  (D + (-1 : Int) * G ≥ (2 : Int)) →
  (D + (-1 : Int) * F ≥ (3 : Int)) →
  (D + (-1 : Int) * E ≥ (1 : Int)) →
  (D + (-1 : Int) * C ≥ (4 : Int)) →
  (D + (-1 : Int) * B ≥ (2 : Int)) →
  (D + (-1 : Int) * A ≥ (4 : Int)) →
  (D + (-1 : Int) * L ≥ (3 : Int)) →
  (D + H ≥ (7 : Int)) →
  (D + J ≥ (5 : Int)) →
  (D + I ≥ (6 : Int)) →
  (D + G ≥ (6 : Int)) →
  (D + F ≥ (5 : Int)) →
  (D + E ≥ (7 : Int)) →
  (D + C ≥ (4 : Int)) →
  (D + B ≥ (6 : Int)) →
  (D + A ≥ (4 : Int)) →
  (D + L ≥ (5 : Int)) →
  (C + H ≥ (3 : Int)) →
  (C + J ≥ (1 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + B ≥ (2 : Int)) →
  (C + L ≥ (1 : Int)) →
  (B + (-1 : Int) * L ≥ (1 : Int)) →
  (B + H ≥ (5 : Int)) →
  (B + J ≥ (3 : Int)) →
  (B + I ≥ (4 : Int)) →
  (B + L ≥ (3 : Int)) →
  (A + (-1 : Int) * F ≥ (-1 : Int)) →
  (A + (-1 : Int) * C ≥ (0 : Int)) →
  (A + H ≥ (3 : Int)) →
  (A + J ≥ (1 : Int)) →
  (A + I ≥ (2 : Int)) →
  (A + G ≥ (2 : Int)) →
  (A + F ≥ (1 : Int)) →
  (A + C ≥ (0 : Int)) →
  (A + B ≥ (2 : Int)) →
  (A + L ≥ (1 : Int)) →
  (L + H ≥ (4 : Int)) →
  (L + J ≥ (2 : Int)) →
  (L + I ≥ (3 : Int)) →
  (H ≥ (3 : Int)) →
  (J ≥ (1 : Int)) →
  (I ≥ (2 : Int)) →
  (G ≥ (2 : Int)) →
  (F ≥ (1 : Int)) →
  (E ≥ (3 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (0 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (0 : Int)) →
  (L ≥ (1 : Int)) →
  (F ≤ (1 : Int)) →
  (C ≤ (0 : Int)) →
  (A ≤ (0 : Int)) →
  ((-1 : Int) * J + H ≥ (2 : Int)) →
  r2 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  ((-1 : Int) * J + I ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (1 : Int)) →
  ((-1 : Int) * G + B ≥ (0 : Int)) →
  ((-1 : Int) * G + L ≥ (-1 : Int)) →
  ((-1 : Int) * F + (-1 : Int) * C ≥ (-1 : Int)) →
  ((-1 : Int) * F + H ≥ (2 : Int)) →
  ((-1 : Int) * F + J ≥ (0 : Int)) →
  ((-1 : Int) * F + I ≥ (1 : Int)) →
  ((-1 : Int) * F + G ≥ (2 : Int)) →
  ((-1 : Int) * F + C ≥ (-1 : Int)) →
  ((-1 : Int) * F + B ≥ (2 : Int)) →
  ((-1 : Int) * F + L ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (0 : Int)) →
  ((-1 : Int) * E + L ≥ (-1 : Int)) →
  ((-1 : Int) * D + G ≥ (-1 : Int)) →
  ((-1 : Int) * D + E ≥ (-1 : Int)) →
  ((-1 : Int) * D + B ≥ (-1 : Int)) →
  ((-1 : Int) * D + L ≥ (-2 : Int)) →
  ((-1 : Int) * C + H ≥ (3 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (2 : Int)) →
  ((-1 : Int) * C + B ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (2 : Int)) →
  ((-1 : Int) * B + L ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * F ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * C ≥ (0 : Int)) →
  ((-1 : Int) * A + H ≥ (3 : Int)) →
  ((-1 : Int) * A + J ≥ (1 : Int)) →
  ((-1 : Int) * A + I ≥ (2 : Int)) →
  ((-1 : Int) * A + G ≥ (3 : Int)) →
  ((-1 : Int) * A + F ≥ (1 : Int)) →
  ((-1 : Int) * A + C ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (3 : Int)) →
  ((-1 : Int) * A + L ≥ (2 : Int)) →
  (J + (-1 : Int) * I ≥ (-1 : Int)) →
  (J + H ≥ (4 : Int)) →
  (J + I ≥ (3 : Int)) →
  (I + H ≥ (5 : Int)) →
  (G + (-1 : Int) * H ≥ (0 : Int)) →
  (G + (-1 : Int) * J ≥ (2 : Int)) →
  (G + (-1 : Int) * I ≥ (1 : Int)) →
  (G + (-1 : Int) * C ≥ (3 : Int)) →
  (G + (-1 : Int) * B ≥ (0 : Int)) →
  (G + (-1 : Int) * L ≥ (1 : Int)) →
  (G + H ≥ (6 : Int)) →
  (G + J ≥ (4 : Int)) →
  (G + I ≥ (5 : Int)) →
  (G + C ≥ (3 : Int)) →
  (G + B ≥ (6 : Int)) →
  (G + L ≥ (5 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + H ≥ (4 : Int)) →
  (F + J ≥ (2 : Int)) →
  (F + I ≥ (3 : Int)) →
  (F + G ≥ (4 : Int)) →
  (F + C ≥ (1 : Int)) →
  (F + B ≥ (4 : Int)) →
  (F + L ≥ (3 : Int)) →
  (E + (-1 : Int) * H ≥ (0 : Int)) →
  (E + (-1 : Int) * J ≥ (2 : Int)) →
  (E + (-1 : Int) * I ≥ (1 : Int)) →
  (E + (-1 : Int) * G ≥ (0 : Int)) →
  (E + (-1 : Int) * F ≥ (2 : Int)) →
  (E + (-1 : Int) * C ≥ (3 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + (-1 : Int) * A ≥ (3 : Int)) →
  (E + (-1 : Int) * L ≥ (1 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + J ≥ (4 : Int)) →
  (E + I ≥ (5 : Int)) →
  (E + G ≥ (6 : Int)) →
  (E + F ≥ (4 : Int)) →
  (E + C ≥ (3 : Int)) →
  (E + B ≥ (6 : Int)) →
  (E + A ≥ (3 : Int)) →
  (E + L ≥ (5 : Int)) →
  (D + (-1 : Int) * H ≥ (1 : Int)) →
  (D + (-1 : Int) * J ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (2 : Int)) →
  (D + (-1 : Int) * G ≥ (1 : Int)) →
  (D + (-1 : Int) * F ≥ (3 : Int)) →
  (D + (-1 : Int) * E ≥ (1 : Int)) →
  (D + (-1 : Int) * C ≥ (4 : Int)) →
  (D + (-1 : Int) * B ≥ (1 : Int)) →
  (D + (-1 : Int) * A ≥ (4 : Int)) →
  (D + (-1 : Int) * L ≥ (2 : Int)) →
  (D + H ≥ (7 : Int)) →
  (D + J ≥ (5 : Int)) →
  (D + I ≥ (6 : Int)) →
  (D + G ≥ (7 : Int)) →
  (D + F ≥ (5 : Int)) →
  (D + E ≥ (7 : Int)) →
  (D + C ≥ (4 : Int)) →
  (D + B ≥ (7 : Int)) →
  (D + A ≥ (4 : Int)) →
  (D + L ≥ (6 : Int)) →
  (C + H ≥ (3 : Int)) →
  (C + J ≥ (1 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + B ≥ (3 : Int)) →
  (C + L ≥ (2 : Int)) →
  (B + (-1 : Int) * H ≥ (0 : Int)) →
  (B + (-1 : Int) * J ≥ (2 : Int)) →
  (B + (-1 : Int) * I ≥ (1 : Int)) →
  (B + (-1 : Int) * L ≥ (1 : Int)) →
  (B + H ≥ (6 : Int)) →
  (B + J ≥ (4 : Int)) →
  (B + I ≥ (5 : Int)) →
  (B + L ≥ (5 : Int)) →
  (A + (-1 : Int) * F ≥ (-1 : Int)) →
  (A + (-1 : Int) * C ≥ (0 : Int)) →
  (A + H ≥ (3 : Int)) →
  (A + J ≥ (1 : Int)) →
  (A + I ≥ (2 : Int)) →
  (A + G ≥ (3 : Int)) →
  (A + F ≥ (1 : Int)) →
  (A + C ≥ (0 : Int)) →
  (A + B ≥ (3 : Int)) →
  (A + L ≥ (2 : Int)) →
  (L + (-1 : Int) * H ≥ (-1 : Int)) →
  (L + (-1 : Int) * J ≥ (1 : Int)) →
  (L + (-1 : Int) * I ≥ (0 : Int)) →
  (L + H ≥ (5 : Int)) →
  (L + J ≥ (3 : Int)) →
  (L + I ≥ (4 : Int)) →
  (H ≥ (3 : Int)) →
  (J ≥ (1 : Int)) →
  (I ≥ (2 : Int)) →
  (G ≥ (3 : Int)) →
  (F ≥ (1 : Int)) →
  (E ≥ (3 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (0 : Int)) →
  (B ≥ (3 : Int)) →
  (A ≥ (0 : Int)) →
  (L ≥ (2 : Int)) →
  (F ≤ (1 : Int)) →
  (C ≤ (0 : Int)) →
  (A ≤ (0 : Int)) →
  ((-1 : Int) * J + H ≥ (2 : Int)) →
  r2 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  ((-1 : Int) * G + J ≥ (-1 : Int)) →
  ((-1 : Int) * G + I ≥ (0 : Int)) →
  ((-1 : Int) * G + B ≥ (0 : Int)) →
  ((-1 : Int) * G + L ≥ (-1 : Int)) →
  ((-1 : Int) * F + (-1 : Int) * H ≥ (-1 : Int)) →
  ((-1 : Int) * F + (-1 : Int) * C ≥ (-1 : Int)) →
  ((-1 : Int) * F + H ≥ (-1 : Int)) →
  ((-1 : Int) * F + J ≥ (0 : Int)) →
  ((-1 : Int) * F + I ≥ (1 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + C ≥ (-1 : Int)) →
  ((-1 : Int) * F + B ≥ (1 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * D + E ≥ (-1 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * H ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (0 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (2 : Int)) →
  ((-1 : Int) * C + B ≥ (2 : Int)) →
  ((-1 : Int) * C + L ≥ (1 : Int)) →
  ((-1 : Int) * B + J ≥ (-1 : Int)) →
  ((-1 : Int) * B + I ≥ (0 : Int)) →
  ((-1 : Int) * B + L ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * H ≥ (0 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * F ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * C ≥ (0 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * A + J ≥ (1 : Int)) →
  ((-1 : Int) * A + I ≥ (2 : Int)) →
  ((-1 : Int) * A + G ≥ (2 : Int)) →
  ((-1 : Int) * A + F ≥ (1 : Int)) →
  ((-1 : Int) * A + C ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (2 : Int)) →
  ((-1 : Int) * A + L ≥ (1 : Int)) →
  ((-1 : Int) * L + J ≥ (0 : Int)) →
  ((-1 : Int) * L + I ≥ (1 : Int)) →
  (J + (-1 : Int) * H ≥ (1 : Int)) →
  (J + (-1 : Int) * I ≥ (-1 : Int)) →
  (J + H ≥ (1 : Int)) →
  (J + I ≥ (3 : Int)) →
  (I + (-1 : Int) * H ≥ (2 : Int)) →
  (I + H ≥ (2 : Int)) →
  (G + (-1 : Int) * H ≥ (2 : Int)) →
  (G + (-1 : Int) * J ≥ (1 : Int)) →
  (G + (-1 : Int) * I ≥ (0 : Int)) →
  (G + (-1 : Int) * C ≥ (2 : Int)) →
  (G + (-1 : Int) * B ≥ (0 : Int)) →
  (G + (-1 : Int) * L ≥ (1 : Int)) →
  (G + H ≥ (2 : Int)) →
  (G + J ≥ (3 : Int)) →
  (G + I ≥ (4 : Int)) →
  (G + C ≥ (2 : Int)) →
  (G + B ≥ (4 : Int)) →
  (G + L ≥ (3 : Int)) →
  (F + (-1 : Int) * H ≥ (1 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + H ≥ (1 : Int)) →
  (F + J ≥ (2 : Int)) →
  (F + I ≥ (3 : Int)) →
  (F + G ≥ (3 : Int)) →
  (F + C ≥ (1 : Int)) →
  (F + B ≥ (3 : Int)) →
  (F + L ≥ (2 : Int)) →
  (E + (-1 : Int) * H ≥ (3 : Int)) →
  (E + (-1 : Int) * J ≥ (1 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * G ≥ (0 : Int)) →
  (E + (-1 : Int) * F ≥ (2 : Int)) →
  (E + (-1 : Int) * C ≥ (3 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + (-1 : Int) * A ≥ (3 : Int)) →
  (E + (-1 : Int) * L ≥ (1 : Int)) →
  (E + H ≥ (3 : Int)) →
  (E + J ≥ (4 : Int)) →
  (E + I ≥ (5 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (4 : Int)) →
  (E + C ≥ (3 : Int)) →
  (E + B ≥ (5 : Int)) →
  (E + A ≥ (3 : Int)) →
  (E + L ≥ (4 : Int)) →
  (D + (-1 : Int) * H ≥ (4 : Int)) →
  (D + (-1 : Int) * J ≥ (2 : Int)) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (D + (-1 : Int) * G ≥ (1 : Int)) →
  (D + (-1 : Int) * F ≥ (3 : Int)) →
  (D + (-1 : Int) * E ≥ (1 : Int)) →
  (D + (-1 : Int) * C ≥ (4 : Int)) →
  (D + (-1 : Int) * B ≥ (1 : Int)) →
  (D + (-1 : Int) * A ≥ (4 : Int)) →
  (D + (-1 : Int) * L ≥ (2 : Int)) →
  (D + H ≥ (4 : Int)) →
  (D + J ≥ (5 : Int)) →
  (D + I ≥ (6 : Int)) →
  (D + G ≥ (6 : Int)) →
  (D + F ≥ (5 : Int)) →
  (D + E ≥ (7 : Int)) →
  (D + C ≥ (4 : Int)) →
  (D + B ≥ (6 : Int)) →
  (D + A ≥ (4 : Int)) →
  (D + L ≥ (5 : Int)) →
  (C + (-1 : Int) * H ≥ (0 : Int)) →
  (C + H ≥ (0 : Int)) →
  (C + J ≥ (1 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + B ≥ (2 : Int)) →
  (C + L ≥ (1 : Int)) →
  (B + (-1 : Int) * H ≥ (2 : Int)) →
  (B + (-1 : Int) * J ≥ (1 : Int)) →
  (B + (-1 : Int) * I ≥ (0 : Int)) →
  (B + (-1 : Int) * L ≥ (1 : Int)) →
  (B + H ≥ (2 : Int)) →
  (B + J ≥ (3 : Int)) →
  (B + I ≥ (4 : Int)) →
  (B + L ≥ (3 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * F ≥ (-1 : Int)) →
  (A + (-1 : Int) * C ≥ (0 : Int)) →
  (A + H ≥ (0 : Int)) →
  (A + J ≥ (1 : Int)) →
  (A + I ≥ (2 : Int)) →
  (A + G ≥ (2 : Int)) →
  (A + F ≥ (1 : Int)) →
  (A + C ≥ (0 : Int)) →
  (A + B ≥ (2 : Int)) →
  (A + L ≥ (1 : Int)) →
  (L + (-1 : Int) * H ≥ (1 : Int)) →
  (L + (-1 : Int) * J ≥ (0 : Int)) →
  (L + (-1 : Int) * I ≥ (-1 : Int)) →
  (L + H ≥ (1 : Int)) →
  (L + J ≥ (2 : Int)) →
  (L + I ≥ (3 : Int)) →
  (H ≥ (0 : Int)) →
  (J ≥ (1 : Int)) →
  (I ≥ (2 : Int)) →
  (G ≥ (2 : Int)) →
  (F ≥ (1 : Int)) →
  (E ≥ (3 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (0 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (0 : Int)) →
  (L ≥ (1 : Int)) →
  (H ≤ (0 : Int)) →
  (F ≤ (1 : Int)) →
  (C ≤ (0 : Int)) →
  (A ≤ (0 : Int)) →
  ((-1 : Int) * J + I ≥ (1 : Int)) →
  r3 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A L B C D E F G H I J K) →
  (True) →
  r0 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A L B C D E F G H I J K) →
  (True) →
  r0 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A I B C D E F G K J L H) →
  (True) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r3 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r3 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r3 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r3 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r3 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r3 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r3 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r3 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A I B C D E F G K J L H) →
  (True) →
  r3 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r3 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r3 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r3 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r3 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r3 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r3 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r3 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r3 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r3 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r3 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r3 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r3 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r3 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r3 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r3 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r3 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r3 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r3 A I B C D E F G L J K H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r3 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G L J K H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G L J K H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r3 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G L J K H) →
  (r3 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A I B C D E F G L K J H) →
  (r3 A I B C D E F G L J K H) →
  (True) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A I B C D E F G L K J H) →
  (r0 A I B C D E F G L J K H) →
  (True) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  False)))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«graham-scan-full.31_000»
