import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«incremental.35_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1957:1-1957:12 (check-sat, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":9:1-562:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":563:1-868:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":869:1-1195:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1196:1-1497:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1498:1-1508:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1509:1-1519:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1520:1-1530:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1531:1-1543:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1544:1-1556:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1557:1-1569:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1570:1-1584:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1585:1-1599:2 (clause 12, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1600:1-1614:2 (clause 13, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1615:1-1629:2 (clause 14, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1630:1-1644:2 (clause 15, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1645:1-1655:2 (clause 16, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1656:1-1668:2 (clause 17, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1669:1-1681:2 (clause 18, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1682:1-1694:2 (clause 19, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1695:1-1709:2 (clause 20, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1710:1-1724:2 (clause 21, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1725:1-1739:2 (clause 22, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1740:1-1754:2 (clause 23, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1755:1-1769:2 (clause 24, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1770:1-1785:2 (clause 25, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1786:1-1801:2 (clause 26, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1802:1-1817:2 (clause 27, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1818:1-1833:2 (clause 28, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1834:1-1849:2 (clause 29, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1850:1-1865:2 (clause 30, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1866:1-1879:2 (clause 31, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1880:1-1893:2 (clause 32, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1894:1-1907:2 (clause 33, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1908:1-1921:2 (clause 34, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1922:1-1933:2 (clause 35, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1934:1-1945:2 (clause 36, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/incremental.35_000.smt2":1946:1-1955:2 (clause 37, command 42)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R : Int),
  ((-1 : Int) * Q + (-1 : Int) * O ≥ (-5 : Int)) →
  ((-1 : Int) * Q + P ≥ (-2 : Int)) →
  ((-1 : Int) * Q + O ≥ (-1 : Int)) →
  ((-1 : Int) * P + (-1 : Int) * O ≥ (-3 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + (-1 : Int) * Q ≥ (-6 : Int)) →
  ((-1 : Int) * N + (-1 : Int) * P ≥ (-4 : Int)) →
  ((-1 : Int) * N + (-1 : Int) * O ≥ (-5 : Int)) →
  ((-1 : Int) * N + (-1 : Int) * F ≥ (-4 : Int)) →
  ((-1 : Int) * N + (-1 : Int) * E ≥ (-5 : Int)) →
  ((-1 : Int) * N + (-1 : Int) * D ≥ (-4 : Int)) →
  ((-1 : Int) * N + (-1 : Int) * C ≥ (-4 : Int)) →
  ((-1 : Int) * N + Q ≥ (0 : Int)) →
  ((-1 : Int) * N + P ≥ (-2 : Int)) →
  ((-1 : Int) * N + O ≥ (-1 : Int)) →
  ((-1 : Int) * N + F ≥ (-2 : Int)) →
  ((-1 : Int) * N + E ≥ (-1 : Int)) →
  ((-1 : Int) * N + D ≥ (-2 : Int)) →
  ((-1 : Int) * N + C ≥ (-2 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * Q ≥ (-4 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * P ≥ (-2 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * O ≥ (-3 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * N ≥ (-4 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * F ≥ (-2 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * E ≥ (-3 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * D ≥ (-2 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * M + Q ≥ (2 : Int)) →
  ((-1 : Int) * M + P ≥ (0 : Int)) →
  ((-1 : Int) * M + O ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (2 : Int)) →
  ((-1 : Int) * M + F ≥ (0 : Int)) →
  ((-1 : Int) * M + E ≥ (1 : Int)) →
  ((-1 : Int) * M + D ≥ (0 : Int)) →
  ((-1 : Int) * M + C ≥ (0 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * Q ≥ (-8 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * P ≥ (-6 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * O ≥ (-7 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * N ≥ (-8 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * M ≥ (-6 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * J ≥ (-5 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * I ≥ (-5 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * H ≥ (-6 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * G ≥ (-5 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * F ≥ (-6 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * E ≥ (-7 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * D ≥ (-6 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * C ≥ (-6 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * B ≥ (-7 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * A ≥ (-9 : Int)) →
  ((-1 : Int) * K + Q ≥ (-2 : Int)) →
  ((-1 : Int) * K + P ≥ (-4 : Int)) →
  ((-1 : Int) * K + O ≥ (-3 : Int)) →
  ((-1 : Int) * K + N ≥ (-2 : Int)) →
  ((-1 : Int) * K + M ≥ (-4 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * K + J ≥ (-5 : Int)) →
  ((-1 : Int) * K + I ≥ (-5 : Int)) →
  ((-1 : Int) * K + H ≥ (-4 : Int)) →
  ((-1 : Int) * K + G ≥ (-5 : Int)) →
  ((-1 : Int) * K + F ≥ (-4 : Int)) →
  ((-1 : Int) * K + E ≥ (-3 : Int)) →
  ((-1 : Int) * K + D ≥ (-4 : Int)) →
  ((-1 : Int) * K + C ≥ (-4 : Int)) →
  ((-1 : Int) * K + B ≥ (-3 : Int)) →
  ((-1 : Int) * K + A ≥ (-1 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * Q ≥ (-3 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * P ≥ (-1 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * O ≥ (-2 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * N ≥ (-3 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * M ≥ (-1 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * F ≥ (-1 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * E ≥ (-2 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * D ≥ (-1 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * C ≥ (-1 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * A ≥ (-4 : Int)) →
  ((-1 : Int) * J + Q ≥ (3 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + O ≥ (2 : Int)) →
  ((-1 : Int) * J + N ≥ (3 : Int)) →
  ((-1 : Int) * J + M ≥ (1 : Int)) →
  ((-1 : Int) * J + F ≥ (1 : Int)) →
  ((-1 : Int) * J + E ≥ (2 : Int)) →
  ((-1 : Int) * J + D ≥ (1 : Int)) →
  ((-1 : Int) * J + C ≥ (1 : Int)) →
  ((-1 : Int) * J + B ≥ (2 : Int)) →
  ((-1 : Int) * J + A ≥ (4 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * Q ≥ (-3 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * P ≥ (-1 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * O ≥ (-2 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * N ≥ (-3 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * M ≥ (-1 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * J ≥ (0 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * F ≥ (-1 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * E ≥ (-2 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * D ≥ (-1 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * C ≥ (-1 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * A ≥ (-4 : Int)) →
  ((-1 : Int) * I + Q ≥ (3 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + O ≥ (2 : Int)) →
  ((-1 : Int) * I + N ≥ (3 : Int)) →
  ((-1 : Int) * I + M ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (0 : Int)) →
  ((-1 : Int) * I + F ≥ (1 : Int)) →
  ((-1 : Int) * I + E ≥ (2 : Int)) →
  ((-1 : Int) * I + D ≥ (1 : Int)) →
  ((-1 : Int) * I + C ≥ (1 : Int)) →
  ((-1 : Int) * I + B ≥ (2 : Int)) →
  ((-1 : Int) * I + A ≥ (4 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * Q ≥ (-4 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * P ≥ (-2 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * O ≥ (-3 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * N ≥ (-4 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * M ≥ (-2 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * J ≥ (-1 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * I ≥ (-1 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * F ≥ (-2 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * E ≥ (-3 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * D ≥ (-2 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * B ≥ (-3 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * A ≥ (-5 : Int)) →
  ((-1 : Int) * H + Q ≥ (2 : Int)) →
  ((-1 : Int) * H + P ≥ (0 : Int)) →
  ((-1 : Int) * H + O ≥ (1 : Int)) →
  ((-1 : Int) * H + N ≥ (2 : Int)) →
  ((-1 : Int) * H + M ≥ (0 : Int)) →
  ((-1 : Int) * H + J ≥ (-1 : Int)) →
  ((-1 : Int) * H + I ≥ (-1 : Int)) →
  ((-1 : Int) * H + F ≥ (0 : Int)) →
  ((-1 : Int) * H + E ≥ (1 : Int)) →
  ((-1 : Int) * H + D ≥ (0 : Int)) →
  ((-1 : Int) * H + C ≥ (0 : Int)) →
  ((-1 : Int) * H + B ≥ (1 : Int)) →
  ((-1 : Int) * H + A ≥ (3 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * Q ≥ (-3 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * P ≥ (-1 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * O ≥ (-2 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * N ≥ (-3 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * M ≥ (-1 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * J ≥ (0 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * I ≥ (0 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * H ≥ (-1 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * F ≥ (-1 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * E ≥ (-2 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * D ≥ (-1 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * C ≥ (-1 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * B ≥ (-2 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * A ≥ (-4 : Int)) →
  ((-1 : Int) * G + Q ≥ (3 : Int)) →
  ((-1 : Int) * G + P ≥ (1 : Int)) →
  ((-1 : Int) * G + O ≥ (2 : Int)) →
  ((-1 : Int) * G + N ≥ (3 : Int)) →
  ((-1 : Int) * G + M ≥ (1 : Int)) →
  ((-1 : Int) * G + J ≥ (0 : Int)) →
  ((-1 : Int) * G + I ≥ (0 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * G + F ≥ (1 : Int)) →
  ((-1 : Int) * G + E ≥ (2 : Int)) →
  ((-1 : Int) * G + D ≥ (1 : Int)) →
  ((-1 : Int) * G + C ≥ (1 : Int)) →
  ((-1 : Int) * G + B ≥ (2 : Int)) →
  ((-1 : Int) * G + A ≥ (4 : Int)) →
  ((-1 : Int) * F + (-1 : Int) * Q ≥ (-4 : Int)) →
  ((-1 : Int) * F + (-1 : Int) * P ≥ (-2 : Int)) →
  ((-1 : Int) * F + (-1 : Int) * O ≥ (-3 : Int)) →
  ((-1 : Int) * F + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * F + Q ≥ (2 : Int)) →
  ((-1 : Int) * F + P ≥ (0 : Int)) →
  ((-1 : Int) * F + O ≥ (1 : Int)) →
  ((-1 : Int) * F + C ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * Q ≥ (-5 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * O ≥ (-4 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * F ≥ (-3 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-3 : Int)) →
  ((-1 : Int) * E + Q ≥ (1 : Int)) →
  ((-1 : Int) * E + P ≥ (-1 : Int)) →
  ((-1 : Int) * E + O ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-1 : Int)) →
  ((-1 : Int) * D + (-1 : Int) * Q ≥ (-4 : Int)) →
  ((-1 : Int) * D + (-1 : Int) * P ≥ (-2 : Int)) →
  ((-1 : Int) * D + (-1 : Int) * O ≥ (-3 : Int)) →
  ((-1 : Int) * D + (-1 : Int) * F ≥ (-2 : Int)) →
  ((-1 : Int) * D + (-1 : Int) * E ≥ (-3 : Int)) →
  ((-1 : Int) * D + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * D + Q ≥ (2 : Int)) →
  ((-1 : Int) * D + P ≥ (0 : Int)) →
  ((-1 : Int) * D + O ≥ (1 : Int)) →
  ((-1 : Int) * D + F ≥ (0 : Int)) →
  ((-1 : Int) * D + E ≥ (1 : Int)) →
  ((-1 : Int) * D + C ≥ (0 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * Q ≥ (-4 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * P ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * O ≥ (-3 : Int)) →
  ((-1 : Int) * C + Q ≥ (2 : Int)) →
  ((-1 : Int) * C + P ≥ (0 : Int)) →
  ((-1 : Int) * C + O ≥ (1 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * Q ≥ (-5 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * O ≥ (-4 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * N ≥ (-5 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * M ≥ (-3 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * F ≥ (-3 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * E ≥ (-4 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * D ≥ (-3 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * C ≥ (-3 : Int)) →
  ((-1 : Int) * B + Q ≥ (1 : Int)) →
  ((-1 : Int) * B + P ≥ (-1 : Int)) →
  ((-1 : Int) * B + O ≥ (0 : Int)) →
  ((-1 : Int) * B + N ≥ (1 : Int)) →
  ((-1 : Int) * B + M ≥ (-1 : Int)) →
  ((-1 : Int) * B + F ≥ (-1 : Int)) →
  ((-1 : Int) * B + E ≥ (0 : Int)) →
  ((-1 : Int) * B + D ≥ (-1 : Int)) →
  ((-1 : Int) * B + C ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * Q ≥ (-7 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * P ≥ (-5 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * O ≥ (-6 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * N ≥ (-7 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * M ≥ (-5 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * F ≥ (-5 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * E ≥ (-6 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * D ≥ (-5 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * C ≥ (-5 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * B ≥ (-6 : Int)) →
  ((-1 : Int) * A + Q ≥ (-1 : Int)) →
  ((-1 : Int) * A + P ≥ (-3 : Int)) →
  ((-1 : Int) * A + O ≥ (-2 : Int)) →
  ((-1 : Int) * A + N ≥ (-1 : Int)) →
  ((-1 : Int) * A + M ≥ (-3 : Int)) →
  ((-1 : Int) * A + F ≥ (-3 : Int)) →
  ((-1 : Int) * A + E ≥ (-2 : Int)) →
  ((-1 : Int) * A + D ≥ (-3 : Int)) →
  ((-1 : Int) * A + C ≥ (-3 : Int)) →
  ((-1 : Int) * A + B ≥ (-2 : Int)) →
  (Q + (-1 : Int) * P ≥ (2 : Int)) →
  (Q + (-1 : Int) * O ≥ (1 : Int)) →
  (Q + P ≥ (4 : Int)) →
  (Q + O ≥ (5 : Int)) →
  (P + (-1 : Int) * O ≥ (-1 : Int)) →
  (P + O ≥ (3 : Int)) →
  (N + (-1 : Int) * Q ≥ (0 : Int)) →
  (N + (-1 : Int) * P ≥ (2 : Int)) →
  (N + (-1 : Int) * O ≥ (1 : Int)) →
  (N + (-1 : Int) * F ≥ (2 : Int)) →
  (N + (-1 : Int) * E ≥ (1 : Int)) →
  (N + (-1 : Int) * D ≥ (2 : Int)) →
  (N + (-1 : Int) * C ≥ (2 : Int)) →
  (N + Q ≥ (6 : Int)) →
  (N + P ≥ (4 : Int)) →
  (N + O ≥ (5 : Int)) →
  (N + F ≥ (4 : Int)) →
  (N + E ≥ (5 : Int)) →
  (N + D ≥ (4 : Int)) →
  (N + C ≥ (4 : Int)) →
  (M + (-1 : Int) * Q ≥ (-2 : Int)) →
  (M + (-1 : Int) * P ≥ (0 : Int)) →
  (M + (-1 : Int) * O ≥ (-1 : Int)) →
  (M + (-1 : Int) * N ≥ (-2 : Int)) →
  (M + (-1 : Int) * F ≥ (0 : Int)) →
  (M + (-1 : Int) * E ≥ (-1 : Int)) →
  (M + (-1 : Int) * D ≥ (0 : Int)) →
  (M + (-1 : Int) * C ≥ (0 : Int)) →
  (M + Q ≥ (4 : Int)) →
  (M + P ≥ (2 : Int)) →
  (M + O ≥ (3 : Int)) →
  (M + N ≥ (4 : Int)) →
  (M + F ≥ (2 : Int)) →
  (M + E ≥ (3 : Int)) →
  (M + D ≥ (2 : Int)) →
  (M + C ≥ (2 : Int)) →
  (L + (-1 : Int) * Q ≥ (1 : Int)) →
  (L + (-1 : Int) * P ≥ (3 : Int)) →
  (L + (-1 : Int) * O ≥ (2 : Int)) →
  (L + (-1 : Int) * N ≥ (1 : Int)) →
  (L + (-1 : Int) * M ≥ (3 : Int)) →
  (L + (-1 : Int) * J ≥ (4 : Int)) →
  (L + (-1 : Int) * I ≥ (4 : Int)) →
  (L + (-1 : Int) * H ≥ (3 : Int)) →
  (L + (-1 : Int) * G ≥ (4 : Int)) →
  (L + (-1 : Int) * F ≥ (3 : Int)) →
  (L + (-1 : Int) * E ≥ (2 : Int)) →
  (L + (-1 : Int) * D ≥ (3 : Int)) →
  (L + (-1 : Int) * C ≥ (3 : Int)) →
  (L + (-1 : Int) * B ≥ (2 : Int)) →
  (L + (-1 : Int) * A ≥ (0 : Int)) →
  (L + Q ≥ (7 : Int)) →
  (L + P ≥ (5 : Int)) →
  (L + O ≥ (6 : Int)) →
  (L + N ≥ (7 : Int)) →
  (L + M ≥ (5 : Int)) →
  (L + J ≥ (4 : Int)) →
  (L + I ≥ (4 : Int)) →
  (L + H ≥ (5 : Int)) →
  (L + G ≥ (4 : Int)) →
  (L + F ≥ (5 : Int)) →
  (L + E ≥ (6 : Int)) →
  (L + D ≥ (5 : Int)) →
  (L + C ≥ (5 : Int)) →
  (L + B ≥ (6 : Int)) →
  (L + A ≥ (8 : Int)) →
  (K + (-1 : Int) * Q ≥ (2 : Int)) →
  (K + (-1 : Int) * P ≥ (4 : Int)) →
  (K + (-1 : Int) * O ≥ (3 : Int)) →
  (K + (-1 : Int) * N ≥ (2 : Int)) →
  (K + (-1 : Int) * M ≥ (4 : Int)) →
  (K + (-1 : Int) * J ≥ (5 : Int)) →
  (K + (-1 : Int) * I ≥ (5 : Int)) →
  (K + (-1 : Int) * H ≥ (4 : Int)) →
  (K + (-1 : Int) * G ≥ (5 : Int)) →
  (K + (-1 : Int) * F ≥ (4 : Int)) →
  (K + (-1 : Int) * E ≥ (3 : Int)) →
  (K + (-1 : Int) * D ≥ (4 : Int)) →
  (K + (-1 : Int) * C ≥ (4 : Int)) →
  (K + (-1 : Int) * B ≥ (3 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + Q ≥ (8 : Int)) →
  (K + P ≥ (6 : Int)) →
  (K + O ≥ (7 : Int)) →
  (K + N ≥ (8 : Int)) →
  (K + M ≥ (6 : Int)) →
  (K + L ≥ (9 : Int)) →
  (K + J ≥ (5 : Int)) →
  (K + I ≥ (5 : Int)) →
  (K + H ≥ (6 : Int)) →
  (K + G ≥ (5 : Int)) →
  (K + F ≥ (6 : Int)) →
  (K + E ≥ (7 : Int)) →
  (K + D ≥ (6 : Int)) →
  (K + C ≥ (6 : Int)) →
  (K + B ≥ (7 : Int)) →
  (K + A ≥ (9 : Int)) →
  (J + (-1 : Int) * Q ≥ (-3 : Int)) →
  (J + (-1 : Int) * P ≥ (-1 : Int)) →
  (J + (-1 : Int) * O ≥ (-2 : Int)) →
  (J + (-1 : Int) * N ≥ (-3 : Int)) →
  (J + (-1 : Int) * M ≥ (-1 : Int)) →
  (J + (-1 : Int) * F ≥ (-1 : Int)) →
  (J + (-1 : Int) * E ≥ (-2 : Int)) →
  (J + (-1 : Int) * D ≥ (-1 : Int)) →
  (J + (-1 : Int) * C ≥ (-1 : Int)) →
  (J + (-1 : Int) * B ≥ (-2 : Int)) →
  (J + (-1 : Int) * A ≥ (-4 : Int)) →
  (J + Q ≥ (3 : Int)) →
  (J + P ≥ (1 : Int)) →
  (J + O ≥ (2 : Int)) →
  (J + N ≥ (3 : Int)) →
  (J + M ≥ (1 : Int)) →
  (J + F ≥ (1 : Int)) →
  (J + E ≥ (2 : Int)) →
  (J + D ≥ (1 : Int)) →
  (J + C ≥ (1 : Int)) →
  (J + B ≥ (2 : Int)) →
  (J + A ≥ (4 : Int)) →
  (I + (-1 : Int) * Q ≥ (-3 : Int)) →
  (I + (-1 : Int) * P ≥ (-1 : Int)) →
  (I + (-1 : Int) * O ≥ (-2 : Int)) →
  (I + (-1 : Int) * N ≥ (-3 : Int)) →
  (I + (-1 : Int) * M ≥ (-1 : Int)) →
  (I + (-1 : Int) * J ≥ (0 : Int)) →
  (I + (-1 : Int) * F ≥ (-1 : Int)) →
  (I + (-1 : Int) * E ≥ (-2 : Int)) →
  (I + (-1 : Int) * D ≥ (-1 : Int)) →
  (I + (-1 : Int) * C ≥ (-1 : Int)) →
  (I + (-1 : Int) * B ≥ (-2 : Int)) →
  (I + (-1 : Int) * A ≥ (-4 : Int)) →
  (I + Q ≥ (3 : Int)) →
  (I + P ≥ (1 : Int)) →
  (I + O ≥ (2 : Int)) →
  (I + N ≥ (3 : Int)) →
  (I + M ≥ (1 : Int)) →
  (I + J ≥ (0 : Int)) →
  (I + F ≥ (1 : Int)) →
  (I + E ≥ (2 : Int)) →
  (I + D ≥ (1 : Int)) →
  (I + C ≥ (1 : Int)) →
  (I + B ≥ (2 : Int)) →
  (I + A ≥ (4 : Int)) →
  (H + (-1 : Int) * Q ≥ (-2 : Int)) →
  (H + (-1 : Int) * P ≥ (0 : Int)) →
  (H + (-1 : Int) * O ≥ (-1 : Int)) →
  (H + (-1 : Int) * N ≥ (-2 : Int)) →
  (H + (-1 : Int) * M ≥ (0 : Int)) →
  (H + (-1 : Int) * J ≥ (1 : Int)) →
  (H + (-1 : Int) * I ≥ (1 : Int)) →
  (H + (-1 : Int) * F ≥ (0 : Int)) →
  (H + (-1 : Int) * E ≥ (-1 : Int)) →
  (H + (-1 : Int) * D ≥ (0 : Int)) →
  (H + (-1 : Int) * C ≥ (0 : Int)) →
  (H + (-1 : Int) * B ≥ (-1 : Int)) →
  (H + (-1 : Int) * A ≥ (-3 : Int)) →
  (H + Q ≥ (4 : Int)) →
  (H + P ≥ (2 : Int)) →
  (H + O ≥ (3 : Int)) →
  (H + N ≥ (4 : Int)) →
  (H + M ≥ (2 : Int)) →
  (H + J ≥ (1 : Int)) →
  (H + I ≥ (1 : Int)) →
  (H + F ≥ (2 : Int)) →
  (H + E ≥ (3 : Int)) →
  (H + D ≥ (2 : Int)) →
  (H + C ≥ (2 : Int)) →
  (H + B ≥ (3 : Int)) →
  (H + A ≥ (5 : Int)) →
  (G + (-1 : Int) * Q ≥ (-3 : Int)) →
  (G + (-1 : Int) * P ≥ (-1 : Int)) →
  (G + (-1 : Int) * O ≥ (-2 : Int)) →
  (G + (-1 : Int) * N ≥ (-3 : Int)) →
  (G + (-1 : Int) * M ≥ (-1 : Int)) →
  (G + (-1 : Int) * J ≥ (0 : Int)) →
  (G + (-1 : Int) * I ≥ (0 : Int)) →
  (G + (-1 : Int) * H ≥ (-1 : Int)) →
  (G + (-1 : Int) * F ≥ (-1 : Int)) →
  (G + (-1 : Int) * E ≥ (-2 : Int)) →
  (G + (-1 : Int) * D ≥ (-1 : Int)) →
  (G + (-1 : Int) * C ≥ (-1 : Int)) →
  (G + (-1 : Int) * B ≥ (-2 : Int)) →
  (G + (-1 : Int) * A ≥ (-4 : Int)) →
  (G + Q ≥ (3 : Int)) →
  (G + P ≥ (1 : Int)) →
  (G + O ≥ (2 : Int)) →
  (G + N ≥ (3 : Int)) →
  (G + M ≥ (1 : Int)) →
  (G + J ≥ (0 : Int)) →
  (G + I ≥ (0 : Int)) →
  (G + H ≥ (1 : Int)) →
  (G + F ≥ (1 : Int)) →
  (G + E ≥ (2 : Int)) →
  (G + D ≥ (1 : Int)) →
  (G + C ≥ (1 : Int)) →
  (G + B ≥ (2 : Int)) →
  (G + A ≥ (4 : Int)) →
  (F + (-1 : Int) * Q ≥ (-2 : Int)) →
  (F + (-1 : Int) * P ≥ (0 : Int)) →
  (F + (-1 : Int) * O ≥ (-1 : Int)) →
  (F + (-1 : Int) * C ≥ (0 : Int)) →
  (F + Q ≥ (4 : Int)) →
  (F + P ≥ (2 : Int)) →
  (F + O ≥ (3 : Int)) →
  (F + C ≥ (2 : Int)) →
  (E + (-1 : Int) * Q ≥ (-1 : Int)) →
  (E + (-1 : Int) * P ≥ (1 : Int)) →
  (E + (-1 : Int) * O ≥ (0 : Int)) →
  (E + (-1 : Int) * F ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (1 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + O ≥ (4 : Int)) →
  (E + F ≥ (3 : Int)) →
  (E + C ≥ (3 : Int)) →
  (D + (-1 : Int) * Q ≥ (-2 : Int)) →
  (D + (-1 : Int) * P ≥ (0 : Int)) →
  (D + (-1 : Int) * O ≥ (-1 : Int)) →
  (D + (-1 : Int) * F ≥ (0 : Int)) →
  (D + (-1 : Int) * E ≥ (-1 : Int)) →
  (D + (-1 : Int) * C ≥ (0 : Int)) →
  (D + Q ≥ (4 : Int)) →
  (D + P ≥ (2 : Int)) →
  (D + O ≥ (3 : Int)) →
  (D + F ≥ (2 : Int)) →
  (D + E ≥ (3 : Int)) →
  (D + C ≥ (2 : Int)) →
  (C + (-1 : Int) * Q ≥ (-2 : Int)) →
  (C + (-1 : Int) * P ≥ (0 : Int)) →
  (C + (-1 : Int) * O ≥ (-1 : Int)) →
  (C + Q ≥ (4 : Int)) →
  (C + P ≥ (2 : Int)) →
  (C + O ≥ (3 : Int)) →
  (B + (-1 : Int) * Q ≥ (-1 : Int)) →
  (B + (-1 : Int) * P ≥ (1 : Int)) →
  (B + (-1 : Int) * O ≥ (0 : Int)) →
  (B + (-1 : Int) * N ≥ (-1 : Int)) →
  (B + (-1 : Int) * M ≥ (1 : Int)) →
  (B + (-1 : Int) * F ≥ (1 : Int)) →
  (B + (-1 : Int) * E ≥ (0 : Int)) →
  (B + (-1 : Int) * D ≥ (1 : Int)) →
  (B + (-1 : Int) * C ≥ (1 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (3 : Int)) →
  (B + O ≥ (4 : Int)) →
  (B + N ≥ (5 : Int)) →
  (B + M ≥ (3 : Int)) →
  (B + F ≥ (3 : Int)) →
  (B + E ≥ (4 : Int)) →
  (B + D ≥ (3 : Int)) →
  (B + C ≥ (3 : Int)) →
  (A + (-1 : Int) * Q ≥ (1 : Int)) →
  (A + (-1 : Int) * P ≥ (3 : Int)) →
  (A + (-1 : Int) * O ≥ (2 : Int)) →
  (A + (-1 : Int) * N ≥ (1 : Int)) →
  (A + (-1 : Int) * M ≥ (3 : Int)) →
  (A + (-1 : Int) * F ≥ (3 : Int)) →
  (A + (-1 : Int) * E ≥ (2 : Int)) →
  (A + (-1 : Int) * D ≥ (3 : Int)) →
  (A + (-1 : Int) * C ≥ (3 : Int)) →
  (A + (-1 : Int) * B ≥ (2 : Int)) →
  (A + Q ≥ (7 : Int)) →
  (A + P ≥ (5 : Int)) →
  (A + O ≥ (6 : Int)) →
  (A + N ≥ (7 : Int)) →
  (A + M ≥ (5 : Int)) →
  (A + F ≥ (5 : Int)) →
  (A + E ≥ (6 : Int)) →
  (A + D ≥ (5 : Int)) →
  (A + C ≥ (5 : Int)) →
  (A + B ≥ (6 : Int)) →
  (Q ≥ (3 : Int)) →
  (P ≥ (1 : Int)) →
  (O ≥ (2 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (1 : Int)) →
  (L ≥ (4 : Int)) →
  (K ≥ (5 : Int)) →
  (J ≥ (0 : Int)) →
  (I ≥ (0 : Int)) →
  (H ≥ (1 : Int)) →
  (G ≥ (0 : Int)) →
  (F ≥ (1 : Int)) →
  (E ≥ (2 : Int)) →
  (D ≥ (1 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (4 : Int)) →
  (Q ≤ (3 : Int)) →
  (P ≤ (1 : Int)) →
  (O ≤ (2 : Int)) →
  (N ≤ (3 : Int)) →
  (M ≤ (1 : Int)) →
  (K ≤ (5 : Int)) →
  (J ≤ (0 : Int)) →
  (I ≤ (0 : Int)) →
  (H ≤ (1 : Int)) →
  (G ≤ (0 : Int)) →
  (F ≤ (1 : Int)) →
  (E ≤ (2 : Int)) →
  (D ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  (B ≤ (2 : Int)) →
  (A ≤ (4 : Int)) →
  ((-1 : Int) * Q + (-1 : Int) * P ≥ (-4 : Int)) →
  r1 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  ((-1 : Int) * N + Q ≥ (1 : Int)) →
  ((-1 : Int) * M + Q ≥ (3 : Int)) →
  ((-1 : Int) * M + P ≥ (1 : Int)) →
  ((-1 : Int) * M + O ≥ (2 : Int)) →
  ((-1 : Int) * M + N ≥ (2 : Int)) →
  ((-1 : Int) * M + F ≥ (0 : Int)) →
  ((-1 : Int) * M + E ≥ (1 : Int)) →
  ((-1 : Int) * M + D ≥ (0 : Int)) →
  ((-1 : Int) * M + C ≥ (0 : Int)) →
  ((-1 : Int) * K + Q ≥ (-1 : Int)) →
  ((-1 : Int) * K + N ≥ (-2 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * K + A ≥ (-1 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * M ≥ (-1 : Int)) →
  ((-1 : Int) * J + Q ≥ (4 : Int)) →
  ((-1 : Int) * J + P ≥ (2 : Int)) →
  ((-1 : Int) * J + O ≥ (3 : Int)) →
  ((-1 : Int) * J + N ≥ (3 : Int)) →
  ((-1 : Int) * J + M ≥ (1 : Int)) →
  ((-1 : Int) * J + F ≥ (1 : Int)) →
  ((-1 : Int) * J + E ≥ (2 : Int)) →
  ((-1 : Int) * J + D ≥ (1 : Int)) →
  ((-1 : Int) * J + C ≥ (1 : Int)) →
  ((-1 : Int) * J + B ≥ (2 : Int)) →
  ((-1 : Int) * J + A ≥ (4 : Int)) →
  ((-1 : Int) * I + Q ≥ (2 : Int)) →
  ((-1 : Int) * I + N ≥ (1 : Int)) →
  ((-1 : Int) * I + A ≥ (2 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * M ≥ (-2 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * J ≥ (-1 : Int)) →
  ((-1 : Int) * H + Q ≥ (3 : Int)) →
  ((-1 : Int) * H + P ≥ (1 : Int)) →
  ((-1 : Int) * H + O ≥ (2 : Int)) →
  ((-1 : Int) * H + N ≥ (2 : Int)) →
  ((-1 : Int) * H + M ≥ (0 : Int)) →
  ((-1 : Int) * H + J ≥ (-1 : Int)) →
  ((-1 : Int) * H + I ≥ (-1 : Int)) →
  ((-1 : Int) * H + F ≥ (0 : Int)) →
  ((-1 : Int) * H + E ≥ (1 : Int)) →
  ((-1 : Int) * H + D ≥ (0 : Int)) →
  ((-1 : Int) * H + C ≥ (0 : Int)) →
  ((-1 : Int) * H + B ≥ (1 : Int)) →
  ((-1 : Int) * H + A ≥ (3 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * M ≥ (-1 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * J ≥ (0 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * H ≥ (-1 : Int)) →
  ((-1 : Int) * G + Q ≥ (4 : Int)) →
  ((-1 : Int) * G + P ≥ (2 : Int)) →
  ((-1 : Int) * G + O ≥ (3 : Int)) →
  ((-1 : Int) * G + N ≥ (3 : Int)) →
  ((-1 : Int) * G + M ≥ (1 : Int)) →
  ((-1 : Int) * G + J ≥ (0 : Int)) →
  ((-1 : Int) * G + I ≥ (0 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * G + F ≥ (1 : Int)) →
  ((-1 : Int) * G + E ≥ (2 : Int)) →
  ((-1 : Int) * G + D ≥ (1 : Int)) →
  ((-1 : Int) * G + C ≥ (1 : Int)) →
  ((-1 : Int) * G + B ≥ (2 : Int)) →
  ((-1 : Int) * G + A ≥ (4 : Int)) →
  ((-1 : Int) * F + Q ≥ (3 : Int)) →
  ((-1 : Int) * F + P ≥ (1 : Int)) →
  ((-1 : Int) * F + O ≥ (2 : Int)) →
  ((-1 : Int) * F + C ≥ (0 : Int)) →
  ((-1 : Int) * E + Q ≥ (1 : Int)) →
  ((-1 : Int) * D + Q ≥ (1 : Int)) →
  ((-1 : Int) * C + Q ≥ (3 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + O ≥ (2 : Int)) →
  ((-1 : Int) * B + Q ≥ (2 : Int)) →
  ((-1 : Int) * B + P ≥ (0 : Int)) →
  ((-1 : Int) * B + O ≥ (1 : Int)) →
  ((-1 : Int) * B + N ≥ (1 : Int)) →
  ((-1 : Int) * B + F ≥ (-1 : Int)) →
  ((-1 : Int) * B + C ≥ (-1 : Int)) →
  ((-1 : Int) * A + Q ≥ (0 : Int)) →
  ((-1 : Int) * A + N ≥ (-1 : Int)) →
  (Q + (-1 : Int) * P ≥ (2 : Int)) →
  (Q + (-1 : Int) * O ≥ (1 : Int)) →
  (Q + P ≥ (6 : Int)) →
  (Q + O ≥ (7 : Int)) →
  (P + (-1 : Int) * O ≥ (-1 : Int)) →
  (P + O ≥ (5 : Int)) →
  (N + (-1 : Int) * Q ≥ (-1 : Int)) →
  (N + (-1 : Int) * P ≥ (1 : Int)) →
  (N + (-1 : Int) * O ≥ (0 : Int)) →
  (N + (-1 : Int) * F ≥ (2 : Int)) →
  (N + (-1 : Int) * E ≥ (0 : Int)) →
  (N + (-1 : Int) * D ≥ (0 : Int)) →
  (N + (-1 : Int) * C ≥ (2 : Int)) →
  (N + Q ≥ (7 : Int)) →
  (N + P ≥ (5 : Int)) →
  (N + O ≥ (6 : Int)) →
  (N + F ≥ (4 : Int)) →
  (N + E ≥ (5 : Int)) →
  (N + D ≥ (4 : Int)) →
  (N + C ≥ (4 : Int)) →
  (M + Q ≥ (5 : Int)) →
  (M + P ≥ (3 : Int)) →
  (M + O ≥ (4 : Int)) →
  (M + N ≥ (4 : Int)) →
  (M + F ≥ (2 : Int)) →
  (M + E ≥ (3 : Int)) →
  (M + D ≥ (2 : Int)) →
  (M + C ≥ (2 : Int)) →
  (L + (-1 : Int) * Q ≥ (0 : Int)) →
  (L + (-1 : Int) * P ≥ (2 : Int)) →
  (L + (-1 : Int) * O ≥ (1 : Int)) →
  (L + (-1 : Int) * N ≥ (1 : Int)) →
  (L + (-1 : Int) * M ≥ (3 : Int)) →
  (L + (-1 : Int) * J ≥ (4 : Int)) →
  (L + (-1 : Int) * I ≥ (2 : Int)) →
  (L + (-1 : Int) * H ≥ (3 : Int)) →
  (L + (-1 : Int) * G ≥ (4 : Int)) →
  (L + (-1 : Int) * F ≥ (3 : Int)) →
  (L + (-1 : Int) * E ≥ (1 : Int)) →
  (L + (-1 : Int) * D ≥ (1 : Int)) →
  (L + (-1 : Int) * C ≥ (3 : Int)) →
  (L + (-1 : Int) * B ≥ (2 : Int)) →
  (L + (-1 : Int) * A ≥ (0 : Int)) →
  (L + Q ≥ (8 : Int)) →
  (L + P ≥ (6 : Int)) →
  (L + O ≥ (7 : Int)) →
  (L + N ≥ (7 : Int)) →
  (L + M ≥ (5 : Int)) →
  (L + J ≥ (4 : Int)) →
  (L + I ≥ (4 : Int)) →
  (L + H ≥ (5 : Int)) →
  (L + G ≥ (4 : Int)) →
  (L + F ≥ (5 : Int)) →
  (L + E ≥ (6 : Int)) →
  (L + D ≥ (5 : Int)) →
  (L + C ≥ (5 : Int)) →
  (L + B ≥ (6 : Int)) →
  (L + A ≥ (8 : Int)) →
  (K + (-1 : Int) * Q ≥ (1 : Int)) →
  (K + (-1 : Int) * P ≥ (3 : Int)) →
  (K + (-1 : Int) * O ≥ (2 : Int)) →
  (K + (-1 : Int) * N ≥ (2 : Int)) →
  (K + (-1 : Int) * M ≥ (4 : Int)) →
  (K + (-1 : Int) * J ≥ (5 : Int)) →
  (K + (-1 : Int) * I ≥ (3 : Int)) →
  (K + (-1 : Int) * H ≥ (4 : Int)) →
  (K + (-1 : Int) * G ≥ (5 : Int)) →
  (K + (-1 : Int) * F ≥ (4 : Int)) →
  (K + (-1 : Int) * E ≥ (2 : Int)) →
  (K + (-1 : Int) * D ≥ (2 : Int)) →
  (K + (-1 : Int) * C ≥ (4 : Int)) →
  (K + (-1 : Int) * B ≥ (3 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + Q ≥ (9 : Int)) →
  (K + P ≥ (7 : Int)) →
  (K + O ≥ (8 : Int)) →
  (K + N ≥ (8 : Int)) →
  (K + M ≥ (6 : Int)) →
  (K + L ≥ (9 : Int)) →
  (K + J ≥ (5 : Int)) →
  (K + I ≥ (5 : Int)) →
  (K + H ≥ (6 : Int)) →
  (K + G ≥ (5 : Int)) →
  (K + F ≥ (6 : Int)) →
  (K + E ≥ (7 : Int)) →
  (K + D ≥ (6 : Int)) →
  (K + C ≥ (6 : Int)) →
  (K + B ≥ (7 : Int)) →
  (K + A ≥ (9 : Int)) →
  (J + (-1 : Int) * M ≥ (-1 : Int)) →
  (J + Q ≥ (4 : Int)) →
  (J + P ≥ (2 : Int)) →
  (J + O ≥ (3 : Int)) →
  (J + N ≥ (3 : Int)) →
  (J + M ≥ (1 : Int)) →
  (J + F ≥ (1 : Int)) →
  (J + E ≥ (2 : Int)) →
  (J + D ≥ (1 : Int)) →
  (J + C ≥ (1 : Int)) →
  (J + B ≥ (2 : Int)) →
  (J + A ≥ (4 : Int)) →
  (I + (-1 : Int) * M ≥ (-1 : Int)) →
  (I + (-1 : Int) * J ≥ (0 : Int)) →
  (I + Q ≥ (4 : Int)) →
  (I + P ≥ (2 : Int)) →
  (I + O ≥ (3 : Int)) →
  (I + N ≥ (3 : Int)) →
  (I + M ≥ (1 : Int)) →
  (I + J ≥ (0 : Int)) →
  (I + F ≥ (1 : Int)) →
  (I + E ≥ (2 : Int)) →
  (I + D ≥ (1 : Int)) →
  (I + C ≥ (1 : Int)) →
  (I + B ≥ (2 : Int)) →
  (I + A ≥ (4 : Int)) →
  (H + (-1 : Int) * M ≥ (0 : Int)) →
  (H + (-1 : Int) * J ≥ (1 : Int)) →
  (H + Q ≥ (5 : Int)) →
  (H + P ≥ (3 : Int)) →
  (H + O ≥ (4 : Int)) →
  (H + N ≥ (4 : Int)) →
  (H + M ≥ (2 : Int)) →
  (H + J ≥ (1 : Int)) →
  (H + I ≥ (1 : Int)) →
  (H + F ≥ (2 : Int)) →
  (H + E ≥ (3 : Int)) →
  (H + D ≥ (2 : Int)) →
  (H + C ≥ (2 : Int)) →
  (H + B ≥ (3 : Int)) →
  (H + A ≥ (5 : Int)) →
  (G + (-1 : Int) * M ≥ (-1 : Int)) →
  (G + (-1 : Int) * J ≥ (0 : Int)) →
  (G + (-1 : Int) * H ≥ (-1 : Int)) →
  (G + Q ≥ (4 : Int)) →
  (G + P ≥ (2 : Int)) →
  (G + O ≥ (3 : Int)) →
  (G + N ≥ (3 : Int)) →
  (G + M ≥ (1 : Int)) →
  (G + J ≥ (0 : Int)) →
  (G + I ≥ (0 : Int)) →
  (G + H ≥ (1 : Int)) →
  (G + F ≥ (1 : Int)) →
  (G + E ≥ (2 : Int)) →
  (G + D ≥ (1 : Int)) →
  (G + C ≥ (1 : Int)) →
  (G + B ≥ (2 : Int)) →
  (G + A ≥ (4 : Int)) →
  (F + (-1 : Int) * C ≥ (0 : Int)) →
  (F + Q ≥ (5 : Int)) →
  (F + P ≥ (3 : Int)) →
  (F + O ≥ (4 : Int)) →
  (F + C ≥ (2 : Int)) →
  (E + Q ≥ (6 : Int)) →
  (E + P ≥ (4 : Int)) →
  (E + O ≥ (5 : Int)) →
  (E + F ≥ (3 : Int)) →
  (E + C ≥ (3 : Int)) →
  (D + Q ≥ (5 : Int)) →
  (D + P ≥ (3 : Int)) →
  (D + O ≥ (4 : Int)) →
  (D + F ≥ (2 : Int)) →
  (D + E ≥ (3 : Int)) →
  (D + C ≥ (2 : Int)) →
  (C + Q ≥ (5 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + O ≥ (4 : Int)) →
  (B + (-1 : Int) * M ≥ (1 : Int)) →
  (B + (-1 : Int) * F ≥ (1 : Int)) →
  (B + (-1 : Int) * C ≥ (1 : Int)) →
  (B + Q ≥ (6 : Int)) →
  (B + P ≥ (4 : Int)) →
  (B + O ≥ (5 : Int)) →
  (B + N ≥ (5 : Int)) →
  (B + M ≥ (3 : Int)) →
  (B + F ≥ (3 : Int)) →
  (B + E ≥ (4 : Int)) →
  (B + D ≥ (3 : Int)) →
  (B + C ≥ (3 : Int)) →
  (A + (-1 : Int) * Q ≥ (0 : Int)) →
  (A + (-1 : Int) * P ≥ (2 : Int)) →
  (A + (-1 : Int) * O ≥ (1 : Int)) →
  (A + (-1 : Int) * N ≥ (1 : Int)) →
  (A + (-1 : Int) * M ≥ (3 : Int)) →
  (A + (-1 : Int) * F ≥ (3 : Int)) →
  (A + (-1 : Int) * E ≥ (1 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (3 : Int)) →
  (A + (-1 : Int) * B ≥ (2 : Int)) →
  (A + Q ≥ (8 : Int)) →
  (A + P ≥ (6 : Int)) →
  (A + O ≥ (7 : Int)) →
  (A + N ≥ (7 : Int)) →
  (A + M ≥ (5 : Int)) →
  (A + F ≥ (5 : Int)) →
  (A + E ≥ (6 : Int)) →
  (A + D ≥ (5 : Int)) →
  (A + C ≥ (5 : Int)) →
  (A + B ≥ (6 : Int)) →
  (Q ≥ (4 : Int)) →
  (P ≥ (2 : Int)) →
  (O ≥ (3 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (1 : Int)) →
  (L ≥ (4 : Int)) →
  (K ≥ (5 : Int)) →
  (J ≥ (0 : Int)) →
  (I ≥ (0 : Int)) →
  (H ≥ (1 : Int)) →
  (G ≥ (0 : Int)) →
  (F ≥ (1 : Int)) →
  (E ≥ (2 : Int)) →
  (D ≥ (1 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (4 : Int)) →
  (M ≤ (1 : Int)) →
  (J ≤ (0 : Int)) →
  (H ≤ (1 : Int)) →
  (G ≤ (0 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  r1 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  ((-1 : Int) * M + (-1 : Int) * E ≥ (-3 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * D ≥ (-2 : Int)) →
  ((-1 : Int) * M + Q ≥ (2 : Int)) →
  ((-1 : Int) * M + P ≥ (0 : Int)) →
  ((-1 : Int) * M + O ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (2 : Int)) →
  ((-1 : Int) * M + F ≥ (0 : Int)) →
  ((-1 : Int) * M + E ≥ (1 : Int)) →
  ((-1 : Int) * M + D ≥ (0 : Int)) →
  ((-1 : Int) * M + C ≥ (0 : Int)) →
  ((-1 : Int) * K + N ≥ (-2 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * K + A ≥ (-1 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * M ≥ (-1 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * E ≥ (-2 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * D ≥ (-1 : Int)) →
  ((-1 : Int) * J + Q ≥ (3 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + O ≥ (2 : Int)) →
  ((-1 : Int) * J + N ≥ (3 : Int)) →
  ((-1 : Int) * J + M ≥ (1 : Int)) →
  ((-1 : Int) * J + F ≥ (1 : Int)) →
  ((-1 : Int) * J + E ≥ (2 : Int)) →
  ((-1 : Int) * J + D ≥ (1 : Int)) →
  ((-1 : Int) * J + C ≥ (1 : Int)) →
  ((-1 : Int) * J + B ≥ (2 : Int)) →
  ((-1 : Int) * J + A ≥ (4 : Int)) →
  ((-1 : Int) * I + Q ≥ (1 : Int)) →
  ((-1 : Int) * I + N ≥ (1 : Int)) →
  ((-1 : Int) * I + A ≥ (2 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * M ≥ (-2 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * J ≥ (-1 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * E ≥ (-3 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * D ≥ (-2 : Int)) →
  ((-1 : Int) * H + Q ≥ (2 : Int)) →
  ((-1 : Int) * H + P ≥ (0 : Int)) →
  ((-1 : Int) * H + O ≥ (1 : Int)) →
  ((-1 : Int) * H + N ≥ (2 : Int)) →
  ((-1 : Int) * H + M ≥ (0 : Int)) →
  ((-1 : Int) * H + J ≥ (-1 : Int)) →
  ((-1 : Int) * H + I ≥ (-1 : Int)) →
  ((-1 : Int) * H + F ≥ (0 : Int)) →
  ((-1 : Int) * H + E ≥ (1 : Int)) →
  ((-1 : Int) * H + D ≥ (0 : Int)) →
  ((-1 : Int) * H + C ≥ (0 : Int)) →
  ((-1 : Int) * H + B ≥ (1 : Int)) →
  ((-1 : Int) * H + A ≥ (3 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * M ≥ (-1 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * J ≥ (0 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * H ≥ (-1 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * E ≥ (-2 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * D ≥ (-1 : Int)) →
  ((-1 : Int) * G + Q ≥ (3 : Int)) →
  ((-1 : Int) * G + P ≥ (1 : Int)) →
  ((-1 : Int) * G + O ≥ (2 : Int)) →
  ((-1 : Int) * G + N ≥ (3 : Int)) →
  ((-1 : Int) * G + M ≥ (1 : Int)) →
  ((-1 : Int) * G + J ≥ (0 : Int)) →
  ((-1 : Int) * G + I ≥ (0 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * G + F ≥ (1 : Int)) →
  ((-1 : Int) * G + E ≥ (2 : Int)) →
  ((-1 : Int) * G + D ≥ (1 : Int)) →
  ((-1 : Int) * G + C ≥ (1 : Int)) →
  ((-1 : Int) * G + B ≥ (2 : Int)) →
  ((-1 : Int) * G + A ≥ (4 : Int)) →
  ((-1 : Int) * F + C ≥ (0 : Int)) →
  ((-1 : Int) * E + Q ≥ (1 : Int)) →
  ((-1 : Int) * E + P ≥ (-1 : Int)) →
  ((-1 : Int) * E + O ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-1 : Int)) →
  ((-1 : Int) * D + (-1 : Int) * E ≥ (-3 : Int)) →
  ((-1 : Int) * D + Q ≥ (2 : Int)) →
  ((-1 : Int) * D + P ≥ (0 : Int)) →
  ((-1 : Int) * D + O ≥ (1 : Int)) →
  ((-1 : Int) * D + F ≥ (0 : Int)) →
  ((-1 : Int) * D + E ≥ (1 : Int)) →
  ((-1 : Int) * D + C ≥ (0 : Int)) →
  ((-1 : Int) * B + N ≥ (0 : Int)) →
  ((-1 : Int) * B + F ≥ (-1 : Int)) →
  ((-1 : Int) * B + C ≥ (-1 : Int)) →
  ((-1 : Int) * A + N ≥ (-1 : Int)) →
  (Q + (-1 : Int) * P ≥ (2 : Int)) →
  (Q + (-1 : Int) * O ≥ (1 : Int)) →
  (Q + P ≥ (4 : Int)) →
  (Q + O ≥ (5 : Int)) →
  (P + (-1 : Int) * O ≥ (-1 : Int)) →
  (P + O ≥ (3 : Int)) →
  (N + (-1 : Int) * Q ≥ (0 : Int)) →
  (N + (-1 : Int) * P ≥ (2 : Int)) →
  (N + (-1 : Int) * O ≥ (1 : Int)) →
  (N + (-1 : Int) * F ≥ (1 : Int)) →
  (N + (-1 : Int) * E ≥ (1 : Int)) →
  (N + (-1 : Int) * D ≥ (2 : Int)) →
  (N + (-1 : Int) * C ≥ (1 : Int)) →
  (N + Q ≥ (6 : Int)) →
  (N + P ≥ (4 : Int)) →
  (N + O ≥ (5 : Int)) →
  (N + F ≥ (4 : Int)) →
  (N + E ≥ (5 : Int)) →
  (N + D ≥ (4 : Int)) →
  (N + C ≥ (4 : Int)) →
  (M + (-1 : Int) * E ≥ (-1 : Int)) →
  (M + (-1 : Int) * D ≥ (0 : Int)) →
  (M + Q ≥ (4 : Int)) →
  (M + P ≥ (2 : Int)) →
  (M + O ≥ (3 : Int)) →
  (M + N ≥ (4 : Int)) →
  (M + F ≥ (2 : Int)) →
  (M + E ≥ (3 : Int)) →
  (M + D ≥ (2 : Int)) →
  (M + C ≥ (2 : Int)) →
  (L + (-1 : Int) * Q ≥ (1 : Int)) →
  (L + (-1 : Int) * P ≥ (3 : Int)) →
  (L + (-1 : Int) * O ≥ (2 : Int)) →
  (L + (-1 : Int) * N ≥ (1 : Int)) →
  (L + (-1 : Int) * M ≥ (3 : Int)) →
  (L + (-1 : Int) * J ≥ (4 : Int)) →
  (L + (-1 : Int) * I ≥ (2 : Int)) →
  (L + (-1 : Int) * H ≥ (3 : Int)) →
  (L + (-1 : Int) * G ≥ (4 : Int)) →
  (L + (-1 : Int) * F ≥ (2 : Int)) →
  (L + (-1 : Int) * E ≥ (2 : Int)) →
  (L + (-1 : Int) * D ≥ (3 : Int)) →
  (L + (-1 : Int) * C ≥ (2 : Int)) →
  (L + (-1 : Int) * B ≥ (1 : Int)) →
  (L + (-1 : Int) * A ≥ (0 : Int)) →
  (L + Q ≥ (7 : Int)) →
  (L + P ≥ (5 : Int)) →
  (L + O ≥ (6 : Int)) →
  (L + N ≥ (7 : Int)) →
  (L + M ≥ (5 : Int)) →
  (L + J ≥ (4 : Int)) →
  (L + I ≥ (4 : Int)) →
  (L + H ≥ (5 : Int)) →
  (L + G ≥ (4 : Int)) →
  (L + F ≥ (5 : Int)) →
  (L + E ≥ (6 : Int)) →
  (L + D ≥ (5 : Int)) →
  (L + C ≥ (5 : Int)) →
  (L + B ≥ (6 : Int)) →
  (L + A ≥ (8 : Int)) →
  (K + (-1 : Int) * Q ≥ (2 : Int)) →
  (K + (-1 : Int) * P ≥ (4 : Int)) →
  (K + (-1 : Int) * O ≥ (3 : Int)) →
  (K + (-1 : Int) * N ≥ (2 : Int)) →
  (K + (-1 : Int) * M ≥ (4 : Int)) →
  (K + (-1 : Int) * J ≥ (5 : Int)) →
  (K + (-1 : Int) * I ≥ (3 : Int)) →
  (K + (-1 : Int) * H ≥ (4 : Int)) →
  (K + (-1 : Int) * G ≥ (5 : Int)) →
  (K + (-1 : Int) * F ≥ (3 : Int)) →
  (K + (-1 : Int) * E ≥ (3 : Int)) →
  (K + (-1 : Int) * D ≥ (4 : Int)) →
  (K + (-1 : Int) * C ≥ (3 : Int)) →
  (K + (-1 : Int) * B ≥ (2 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + Q ≥ (8 : Int)) →
  (K + P ≥ (6 : Int)) →
  (K + O ≥ (7 : Int)) →
  (K + N ≥ (8 : Int)) →
  (K + M ≥ (6 : Int)) →
  (K + L ≥ (9 : Int)) →
  (K + J ≥ (5 : Int)) →
  (K + I ≥ (5 : Int)) →
  (K + H ≥ (6 : Int)) →
  (K + G ≥ (5 : Int)) →
  (K + F ≥ (6 : Int)) →
  (K + E ≥ (7 : Int)) →
  (K + D ≥ (6 : Int)) →
  (K + C ≥ (6 : Int)) →
  (K + B ≥ (7 : Int)) →
  (K + A ≥ (9 : Int)) →
  (J + (-1 : Int) * M ≥ (-1 : Int)) →
  (J + (-1 : Int) * E ≥ (-2 : Int)) →
  (J + (-1 : Int) * D ≥ (-1 : Int)) →
  (J + Q ≥ (3 : Int)) →
  (J + P ≥ (1 : Int)) →
  (J + O ≥ (2 : Int)) →
  (J + N ≥ (3 : Int)) →
  (J + M ≥ (1 : Int)) →
  (J + F ≥ (1 : Int)) →
  (J + E ≥ (2 : Int)) →
  (J + D ≥ (1 : Int)) →
  (J + C ≥ (1 : Int)) →
  (J + B ≥ (2 : Int)) →
  (J + A ≥ (4 : Int)) →
  (I + (-1 : Int) * M ≥ (-1 : Int)) →
  (I + (-1 : Int) * J ≥ (0 : Int)) →
  (I + (-1 : Int) * E ≥ (-2 : Int)) →
  (I + (-1 : Int) * D ≥ (-1 : Int)) →
  (I + Q ≥ (3 : Int)) →
  (I + P ≥ (1 : Int)) →
  (I + O ≥ (2 : Int)) →
  (I + N ≥ (3 : Int)) →
  (I + M ≥ (1 : Int)) →
  (I + J ≥ (0 : Int)) →
  (I + F ≥ (1 : Int)) →
  (I + E ≥ (2 : Int)) →
  (I + D ≥ (1 : Int)) →
  (I + C ≥ (1 : Int)) →
  (I + B ≥ (2 : Int)) →
  (I + A ≥ (4 : Int)) →
  (H + (-1 : Int) * M ≥ (0 : Int)) →
  (H + (-1 : Int) * J ≥ (1 : Int)) →
  (H + (-1 : Int) * E ≥ (-1 : Int)) →
  (H + (-1 : Int) * D ≥ (0 : Int)) →
  (H + Q ≥ (4 : Int)) →
  (H + P ≥ (2 : Int)) →
  (H + O ≥ (3 : Int)) →
  (H + N ≥ (4 : Int)) →
  (H + M ≥ (2 : Int)) →
  (H + J ≥ (1 : Int)) →
  (H + I ≥ (1 : Int)) →
  (H + F ≥ (2 : Int)) →
  (H + E ≥ (3 : Int)) →
  (H + D ≥ (2 : Int)) →
  (H + C ≥ (2 : Int)) →
  (H + B ≥ (3 : Int)) →
  (H + A ≥ (5 : Int)) →
  (G + (-1 : Int) * M ≥ (-1 : Int)) →
  (G + (-1 : Int) * J ≥ (0 : Int)) →
  (G + (-1 : Int) * H ≥ (-1 : Int)) →
  (G + (-1 : Int) * E ≥ (-2 : Int)) →
  (G + (-1 : Int) * D ≥ (-1 : Int)) →
  (G + Q ≥ (3 : Int)) →
  (G + P ≥ (1 : Int)) →
  (G + O ≥ (2 : Int)) →
  (G + N ≥ (3 : Int)) →
  (G + M ≥ (1 : Int)) →
  (G + J ≥ (0 : Int)) →
  (G + I ≥ (0 : Int)) →
  (G + H ≥ (1 : Int)) →
  (G + F ≥ (1 : Int)) →
  (G + E ≥ (2 : Int)) →
  (G + D ≥ (1 : Int)) →
  (G + C ≥ (1 : Int)) →
  (G + B ≥ (2 : Int)) →
  (G + A ≥ (4 : Int)) →
  (F + (-1 : Int) * C ≥ (0 : Int)) →
  (F + Q ≥ (4 : Int)) →
  (F + P ≥ (2 : Int)) →
  (F + O ≥ (3 : Int)) →
  (F + C ≥ (2 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + O ≥ (4 : Int)) →
  (E + F ≥ (3 : Int)) →
  (E + C ≥ (3 : Int)) →
  (D + (-1 : Int) * E ≥ (-1 : Int)) →
  (D + Q ≥ (4 : Int)) →
  (D + P ≥ (2 : Int)) →
  (D + O ≥ (3 : Int)) →
  (D + F ≥ (2 : Int)) →
  (D + E ≥ (3 : Int)) →
  (D + C ≥ (2 : Int)) →
  (C + Q ≥ (4 : Int)) →
  (C + P ≥ (2 : Int)) →
  (C + O ≥ (3 : Int)) →
  (B + (-1 : Int) * M ≥ (1 : Int)) →
  (B + (-1 : Int) * F ≥ (1 : Int)) →
  (B + (-1 : Int) * E ≥ (0 : Int)) →
  (B + (-1 : Int) * D ≥ (1 : Int)) →
  (B + (-1 : Int) * C ≥ (1 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (3 : Int)) →
  (B + O ≥ (4 : Int)) →
  (B + N ≥ (5 : Int)) →
  (B + M ≥ (3 : Int)) →
  (B + F ≥ (3 : Int)) →
  (B + E ≥ (4 : Int)) →
  (B + D ≥ (3 : Int)) →
  (B + C ≥ (3 : Int)) →
  (A + (-1 : Int) * Q ≥ (1 : Int)) →
  (A + (-1 : Int) * P ≥ (3 : Int)) →
  (A + (-1 : Int) * O ≥ (2 : Int)) →
  (A + (-1 : Int) * N ≥ (1 : Int)) →
  (A + (-1 : Int) * M ≥ (3 : Int)) →
  (A + (-1 : Int) * F ≥ (2 : Int)) →
  (A + (-1 : Int) * E ≥ (2 : Int)) →
  (A + (-1 : Int) * D ≥ (3 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (1 : Int)) →
  (A + Q ≥ (7 : Int)) →
  (A + P ≥ (5 : Int)) →
  (A + O ≥ (6 : Int)) →
  (A + N ≥ (7 : Int)) →
  (A + M ≥ (5 : Int)) →
  (A + F ≥ (5 : Int)) →
  (A + E ≥ (6 : Int)) →
  (A + D ≥ (5 : Int)) →
  (A + C ≥ (5 : Int)) →
  (A + B ≥ (6 : Int)) →
  (Q ≥ (3 : Int)) →
  (P ≥ (1 : Int)) →
  (O ≥ (2 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (1 : Int)) →
  (L ≥ (4 : Int)) →
  (K ≥ (5 : Int)) →
  (J ≥ (0 : Int)) →
  (I ≥ (0 : Int)) →
  (H ≥ (1 : Int)) →
  (G ≥ (0 : Int)) →
  (F ≥ (1 : Int)) →
  (E ≥ (2 : Int)) →
  (D ≥ (1 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (4 : Int)) →
  (M ≤ (1 : Int)) →
  (J ≤ (0 : Int)) →
  (H ≤ (1 : Int)) →
  (G ≤ (0 : Int)) →
  (E ≤ (2 : Int)) →
  (D ≤ (1 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  r1 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  ((-1 : Int) * N + Q ≥ (1 : Int)) →
  ((-1 : Int) * M + Q ≥ (2 : Int)) →
  ((-1 : Int) * M + P ≥ (0 : Int)) →
  ((-1 : Int) * M + O ≥ (1 : Int)) →
  ((-1 : Int) * M + N ≥ (1 : Int)) →
  ((-1 : Int) * M + F ≥ (0 : Int)) →
  ((-1 : Int) * M + E ≥ (1 : Int)) →
  ((-1 : Int) * M + D ≥ (0 : Int)) →
  ((-1 : Int) * M + C ≥ (0 : Int)) →
  ((-1 : Int) * K + Q ≥ (-1 : Int)) →
  ((-1 : Int) * K + N ≥ (-2 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * K + A ≥ (-1 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * M ≥ (-1 : Int)) →
  ((-1 : Int) * J + Q ≥ (3 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + O ≥ (2 : Int)) →
  ((-1 : Int) * J + N ≥ (2 : Int)) →
  ((-1 : Int) * J + M ≥ (1 : Int)) →
  ((-1 : Int) * J + F ≥ (1 : Int)) →
  ((-1 : Int) * J + E ≥ (2 : Int)) →
  ((-1 : Int) * J + D ≥ (1 : Int)) →
  ((-1 : Int) * J + C ≥ (1 : Int)) →
  ((-1 : Int) * J + B ≥ (2 : Int)) →
  ((-1 : Int) * J + A ≥ (3 : Int)) →
  ((-1 : Int) * I + Q ≥ (2 : Int)) →
  ((-1 : Int) * I + N ≥ (1 : Int)) →
  ((-1 : Int) * I + A ≥ (2 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * M ≥ (-2 : Int)) →
  ((-1 : Int) * H + (-1 : Int) * J ≥ (-1 : Int)) →
  ((-1 : Int) * H + Q ≥ (2 : Int)) →
  ((-1 : Int) * H + P ≥ (0 : Int)) →
  ((-1 : Int) * H + O ≥ (1 : Int)) →
  ((-1 : Int) * H + N ≥ (1 : Int)) →
  ((-1 : Int) * H + M ≥ (0 : Int)) →
  ((-1 : Int) * H + J ≥ (-1 : Int)) →
  ((-1 : Int) * H + I ≥ (-1 : Int)) →
  ((-1 : Int) * H + F ≥ (0 : Int)) →
  ((-1 : Int) * H + E ≥ (1 : Int)) →
  ((-1 : Int) * H + D ≥ (0 : Int)) →
  ((-1 : Int) * H + C ≥ (0 : Int)) →
  ((-1 : Int) * H + B ≥ (1 : Int)) →
  ((-1 : Int) * H + A ≥ (2 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * M ≥ (-2 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * J ≥ (-1 : Int)) →
  ((-1 : Int) * G + (-1 : Int) * H ≥ (-1 : Int)) →
  ((-1 : Int) * G + Q ≥ (2 : Int)) →
  ((-1 : Int) * G + P ≥ (0 : Int)) →
  ((-1 : Int) * G + O ≥ (1 : Int)) →
  ((-1 : Int) * G + N ≥ (1 : Int)) →
  ((-1 : Int) * G + M ≥ (0 : Int)) →
  ((-1 : Int) * G + J ≥ (-1 : Int)) →
  ((-1 : Int) * G + I ≥ (-1 : Int)) →
  ((-1 : Int) * G + H ≥ (-1 : Int)) →
  ((-1 : Int) * G + F ≥ (0 : Int)) →
  ((-1 : Int) * G + E ≥ (1 : Int)) →
  ((-1 : Int) * G + D ≥ (0 : Int)) →
  ((-1 : Int) * G + C ≥ (0 : Int)) →
  ((-1 : Int) * G + B ≥ (1 : Int)) →
  ((-1 : Int) * G + A ≥ (2 : Int)) →
  ((-1 : Int) * F + Q ≥ (2 : Int)) →
  ((-1 : Int) * F + P ≥ (0 : Int)) →
  ((-1 : Int) * F + O ≥ (1 : Int)) →
  ((-1 : Int) * F + C ≥ (0 : Int)) →
  ((-1 : Int) * E + Q ≥ (1 : Int)) →
  ((-1 : Int) * D + Q ≥ (1 : Int)) →
  ((-1 : Int) * C + Q ≥ (2 : Int)) →
  ((-1 : Int) * C + P ≥ (0 : Int)) →
  ((-1 : Int) * C + O ≥ (1 : Int)) →
  ((-1 : Int) * B + Q ≥ (1 : Int)) →
  ((-1 : Int) * B + P ≥ (-1 : Int)) →
  ((-1 : Int) * B + O ≥ (0 : Int)) →
  ((-1 : Int) * B + N ≥ (0 : Int)) →
  ((-1 : Int) * B + F ≥ (-1 : Int)) →
  ((-1 : Int) * B + C ≥ (-1 : Int)) →
  ((-1 : Int) * A + Q ≥ (0 : Int)) →
  ((-1 : Int) * A + N ≥ (-1 : Int)) →
  (Q + (-1 : Int) * P ≥ (2 : Int)) →
  (Q + (-1 : Int) * O ≥ (1 : Int)) →
  (Q + P ≥ (4 : Int)) →
  (Q + O ≥ (5 : Int)) →
  (P + (-1 : Int) * O ≥ (-1 : Int)) →
  (P + O ≥ (3 : Int)) →
  (N + (-1 : Int) * Q ≥ (-1 : Int)) →
  (N + (-1 : Int) * P ≥ (1 : Int)) →
  (N + (-1 : Int) * O ≥ (0 : Int)) →
  (N + (-1 : Int) * F ≥ (1 : Int)) →
  (N + (-1 : Int) * E ≥ (0 : Int)) →
  (N + (-1 : Int) * D ≥ (0 : Int)) →
  (N + (-1 : Int) * C ≥ (1 : Int)) →
  (N + Q ≥ (5 : Int)) →
  (N + P ≥ (3 : Int)) →
  (N + O ≥ (4 : Int)) →
  (N + F ≥ (3 : Int)) →
  (N + E ≥ (4 : Int)) →
  (N + D ≥ (3 : Int)) →
  (N + C ≥ (3 : Int)) →
  (M + Q ≥ (4 : Int)) →
  (M + P ≥ (2 : Int)) →
  (M + O ≥ (3 : Int)) →
  (M + N ≥ (3 : Int)) →
  (M + F ≥ (2 : Int)) →
  (M + E ≥ (3 : Int)) →
  (M + D ≥ (2 : Int)) →
  (M + C ≥ (2 : Int)) →
  (L + (-1 : Int) * Q ≥ (0 : Int)) →
  (L + (-1 : Int) * P ≥ (2 : Int)) →
  (L + (-1 : Int) * O ≥ (1 : Int)) →
  (L + (-1 : Int) * N ≥ (1 : Int)) →
  (L + (-1 : Int) * M ≥ (2 : Int)) →
  (L + (-1 : Int) * J ≥ (3 : Int)) →
  (L + (-1 : Int) * I ≥ (2 : Int)) →
  (L + (-1 : Int) * H ≥ (2 : Int)) →
  (L + (-1 : Int) * G ≥ (2 : Int)) →
  (L + (-1 : Int) * F ≥ (2 : Int)) →
  (L + (-1 : Int) * E ≥ (1 : Int)) →
  (L + (-1 : Int) * D ≥ (1 : Int)) →
  (L + (-1 : Int) * C ≥ (2 : Int)) →
  (L + (-1 : Int) * B ≥ (1 : Int)) →
  (L + (-1 : Int) * A ≥ (0 : Int)) →
  (L + Q ≥ (6 : Int)) →
  (L + P ≥ (4 : Int)) →
  (L + O ≥ (5 : Int)) →
  (L + N ≥ (5 : Int)) →
  (L + M ≥ (4 : Int)) →
  (L + J ≥ (3 : Int)) →
  (L + I ≥ (3 : Int)) →
  (L + H ≥ (3 : Int)) →
  (L + G ≥ (3 : Int)) →
  (L + F ≥ (4 : Int)) →
  (L + E ≥ (5 : Int)) →
  (L + D ≥ (4 : Int)) →
  (L + C ≥ (4 : Int)) →
  (L + B ≥ (5 : Int)) →
  (L + A ≥ (6 : Int)) →
  (K + (-1 : Int) * Q ≥ (1 : Int)) →
  (K + (-1 : Int) * P ≥ (3 : Int)) →
  (K + (-1 : Int) * O ≥ (2 : Int)) →
  (K + (-1 : Int) * N ≥ (2 : Int)) →
  (K + (-1 : Int) * M ≥ (3 : Int)) →
  (K + (-1 : Int) * J ≥ (4 : Int)) →
  (K + (-1 : Int) * I ≥ (3 : Int)) →
  (K + (-1 : Int) * H ≥ (3 : Int)) →
  (K + (-1 : Int) * G ≥ (3 : Int)) →
  (K + (-1 : Int) * F ≥ (3 : Int)) →
  (K + (-1 : Int) * E ≥ (2 : Int)) →
  (K + (-1 : Int) * D ≥ (2 : Int)) →
  (K + (-1 : Int) * C ≥ (3 : Int)) →
  (K + (-1 : Int) * B ≥ (2 : Int)) →
  (K + (-1 : Int) * A ≥ (1 : Int)) →
  (K + Q ≥ (7 : Int)) →
  (K + P ≥ (5 : Int)) →
  (K + O ≥ (6 : Int)) →
  (K + N ≥ (6 : Int)) →
  (K + M ≥ (5 : Int)) →
  (K + L ≥ (7 : Int)) →
  (K + J ≥ (4 : Int)) →
  (K + I ≥ (4 : Int)) →
  (K + H ≥ (4 : Int)) →
  (K + G ≥ (4 : Int)) →
  (K + F ≥ (5 : Int)) →
  (K + E ≥ (6 : Int)) →
  (K + D ≥ (5 : Int)) →
  (K + C ≥ (5 : Int)) →
  (K + B ≥ (6 : Int)) →
  (K + A ≥ (7 : Int)) →
  (J + (-1 : Int) * M ≥ (-1 : Int)) →
  (J + Q ≥ (3 : Int)) →
  (J + P ≥ (1 : Int)) →
  (J + O ≥ (2 : Int)) →
  (J + N ≥ (2 : Int)) →
  (J + M ≥ (1 : Int)) →
  (J + F ≥ (1 : Int)) →
  (J + E ≥ (2 : Int)) →
  (J + D ≥ (1 : Int)) →
  (J + C ≥ (1 : Int)) →
  (J + B ≥ (2 : Int)) →
  (J + A ≥ (3 : Int)) →
  (I + (-1 : Int) * M ≥ (-1 : Int)) →
  (I + (-1 : Int) * J ≥ (0 : Int)) →
  (I + Q ≥ (3 : Int)) →
  (I + P ≥ (1 : Int)) →
  (I + O ≥ (2 : Int)) →
  (I + N ≥ (2 : Int)) →
  (I + M ≥ (1 : Int)) →
  (I + J ≥ (0 : Int)) →
  (I + F ≥ (1 : Int)) →
  (I + E ≥ (2 : Int)) →
  (I + D ≥ (1 : Int)) →
  (I + C ≥ (1 : Int)) →
  (I + B ≥ (2 : Int)) →
  (I + A ≥ (3 : Int)) →
  (H + (-1 : Int) * M ≥ (-1 : Int)) →
  (H + (-1 : Int) * J ≥ (0 : Int)) →
  (H + Q ≥ (3 : Int)) →
  (H + P ≥ (1 : Int)) →
  (H + O ≥ (2 : Int)) →
  (H + N ≥ (2 : Int)) →
  (H + M ≥ (1 : Int)) →
  (H + J ≥ (0 : Int)) →
  (H + I ≥ (0 : Int)) →
  (H + F ≥ (1 : Int)) →
  (H + E ≥ (2 : Int)) →
  (H + D ≥ (1 : Int)) →
  (H + C ≥ (1 : Int)) →
  (H + B ≥ (2 : Int)) →
  (H + A ≥ (3 : Int)) →
  (G + Q ≥ (3 : Int)) →
  (G + P ≥ (0 : Int)) →
  (G + O ≥ (1 : Int)) →
  (G + N ≥ (2 : Int)) →
  (G + F ≥ (0 : Int)) →
  (G + C ≥ (0 : Int)) →
  (G + B ≥ (1 : Int)) →
  (G + A ≥ (3 : Int)) →
  (F + (-1 : Int) * P ≥ (0 : Int)) →
  (F + (-1 : Int) * O ≥ (-1 : Int)) →
  (F + (-1 : Int) * C ≥ (0 : Int)) →
  (F + Q ≥ (4 : Int)) →
  (F + P ≥ (2 : Int)) →
  (F + O ≥ (3 : Int)) →
  (F + C ≥ (2 : Int)) →
  (E + Q ≥ (5 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + O ≥ (4 : Int)) →
  (E + F ≥ (3 : Int)) →
  (E + C ≥ (3 : Int)) →
  (D + Q ≥ (4 : Int)) →
  (D + P ≥ (2 : Int)) →
  (D + O ≥ (3 : Int)) →
  (D + F ≥ (2 : Int)) →
  (D + E ≥ (3 : Int)) →
  (D + C ≥ (2 : Int)) →
  (C + (-1 : Int) * P ≥ (0 : Int)) →
  (C + (-1 : Int) * O ≥ (-1 : Int)) →
  (C + Q ≥ (4 : Int)) →
  (C + P ≥ (2 : Int)) →
  (C + O ≥ (3 : Int)) →
  (B + (-1 : Int) * P ≥ (1 : Int)) →
  (B + (-1 : Int) * O ≥ (0 : Int)) →
  (B + (-1 : Int) * M ≥ (1 : Int)) →
  (B + (-1 : Int) * F ≥ (1 : Int)) →
  (B + (-1 : Int) * C ≥ (1 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (3 : Int)) →
  (B + O ≥ (4 : Int)) →
  (B + N ≥ (4 : Int)) →
  (B + M ≥ (3 : Int)) →
  (B + F ≥ (3 : Int)) →
  (B + E ≥ (4 : Int)) →
  (B + D ≥ (3 : Int)) →
  (B + C ≥ (3 : Int)) →
  (A + (-1 : Int) * Q ≥ (0 : Int)) →
  (A + (-1 : Int) * P ≥ (2 : Int)) →
  (A + (-1 : Int) * O ≥ (1 : Int)) →
  (A + (-1 : Int) * N ≥ (1 : Int)) →
  (A + (-1 : Int) * M ≥ (2 : Int)) →
  (A + (-1 : Int) * F ≥ (2 : Int)) →
  (A + (-1 : Int) * E ≥ (1 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (1 : Int)) →
  (A + Q ≥ (6 : Int)) →
  (A + P ≥ (4 : Int)) →
  (A + O ≥ (5 : Int)) →
  (A + N ≥ (5 : Int)) →
  (A + M ≥ (4 : Int)) →
  (A + F ≥ (4 : Int)) →
  (A + E ≥ (5 : Int)) →
  (A + D ≥ (4 : Int)) →
  (A + C ≥ (4 : Int)) →
  (A + B ≥ (5 : Int)) →
  (Q ≥ (3 : Int)) →
  (P ≥ (1 : Int)) →
  (O ≥ (2 : Int)) →
  (N ≥ (2 : Int)) →
  (M ≥ (1 : Int)) →
  (L ≥ (3 : Int)) →
  (K ≥ (4 : Int)) →
  (J ≥ (0 : Int)) →
  (I ≥ (0 : Int)) →
  (H ≥ (0 : Int)) →
  (F ≥ (1 : Int)) →
  (E ≥ (2 : Int)) →
  (D ≥ (1 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (3 : Int)) →
  (M ≤ (1 : Int)) →
  (J ≤ (0 : Int)) →
  (H ≤ (1 : Int)) →
  (G ≤ (1 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  r3 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r1 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r0 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r3 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r0 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r3 A B C D E F G H I J K L M N Q P R O) →
  (True) →
  r1 A B C D E F G H I J K L M N R Q P O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r0 A B C D E F G H I J K L M N P Q S O) →
  (r3 A B C D E F G H I J K L M N P R Q O) →
  (r0 A B C D E F G H I J K L M N P S R O) →
  (True) →
  r1 A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r0 A B C D E F G H I J K L M N P Q S O) →
  (r0 A B C D E F G H I J K L M N P R Q O) →
  (r3 A B C D E F G H I J K L M N P S R O) →
  (True) →
  r1 A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 A B C D E F G H I J K L M N P Q S O) →
  (r0 A B C D E F G H I J K L M N P R Q O) →
  (r0 A B C D E F G H I J K L M N P S R O) →
  (True) →
  r1 A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N P S Q O) →
  (r3 A B C D E F G H I J K L M N T S R O) →
  (r0 A B C D E F G H I J K L M N Q S R O) →
  (r0 A B C D E F G H I J K L M N Q T S O) →
  (r0 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r1 A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N P S Q O) →
  (r0 A B C D E F G H I J K L M N T S R O) →
  (r3 A B C D E F G H I J K L M N Q S R O) →
  (r0 A B C D E F G H I J K L M N Q T S O) →
  (r0 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r1 A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N P S Q O) →
  (r0 A B C D E F G H I J K L M N T S R O) →
  (r0 A B C D E F G H I J K L M N Q S R O) →
  (r3 A B C D E F G H I J K L M N Q T S O) →
  (r0 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r1 A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N P S Q O) →
  (r0 A B C D E F G H I J K L M N T S R O) →
  (r0 A B C D E F G H I J K L M N Q S R O) →
  (r0 A B C D E F G H I J K L M N Q T S O) →
  (r3 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r1 A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r3 A B C D E F G H I J K L M N P S Q O) →
  (r0 A B C D E F G H I J K L M N T S R O) →
  (r0 A B C D E F G H I J K L M N Q S R O) →
  (r0 A B C D E F G H I J K L M N Q T S O) →
  (r0 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r1 A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r3 A B C D E F G H I J K L M N Q P R O) →
  (True) →
  r3 A B C D E F G H I J K L M N R Q P O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r0 A B C D E F G H I J K L M N P Q S O) →
  (r3 A B C D E F G H I J K L M N P R Q O) →
  (r0 A B C D E F G H I J K L M N P S R O) →
  (True) →
  r3 A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r0 A B C D E F G H I J K L M N P Q S O) →
  (r0 A B C D E F G H I J K L M N P R Q O) →
  (r3 A B C D E F G H I J K L M N P S R O) →
  (True) →
  r3 A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 A B C D E F G H I J K L M N P Q S O) →
  (r0 A B C D E F G H I J K L M N P R Q O) →
  (r0 A B C D E F G H I J K L M N P S R O) →
  (True) →
  r3 A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N P S Q O) →
  (r3 A B C D E F G H I J K L M N T S R O) →
  (r0 A B C D E F G H I J K L M N Q S R O) →
  (r0 A B C D E F G H I J K L M N Q T S O) →
  (r0 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r3 A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N P S Q O) →
  (r0 A B C D E F G H I J K L M N T S R O) →
  (r3 A B C D E F G H I J K L M N Q S R O) →
  (r0 A B C D E F G H I J K L M N Q T S O) →
  (r0 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r3 A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N P S Q O) →
  (r0 A B C D E F G H I J K L M N T S R O) →
  (r0 A B C D E F G H I J K L M N Q S R O) →
  (r3 A B C D E F G H I J K L M N Q T S O) →
  (r0 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r3 A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N P S Q O) →
  (r0 A B C D E F G H I J K L M N T S R O) →
  (r0 A B C D E F G H I J K L M N Q S R O) →
  (r0 A B C D E F G H I J K L M N Q T S O) →
  (r3 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r3 A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r3 A B C D E F G H I J K L M N P S Q O) →
  (r0 A B C D E F G H I J K L M N T S R O) →
  (r0 A B C D E F G H I J K L M N Q S R O) →
  (r0 A B C D E F G H I J K L M N Q T S O) →
  (r0 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r3 A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N P S Q O) →
  (r3 A B C D E F G H I J K L M N P R S O) →
  (r0 A B C D E F G H I J K L M N T S R O) →
  (r0 A B C D E F G H I J K L M N Q S R O) →
  (r0 A B C D E F G H I J K L M N Q T S O) →
  (r0 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r3 A B C D E F G H I J K L M N P S Q O) →
  (r0 A B C D E F G H I J K L M N P R S O) →
  (r0 A B C D E F G H I J K L M N T S R O) →
  (r0 A B C D E F G H I J K L M N Q S R O) →
  (r0 A B C D E F G H I J K L M N Q T S O) →
  (r0 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N P S Q O) →
  (r0 A B C D E F G H I J K L M N P R S O) →
  (r0 A B C D E F G H I J K L M N T S R O) →
  (r0 A B C D E F G H I J K L M N Q S R O) →
  (r0 A B C D E F G H I J K L M N Q T S O) →
  (r3 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N P S Q O) →
  (r0 A B C D E F G H I J K L M N P R S O) →
  (r0 A B C D E F G H I J K L M N T S R O) →
  (r0 A B C D E F G H I J K L M N Q S R O) →
  (r3 A B C D E F G H I J K L M N Q T S O) →
  (r0 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N P S Q O) →
  (r0 A B C D E F G H I J K L M N P R S O) →
  (r0 A B C D E F G H I J K L M N T S R O) →
  (r3 A B C D E F G H I J K L M N Q S R O) →
  (r0 A B C D E F G H I J K L M N Q T S O) →
  (r0 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N P S Q O) →
  (r0 A B C D E F G H I J K L M N P R S O) →
  (r3 A B C D E F G H I J K L M N T S R O) →
  (r0 A B C D E F G H I J K L M N Q S R O) →
  (r0 A B C D E F G H I J K L M N Q T S O) →
  (r0 A B C D E F G H I J K L M N P T S O) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r0 A B C D E F G H I J K L M N P Q S O) →
  (r3 A B C D E F G H I J K L M N S Q R O) →
  (r0 A B C D E F G H I J K L M N P R Q O) →
  (r0 A B C D E F G H I J K L M N P S R O) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 A B C D E F G H I J K L M N P Q S O) →
  (r0 A B C D E F G H I J K L M N S Q R O) →
  (r0 A B C D E F G H I J K L M N P R Q O) →
  (r0 A B C D E F G H I J K L M N P S R O) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r0 A B C D E F G H I J K L M N P Q S O) →
  (r0 A B C D E F G H I J K L M N S Q R O) →
  (r0 A B C D E F G H I J K L M N P R Q O) →
  (r3 A B C D E F G H I J K L M N P S R O) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r0 A B C D E F G H I J K L M N P Q S O) →
  (r0 A B C D E F G H I J K L M N S Q R O) →
  (r3 A B C D E F G H I J K L M N P R Q O) →
  (r0 A B C D E F G H I J K L M N P S R O) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 A B C D E F G H I J K L M N R Q P O) →
  (r3 A B C D E F G H I J K L M N R P Q O) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r3 A B C D E F G H I J K L M N R Q P O) →
  (r0 A B C D E F G H I J K L M N R P Q O) →
  (True) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  False))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«incremental.35_000»
