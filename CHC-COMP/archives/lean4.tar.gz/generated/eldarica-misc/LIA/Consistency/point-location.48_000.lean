import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«point-location.48_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1335:1-1335:12 (check-sat, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":11:1-122:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":123:1-233:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":234:1-350:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":351:1-462:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":463:1-587:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":588:1-703:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":704:1-818:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":819:1-829:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":830:1-840:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":841:1-851:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":852:1-862:2 (clause 11, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":863:1-873:2 (clause 12, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":874:1-886:2 (clause 13, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":887:1-899:2 (clause 14, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":900:1-912:2 (clause 15, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":913:1-927:2 (clause 16, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":928:1-942:2 (clause 17, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":943:1-957:2 (clause 18, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":958:1-972:2 (clause 19, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":973:1-987:2 (clause 20, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":988:1-998:2 (clause 21, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":999:1-1009:2 (clause 22, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1010:1-1022:2 (clause 23, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1023:1-1035:2 (clause 24, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1036:1-1048:2 (clause 25, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1049:1-1063:2 (clause 26, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1064:1-1078:2 (clause 27, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1079:1-1093:2 (clause 28, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1094:1-1108:2 (clause 29, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1109:1-1123:2 (clause 30, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1124:1-1139:2 (clause 31, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1140:1-1155:2 (clause 32, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1156:1-1171:2 (clause 33, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1172:1-1187:2 (clause 34, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1188:1-1203:2 (clause 35, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1204:1-1219:2 (clause 36, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1220:1-1233:2 (clause 37, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1234:1-1247:2 (clause 38, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1248:1-1261:2 (clause 39, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1262:1-1275:2 (clause 40, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1276:1-1287:2 (clause 41, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1288:1-1299:2 (clause 42, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1300:1-1311:2 (clause 43, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1312:1-1323:2 (clause 44, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.48_000.smt2":1324:1-1333:2 (clause 45, command 52)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + H ≥ (1 : Int)) →
  ((-1 : Int) * I + G ≥ (4 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + H ≥ (0 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * B + D ≥ (2 : Int)) →
  ((-1 : Int) * B + C ≥ (1 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (11 : Int)) →
  (I + H ≥ (7 : Int)) →
  (I + G ≥ (10 : Int)) →
  (F + (-1 : Int) * H ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (10 : Int)) →
  (F + I ≥ (9 : Int)) →
  (F + G ≥ (13 : Int)) →
  (F + D ≥ (12 : Int)) →
  (F + C ≥ (11 : Int)) →
  (F + B ≥ (10 : Int)) →
  (F + A ≥ (13 : Int)) →
  (F + K ≥ (9 : Int)) →
  (E + (-1 : Int) * H ≥ (3 : Int)) →
  (E + (-1 : Int) * I ≥ (4 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (11 : Int)) →
  (E + I ≥ (10 : Int)) →
  (E + G ≥ (14 : Int)) →
  (E + F ≥ (13 : Int)) →
  (E + D ≥ (13 : Int)) →
  (E + C ≥ (12 : Int)) →
  (E + B ≥ (11 : Int)) →
  (E + A ≥ (14 : Int)) →
  (E + K ≥ (10 : Int)) →
  (D + (-1 : Int) * H ≥ (2 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + H ≥ (10 : Int)) →
  (D + I ≥ (9 : Int)) →
  (D + G ≥ (13 : Int)) →
  (C + (-1 : Int) * H ≥ (1 : Int)) →
  (C + (-1 : Int) * I ≥ (2 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (9 : Int)) →
  (C + I ≥ (8 : Int)) →
  (C + G ≥ (12 : Int)) →
  (C + D ≥ (11 : Int)) →
  (B + (-1 : Int) * H ≥ (0 : Int)) →
  (B + (-1 : Int) * I ≥ (1 : Int)) →
  (B + H ≥ (8 : Int)) →
  (B + I ≥ (7 : Int)) →
  (B + G ≥ (11 : Int)) →
  (B + D ≥ (10 : Int)) →
  (B + C ≥ (9 : Int)) →
  (A + (-1 : Int) * H ≥ (3 : Int)) →
  (A + (-1 : Int) * I ≥ (4 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (3 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (11 : Int)) →
  (A + I ≥ (10 : Int)) →
  (A + G ≥ (14 : Int)) →
  (A + D ≥ (13 : Int)) →
  (A + C ≥ (12 : Int)) →
  (A + B ≥ (11 : Int)) →
  (A + K ≥ (10 : Int)) →
  (K + (-1 : Int) * I ≥ (0 : Int)) →
  (K + H ≥ (7 : Int)) →
  (K + I ≥ (6 : Int)) →
  (K + G ≥ (10 : Int)) →
  (K + D ≥ (9 : Int)) →
  (K + C ≥ (8 : Int)) →
  (K + B ≥ (7 : Int)) →
  (H ≥ (4 : Int)) →
  (I ≥ (3 : Int)) →
  (G ≥ (7 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (7 : Int)) →
  (D ≥ (6 : Int)) →
  (C ≥ (5 : Int)) →
  (B ≥ (4 : Int)) →
  (A ≥ (7 : Int)) →
  (K ≥ (3 : Int)) →
  ((-1 : Int) * H + G ≥ (3 : Int)) →
  r1 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + H ≥ (1 : Int)) →
  ((-1 : Int) * I + G ≥ (5 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * B + D ≥ (2 : Int)) →
  ((-1 : Int) * B + C ≥ (1 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (12 : Int)) →
  (I + H ≥ (7 : Int)) →
  (I + G ≥ (11 : Int)) →
  (F + (-1 : Int) * H ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (4 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (11 : Int)) →
  (F + I ≥ (10 : Int)) →
  (F + G ≥ (15 : Int)) →
  (F + D ≥ (14 : Int)) →
  (F + C ≥ (13 : Int)) →
  (F + B ≥ (12 : Int)) →
  (F + A ≥ (15 : Int)) →
  (F + K ≥ (10 : Int)) →
  (E + (-1 : Int) * H ≥ (4 : Int)) →
  (E + (-1 : Int) * I ≥ (5 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (12 : Int)) →
  (E + I ≥ (11 : Int)) →
  (E + G ≥ (16 : Int)) →
  (E + F ≥ (15 : Int)) →
  (E + D ≥ (15 : Int)) →
  (E + C ≥ (14 : Int)) →
  (E + B ≥ (13 : Int)) →
  (E + A ≥ (16 : Int)) →
  (E + K ≥ (11 : Int)) →
  (D + (-1 : Int) * H ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (4 : Int)) →
  (D + H ≥ (11 : Int)) →
  (D + I ≥ (10 : Int)) →
  (D + G ≥ (15 : Int)) →
  (C + (-1 : Int) * H ≥ (2 : Int)) →
  (C + (-1 : Int) * I ≥ (3 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (10 : Int)) →
  (C + I ≥ (9 : Int)) →
  (C + G ≥ (14 : Int)) →
  (C + D ≥ (13 : Int)) →
  (B + (-1 : Int) * H ≥ (1 : Int)) →
  (B + (-1 : Int) * I ≥ (2 : Int)) →
  (B + H ≥ (9 : Int)) →
  (B + I ≥ (8 : Int)) →
  (B + G ≥ (13 : Int)) →
  (B + D ≥ (12 : Int)) →
  (B + C ≥ (11 : Int)) →
  (A + (-1 : Int) * H ≥ (4 : Int)) →
  (A + (-1 : Int) * I ≥ (5 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (3 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (12 : Int)) →
  (A + I ≥ (11 : Int)) →
  (A + G ≥ (16 : Int)) →
  (A + D ≥ (15 : Int)) →
  (A + C ≥ (14 : Int)) →
  (A + B ≥ (13 : Int)) →
  (A + K ≥ (11 : Int)) →
  (K + (-1 : Int) * I ≥ (0 : Int)) →
  (K + H ≥ (7 : Int)) →
  (K + I ≥ (6 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + D ≥ (10 : Int)) →
  (K + C ≥ (9 : Int)) →
  (K + B ≥ (8 : Int)) →
  (H ≥ (4 : Int)) →
  (I ≥ (3 : Int)) →
  (G ≥ (8 : Int)) →
  (F ≥ (7 : Int)) →
  (E ≥ (8 : Int)) →
  (D ≥ (7 : Int)) →
  (C ≥ (6 : Int)) →
  (B ≥ (5 : Int)) →
  (A ≥ (8 : Int)) →
  (K ≥ (3 : Int)) →
  ((-1 : Int) * H + G ≥ (4 : Int)) →
  r1 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * E + K ≥ (-3 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + H ≥ (0 : Int)) →
  ((-1 : Int) * B + I ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (4 : Int)) →
  ((-1 : Int) * B + D ≥ (3 : Int)) →
  ((-1 : Int) * B + C ≥ (2 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (9 : Int)) →
  (I + (-1 : Int) * H ≥ (1 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (11 : Int)) →
  (F + (-1 : Int) * H ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (2 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (3 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (8 : Int)) →
  (F + I ≥ (10 : Int)) →
  (F + G ≥ (13 : Int)) →
  (F + D ≥ (12 : Int)) →
  (F + C ≥ (11 : Int)) →
  (F + B ≥ (8 : Int)) →
  (F + A ≥ (13 : Int)) →
  (F + K ≥ (10 : Int)) →
  (E + (-1 : Int) * H ≥ (4 : Int)) →
  (E + (-1 : Int) * I ≥ (3 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (4 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (9 : Int)) →
  (E + I ≥ (11 : Int)) →
  (E + G ≥ (14 : Int)) →
  (E + F ≥ (13 : Int)) →
  (E + D ≥ (13 : Int)) →
  (E + C ≥ (12 : Int)) →
  (E + B ≥ (9 : Int)) →
  (E + A ≥ (14 : Int)) →
  (E + K ≥ (11 : Int)) →
  (D + (-1 : Int) * H ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (2 : Int)) →
  (D + H ≥ (8 : Int)) →
  (D + I ≥ (10 : Int)) →
  (D + G ≥ (13 : Int)) →
  (C + (-1 : Int) * H ≥ (2 : Int)) →
  (C + (-1 : Int) * I ≥ (1 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (7 : Int)) →
  (C + I ≥ (9 : Int)) →
  (C + G ≥ (12 : Int)) →
  (C + D ≥ (11 : Int)) →
  (B + (-1 : Int) * H ≥ (0 : Int)) →
  (B + H ≥ (4 : Int)) →
  (B + I ≥ (6 : Int)) →
  (B + G ≥ (9 : Int)) →
  (B + D ≥ (8 : Int)) →
  (B + C ≥ (7 : Int)) →
  (A + (-1 : Int) * H ≥ (4 : Int)) →
  (A + (-1 : Int) * I ≥ (3 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (4 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (9 : Int)) →
  (A + I ≥ (11 : Int)) →
  (A + G ≥ (14 : Int)) →
  (A + D ≥ (13 : Int)) →
  (A + C ≥ (12 : Int)) →
  (A + B ≥ (9 : Int)) →
  (A + K ≥ (11 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * I ≥ (0 : Int)) →
  (K + (-1 : Int) * D ≥ (-2 : Int)) →
  (K + (-1 : Int) * C ≥ (-1 : Int)) →
  (K + (-1 : Int) * B ≥ (1 : Int)) →
  (K + H ≥ (6 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + D ≥ (10 : Int)) →
  (K + C ≥ (9 : Int)) →
  (K + B ≥ (6 : Int)) →
  (H ≥ (2 : Int)) →
  (I ≥ (4 : Int)) →
  (G ≥ (7 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (7 : Int)) →
  (D ≥ (6 : Int)) →
  (C ≥ (5 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (7 : Int)) →
  (K ≥ (4 : Int)) →
  ((-1 : Int) * H + G ≥ (4 : Int)) →
  r1 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + G ≥ (4 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * B + D ≥ (2 : Int)) →
  ((-1 : Int) * B + C ≥ (1 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (10 : Int)) →
  (I + (-1 : Int) * H ≥ (1 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (12 : Int)) →
  (F + (-1 : Int) * H ≥ (4 : Int)) →
  (F + (-1 : Int) * I ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (9 : Int)) →
  (F + I ≥ (11 : Int)) →
  (F + G ≥ (15 : Int)) →
  (F + D ≥ (14 : Int)) →
  (F + C ≥ (13 : Int)) →
  (F + B ≥ (12 : Int)) →
  (F + A ≥ (15 : Int)) →
  (F + K ≥ (11 : Int)) →
  (E + (-1 : Int) * H ≥ (5 : Int)) →
  (E + (-1 : Int) * I ≥ (4 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (10 : Int)) →
  (E + I ≥ (12 : Int)) →
  (E + G ≥ (16 : Int)) →
  (E + F ≥ (15 : Int)) →
  (E + D ≥ (15 : Int)) →
  (E + C ≥ (14 : Int)) →
  (E + B ≥ (13 : Int)) →
  (E + A ≥ (16 : Int)) →
  (E + K ≥ (12 : Int)) →
  (D + (-1 : Int) * H ≥ (4 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + H ≥ (9 : Int)) →
  (D + I ≥ (11 : Int)) →
  (D + G ≥ (15 : Int)) →
  (C + (-1 : Int) * H ≥ (3 : Int)) →
  (C + (-1 : Int) * I ≥ (2 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (8 : Int)) →
  (C + I ≥ (10 : Int)) →
  (C + G ≥ (14 : Int)) →
  (C + D ≥ (13 : Int)) →
  (B + (-1 : Int) * H ≥ (2 : Int)) →
  (B + (-1 : Int) * I ≥ (1 : Int)) →
  (B + H ≥ (7 : Int)) →
  (B + I ≥ (9 : Int)) →
  (B + G ≥ (13 : Int)) →
  (B + D ≥ (12 : Int)) →
  (B + C ≥ (11 : Int)) →
  (A + (-1 : Int) * H ≥ (5 : Int)) →
  (A + (-1 : Int) * I ≥ (4 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (3 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (10 : Int)) →
  (A + I ≥ (12 : Int)) →
  (A + G ≥ (16 : Int)) →
  (A + D ≥ (15 : Int)) →
  (A + C ≥ (14 : Int)) →
  (A + B ≥ (13 : Int)) →
  (A + K ≥ (12 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * I ≥ (0 : Int)) →
  (K + H ≥ (6 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + G ≥ (12 : Int)) →
  (K + D ≥ (11 : Int)) →
  (K + C ≥ (10 : Int)) →
  (K + B ≥ (9 : Int)) →
  (H ≥ (2 : Int)) →
  (I ≥ (4 : Int)) →
  (G ≥ (8 : Int)) →
  (F ≥ (7 : Int)) →
  (E ≥ (8 : Int)) →
  (D ≥ (7 : Int)) →
  (C ≥ (6 : Int)) →
  (B ≥ (5 : Int)) →
  (A ≥ (8 : Int)) →
  (K ≥ (4 : Int)) →
  ((-1 : Int) * H + G ≥ (5 : Int)) →
  r1 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + (-1 : Int) * H ≥ (-5 : Int)) →
  ((-1 : Int) * I + H ≥ (-1 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * E + K ≥ (-3 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * H ≥ (-4 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * I ≥ (-5 : Int)) →
  ((-1 : Int) * B + H ≥ (0 : Int)) →
  ((-1 : Int) * B + I ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (4 : Int)) →
  ((-1 : Int) * B + D ≥ (3 : Int)) →
  ((-1 : Int) * B + C ≥ (2 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (8 : Int)) →
  (I + (-1 : Int) * H ≥ (1 : Int)) →
  (I + H ≥ (5 : Int)) →
  (I + G ≥ (9 : Int)) →
  (F + (-1 : Int) * H ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (2 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (3 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (7 : Int)) →
  (F + I ≥ (8 : Int)) →
  (F + G ≥ (11 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (9 : Int)) →
  (F + B ≥ (7 : Int)) →
  (F + A ≥ (11 : Int)) →
  (F + K ≥ (8 : Int)) →
  (E + (-1 : Int) * H ≥ (4 : Int)) →
  (E + (-1 : Int) * I ≥ (3 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (4 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (8 : Int)) →
  (E + I ≥ (9 : Int)) →
  (E + G ≥ (12 : Int)) →
  (E + F ≥ (11 : Int)) →
  (E + D ≥ (11 : Int)) →
  (E + C ≥ (10 : Int)) →
  (E + B ≥ (8 : Int)) →
  (E + A ≥ (12 : Int)) →
  (E + K ≥ (9 : Int)) →
  (D + (-1 : Int) * H ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (2 : Int)) →
  (D + H ≥ (7 : Int)) →
  (D + I ≥ (8 : Int)) →
  (D + G ≥ (11 : Int)) →
  (C + (-1 : Int) * H ≥ (2 : Int)) →
  (C + (-1 : Int) * I ≥ (1 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + I ≥ (7 : Int)) →
  (C + G ≥ (10 : Int)) →
  (C + D ≥ (9 : Int)) →
  (B + (-1 : Int) * H ≥ (0 : Int)) →
  (B + (-1 : Int) * I ≥ (-1 : Int)) →
  (B + H ≥ (4 : Int)) →
  (B + I ≥ (5 : Int)) →
  (B + G ≥ (8 : Int)) →
  (B + D ≥ (7 : Int)) →
  (B + C ≥ (6 : Int)) →
  (A + (-1 : Int) * H ≥ (4 : Int)) →
  (A + (-1 : Int) * I ≥ (3 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (4 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (8 : Int)) →
  (A + I ≥ (9 : Int)) →
  (A + G ≥ (12 : Int)) →
  (A + D ≥ (11 : Int)) →
  (A + C ≥ (10 : Int)) →
  (A + B ≥ (8 : Int)) →
  (A + K ≥ (9 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * I ≥ (0 : Int)) →
  (K + (-1 : Int) * D ≥ (-2 : Int)) →
  (K + (-1 : Int) * C ≥ (-1 : Int)) →
  (K + (-1 : Int) * B ≥ (1 : Int)) →
  (K + H ≥ (5 : Int)) →
  (K + I ≥ (6 : Int)) →
  (K + G ≥ (9 : Int)) →
  (K + D ≥ (8 : Int)) →
  (K + C ≥ (7 : Int)) →
  (K + B ≥ (5 : Int)) →
  (H ≥ (2 : Int)) →
  (I ≥ (3 : Int)) →
  (G ≥ (6 : Int)) →
  (F ≥ (5 : Int)) →
  (E ≥ (6 : Int)) →
  (D ≥ (5 : Int)) →
  (C ≥ (4 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (6 : Int)) →
  (K ≥ (3 : Int)) →
  (H ≤ (2 : Int)) →
  (I ≤ (3 : Int)) →
  (B ≤ (2 : Int)) →
  ((-1 : Int) * H + G ≥ (4 : Int)) →
  r1 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + (-1 : Int) * H ≥ (-5 : Int)) →
  ((-1 : Int) * I + H ≥ (-1 : Int)) →
  ((-1 : Int) * I + G ≥ (4 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * B + D ≥ (2 : Int)) →
  ((-1 : Int) * B + C ≥ (1 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (9 : Int)) →
  (I + (-1 : Int) * H ≥ (1 : Int)) →
  (I + H ≥ (5 : Int)) →
  (I + G ≥ (10 : Int)) →
  (F + (-1 : Int) * H ≥ (4 : Int)) →
  (F + (-1 : Int) * I ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (8 : Int)) →
  (F + I ≥ (9 : Int)) →
  (F + G ≥ (13 : Int)) →
  (F + D ≥ (12 : Int)) →
  (F + C ≥ (11 : Int)) →
  (F + B ≥ (10 : Int)) →
  (F + A ≥ (13 : Int)) →
  (F + K ≥ (9 : Int)) →
  (E + (-1 : Int) * H ≥ (5 : Int)) →
  (E + (-1 : Int) * I ≥ (4 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (9 : Int)) →
  (E + I ≥ (10 : Int)) →
  (E + G ≥ (14 : Int)) →
  (E + F ≥ (13 : Int)) →
  (E + D ≥ (13 : Int)) →
  (E + C ≥ (12 : Int)) →
  (E + B ≥ (11 : Int)) →
  (E + A ≥ (14 : Int)) →
  (E + K ≥ (10 : Int)) →
  (D + (-1 : Int) * H ≥ (4 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + H ≥ (8 : Int)) →
  (D + I ≥ (9 : Int)) →
  (D + G ≥ (13 : Int)) →
  (C + (-1 : Int) * H ≥ (3 : Int)) →
  (C + (-1 : Int) * I ≥ (2 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (7 : Int)) →
  (C + I ≥ (8 : Int)) →
  (C + G ≥ (12 : Int)) →
  (C + D ≥ (11 : Int)) →
  (B + (-1 : Int) * H ≥ (2 : Int)) →
  (B + (-1 : Int) * I ≥ (1 : Int)) →
  (B + H ≥ (6 : Int)) →
  (B + I ≥ (7 : Int)) →
  (B + G ≥ (11 : Int)) →
  (B + D ≥ (10 : Int)) →
  (B + C ≥ (9 : Int)) →
  (A + (-1 : Int) * H ≥ (5 : Int)) →
  (A + (-1 : Int) * I ≥ (4 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (3 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (9 : Int)) →
  (A + I ≥ (10 : Int)) →
  (A + G ≥ (14 : Int)) →
  (A + D ≥ (13 : Int)) →
  (A + C ≥ (12 : Int)) →
  (A + B ≥ (11 : Int)) →
  (A + K ≥ (10 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * I ≥ (0 : Int)) →
  (K + H ≥ (5 : Int)) →
  (K + I ≥ (6 : Int)) →
  (K + G ≥ (10 : Int)) →
  (K + D ≥ (9 : Int)) →
  (K + C ≥ (8 : Int)) →
  (K + B ≥ (7 : Int)) →
  (H ≥ (2 : Int)) →
  (I ≥ (3 : Int)) →
  (G ≥ (7 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (7 : Int)) →
  (D ≥ (6 : Int)) →
  (C ≥ (5 : Int)) →
  (B ≥ (4 : Int)) →
  (A ≥ (7 : Int)) →
  (K ≥ (3 : Int)) →
  (H ≤ (2 : Int)) →
  (I ≤ (3 : Int)) →
  ((-1 : Int) * H + G ≥ (5 : Int)) →
  r1 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + G ≥ (2 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (-2 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * D + I ≥ (-1 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + H ≥ (0 : Int)) →
  ((-1 : Int) * B + I ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * B + D ≥ (2 : Int)) →
  ((-1 : Int) * B + C ≥ (1 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + I ≥ (1 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (8 : Int)) →
  (I + (-1 : Int) * H ≥ (1 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (10 : Int)) →
  (F + (-1 : Int) * H ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (1 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (7 : Int)) →
  (F + I ≥ (9 : Int)) →
  (F + G ≥ (11 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (9 : Int)) →
  (F + B ≥ (7 : Int)) →
  (F + A ≥ (11 : Int)) →
  (F + K ≥ (8 : Int)) →
  (E + (-1 : Int) * H ≥ (3 : Int)) →
  (E + (-1 : Int) * I ≥ (2 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (8 : Int)) →
  (E + I ≥ (10 : Int)) →
  (E + G ≥ (12 : Int)) →
  (E + F ≥ (11 : Int)) →
  (E + D ≥ (11 : Int)) →
  (E + C ≥ (10 : Int)) →
  (E + B ≥ (8 : Int)) →
  (E + A ≥ (12 : Int)) →
  (E + K ≥ (9 : Int)) →
  (D + (-1 : Int) * H ≥ (2 : Int)) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (D + H ≥ (7 : Int)) →
  (D + I ≥ (9 : Int)) →
  (D + G ≥ (11 : Int)) →
  (C + (-1 : Int) * H ≥ (1 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + I ≥ (8 : Int)) →
  (C + G ≥ (10 : Int)) →
  (C + D ≥ (9 : Int)) →
  (B + (-1 : Int) * H ≥ (0 : Int)) →
  (B + H ≥ (4 : Int)) →
  (B + I ≥ (6 : Int)) →
  (B + G ≥ (8 : Int)) →
  (B + D ≥ (7 : Int)) →
  (B + C ≥ (6 : Int)) →
  (A + (-1 : Int) * H ≥ (3 : Int)) →
  (A + (-1 : Int) * I ≥ (2 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (3 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (8 : Int)) →
  (A + I ≥ (10 : Int)) →
  (A + G ≥ (12 : Int)) →
  (A + D ≥ (11 : Int)) →
  (A + C ≥ (10 : Int)) →
  (A + B ≥ (8 : Int)) →
  (A + K ≥ (9 : Int)) →
  (K + H ≥ (5 : Int)) →
  (K + I ≥ (7 : Int)) →
  (K + G ≥ (9 : Int)) →
  (K + D ≥ (8 : Int)) →
  (K + C ≥ (7 : Int)) →
  (K + B ≥ (5 : Int)) →
  (H ≥ (2 : Int)) →
  (I ≥ (4 : Int)) →
  (G ≥ (6 : Int)) →
  (F ≥ (5 : Int)) →
  (E ≥ (6 : Int)) →
  (D ≥ (5 : Int)) →
  (C ≥ (4 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (6 : Int)) →
  (K ≥ (3 : Int)) →
  ((-1 : Int) * H + G ≥ (3 : Int)) →
  r3 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r1 A B C D K E F G H I J) →
  (True) →
  r0 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r2 A B C D K E F G H I J) →
  (True) →
  r0 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 A B C D K E F G H I J) →
  (True) →
  r5 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r2 A B C D H E F J I K G) →
  (True) →
  r1 A B C D H E F K J I G) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 A B C D H E F K I J G) →
  (True) →
  r1 A B C D H E F K J I G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r2 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r1 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r0 A B C D H E F I K J G) →
  (r2 A B C D H E F I L K G) →
  (True) →
  r1 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D H E F I J L G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r1 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r2 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r1 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r2 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r1 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r2 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r1 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r2 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r1 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r2 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r1 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r2 A B C D H E F J I K G) →
  (True) →
  r2 A B C D H E F K J I G) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 A B C D H E F K I J G) →
  (True) →
  r2 A B C D H E F K J I G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r2 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r2 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r0 A B C D H E F I K J G) →
  (r2 A B C D H E F I L K G) →
  (True) →
  r2 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D H E F I J L G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r2 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r2 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r2 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r2 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r2 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r2 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r2 A B C D H E F v_13 J K G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r2 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F v_13 J K G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F v_13 J K G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r2 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F v_13 J K G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r2 A B C D H E F I L K G) →
  (r0 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F v_13 J K G) →
  (r0 A B C D H E F L K J G) →
  (r2 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F v_13 J K G) →
  (r2 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r2 A B C D H E F L J K G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D H E F I J L G) →
  (r0 A B C D H E F L J K G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r0 A B C D H E F L J K G) →
  (r0 A B C D H E F I K J G) →
  (r2 A B C D H E F I L K G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r0 A B C D H E F L J K G) →
  (r2 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 A B C D H E F K J I G) →
  (r2 A B C D H E F K I J G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r2 A B C D H E F K J I G) →
  (r0 A B C D H E F K I J G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r5 A B C D H E F K J I G) →
  (r2 A B C D H E F K J I G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 A B C D H E F K J I G) →
  (r0 A B C D H E F K J I G) →
  (True) →
  r4) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r4) →
  False))))))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«point-location.48_000»
