import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«fortune-half.23_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":786:1-786:12 (check-sat, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":9:1-82:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":83:1-178:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":179:1-248:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":249:1-326:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":327:1-337:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":338:1-348:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":349:1-359:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":360:1-372:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":373:1-385:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":386:1-398:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":399:1-413:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":414:1-428:2 (clause 12, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":429:1-443:2 (clause 13, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":444:1-458:2 (clause 14, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":459:1-473:2 (clause 15, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":474:1-484:2 (clause 16, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":485:1-497:2 (clause 17, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":498:1-510:2 (clause 18, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":511:1-523:2 (clause 19, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":524:1-538:2 (clause 20, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":539:1-553:2 (clause 21, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":554:1-568:2 (clause 22, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":569:1-583:2 (clause 23, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":584:1-598:2 (clause 24, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":599:1-614:2 (clause 25, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":615:1-630:2 (clause 26, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":631:1-646:2 (clause 27, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":647:1-662:2 (clause 28, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":663:1-678:2 (clause 29, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":679:1-694:2 (clause 30, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":695:1-708:2 (clause 31, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":709:1-722:2 (clause 32, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":723:1-736:2 (clause 33, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":737:1-750:2 (clause 34, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":751:1-762:2 (clause 35, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":763:1-774:2 (clause 36, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-half.23_000.smt2":775:1-784:2 (clause 37, command 42)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M : Int),
  ((-1 : Int) * M + B ≥ (3 : Int)) →
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * M + I ≥ (3 : Int)) →
  ((-1 : Int) * K + J ≥ (1 : Int)) →
  ((-1 : Int) * K + I ≥ (2 : Int)) →
  ((-1 : Int) * J + I ≥ (1 : Int)) →
  ((-1 : Int) * H + M ≥ (-1 : Int)) →
  ((-1 : Int) * H + J ≥ (1 : Int)) →
  ((-1 : Int) * H + B ≥ (2 : Int)) →
  ((-1 : Int) * H + A ≥ (0 : Int)) →
  ((-1 : Int) * H + I ≥ (2 : Int)) →
  ((-1 : Int) * G + M ≥ (0 : Int)) →
  ((-1 : Int) * G + K ≥ (0 : Int)) →
  ((-1 : Int) * G + J ≥ (2 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * G + B ≥ (3 : Int)) →
  ((-1 : Int) * G + A ≥ (1 : Int)) →
  ((-1 : Int) * G + I ≥ (3 : Int)) →
  ((-1 : Int) * E + B ≥ (0 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * D + F ≥ (0 : Int)) →
  ((-1 : Int) * C + M ≥ (0 : Int)) →
  ((-1 : Int) * C + K ≥ (0 : Int)) →
  ((-1 : Int) * C + J ≥ (2 : Int)) →
  ((-1 : Int) * C + H ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (0 : Int)) →
  ((-1 : Int) * C + F ≥ (3 : Int)) →
  ((-1 : Int) * C + E ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (3 : Int)) →
  ((-1 : Int) * C + A ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (3 : Int)) →
  ((-1 : Int) * B + I ≥ (0 : Int)) →
  ((-1 : Int) * A + J ≥ (1 : Int)) →
  ((-1 : Int) * A + B ≥ (2 : Int)) →
  ((-1 : Int) * A + I ≥ (2 : Int)) →
  (M + (-1 : Int) * A ≥ (-1 : Int)) →
  (H + (-1 : Int) * M ≥ (1 : Int)) →
  (H + (-1 : Int) * A ≥ (0 : Int)) →
  (F + (-1 : Int) * M ≥ (3 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + (-1 : Int) * J ≥ (1 : Int)) →
  (F + (-1 : Int) * H ≥ (2 : Int)) →
  (F + (-1 : Int) * G ≥ (3 : Int)) →
  (F + (-1 : Int) * A ≥ (2 : Int)) →
  (E + (-1 : Int) * M ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (2 : Int)) →
  (E + (-1 : Int) * J ≥ (1 : Int)) →
  (E + (-1 : Int) * H ≥ (2 : Int)) →
  (E + (-1 : Int) * G ≥ (3 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + (-1 : Int) * A ≥ (2 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (D + (-1 : Int) * M ≥ (3 : Int)) →
  (D + (-1 : Int) * K ≥ (2 : Int)) →
  (D + (-1 : Int) * J ≥ (1 : Int)) →
  (D + (-1 : Int) * H ≥ (2 : Int)) →
  (D + (-1 : Int) * G ≥ (3 : Int)) →
  (D + (-1 : Int) * F ≥ (0 : Int)) →
  (D + (-1 : Int) * A ≥ (2 : Int)) →
  (C + (-1 : Int) * G ≥ (0 : Int)) →
  (B + (-1 : Int) * K ≥ (2 : Int)) →
  (B + (-1 : Int) * J ≥ (1 : Int)) →
  (B + (-1 : Int) * I ≥ (0 : Int)) →
  ((-1 : Int) * M + J ≥ (2 : Int)) →
  r3 M A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  ((-1 : Int) * M + J ≥ (1 : Int)) →
  ((-1 : Int) * M + B ≥ (3 : Int)) →
  ((-1 : Int) * M + A ≥ (2 : Int)) →
  ((-1 : Int) * M + I ≥ (2 : Int)) →
  ((-1 : Int) * K + J ≥ (1 : Int)) →
  ((-1 : Int) * K + I ≥ (2 : Int)) →
  ((-1 : Int) * J + I ≥ (1 : Int)) →
  ((-1 : Int) * H + B ≥ (1 : Int)) →
  ((-1 : Int) * H + A ≥ (0 : Int)) →
  ((-1 : Int) * H + I ≥ (0 : Int)) →
  ((-1 : Int) * G + M ≥ (0 : Int)) →
  ((-1 : Int) * G + K ≥ (0 : Int)) →
  ((-1 : Int) * G + J ≥ (1 : Int)) →
  ((-1 : Int) * G + H ≥ (2 : Int)) →
  ((-1 : Int) * G + B ≥ (3 : Int)) →
  ((-1 : Int) * G + A ≥ (2 : Int)) →
  ((-1 : Int) * G + I ≥ (2 : Int)) →
  ((-1 : Int) * E + H ≥ (-1 : Int)) →
  ((-1 : Int) * E + F ≥ (0 : Int)) →
  ((-1 : Int) * E + D ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (0 : Int)) →
  ((-1 : Int) * E + A ≥ (-1 : Int)) →
  ((-1 : Int) * E + I ≥ (-1 : Int)) →
  ((-1 : Int) * D + F ≥ (0 : Int)) →
  ((-1 : Int) * C + M ≥ (0 : Int)) →
  ((-1 : Int) * C + K ≥ (0 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + H ≥ (2 : Int)) →
  ((-1 : Int) * C + G ≥ (0 : Int)) →
  ((-1 : Int) * C + F ≥ (3 : Int)) →
  ((-1 : Int) * C + E ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (3 : Int)) →
  ((-1 : Int) * C + A ≥ (2 : Int)) →
  ((-1 : Int) * C + I ≥ (2 : Int)) →
  ((-1 : Int) * B + I ≥ (-1 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  ((-1 : Int) * A + I ≥ (0 : Int)) →
  (M + (-1 : Int) * K ≥ (0 : Int)) →
  (M + (-1 : Int) * J ≥ (-1 : Int)) →
  (K + (-1 : Int) * J ≥ (-1 : Int)) →
  (H + (-1 : Int) * M ≥ (2 : Int)) →
  (H + (-1 : Int) * K ≥ (2 : Int)) →
  (H + (-1 : Int) * J ≥ (1 : Int)) →
  (H + (-1 : Int) * B ≥ (-1 : Int)) →
  (H + (-1 : Int) * A ≥ (0 : Int)) →
  (H + (-1 : Int) * I ≥ (0 : Int)) →
  (G + (-1 : Int) * M ≥ (0 : Int)) →
  (G + (-1 : Int) * K ≥ (0 : Int)) →
  (G + (-1 : Int) * J ≥ (-1 : Int)) →
  (F + (-1 : Int) * M ≥ (3 : Int)) →
  (F + (-1 : Int) * K ≥ (3 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * H ≥ (1 : Int)) →
  (F + (-1 : Int) * G ≥ (3 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (1 : Int)) →
  (F + (-1 : Int) * I ≥ (1 : Int)) →
  (E + (-1 : Int) * M ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + (-1 : Int) * J ≥ (2 : Int)) →
  (E + (-1 : Int) * H ≥ (1 : Int)) →
  (E + (-1 : Int) * G ≥ (3 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + (-1 : Int) * A ≥ (1 : Int)) →
  (E + (-1 : Int) * I ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (3 : Int)) →
  (D + (-1 : Int) * K ≥ (3 : Int)) →
  (D + (-1 : Int) * J ≥ (2 : Int)) →
  (D + (-1 : Int) * H ≥ (1 : Int)) →
  (D + (-1 : Int) * G ≥ (3 : Int)) →
  (D + (-1 : Int) * F ≥ (0 : Int)) →
  (D + (-1 : Int) * B ≥ (0 : Int)) →
  (D + (-1 : Int) * A ≥ (1 : Int)) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (C + (-1 : Int) * M ≥ (0 : Int)) →
  (C + (-1 : Int) * K ≥ (0 : Int)) →
  (C + (-1 : Int) * J ≥ (-1 : Int)) →
  (C + (-1 : Int) * G ≥ (0 : Int)) →
  (B + (-1 : Int) * K ≥ (3 : Int)) →
  (B + (-1 : Int) * J ≥ (2 : Int)) →
  (B + (-1 : Int) * I ≥ (1 : Int)) →
  (A + (-1 : Int) * K ≥ (2 : Int)) →
  (A + (-1 : Int) * J ≥ (1 : Int)) →
  (A + (-1 : Int) * B ≥ (-1 : Int)) →
  (A + (-1 : Int) * I ≥ (0 : Int)) →
  ((-1 : Int) * M + K ≥ (0 : Int)) →
  r3 M A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * K + J ≥ (1 : Int)) →
  ((-1 : Int) * K + I ≥ (2 : Int)) →
  ((-1 : Int) * J + I ≥ (1 : Int)) →
  ((-1 : Int) * H + B ≥ (1 : Int)) →
  ((-1 : Int) * H + A ≥ (0 : Int)) →
  ((-1 : Int) * G + M ≥ (0 : Int)) →
  ((-1 : Int) * G + K ≥ (0 : Int)) →
  ((-1 : Int) * G + J ≥ (1 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * G + B ≥ (3 : Int)) →
  ((-1 : Int) * G + A ≥ (1 : Int)) →
  ((-1 : Int) * G + I ≥ (2 : Int)) →
  ((-1 : Int) * E + F ≥ (0 : Int)) →
  ((-1 : Int) * E + D ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (0 : Int)) →
  ((-1 : Int) * D + F ≥ (0 : Int)) →
  ((-1 : Int) * C + M ≥ (0 : Int)) →
  ((-1 : Int) * C + K ≥ (0 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + H ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (0 : Int)) →
  ((-1 : Int) * C + F ≥ (3 : Int)) →
  ((-1 : Int) * C + E ≥ (3 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (3 : Int)) →
  ((-1 : Int) * C + A ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (2 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  (H + (-1 : Int) * M ≥ (1 : Int)) →
  (H + (-1 : Int) * A ≥ (0 : Int)) →
  (F + (-1 : Int) * M ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (3 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * H ≥ (1 : Int)) →
  (F + (-1 : Int) * G ≥ (3 : Int)) →
  (F + (-1 : Int) * B ≥ (0 : Int)) →
  (F + (-1 : Int) * A ≥ (1 : Int)) →
  (F + (-1 : Int) * I ≥ (1 : Int)) →
  (E + (-1 : Int) * M ≥ (2 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + (-1 : Int) * J ≥ (2 : Int)) →
  (E + (-1 : Int) * H ≥ (1 : Int)) →
  (E + (-1 : Int) * G ≥ (3 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + (-1 : Int) * A ≥ (1 : Int)) →
  (E + (-1 : Int) * I ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (2 : Int)) →
  (D + (-1 : Int) * K ≥ (3 : Int)) →
  (D + (-1 : Int) * J ≥ (2 : Int)) →
  (D + (-1 : Int) * H ≥ (1 : Int)) →
  (D + (-1 : Int) * G ≥ (3 : Int)) →
  (D + (-1 : Int) * F ≥ (0 : Int)) →
  (D + (-1 : Int) * B ≥ (0 : Int)) →
  (D + (-1 : Int) * A ≥ (1 : Int)) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (C + (-1 : Int) * G ≥ (0 : Int)) →
  (B + (-1 : Int) * K ≥ (3 : Int)) →
  (B + (-1 : Int) * J ≥ (2 : Int)) →
  (B + (-1 : Int) * I ≥ (1 : Int)) →
  ((-1 : Int) * M + B ≥ (2 : Int)) →
  r3 M A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  ((-1 : Int) * M + J ≥ (1 : Int)) →
  ((-1 : Int) * M + B ≥ (2 : Int)) →
  ((-1 : Int) * M + A ≥ (1 : Int)) →
  ((-1 : Int) * M + I ≥ (2 : Int)) →
  ((-1 : Int) * K + J ≥ (1 : Int)) →
  ((-1 : Int) * K + I ≥ (2 : Int)) →
  ((-1 : Int) * J + I ≥ (1 : Int)) →
  ((-1 : Int) * H + J ≥ (0 : Int)) →
  ((-1 : Int) * H + B ≥ (1 : Int)) →
  ((-1 : Int) * H + A ≥ (0 : Int)) →
  ((-1 : Int) * H + I ≥ (1 : Int)) →
  ((-1 : Int) * G + M ≥ (0 : Int)) →
  ((-1 : Int) * G + K ≥ (0 : Int)) →
  ((-1 : Int) * G + J ≥ (1 : Int)) →
  ((-1 : Int) * G + H ≥ (1 : Int)) →
  ((-1 : Int) * G + B ≥ (2 : Int)) →
  ((-1 : Int) * G + A ≥ (1 : Int)) →
  ((-1 : Int) * G + I ≥ (2 : Int)) →
  ((-1 : Int) * E + B ≥ (0 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * D + F ≥ (0 : Int)) →
  ((-1 : Int) * C + M ≥ (0 : Int)) →
  ((-1 : Int) * C + K ≥ (0 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + H ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (0 : Int)) →
  ((-1 : Int) * C + F ≥ (3 : Int)) →
  ((-1 : Int) * C + E ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (2 : Int)) →
  ((-1 : Int) * C + A ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (2 : Int)) →
  ((-1 : Int) * B + I ≥ (0 : Int)) →
  ((-1 : Int) * A + J ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  ((-1 : Int) * A + I ≥ (1 : Int)) →
  (M + (-1 : Int) * K ≥ (0 : Int)) →
  (H + (-1 : Int) * M ≥ (1 : Int)) →
  (H + (-1 : Int) * K ≥ (1 : Int)) →
  (H + (-1 : Int) * J ≥ (0 : Int)) →
  (H + (-1 : Int) * A ≥ (0 : Int)) →
  (F + (-1 : Int) * M ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + (-1 : Int) * J ≥ (1 : Int)) →
  (F + (-1 : Int) * H ≥ (1 : Int)) →
  (F + (-1 : Int) * G ≥ (3 : Int)) →
  (F + (-1 : Int) * A ≥ (1 : Int)) →
  (E + (-1 : Int) * M ≥ (2 : Int)) →
  (E + (-1 : Int) * K ≥ (2 : Int)) →
  (E + (-1 : Int) * J ≥ (1 : Int)) →
  (E + (-1 : Int) * H ≥ (1 : Int)) →
  (E + (-1 : Int) * G ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + (-1 : Int) * A ≥ (1 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (D + (-1 : Int) * M ≥ (2 : Int)) →
  (D + (-1 : Int) * K ≥ (2 : Int)) →
  (D + (-1 : Int) * J ≥ (1 : Int)) →
  (D + (-1 : Int) * H ≥ (1 : Int)) →
  (D + (-1 : Int) * G ≥ (3 : Int)) →
  (D + (-1 : Int) * F ≥ (0 : Int)) →
  (D + (-1 : Int) * A ≥ (1 : Int)) →
  (C + (-1 : Int) * G ≥ (0 : Int)) →
  (B + (-1 : Int) * K ≥ (2 : Int)) →
  (B + (-1 : Int) * J ≥ (1 : Int)) →
  (B + (-1 : Int) * I ≥ (0 : Int)) →
  (A + (-1 : Int) * K ≥ (1 : Int)) →
  (A + (-1 : Int) * J ≥ (0 : Int)) →
  ((-1 : Int) * M + K ≥ (0 : Int)) →
  r0 M A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r3 M A B C D E F G H I J K L) →
  (True) →
  r2 M A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 M A B C D E F G H I J K L) →
  (True) →
  r2 M A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 J A B C D E F G H L K M I) →
  (True) →
  r3 J A B C D E F G H M L K I) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r2 J A B C D E F G H v_13 K M I) →
  (r0 J A B C D E F G H v_14 L K I) →
  (r2 J A B C D E F G H v_15 M L I) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3 J A B C D E F G H M L K I) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r2 J A B C D E F G H v_13 K M I) →
  (r2 J A B C D E F G H v_14 L K I) →
  (r0 J A B C D E F G H v_15 M L I) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3 J A B C D E F G H M L K I) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 J A B C D E F G H v_13 K M I) →
  (r2 J A B C D E F G H v_14 L K I) →
  (r2 J A B C D E F G H v_15 M L I) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3 J A B C D E F G H M L K I) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r2 K A B C D E F G H J M v_14 I) →
  (r0 K A B C D E F G H N M L I) →
  (r2 K A B C D E F G H v_15 M L I) →
  (r2 K A B C D E F G H v_16 N M I) →
  (r2 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r3 K A B C D E F G H J M L I) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r2 K A B C D E F G H J M v_14 I) →
  (r2 K A B C D E F G H N M L I) →
  (r0 K A B C D E F G H v_15 M L I) →
  (r2 K A B C D E F G H v_16 N M I) →
  (r2 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r3 K A B C D E F G H J M L I) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r2 K A B C D E F G H J M v_14 I) →
  (r2 K A B C D E F G H N M L I) →
  (r2 K A B C D E F G H v_15 M L I) →
  (r0 K A B C D E F G H v_16 N M I) →
  (r2 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r3 K A B C D E F G H J M L I) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r2 K A B C D E F G H J M v_14 I) →
  (r2 K A B C D E F G H N M L I) →
  (r2 K A B C D E F G H v_15 M L I) →
  (r2 K A B C D E F G H v_16 N M I) →
  (r0 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r3 K A B C D E F G H J M L I) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r0 K A B C D E F G H J M v_14 I) →
  (r2 K A B C D E F G H N M L I) →
  (r2 K A B C D E F G H v_15 M L I) →
  (r2 K A B C D E F G H v_16 N M I) →
  (r2 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r3 K A B C D E F G H J M L I) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 J A B C D E F G H L K M I) →
  (True) →
  r0 J A B C D E F G H M L K I) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r2 J A B C D E F G H v_13 K M I) →
  (r0 J A B C D E F G H v_14 L K I) →
  (r2 J A B C D E F G H v_15 M L I) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r0 J A B C D E F G H M L K I) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r2 J A B C D E F G H v_13 K M I) →
  (r2 J A B C D E F G H v_14 L K I) →
  (r0 J A B C D E F G H v_15 M L I) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r0 J A B C D E F G H M L K I) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 J A B C D E F G H v_13 K M I) →
  (r2 J A B C D E F G H v_14 L K I) →
  (r2 J A B C D E F G H v_15 M L I) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r0 J A B C D E F G H M L K I) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r2 K A B C D E F G H J M v_14 I) →
  (r0 K A B C D E F G H N M L I) →
  (r2 K A B C D E F G H v_15 M L I) →
  (r2 K A B C D E F G H v_16 N M I) →
  (r2 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r0 K A B C D E F G H J M L I) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r2 K A B C D E F G H J M v_14 I) →
  (r2 K A B C D E F G H N M L I) →
  (r0 K A B C D E F G H v_15 M L I) →
  (r2 K A B C D E F G H v_16 N M I) →
  (r2 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r0 K A B C D E F G H J M L I) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r2 K A B C D E F G H J M v_14 I) →
  (r2 K A B C D E F G H N M L I) →
  (r2 K A B C D E F G H v_15 M L I) →
  (r0 K A B C D E F G H v_16 N M I) →
  (r2 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r0 K A B C D E F G H J M L I) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r2 K A B C D E F G H J M v_14 I) →
  (r2 K A B C D E F G H N M L I) →
  (r2 K A B C D E F G H v_15 M L I) →
  (r2 K A B C D E F G H v_16 N M I) →
  (r0 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r0 K A B C D E F G H J M L I) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r0 K A B C D E F G H J M v_14 I) →
  (r2 K A B C D E F G H N M L I) →
  (r2 K A B C D E F G H v_15 M L I) →
  (r2 K A B C D E F G H v_16 N M I) →
  (r2 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r0 K A B C D E F G H J M L I) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r2 K A B C D E F G H J M v_14 I) →
  (r0 K A B C D E F G H J L M I) →
  (r2 K A B C D E F G H N M L I) →
  (r2 K A B C D E F G H v_15 M L I) →
  (r2 K A B C D E F G H v_16 N M I) →
  (r2 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r0 K A B C D E F G H J M v_14 I) →
  (r2 K A B C D E F G H J L M I) →
  (r2 K A B C D E F G H N M L I) →
  (r2 K A B C D E F G H v_15 M L I) →
  (r2 K A B C D E F G H v_16 N M I) →
  (r2 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r2 K A B C D E F G H J M v_14 I) →
  (r2 K A B C D E F G H J L M I) →
  (r2 K A B C D E F G H N M L I) →
  (r2 K A B C D E F G H v_15 M L I) →
  (r2 K A B C D E F G H v_16 N M I) →
  (r0 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r2 K A B C D E F G H J M v_14 I) →
  (r2 K A B C D E F G H J L M I) →
  (r2 K A B C D E F G H N M L I) →
  (r2 K A B C D E F G H v_15 M L I) →
  (r0 K A B C D E F G H v_16 N M I) →
  (r2 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r2 K A B C D E F G H J M v_14 I) →
  (r2 K A B C D E F G H J L M I) →
  (r2 K A B C D E F G H N M L I) →
  (r0 K A B C D E F G H v_15 M L I) →
  (r2 K A B C D E F G H v_16 N M I) →
  (r2 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 : Int),
  (r2 K A B C D E F G H J M v_14 I) →
  (r2 K A B C D E F G H J L M I) →
  (r0 K A B C D E F G H N M L I) →
  (r2 K A B C D E F G H v_15 M L I) →
  (r2 K A B C D E F G H v_16 N M I) →
  (r2 K A B C D E F G H J N M I) →
  (v_14 = K) →
  (v_15 = K) →
  (v_16 = K) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r2 J A B C D E F G H v_13 K M I) →
  (r0 J A B C D E F G H M K L I) →
  (r2 J A B C D E F G H v_14 L K I) →
  (r2 J A B C D E F G H v_15 M L I) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 J A B C D E F G H v_13 K M I) →
  (r2 J A B C D E F G H M K L I) →
  (r2 J A B C D E F G H v_14 L K I) →
  (r2 J A B C D E F G H v_15 M L I) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r2 J A B C D E F G H v_13 K M I) →
  (r2 J A B C D E F G H M K L I) →
  (r2 J A B C D E F G H v_14 L K I) →
  (r0 J A B C D E F G H v_15 M L I) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r2 J A B C D E F G H v_13 K M I) →
  (r2 J A B C D E F G H M K L I) →
  (r0 J A B C D E F G H v_14 L K I) →
  (r2 J A B C D E F G H v_15 M L I) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r2 J A B C D E F G H M L K I) →
  (r0 J A B C D E F G H M K L I) →
  (True) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 J A B C D E F G H M L K I) →
  (r2 J A B C D E F G H M K L I) →
  (True) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  False))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«fortune-half.23_000»
