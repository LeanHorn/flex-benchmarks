import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«graham-scan-full.32_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":969:1-969:12 (check-sat, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":11:1-145:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":146:1-295:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":296:1-452:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":453:1-463:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":464:1-474:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":475:1-485:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":486:1-496:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":497:1-507:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":508:1-520:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":521:1-533:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":534:1-546:2 (clause 11, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":547:1-561:2 (clause 12, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":562:1-576:2 (clause 13, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":577:1-591:2 (clause 14, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":592:1-606:2 (clause 15, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":607:1-621:2 (clause 16, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":622:1-632:2 (clause 17, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":633:1-643:2 (clause 18, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":644:1-656:2 (clause 19, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":657:1-669:2 (clause 20, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":670:1-682:2 (clause 21, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":683:1-697:2 (clause 22, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":698:1-712:2 (clause 23, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":713:1-727:2 (clause 24, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":728:1-742:2 (clause 25, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":743:1-757:2 (clause 26, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":758:1-773:2 (clause 27, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":774:1-789:2 (clause 28, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":790:1-805:2 (clause 29, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":806:1-821:2 (clause 30, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":822:1-837:2 (clause 31, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":838:1-853:2 (clause 32, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":854:1-867:2 (clause 33, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":868:1-881:2 (clause 34, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":882:1-895:2 (clause 35, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":896:1-909:2 (clause 36, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":910:1-921:2 (clause 37, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":922:1-933:2 (clause 38, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":934:1-945:2 (clause 39, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":946:1-957:2 (clause 40, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/graham-scan-full.32_000.smt2":958:1-967:2 (clause 41, command 48)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L : Int),
  ((-1 : Int) * J + I ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (1 : Int)) →
  ((-1 : Int) * G + B ≥ (0 : Int)) →
  ((-1 : Int) * G + L ≥ (-1 : Int)) →
  ((-1 : Int) * F + (-1 : Int) * C ≥ (-1 : Int)) →
  ((-1 : Int) * F + H ≥ (2 : Int)) →
  ((-1 : Int) * F + J ≥ (0 : Int)) →
  ((-1 : Int) * F + I ≥ (1 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + C ≥ (-1 : Int)) →
  ((-1 : Int) * F + B ≥ (1 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * D + E ≥ (-1 : Int)) →
  ((-1 : Int) * C + H ≥ (3 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (2 : Int)) →
  ((-1 : Int) * C + B ≥ (2 : Int)) →
  ((-1 : Int) * C + L ≥ (1 : Int)) →
  ((-1 : Int) * B + L ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * F ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * C ≥ (0 : Int)) →
  ((-1 : Int) * A + H ≥ (3 : Int)) →
  ((-1 : Int) * A + J ≥ (1 : Int)) →
  ((-1 : Int) * A + I ≥ (2 : Int)) →
  ((-1 : Int) * A + G ≥ (2 : Int)) →
  ((-1 : Int) * A + F ≥ (1 : Int)) →
  ((-1 : Int) * A + C ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (2 : Int)) →
  ((-1 : Int) * A + L ≥ (1 : Int)) →
  (J + (-1 : Int) * I ≥ (-1 : Int)) →
  (J + H ≥ (4 : Int)) →
  (J + I ≥ (3 : Int)) →
  (I + H ≥ (5 : Int)) →
  (G + (-1 : Int) * C ≥ (2 : Int)) →
  (G + (-1 : Int) * B ≥ (0 : Int)) →
  (G + (-1 : Int) * L ≥ (1 : Int)) →
  (G + H ≥ (5 : Int)) →
  (G + J ≥ (3 : Int)) →
  (G + I ≥ (4 : Int)) →
  (G + C ≥ (2 : Int)) →
  (G + B ≥ (4 : Int)) →
  (G + L ≥ (3 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + H ≥ (4 : Int)) →
  (F + J ≥ (2 : Int)) →
  (F + I ≥ (3 : Int)) →
  (F + G ≥ (3 : Int)) →
  (F + C ≥ (1 : Int)) →
  (F + B ≥ (3 : Int)) →
  (F + L ≥ (2 : Int)) →
  (E + (-1 : Int) * H ≥ (0 : Int)) →
  (E + (-1 : Int) * J ≥ (2 : Int)) →
  (E + (-1 : Int) * I ≥ (1 : Int)) →
  (E + (-1 : Int) * G ≥ (1 : Int)) →
  (E + (-1 : Int) * F ≥ (2 : Int)) →
  (E + (-1 : Int) * C ≥ (3 : Int)) →
  (E + (-1 : Int) * B ≥ (1 : Int)) →
  (E + (-1 : Int) * A ≥ (3 : Int)) →
  (E + (-1 : Int) * L ≥ (2 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + J ≥ (4 : Int)) →
  (E + I ≥ (5 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (4 : Int)) →
  (E + C ≥ (3 : Int)) →
  (E + B ≥ (5 : Int)) →
  (E + A ≥ (3 : Int)) →
  (E + L ≥ (4 : Int)) →
  (D + (-1 : Int) * H ≥ (1 : Int)) →
  (D + (-1 : Int) * J ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (2 : Int)) →
  (D + (-1 : Int) * G ≥ (2 : Int)) →
  (D + (-1 : Int) * F ≥ (3 : Int)) →
  (D + (-1 : Int) * E ≥ (1 : Int)) →
  (D + (-1 : Int) * C ≥ (4 : Int)) →
  (D + (-1 : Int) * B ≥ (2 : Int)) →
  (D + (-1 : Int) * A ≥ (4 : Int)) →
  (D + (-1 : Int) * L ≥ (3 : Int)) →
  (D + H ≥ (7 : Int)) →
  (D + J ≥ (5 : Int)) →
  (D + I ≥ (6 : Int)) →
  (D + G ≥ (6 : Int)) →
  (D + F ≥ (5 : Int)) →
  (D + E ≥ (7 : Int)) →
  (D + C ≥ (4 : Int)) →
  (D + B ≥ (6 : Int)) →
  (D + A ≥ (4 : Int)) →
  (D + L ≥ (5 : Int)) →
  (C + H ≥ (3 : Int)) →
  (C + J ≥ (1 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + B ≥ (2 : Int)) →
  (C + L ≥ (1 : Int)) →
  (B + (-1 : Int) * L ≥ (1 : Int)) →
  (B + H ≥ (5 : Int)) →
  (B + J ≥ (3 : Int)) →
  (B + I ≥ (4 : Int)) →
  (B + L ≥ (3 : Int)) →
  (A + (-1 : Int) * F ≥ (-1 : Int)) →
  (A + (-1 : Int) * C ≥ (0 : Int)) →
  (A + H ≥ (3 : Int)) →
  (A + J ≥ (1 : Int)) →
  (A + I ≥ (2 : Int)) →
  (A + G ≥ (2 : Int)) →
  (A + F ≥ (1 : Int)) →
  (A + C ≥ (0 : Int)) →
  (A + B ≥ (2 : Int)) →
  (A + L ≥ (1 : Int)) →
  (L + H ≥ (4 : Int)) →
  (L + J ≥ (2 : Int)) →
  (L + I ≥ (3 : Int)) →
  (H ≥ (3 : Int)) →
  (J ≥ (1 : Int)) →
  (I ≥ (2 : Int)) →
  (G ≥ (2 : Int)) →
  (F ≥ (1 : Int)) →
  (E ≥ (3 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (0 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (0 : Int)) →
  (L ≥ (1 : Int)) →
  (F ≤ (1 : Int)) →
  (C ≤ (0 : Int)) →
  (A ≤ (0 : Int)) →
  ((-1 : Int) * J + H ≥ (2 : Int)) →
  r2 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  ((-1 : Int) * J + I ≥ (1 : Int)) →
  ((-1 : Int) * I + H ≥ (1 : Int)) →
  ((-1 : Int) * G + B ≥ (0 : Int)) →
  ((-1 : Int) * G + L ≥ (-1 : Int)) →
  ((-1 : Int) * F + (-1 : Int) * C ≥ (-1 : Int)) →
  ((-1 : Int) * F + H ≥ (2 : Int)) →
  ((-1 : Int) * F + J ≥ (0 : Int)) →
  ((-1 : Int) * F + I ≥ (1 : Int)) →
  ((-1 : Int) * F + G ≥ (2 : Int)) →
  ((-1 : Int) * F + C ≥ (-1 : Int)) →
  ((-1 : Int) * F + B ≥ (2 : Int)) →
  ((-1 : Int) * F + L ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (0 : Int)) →
  ((-1 : Int) * E + L ≥ (-1 : Int)) →
  ((-1 : Int) * D + G ≥ (-1 : Int)) →
  ((-1 : Int) * D + E ≥ (-1 : Int)) →
  ((-1 : Int) * D + B ≥ (-1 : Int)) →
  ((-1 : Int) * D + L ≥ (-2 : Int)) →
  ((-1 : Int) * C + H ≥ (3 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (2 : Int)) →
  ((-1 : Int) * C + B ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (2 : Int)) →
  ((-1 : Int) * B + L ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * F ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * C ≥ (0 : Int)) →
  ((-1 : Int) * A + H ≥ (3 : Int)) →
  ((-1 : Int) * A + J ≥ (1 : Int)) →
  ((-1 : Int) * A + I ≥ (2 : Int)) →
  ((-1 : Int) * A + G ≥ (3 : Int)) →
  ((-1 : Int) * A + F ≥ (1 : Int)) →
  ((-1 : Int) * A + C ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (3 : Int)) →
  ((-1 : Int) * A + L ≥ (2 : Int)) →
  (J + (-1 : Int) * I ≥ (-1 : Int)) →
  (J + H ≥ (4 : Int)) →
  (J + I ≥ (3 : Int)) →
  (I + H ≥ (5 : Int)) →
  (G + (-1 : Int) * H ≥ (0 : Int)) →
  (G + (-1 : Int) * J ≥ (2 : Int)) →
  (G + (-1 : Int) * I ≥ (1 : Int)) →
  (G + (-1 : Int) * C ≥ (3 : Int)) →
  (G + (-1 : Int) * B ≥ (0 : Int)) →
  (G + (-1 : Int) * L ≥ (1 : Int)) →
  (G + H ≥ (6 : Int)) →
  (G + J ≥ (4 : Int)) →
  (G + I ≥ (5 : Int)) →
  (G + C ≥ (3 : Int)) →
  (G + B ≥ (6 : Int)) →
  (G + L ≥ (5 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + H ≥ (4 : Int)) →
  (F + J ≥ (2 : Int)) →
  (F + I ≥ (3 : Int)) →
  (F + G ≥ (4 : Int)) →
  (F + C ≥ (1 : Int)) →
  (F + B ≥ (4 : Int)) →
  (F + L ≥ (3 : Int)) →
  (E + (-1 : Int) * H ≥ (0 : Int)) →
  (E + (-1 : Int) * J ≥ (2 : Int)) →
  (E + (-1 : Int) * I ≥ (1 : Int)) →
  (E + (-1 : Int) * G ≥ (0 : Int)) →
  (E + (-1 : Int) * F ≥ (2 : Int)) →
  (E + (-1 : Int) * C ≥ (3 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + (-1 : Int) * A ≥ (3 : Int)) →
  (E + (-1 : Int) * L ≥ (1 : Int)) →
  (E + H ≥ (6 : Int)) →
  (E + J ≥ (4 : Int)) →
  (E + I ≥ (5 : Int)) →
  (E + G ≥ (6 : Int)) →
  (E + F ≥ (4 : Int)) →
  (E + C ≥ (3 : Int)) →
  (E + B ≥ (6 : Int)) →
  (E + A ≥ (3 : Int)) →
  (E + L ≥ (5 : Int)) →
  (D + (-1 : Int) * H ≥ (1 : Int)) →
  (D + (-1 : Int) * J ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (2 : Int)) →
  (D + (-1 : Int) * G ≥ (1 : Int)) →
  (D + (-1 : Int) * F ≥ (3 : Int)) →
  (D + (-1 : Int) * E ≥ (1 : Int)) →
  (D + (-1 : Int) * C ≥ (4 : Int)) →
  (D + (-1 : Int) * B ≥ (1 : Int)) →
  (D + (-1 : Int) * A ≥ (4 : Int)) →
  (D + (-1 : Int) * L ≥ (2 : Int)) →
  (D + H ≥ (7 : Int)) →
  (D + J ≥ (5 : Int)) →
  (D + I ≥ (6 : Int)) →
  (D + G ≥ (7 : Int)) →
  (D + F ≥ (5 : Int)) →
  (D + E ≥ (7 : Int)) →
  (D + C ≥ (4 : Int)) →
  (D + B ≥ (7 : Int)) →
  (D + A ≥ (4 : Int)) →
  (D + L ≥ (6 : Int)) →
  (C + H ≥ (3 : Int)) →
  (C + J ≥ (1 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + B ≥ (3 : Int)) →
  (C + L ≥ (2 : Int)) →
  (B + (-1 : Int) * H ≥ (0 : Int)) →
  (B + (-1 : Int) * J ≥ (2 : Int)) →
  (B + (-1 : Int) * I ≥ (1 : Int)) →
  (B + (-1 : Int) * L ≥ (1 : Int)) →
  (B + H ≥ (6 : Int)) →
  (B + J ≥ (4 : Int)) →
  (B + I ≥ (5 : Int)) →
  (B + L ≥ (5 : Int)) →
  (A + (-1 : Int) * F ≥ (-1 : Int)) →
  (A + (-1 : Int) * C ≥ (0 : Int)) →
  (A + H ≥ (3 : Int)) →
  (A + J ≥ (1 : Int)) →
  (A + I ≥ (2 : Int)) →
  (A + G ≥ (3 : Int)) →
  (A + F ≥ (1 : Int)) →
  (A + C ≥ (0 : Int)) →
  (A + B ≥ (3 : Int)) →
  (A + L ≥ (2 : Int)) →
  (L + (-1 : Int) * H ≥ (-1 : Int)) →
  (L + (-1 : Int) * J ≥ (1 : Int)) →
  (L + (-1 : Int) * I ≥ (0 : Int)) →
  (L + H ≥ (5 : Int)) →
  (L + J ≥ (3 : Int)) →
  (L + I ≥ (4 : Int)) →
  (H ≥ (3 : Int)) →
  (J ≥ (1 : Int)) →
  (I ≥ (2 : Int)) →
  (G ≥ (3 : Int)) →
  (F ≥ (1 : Int)) →
  (E ≥ (3 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (0 : Int)) →
  (B ≥ (3 : Int)) →
  (A ≥ (0 : Int)) →
  (L ≥ (2 : Int)) →
  (F ≤ (1 : Int)) →
  (C ≤ (0 : Int)) →
  (A ≤ (0 : Int)) →
  ((-1 : Int) * J + H ≥ (2 : Int)) →
  r2 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  ((-1 : Int) * G + J ≥ (-1 : Int)) →
  ((-1 : Int) * G + I ≥ (0 : Int)) →
  ((-1 : Int) * G + B ≥ (0 : Int)) →
  ((-1 : Int) * G + L ≥ (-1 : Int)) →
  ((-1 : Int) * F + (-1 : Int) * H ≥ (-1 : Int)) →
  ((-1 : Int) * F + (-1 : Int) * C ≥ (-1 : Int)) →
  ((-1 : Int) * F + H ≥ (-1 : Int)) →
  ((-1 : Int) * F + J ≥ (0 : Int)) →
  ((-1 : Int) * F + I ≥ (1 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + C ≥ (-1 : Int)) →
  ((-1 : Int) * F + B ≥ (1 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * D + E ≥ (-1 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * H ≥ (0 : Int)) →
  ((-1 : Int) * C + H ≥ (0 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (2 : Int)) →
  ((-1 : Int) * C + B ≥ (2 : Int)) →
  ((-1 : Int) * C + L ≥ (1 : Int)) →
  ((-1 : Int) * B + J ≥ (-1 : Int)) →
  ((-1 : Int) * B + I ≥ (0 : Int)) →
  ((-1 : Int) * B + L ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * H ≥ (0 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * F ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * C ≥ (0 : Int)) →
  ((-1 : Int) * A + H ≥ (0 : Int)) →
  ((-1 : Int) * A + J ≥ (1 : Int)) →
  ((-1 : Int) * A + I ≥ (2 : Int)) →
  ((-1 : Int) * A + G ≥ (2 : Int)) →
  ((-1 : Int) * A + F ≥ (1 : Int)) →
  ((-1 : Int) * A + C ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (2 : Int)) →
  ((-1 : Int) * A + L ≥ (1 : Int)) →
  ((-1 : Int) * L + J ≥ (0 : Int)) →
  ((-1 : Int) * L + I ≥ (1 : Int)) →
  (J + (-1 : Int) * H ≥ (1 : Int)) →
  (J + (-1 : Int) * I ≥ (-1 : Int)) →
  (J + H ≥ (1 : Int)) →
  (J + I ≥ (3 : Int)) →
  (I + (-1 : Int) * H ≥ (2 : Int)) →
  (I + H ≥ (2 : Int)) →
  (G + (-1 : Int) * H ≥ (2 : Int)) →
  (G + (-1 : Int) * J ≥ (1 : Int)) →
  (G + (-1 : Int) * I ≥ (0 : Int)) →
  (G + (-1 : Int) * C ≥ (2 : Int)) →
  (G + (-1 : Int) * B ≥ (0 : Int)) →
  (G + (-1 : Int) * L ≥ (1 : Int)) →
  (G + H ≥ (2 : Int)) →
  (G + J ≥ (3 : Int)) →
  (G + I ≥ (4 : Int)) →
  (G + C ≥ (2 : Int)) →
  (G + B ≥ (4 : Int)) →
  (G + L ≥ (3 : Int)) →
  (F + (-1 : Int) * H ≥ (1 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + H ≥ (1 : Int)) →
  (F + J ≥ (2 : Int)) →
  (F + I ≥ (3 : Int)) →
  (F + G ≥ (3 : Int)) →
  (F + C ≥ (1 : Int)) →
  (F + B ≥ (3 : Int)) →
  (F + L ≥ (2 : Int)) →
  (E + (-1 : Int) * H ≥ (3 : Int)) →
  (E + (-1 : Int) * J ≥ (1 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * G ≥ (0 : Int)) →
  (E + (-1 : Int) * F ≥ (2 : Int)) →
  (E + (-1 : Int) * C ≥ (3 : Int)) →
  (E + (-1 : Int) * B ≥ (0 : Int)) →
  (E + (-1 : Int) * A ≥ (3 : Int)) →
  (E + (-1 : Int) * L ≥ (1 : Int)) →
  (E + H ≥ (3 : Int)) →
  (E + J ≥ (4 : Int)) →
  (E + I ≥ (5 : Int)) →
  (E + G ≥ (5 : Int)) →
  (E + F ≥ (4 : Int)) →
  (E + C ≥ (3 : Int)) →
  (E + B ≥ (5 : Int)) →
  (E + A ≥ (3 : Int)) →
  (E + L ≥ (4 : Int)) →
  (D + (-1 : Int) * H ≥ (4 : Int)) →
  (D + (-1 : Int) * J ≥ (2 : Int)) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (D + (-1 : Int) * G ≥ (1 : Int)) →
  (D + (-1 : Int) * F ≥ (3 : Int)) →
  (D + (-1 : Int) * E ≥ (1 : Int)) →
  (D + (-1 : Int) * C ≥ (4 : Int)) →
  (D + (-1 : Int) * B ≥ (1 : Int)) →
  (D + (-1 : Int) * A ≥ (4 : Int)) →
  (D + (-1 : Int) * L ≥ (2 : Int)) →
  (D + H ≥ (4 : Int)) →
  (D + J ≥ (5 : Int)) →
  (D + I ≥ (6 : Int)) →
  (D + G ≥ (6 : Int)) →
  (D + F ≥ (5 : Int)) →
  (D + E ≥ (7 : Int)) →
  (D + C ≥ (4 : Int)) →
  (D + B ≥ (6 : Int)) →
  (D + A ≥ (4 : Int)) →
  (D + L ≥ (5 : Int)) →
  (C + (-1 : Int) * H ≥ (0 : Int)) →
  (C + H ≥ (0 : Int)) →
  (C + J ≥ (1 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + B ≥ (2 : Int)) →
  (C + L ≥ (1 : Int)) →
  (B + (-1 : Int) * H ≥ (2 : Int)) →
  (B + (-1 : Int) * J ≥ (1 : Int)) →
  (B + (-1 : Int) * I ≥ (0 : Int)) →
  (B + (-1 : Int) * L ≥ (1 : Int)) →
  (B + H ≥ (2 : Int)) →
  (B + J ≥ (3 : Int)) →
  (B + I ≥ (4 : Int)) →
  (B + L ≥ (3 : Int)) →
  (A + (-1 : Int) * H ≥ (0 : Int)) →
  (A + (-1 : Int) * F ≥ (-1 : Int)) →
  (A + (-1 : Int) * C ≥ (0 : Int)) →
  (A + H ≥ (0 : Int)) →
  (A + J ≥ (1 : Int)) →
  (A + I ≥ (2 : Int)) →
  (A + G ≥ (2 : Int)) →
  (A + F ≥ (1 : Int)) →
  (A + C ≥ (0 : Int)) →
  (A + B ≥ (2 : Int)) →
  (A + L ≥ (1 : Int)) →
  (L + (-1 : Int) * H ≥ (1 : Int)) →
  (L + (-1 : Int) * J ≥ (0 : Int)) →
  (L + (-1 : Int) * I ≥ (-1 : Int)) →
  (L + H ≥ (1 : Int)) →
  (L + J ≥ (2 : Int)) →
  (L + I ≥ (3 : Int)) →
  (H ≥ (0 : Int)) →
  (J ≥ (1 : Int)) →
  (I ≥ (2 : Int)) →
  (G ≥ (2 : Int)) →
  (F ≥ (1 : Int)) →
  (E ≥ (3 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (0 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (0 : Int)) →
  (L ≥ (1 : Int)) →
  (H ≤ (0 : Int)) →
  (F ≤ (1 : Int)) →
  (C ≤ (0 : Int)) →
  (A ≤ (0 : Int)) →
  ((-1 : Int) * J + I ≥ (1 : Int)) →
  r1 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A L B C D E F G H I J K) →
  (True) →
  r0 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r5 A L B C D E F G H I J K) →
  (True) →
  r0 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A L B C D E F G H I J K) →
  (True) →
  r4 A L B C D E F G H I J K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r5 A I B C D E F G K J L H) →
  (True) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A I B C D E F G L J K H) →
  (True) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r5 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r5 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r5 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r2 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r5 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r5 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r5 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r5 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r5 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r2 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r5 A I B C D E F G K J L H) →
  (True) →
  r5 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A I B C D E F G L J K H) →
  (True) →
  r5 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r5 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r5 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r5 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r5 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r5 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r5 A I B C D E F G L K J H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r5 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r5 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r5 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r5 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r5 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r5 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r5 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r5 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r5 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r5 A J B C D E F G I L K H) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r5 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r5 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r5 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r5 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r0 A J B C D E F G M L K H) →
  (r5 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 A J B C D E F G I L v_13 H) →
  (r0 A J B C D E F G I K L H) →
  (r5 A J B C D E F G M L K H) →
  (r0 A J B C D E F G v_14 L K H) →
  (r0 A J B C D E F G v_15 M L H) →
  (r0 A J B C D E F G I M L H) →
  (v_13 = J) →
  (v_14 = J) →
  (v_15 = J) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r5 A I B C D E F G L J K H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r5 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G L J K H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G L J K H) →
  (r0 A I B C D E F G v_13 K J H) →
  (r5 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A I B C D E F G v_12 J L H) →
  (r0 A I B C D E F G L J K H) →
  (r5 A I B C D E F G v_13 K J H) →
  (r0 A I B C D E F G v_14 L K H) →
  (v_12 = I) →
  (v_13 = I) →
  (v_14 = I) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A I B C D E F G L K J H) →
  (r5 A I B C D E F G L J K H) →
  (True) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r5 A I B C D E F G L K J H) →
  (r0 A I B C D E F G L J K H) →
  (True) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r4 A I B C D E F G L K J H) →
  (r5 A I B C D E F G L K J H) →
  (True) →
  r3) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A I B C D E F G L K J H) →
  (r0 A I B C D E F G L K J H) →
  (True) →
  r3) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r3) →
  False))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«graham-scan-full.32_000»
