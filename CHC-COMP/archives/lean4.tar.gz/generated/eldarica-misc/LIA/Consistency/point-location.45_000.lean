import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«point-location.45_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":627:1-627:12 (check-sat, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":9:1-167:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":168:1-178:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":179:1-189:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":190:1-200:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":201:1-213:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":214:1-226:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":227:1-239:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":240:1-254:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":255:1-269:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":270:1-284:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":285:1-299:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":300:1-314:2 (clause 12, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":315:1-325:2 (clause 13, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":326:1-338:2 (clause 14, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":339:1-351:2 (clause 15, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":352:1-364:2 (clause 16, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":365:1-379:2 (clause 17, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":380:1-394:2 (clause 18, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":395:1-409:2 (clause 19, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":410:1-424:2 (clause 20, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":425:1-439:2 (clause 21, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":440:1-455:2 (clause 22, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":456:1-471:2 (clause 23, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":472:1-487:2 (clause 24, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":488:1-503:2 (clause 25, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":504:1-519:2 (clause 26, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":520:1-535:2 (clause 27, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":536:1-549:2 (clause 28, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":550:1-563:2 (clause 29, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":564:1-577:2 (clause 30, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":578:1-591:2 (clause 31, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":592:1-603:2 (clause 32, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":604:1-615:2 (clause 33, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.45_000.smt2":616:1-625:2 (clause 34, command 39)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + (-1 : Int) * H ≥ (-5 : Int)) →
  ((-1 : Int) * I + H ≥ (-1 : Int)) →
  ((-1 : Int) * I + G ≥ (2 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * H ≥ (-7 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-8 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * D ≥ (-9 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-8 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * B ≥ (-7 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * K ≥ (-6 : Int)) →
  ((-1 : Int) * E + H ≥ (-3 : Int)) →
  ((-1 : Int) * E + I ≥ (-2 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + B ≥ (-3 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * E + K ≥ (-4 : Int)) →
  ((-1 : Int) * D + (-1 : Int) * H ≥ (-6 : Int)) →
  ((-1 : Int) * D + (-1 : Int) * I ≥ (-7 : Int)) →
  ((-1 : Int) * D + H ≥ (-2 : Int)) →
  ((-1 : Int) * D + I ≥ (-1 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * H ≥ (-5 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-6 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * D ≥ (-7 : Int)) →
  ((-1 : Int) * C + H ≥ (-1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * H ≥ (-4 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * I ≥ (-5 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * D ≥ (-6 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * C ≥ (-5 : Int)) →
  ((-1 : Int) * B + H ≥ (0 : Int)) →
  ((-1 : Int) * B + I ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * B + D ≥ (2 : Int)) →
  ((-1 : Int) * B + C ≥ (1 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * H ≥ (-3 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * I ≥ (-4 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * D ≥ (-5 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * C ≥ (-4 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * B ≥ (-3 : Int)) →
  ((-1 : Int) * K + H ≥ (1 : Int)) →
  ((-1 : Int) * K + I ≥ (2 : Int)) →
  ((-1 : Int) * K + G ≥ (4 : Int)) →
  ((-1 : Int) * K + D ≥ (3 : Int)) →
  ((-1 : Int) * K + C ≥ (2 : Int)) →
  ((-1 : Int) * K + B ≥ (1 : Int)) →
  (H + G ≥ (7 : Int)) →
  (I + (-1 : Int) * H ≥ (1 : Int)) →
  (I + H ≥ (5 : Int)) →
  (I + G ≥ (8 : Int)) →
  (F + (-1 : Int) * H ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (1 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (3 : Int)) →
  (F + H ≥ (6 : Int)) →
  (F + I ≥ (7 : Int)) →
  (F + G ≥ (9 : Int)) →
  (F + D ≥ (8 : Int)) →
  (F + C ≥ (7 : Int)) →
  (F + B ≥ (6 : Int)) →
  (F + A ≥ (9 : Int)) →
  (F + K ≥ (5 : Int)) →
  (E + (-1 : Int) * H ≥ (3 : Int)) →
  (E + (-1 : Int) * I ≥ (2 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (4 : Int)) →
  (E + H ≥ (7 : Int)) →
  (E + I ≥ (8 : Int)) →
  (E + G ≥ (10 : Int)) →
  (E + F ≥ (9 : Int)) →
  (E + D ≥ (9 : Int)) →
  (E + C ≥ (8 : Int)) →
  (E + B ≥ (7 : Int)) →
  (E + A ≥ (10 : Int)) →
  (E + K ≥ (6 : Int)) →
  (D + (-1 : Int) * H ≥ (2 : Int)) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (D + H ≥ (6 : Int)) →
  (D + I ≥ (7 : Int)) →
  (D + G ≥ (9 : Int)) →
  (C + (-1 : Int) * H ≥ (1 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (5 : Int)) →
  (C + I ≥ (6 : Int)) →
  (C + G ≥ (8 : Int)) →
  (C + D ≥ (7 : Int)) →
  (B + (-1 : Int) * H ≥ (0 : Int)) →
  (B + (-1 : Int) * I ≥ (-1 : Int)) →
  (B + (-1 : Int) * D ≥ (-2 : Int)) →
  (B + (-1 : Int) * C ≥ (-1 : Int)) →
  (B + H ≥ (4 : Int)) →
  (B + I ≥ (5 : Int)) →
  (B + G ≥ (7 : Int)) →
  (B + D ≥ (6 : Int)) →
  (B + C ≥ (5 : Int)) →
  (A + (-1 : Int) * H ≥ (3 : Int)) →
  (A + (-1 : Int) * I ≥ (2 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (3 : Int)) →
  (A + (-1 : Int) * K ≥ (4 : Int)) →
  (A + H ≥ (7 : Int)) →
  (A + I ≥ (8 : Int)) →
  (A + G ≥ (10 : Int)) →
  (A + D ≥ (9 : Int)) →
  (A + C ≥ (8 : Int)) →
  (A + B ≥ (7 : Int)) →
  (A + K ≥ (6 : Int)) →
  (K + (-1 : Int) * H ≥ (-1 : Int)) →
  (K + (-1 : Int) * I ≥ (-2 : Int)) →
  (K + (-1 : Int) * D ≥ (-3 : Int)) →
  (K + (-1 : Int) * C ≥ (-2 : Int)) →
  (K + (-1 : Int) * B ≥ (-1 : Int)) →
  (K + H ≥ (3 : Int)) →
  (K + I ≥ (4 : Int)) →
  (K + G ≥ (6 : Int)) →
  (K + D ≥ (5 : Int)) →
  (K + C ≥ (4 : Int)) →
  (K + B ≥ (3 : Int)) →
  (H ≥ (2 : Int)) →
  (I ≥ (3 : Int)) →
  (G ≥ (5 : Int)) →
  (F ≥ (4 : Int)) →
  (E ≥ (5 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (3 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (5 : Int)) →
  (K ≥ (1 : Int)) →
  (H ≤ (2 : Int)) →
  (I ≤ (3 : Int)) →
  (E ≤ (5 : Int)) →
  (D ≤ (4 : Int)) →
  (C ≤ (3 : Int)) →
  (B ≤ (2 : Int)) →
  (K ≤ (1 : Int)) →
  ((-1 : Int) * H + G ≥ (3 : Int)) →
  r0 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 A B C D K E F G H I J) →
  (True) →
  r1 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 A B C D K E F G H I J) →
  (True) →
  r1 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 A B C D H E F J I K G) →
  (True) →
  r3 A B C D H E F K J I G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r0 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r3 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r1 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r3 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r3 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r3 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r3 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r3 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r3 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r3 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 A B C D H E F J I K G) →
  (True) →
  r0 A B C D H E F K J I G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r0 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r0 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r1 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r0 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r0 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r0 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r0 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r0 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r0 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r0 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F v_13 J K G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F v_13 J K G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F v_13 J K G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r0 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F v_13 J K G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r1 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F v_13 J K G) →
  (r1 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F v_13 J K G) →
  (r0 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r0 A B C D H E F L J K G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r1 A B C D H E F L J K G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r1 A B C D H E F L J K G) →
  (r1 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r1 A B C D H E F L J K G) →
  (r0 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r1 A B C D H E F K J I G) →
  (r0 A B C D H E F K I J G) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 A B C D H E F K J I G) →
  (r1 A B C D H E F K I J G) →
  (True) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  False)))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«point-location.45_000»
