import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«point-location.46_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":686:1-686:12 (check-sat, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":11:1-169:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":170:1-180:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":181:1-191:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":192:1-202:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":203:1-213:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":214:1-224:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":225:1-237:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":238:1-250:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":251:1-263:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":264:1-278:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":279:1-293:2 (clause 11, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":294:1-308:2 (clause 12, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":309:1-323:2 (clause 13, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":324:1-338:2 (clause 14, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":339:1-349:2 (clause 15, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":350:1-360:2 (clause 16, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":361:1-373:2 (clause 17, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":374:1-386:2 (clause 18, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":387:1-399:2 (clause 19, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":400:1-414:2 (clause 20, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":415:1-429:2 (clause 21, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":430:1-444:2 (clause 22, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":445:1-459:2 (clause 23, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":460:1-474:2 (clause 24, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":475:1-490:2 (clause 25, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":491:1-506:2 (clause 26, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":507:1-522:2 (clause 27, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":523:1-538:2 (clause 28, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":539:1-554:2 (clause 29, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":555:1-570:2 (clause 30, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":571:1-584:2 (clause 31, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":585:1-598:2 (clause 32, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":599:1-612:2 (clause 33, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":613:1-626:2 (clause 34, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":627:1-638:2 (clause 35, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":639:1-650:2 (clause 36, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":651:1-662:2 (clause 37, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":663:1-674:2 (clause 38, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.46_000.smt2":675:1-684:2 (clause 39, command 46)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + (-1 : Int) * H ≥ (-5 : Int)) →
  ((-1 : Int) * I + H ≥ (-1 : Int)) →
  ((-1 : Int) * I + G ≥ (2 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * H ≥ (-7 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-8 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * D ≥ (-9 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-8 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * B ≥ (-7 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * K ≥ (-6 : Int)) →
  ((-1 : Int) * E + H ≥ (-3 : Int)) →
  ((-1 : Int) * E + I ≥ (-2 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + B ≥ (-3 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * E + K ≥ (-4 : Int)) →
  ((-1 : Int) * D + (-1 : Int) * H ≥ (-6 : Int)) →
  ((-1 : Int) * D + (-1 : Int) * I ≥ (-7 : Int)) →
  ((-1 : Int) * D + H ≥ (-2 : Int)) →
  ((-1 : Int) * D + I ≥ (-1 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * H ≥ (-5 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-6 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * D ≥ (-7 : Int)) →
  ((-1 : Int) * C + H ≥ (-1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * H ≥ (-4 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * I ≥ (-5 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * D ≥ (-6 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * C ≥ (-5 : Int)) →
  ((-1 : Int) * B + H ≥ (0 : Int)) →
  ((-1 : Int) * B + I ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * B + D ≥ (2 : Int)) →
  ((-1 : Int) * B + C ≥ (1 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * H ≥ (-3 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * I ≥ (-4 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * D ≥ (-5 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * C ≥ (-4 : Int)) →
  ((-1 : Int) * K + (-1 : Int) * B ≥ (-3 : Int)) →
  ((-1 : Int) * K + H ≥ (1 : Int)) →
  ((-1 : Int) * K + I ≥ (2 : Int)) →
  ((-1 : Int) * K + G ≥ (4 : Int)) →
  ((-1 : Int) * K + D ≥ (3 : Int)) →
  ((-1 : Int) * K + C ≥ (2 : Int)) →
  ((-1 : Int) * K + B ≥ (1 : Int)) →
  (H + G ≥ (7 : Int)) →
  (I + (-1 : Int) * H ≥ (1 : Int)) →
  (I + H ≥ (5 : Int)) →
  (I + G ≥ (8 : Int)) →
  (F + (-1 : Int) * H ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (1 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (3 : Int)) →
  (F + H ≥ (6 : Int)) →
  (F + I ≥ (7 : Int)) →
  (F + G ≥ (9 : Int)) →
  (F + D ≥ (8 : Int)) →
  (F + C ≥ (7 : Int)) →
  (F + B ≥ (6 : Int)) →
  (F + A ≥ (9 : Int)) →
  (F + K ≥ (5 : Int)) →
  (E + (-1 : Int) * H ≥ (3 : Int)) →
  (E + (-1 : Int) * I ≥ (2 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (4 : Int)) →
  (E + H ≥ (7 : Int)) →
  (E + I ≥ (8 : Int)) →
  (E + G ≥ (10 : Int)) →
  (E + F ≥ (9 : Int)) →
  (E + D ≥ (9 : Int)) →
  (E + C ≥ (8 : Int)) →
  (E + B ≥ (7 : Int)) →
  (E + A ≥ (10 : Int)) →
  (E + K ≥ (6 : Int)) →
  (D + (-1 : Int) * H ≥ (2 : Int)) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (D + H ≥ (6 : Int)) →
  (D + I ≥ (7 : Int)) →
  (D + G ≥ (9 : Int)) →
  (C + (-1 : Int) * H ≥ (1 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (5 : Int)) →
  (C + I ≥ (6 : Int)) →
  (C + G ≥ (8 : Int)) →
  (C + D ≥ (7 : Int)) →
  (B + (-1 : Int) * H ≥ (0 : Int)) →
  (B + (-1 : Int) * I ≥ (-1 : Int)) →
  (B + (-1 : Int) * D ≥ (-2 : Int)) →
  (B + (-1 : Int) * C ≥ (-1 : Int)) →
  (B + H ≥ (4 : Int)) →
  (B + I ≥ (5 : Int)) →
  (B + G ≥ (7 : Int)) →
  (B + D ≥ (6 : Int)) →
  (B + C ≥ (5 : Int)) →
  (A + (-1 : Int) * H ≥ (3 : Int)) →
  (A + (-1 : Int) * I ≥ (2 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (3 : Int)) →
  (A + (-1 : Int) * K ≥ (4 : Int)) →
  (A + H ≥ (7 : Int)) →
  (A + I ≥ (8 : Int)) →
  (A + G ≥ (10 : Int)) →
  (A + D ≥ (9 : Int)) →
  (A + C ≥ (8 : Int)) →
  (A + B ≥ (7 : Int)) →
  (A + K ≥ (6 : Int)) →
  (K + (-1 : Int) * H ≥ (-1 : Int)) →
  (K + (-1 : Int) * I ≥ (-2 : Int)) →
  (K + (-1 : Int) * D ≥ (-3 : Int)) →
  (K + (-1 : Int) * C ≥ (-2 : Int)) →
  (K + (-1 : Int) * B ≥ (-1 : Int)) →
  (K + H ≥ (3 : Int)) →
  (K + I ≥ (4 : Int)) →
  (K + G ≥ (6 : Int)) →
  (K + D ≥ (5 : Int)) →
  (K + C ≥ (4 : Int)) →
  (K + B ≥ (3 : Int)) →
  (H ≥ (2 : Int)) →
  (I ≥ (3 : Int)) →
  (G ≥ (5 : Int)) →
  (F ≥ (4 : Int)) →
  (E ≥ (5 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (3 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (5 : Int)) →
  (K ≥ (1 : Int)) →
  (H ≤ (2 : Int)) →
  (I ≤ (3 : Int)) →
  (E ≤ (5 : Int)) →
  (D ≤ (4 : Int)) →
  (C ≤ (3 : Int)) →
  (B ≤ (2 : Int)) →
  (K ≤ (1 : Int)) →
  ((-1 : Int) * H + G ≥ (3 : Int)) →
  r3 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r1 A B C D K E F G H I J) →
  (True) →
  r0 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r2 A B C D K E F G H I J) →
  (True) →
  r0 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 A B C D K E F G H I J) →
  (True) →
  r5 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r2 A B C D H E F J I K G) →
  (True) →
  r1 A B C D H E F K J I G) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 A B C D H E F K I J G) →
  (True) →
  r1 A B C D H E F K J I G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r2 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r1 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r0 A B C D H E F I K J G) →
  (r2 A B C D H E F I L K G) →
  (True) →
  r1 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D H E F I J L G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r1 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r2 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r1 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r2 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r1 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r2 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r1 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r2 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r1 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r2 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r1 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r2 A B C D H E F J I K G) →
  (True) →
  r2 A B C D H E F K J I G) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 A B C D H E F K I J G) →
  (True) →
  r2 A B C D H E F K J I G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r2 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r2 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r0 A B C D H E F I K J G) →
  (r2 A B C D H E F I L K G) →
  (True) →
  r2 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D H E F I J L G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r2 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r2 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r2 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r2 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r2 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r2 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r2 A B C D H E F v_13 J K G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r2 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F v_13 J K G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F v_13 J K G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r2 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F v_13 J K G) →
  (r0 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r2 A B C D H E F I L K G) →
  (r0 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F v_13 J K G) →
  (r0 A B C D H E F L K J G) →
  (r2 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F v_13 J K G) →
  (r2 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r0 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r2 A B C D H E F L J K G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D H E F I J L G) →
  (r0 A B C D H E F L J K G) →
  (r0 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r0 A B C D H E F L J K G) →
  (r0 A B C D H E F I K J G) →
  (r2 A B C D H E F I L K G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r0 A B C D H E F L J K G) →
  (r2 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 A B C D H E F K J I G) →
  (r2 A B C D H E F K I J G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r2 A B C D H E F K J I G) →
  (r0 A B C D H E F K I J G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r5 A B C D H E F K J I G) →
  (r2 A B C D H E F K J I G) →
  (True) →
  r4) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 A B C D H E F K J I G) →
  (r0 A B C D H E F K J I G) →
  (True) →
  r4) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r4) →
  False))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«point-location.46_000»
