import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«point-location.47_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1276:1-1276:12 (check-sat, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":9:1-120:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":121:1-231:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":232:1-348:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":349:1-460:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":461:1-585:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":586:1-701:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":702:1-816:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":817:1-827:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":828:1-838:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":839:1-849:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":850:1-862:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":863:1-875:2 (clause 12, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":876:1-888:2 (clause 13, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":889:1-903:2 (clause 14, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":904:1-918:2 (clause 15, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":919:1-933:2 (clause 16, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":934:1-948:2 (clause 17, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":949:1-963:2 (clause 18, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":964:1-974:2 (clause 19, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":975:1-987:2 (clause 20, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":988:1-1000:2 (clause 21, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1001:1-1013:2 (clause 22, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1014:1-1028:2 (clause 23, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1029:1-1043:2 (clause 24, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1044:1-1058:2 (clause 25, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1059:1-1073:2 (clause 26, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1074:1-1088:2 (clause 27, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1089:1-1104:2 (clause 28, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1105:1-1120:2 (clause 29, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1121:1-1136:2 (clause 30, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1137:1-1152:2 (clause 31, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1153:1-1168:2 (clause 32, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1169:1-1184:2 (clause 33, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1185:1-1198:2 (clause 34, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1199:1-1212:2 (clause 35, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1213:1-1226:2 (clause 36, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1227:1-1240:2 (clause 37, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1241:1-1252:2 (clause 38, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1253:1-1264:2 (clause 39, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/point-location.47_000.smt2":1265:1-1274:2 (clause 40, command 45)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + H ≥ (1 : Int)) →
  ((-1 : Int) * I + G ≥ (4 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + H ≥ (0 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * B + D ≥ (2 : Int)) →
  ((-1 : Int) * B + C ≥ (1 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (11 : Int)) →
  (I + H ≥ (7 : Int)) →
  (I + G ≥ (10 : Int)) →
  (F + (-1 : Int) * H ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (10 : Int)) →
  (F + I ≥ (9 : Int)) →
  (F + G ≥ (13 : Int)) →
  (F + D ≥ (12 : Int)) →
  (F + C ≥ (11 : Int)) →
  (F + B ≥ (10 : Int)) →
  (F + A ≥ (13 : Int)) →
  (F + K ≥ (9 : Int)) →
  (E + (-1 : Int) * H ≥ (3 : Int)) →
  (E + (-1 : Int) * I ≥ (4 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (11 : Int)) →
  (E + I ≥ (10 : Int)) →
  (E + G ≥ (14 : Int)) →
  (E + F ≥ (13 : Int)) →
  (E + D ≥ (13 : Int)) →
  (E + C ≥ (12 : Int)) →
  (E + B ≥ (11 : Int)) →
  (E + A ≥ (14 : Int)) →
  (E + K ≥ (10 : Int)) →
  (D + (-1 : Int) * H ≥ (2 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + H ≥ (10 : Int)) →
  (D + I ≥ (9 : Int)) →
  (D + G ≥ (13 : Int)) →
  (C + (-1 : Int) * H ≥ (1 : Int)) →
  (C + (-1 : Int) * I ≥ (2 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (9 : Int)) →
  (C + I ≥ (8 : Int)) →
  (C + G ≥ (12 : Int)) →
  (C + D ≥ (11 : Int)) →
  (B + (-1 : Int) * H ≥ (0 : Int)) →
  (B + (-1 : Int) * I ≥ (1 : Int)) →
  (B + H ≥ (8 : Int)) →
  (B + I ≥ (7 : Int)) →
  (B + G ≥ (11 : Int)) →
  (B + D ≥ (10 : Int)) →
  (B + C ≥ (9 : Int)) →
  (A + (-1 : Int) * H ≥ (3 : Int)) →
  (A + (-1 : Int) * I ≥ (4 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (3 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (11 : Int)) →
  (A + I ≥ (10 : Int)) →
  (A + G ≥ (14 : Int)) →
  (A + D ≥ (13 : Int)) →
  (A + C ≥ (12 : Int)) →
  (A + B ≥ (11 : Int)) →
  (A + K ≥ (10 : Int)) →
  (K + (-1 : Int) * I ≥ (0 : Int)) →
  (K + H ≥ (7 : Int)) →
  (K + I ≥ (6 : Int)) →
  (K + G ≥ (10 : Int)) →
  (K + D ≥ (9 : Int)) →
  (K + C ≥ (8 : Int)) →
  (K + B ≥ (7 : Int)) →
  (H ≥ (4 : Int)) →
  (I ≥ (3 : Int)) →
  (G ≥ (7 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (7 : Int)) →
  (D ≥ (6 : Int)) →
  (C ≥ (5 : Int)) →
  (B ≥ (4 : Int)) →
  (A ≥ (7 : Int)) →
  (K ≥ (3 : Int)) →
  ((-1 : Int) * H + G ≥ (3 : Int)) →
  r3 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + H ≥ (1 : Int)) →
  ((-1 : Int) * I + G ≥ (5 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * B + D ≥ (2 : Int)) →
  ((-1 : Int) * B + C ≥ (1 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (12 : Int)) →
  (I + H ≥ (7 : Int)) →
  (I + G ≥ (11 : Int)) →
  (F + (-1 : Int) * H ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (4 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (11 : Int)) →
  (F + I ≥ (10 : Int)) →
  (F + G ≥ (15 : Int)) →
  (F + D ≥ (14 : Int)) →
  (F + C ≥ (13 : Int)) →
  (F + B ≥ (12 : Int)) →
  (F + A ≥ (15 : Int)) →
  (F + K ≥ (10 : Int)) →
  (E + (-1 : Int) * H ≥ (4 : Int)) →
  (E + (-1 : Int) * I ≥ (5 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (12 : Int)) →
  (E + I ≥ (11 : Int)) →
  (E + G ≥ (16 : Int)) →
  (E + F ≥ (15 : Int)) →
  (E + D ≥ (15 : Int)) →
  (E + C ≥ (14 : Int)) →
  (E + B ≥ (13 : Int)) →
  (E + A ≥ (16 : Int)) →
  (E + K ≥ (11 : Int)) →
  (D + (-1 : Int) * H ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (4 : Int)) →
  (D + H ≥ (11 : Int)) →
  (D + I ≥ (10 : Int)) →
  (D + G ≥ (15 : Int)) →
  (C + (-1 : Int) * H ≥ (2 : Int)) →
  (C + (-1 : Int) * I ≥ (3 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (10 : Int)) →
  (C + I ≥ (9 : Int)) →
  (C + G ≥ (14 : Int)) →
  (C + D ≥ (13 : Int)) →
  (B + (-1 : Int) * H ≥ (1 : Int)) →
  (B + (-1 : Int) * I ≥ (2 : Int)) →
  (B + H ≥ (9 : Int)) →
  (B + I ≥ (8 : Int)) →
  (B + G ≥ (13 : Int)) →
  (B + D ≥ (12 : Int)) →
  (B + C ≥ (11 : Int)) →
  (A + (-1 : Int) * H ≥ (4 : Int)) →
  (A + (-1 : Int) * I ≥ (5 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (3 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (12 : Int)) →
  (A + I ≥ (11 : Int)) →
  (A + G ≥ (16 : Int)) →
  (A + D ≥ (15 : Int)) →
  (A + C ≥ (14 : Int)) →
  (A + B ≥ (13 : Int)) →
  (A + K ≥ (11 : Int)) →
  (K + (-1 : Int) * I ≥ (0 : Int)) →
  (K + H ≥ (7 : Int)) →
  (K + I ≥ (6 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + D ≥ (10 : Int)) →
  (K + C ≥ (9 : Int)) →
  (K + B ≥ (8 : Int)) →
  (H ≥ (4 : Int)) →
  (I ≥ (3 : Int)) →
  (G ≥ (8 : Int)) →
  (F ≥ (7 : Int)) →
  (E ≥ (8 : Int)) →
  (D ≥ (7 : Int)) →
  (C ≥ (6 : Int)) →
  (B ≥ (5 : Int)) →
  (A ≥ (8 : Int)) →
  (K ≥ (3 : Int)) →
  ((-1 : Int) * H + G ≥ (4 : Int)) →
  r3 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * E + K ≥ (-3 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + H ≥ (0 : Int)) →
  ((-1 : Int) * B + I ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (4 : Int)) →
  ((-1 : Int) * B + D ≥ (3 : Int)) →
  ((-1 : Int) * B + C ≥ (2 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (9 : Int)) →
  (I + (-1 : Int) * H ≥ (1 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (11 : Int)) →
  (F + (-1 : Int) * H ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (2 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (3 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (8 : Int)) →
  (F + I ≥ (10 : Int)) →
  (F + G ≥ (13 : Int)) →
  (F + D ≥ (12 : Int)) →
  (F + C ≥ (11 : Int)) →
  (F + B ≥ (8 : Int)) →
  (F + A ≥ (13 : Int)) →
  (F + K ≥ (10 : Int)) →
  (E + (-1 : Int) * H ≥ (4 : Int)) →
  (E + (-1 : Int) * I ≥ (3 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (4 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (9 : Int)) →
  (E + I ≥ (11 : Int)) →
  (E + G ≥ (14 : Int)) →
  (E + F ≥ (13 : Int)) →
  (E + D ≥ (13 : Int)) →
  (E + C ≥ (12 : Int)) →
  (E + B ≥ (9 : Int)) →
  (E + A ≥ (14 : Int)) →
  (E + K ≥ (11 : Int)) →
  (D + (-1 : Int) * H ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (2 : Int)) →
  (D + H ≥ (8 : Int)) →
  (D + I ≥ (10 : Int)) →
  (D + G ≥ (13 : Int)) →
  (C + (-1 : Int) * H ≥ (2 : Int)) →
  (C + (-1 : Int) * I ≥ (1 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (7 : Int)) →
  (C + I ≥ (9 : Int)) →
  (C + G ≥ (12 : Int)) →
  (C + D ≥ (11 : Int)) →
  (B + (-1 : Int) * H ≥ (0 : Int)) →
  (B + H ≥ (4 : Int)) →
  (B + I ≥ (6 : Int)) →
  (B + G ≥ (9 : Int)) →
  (B + D ≥ (8 : Int)) →
  (B + C ≥ (7 : Int)) →
  (A + (-1 : Int) * H ≥ (4 : Int)) →
  (A + (-1 : Int) * I ≥ (3 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (4 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (9 : Int)) →
  (A + I ≥ (11 : Int)) →
  (A + G ≥ (14 : Int)) →
  (A + D ≥ (13 : Int)) →
  (A + C ≥ (12 : Int)) →
  (A + B ≥ (9 : Int)) →
  (A + K ≥ (11 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * I ≥ (0 : Int)) →
  (K + (-1 : Int) * D ≥ (-2 : Int)) →
  (K + (-1 : Int) * C ≥ (-1 : Int)) →
  (K + (-1 : Int) * B ≥ (1 : Int)) →
  (K + H ≥ (6 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + G ≥ (11 : Int)) →
  (K + D ≥ (10 : Int)) →
  (K + C ≥ (9 : Int)) →
  (K + B ≥ (6 : Int)) →
  (H ≥ (2 : Int)) →
  (I ≥ (4 : Int)) →
  (G ≥ (7 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (7 : Int)) →
  (D ≥ (6 : Int)) →
  (C ≥ (5 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (7 : Int)) →
  (K ≥ (4 : Int)) →
  ((-1 : Int) * H + G ≥ (4 : Int)) →
  r3 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + G ≥ (4 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * B + D ≥ (2 : Int)) →
  ((-1 : Int) * B + C ≥ (1 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (10 : Int)) →
  (I + (-1 : Int) * H ≥ (1 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (12 : Int)) →
  (F + (-1 : Int) * H ≥ (4 : Int)) →
  (F + (-1 : Int) * I ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (9 : Int)) →
  (F + I ≥ (11 : Int)) →
  (F + G ≥ (15 : Int)) →
  (F + D ≥ (14 : Int)) →
  (F + C ≥ (13 : Int)) →
  (F + B ≥ (12 : Int)) →
  (F + A ≥ (15 : Int)) →
  (F + K ≥ (11 : Int)) →
  (E + (-1 : Int) * H ≥ (5 : Int)) →
  (E + (-1 : Int) * I ≥ (4 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (10 : Int)) →
  (E + I ≥ (12 : Int)) →
  (E + G ≥ (16 : Int)) →
  (E + F ≥ (15 : Int)) →
  (E + D ≥ (15 : Int)) →
  (E + C ≥ (14 : Int)) →
  (E + B ≥ (13 : Int)) →
  (E + A ≥ (16 : Int)) →
  (E + K ≥ (12 : Int)) →
  (D + (-1 : Int) * H ≥ (4 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + H ≥ (9 : Int)) →
  (D + I ≥ (11 : Int)) →
  (D + G ≥ (15 : Int)) →
  (C + (-1 : Int) * H ≥ (3 : Int)) →
  (C + (-1 : Int) * I ≥ (2 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (8 : Int)) →
  (C + I ≥ (10 : Int)) →
  (C + G ≥ (14 : Int)) →
  (C + D ≥ (13 : Int)) →
  (B + (-1 : Int) * H ≥ (2 : Int)) →
  (B + (-1 : Int) * I ≥ (1 : Int)) →
  (B + H ≥ (7 : Int)) →
  (B + I ≥ (9 : Int)) →
  (B + G ≥ (13 : Int)) →
  (B + D ≥ (12 : Int)) →
  (B + C ≥ (11 : Int)) →
  (A + (-1 : Int) * H ≥ (5 : Int)) →
  (A + (-1 : Int) * I ≥ (4 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (3 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (10 : Int)) →
  (A + I ≥ (12 : Int)) →
  (A + G ≥ (16 : Int)) →
  (A + D ≥ (15 : Int)) →
  (A + C ≥ (14 : Int)) →
  (A + B ≥ (13 : Int)) →
  (A + K ≥ (12 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * I ≥ (0 : Int)) →
  (K + H ≥ (6 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + G ≥ (12 : Int)) →
  (K + D ≥ (11 : Int)) →
  (K + C ≥ (10 : Int)) →
  (K + B ≥ (9 : Int)) →
  (H ≥ (2 : Int)) →
  (I ≥ (4 : Int)) →
  (G ≥ (8 : Int)) →
  (F ≥ (7 : Int)) →
  (E ≥ (8 : Int)) →
  (D ≥ (7 : Int)) →
  (C ≥ (6 : Int)) →
  (B ≥ (5 : Int)) →
  (A ≥ (8 : Int)) →
  (K ≥ (4 : Int)) →
  ((-1 : Int) * H + G ≥ (5 : Int)) →
  r3 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + (-1 : Int) * H ≥ (-5 : Int)) →
  ((-1 : Int) * I + H ≥ (-1 : Int)) →
  ((-1 : Int) * I + G ≥ (3 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * E + K ≥ (-3 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * H ≥ (-4 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * I ≥ (-5 : Int)) →
  ((-1 : Int) * B + H ≥ (0 : Int)) →
  ((-1 : Int) * B + I ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (4 : Int)) →
  ((-1 : Int) * B + D ≥ (3 : Int)) →
  ((-1 : Int) * B + C ≥ (2 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (8 : Int)) →
  (I + (-1 : Int) * H ≥ (1 : Int)) →
  (I + H ≥ (5 : Int)) →
  (I + G ≥ (9 : Int)) →
  (F + (-1 : Int) * H ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (2 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (3 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (7 : Int)) →
  (F + I ≥ (8 : Int)) →
  (F + G ≥ (11 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (9 : Int)) →
  (F + B ≥ (7 : Int)) →
  (F + A ≥ (11 : Int)) →
  (F + K ≥ (8 : Int)) →
  (E + (-1 : Int) * H ≥ (4 : Int)) →
  (E + (-1 : Int) * I ≥ (3 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (4 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (8 : Int)) →
  (E + I ≥ (9 : Int)) →
  (E + G ≥ (12 : Int)) →
  (E + F ≥ (11 : Int)) →
  (E + D ≥ (11 : Int)) →
  (E + C ≥ (10 : Int)) →
  (E + B ≥ (8 : Int)) →
  (E + A ≥ (12 : Int)) →
  (E + K ≥ (9 : Int)) →
  (D + (-1 : Int) * H ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (2 : Int)) →
  (D + H ≥ (7 : Int)) →
  (D + I ≥ (8 : Int)) →
  (D + G ≥ (11 : Int)) →
  (C + (-1 : Int) * H ≥ (2 : Int)) →
  (C + (-1 : Int) * I ≥ (1 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + I ≥ (7 : Int)) →
  (C + G ≥ (10 : Int)) →
  (C + D ≥ (9 : Int)) →
  (B + (-1 : Int) * H ≥ (0 : Int)) →
  (B + (-1 : Int) * I ≥ (-1 : Int)) →
  (B + H ≥ (4 : Int)) →
  (B + I ≥ (5 : Int)) →
  (B + G ≥ (8 : Int)) →
  (B + D ≥ (7 : Int)) →
  (B + C ≥ (6 : Int)) →
  (A + (-1 : Int) * H ≥ (4 : Int)) →
  (A + (-1 : Int) * I ≥ (3 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (4 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (8 : Int)) →
  (A + I ≥ (9 : Int)) →
  (A + G ≥ (12 : Int)) →
  (A + D ≥ (11 : Int)) →
  (A + C ≥ (10 : Int)) →
  (A + B ≥ (8 : Int)) →
  (A + K ≥ (9 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * I ≥ (0 : Int)) →
  (K + (-1 : Int) * D ≥ (-2 : Int)) →
  (K + (-1 : Int) * C ≥ (-1 : Int)) →
  (K + (-1 : Int) * B ≥ (1 : Int)) →
  (K + H ≥ (5 : Int)) →
  (K + I ≥ (6 : Int)) →
  (K + G ≥ (9 : Int)) →
  (K + D ≥ (8 : Int)) →
  (K + C ≥ (7 : Int)) →
  (K + B ≥ (5 : Int)) →
  (H ≥ (2 : Int)) →
  (I ≥ (3 : Int)) →
  (G ≥ (6 : Int)) →
  (F ≥ (5 : Int)) →
  (E ≥ (6 : Int)) →
  (D ≥ (5 : Int)) →
  (C ≥ (4 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (6 : Int)) →
  (K ≥ (3 : Int)) →
  (H ≤ (2 : Int)) →
  (I ≤ (3 : Int)) →
  (B ≤ (2 : Int)) →
  ((-1 : Int) * H + G ≥ (4 : Int)) →
  r3 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + (-1 : Int) * H ≥ (-5 : Int)) →
  ((-1 : Int) * I + H ≥ (-1 : Int)) →
  ((-1 : Int) * I + G ≥ (4 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * B + D ≥ (2 : Int)) →
  ((-1 : Int) * B + C ≥ (1 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (9 : Int)) →
  (I + (-1 : Int) * H ≥ (1 : Int)) →
  (I + H ≥ (5 : Int)) →
  (I + G ≥ (10 : Int)) →
  (F + (-1 : Int) * H ≥ (4 : Int)) →
  (F + (-1 : Int) * I ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (8 : Int)) →
  (F + I ≥ (9 : Int)) →
  (F + G ≥ (13 : Int)) →
  (F + D ≥ (12 : Int)) →
  (F + C ≥ (11 : Int)) →
  (F + B ≥ (10 : Int)) →
  (F + A ≥ (13 : Int)) →
  (F + K ≥ (9 : Int)) →
  (E + (-1 : Int) * H ≥ (5 : Int)) →
  (E + (-1 : Int) * I ≥ (4 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (9 : Int)) →
  (E + I ≥ (10 : Int)) →
  (E + G ≥ (14 : Int)) →
  (E + F ≥ (13 : Int)) →
  (E + D ≥ (13 : Int)) →
  (E + C ≥ (12 : Int)) →
  (E + B ≥ (11 : Int)) →
  (E + A ≥ (14 : Int)) →
  (E + K ≥ (10 : Int)) →
  (D + (-1 : Int) * H ≥ (4 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + H ≥ (8 : Int)) →
  (D + I ≥ (9 : Int)) →
  (D + G ≥ (13 : Int)) →
  (C + (-1 : Int) * H ≥ (3 : Int)) →
  (C + (-1 : Int) * I ≥ (2 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (7 : Int)) →
  (C + I ≥ (8 : Int)) →
  (C + G ≥ (12 : Int)) →
  (C + D ≥ (11 : Int)) →
  (B + (-1 : Int) * H ≥ (2 : Int)) →
  (B + (-1 : Int) * I ≥ (1 : Int)) →
  (B + H ≥ (6 : Int)) →
  (B + I ≥ (7 : Int)) →
  (B + G ≥ (11 : Int)) →
  (B + D ≥ (10 : Int)) →
  (B + C ≥ (9 : Int)) →
  (A + (-1 : Int) * H ≥ (5 : Int)) →
  (A + (-1 : Int) * I ≥ (4 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (3 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (9 : Int)) →
  (A + I ≥ (10 : Int)) →
  (A + G ≥ (14 : Int)) →
  (A + D ≥ (13 : Int)) →
  (A + C ≥ (12 : Int)) →
  (A + B ≥ (11 : Int)) →
  (A + K ≥ (10 : Int)) →
  (K + (-1 : Int) * H ≥ (1 : Int)) →
  (K + (-1 : Int) * I ≥ (0 : Int)) →
  (K + H ≥ (5 : Int)) →
  (K + I ≥ (6 : Int)) →
  (K + G ≥ (10 : Int)) →
  (K + D ≥ (9 : Int)) →
  (K + C ≥ (8 : Int)) →
  (K + B ≥ (7 : Int)) →
  (H ≥ (2 : Int)) →
  (I ≥ (3 : Int)) →
  (G ≥ (7 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (7 : Int)) →
  (D ≥ (6 : Int)) →
  (C ≥ (5 : Int)) →
  (B ≥ (4 : Int)) →
  (A ≥ (7 : Int)) →
  (K ≥ (3 : Int)) →
  (H ≤ (2 : Int)) →
  (I ≤ (3 : Int)) →
  ((-1 : Int) * H + G ≥ (5 : Int)) →
  r3 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  ((-1 : Int) * I + G ≥ (2 : Int)) →
  ((-1 : Int) * F + G ≥ (1 : Int)) →
  ((-1 : Int) * F + A ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (-2 : Int)) →
  ((-1 : Int) * E + G ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (-1 : Int)) →
  ((-1 : Int) * E + D ≥ (-1 : Int)) →
  ((-1 : Int) * E + C ≥ (-2 : Int)) →
  ((-1 : Int) * E + A ≥ (0 : Int)) →
  ((-1 : Int) * D + I ≥ (-1 : Int)) →
  ((-1 : Int) * D + G ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + G ≥ (2 : Int)) →
  ((-1 : Int) * C + D ≥ (1 : Int)) →
  ((-1 : Int) * B + H ≥ (0 : Int)) →
  ((-1 : Int) * B + I ≥ (1 : Int)) →
  ((-1 : Int) * B + G ≥ (3 : Int)) →
  ((-1 : Int) * B + D ≥ (2 : Int)) →
  ((-1 : Int) * B + C ≥ (1 : Int)) →
  ((-1 : Int) * A + G ≥ (0 : Int)) →
  ((-1 : Int) * K + I ≥ (1 : Int)) →
  ((-1 : Int) * K + G ≥ (3 : Int)) →
  ((-1 : Int) * K + D ≥ (2 : Int)) →
  ((-1 : Int) * K + C ≥ (1 : Int)) →
  (H + G ≥ (8 : Int)) →
  (I + (-1 : Int) * H ≥ (1 : Int)) →
  (I + H ≥ (6 : Int)) →
  (I + G ≥ (10 : Int)) →
  (F + (-1 : Int) * H ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (1 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (1 : Int)) →
  (F + (-1 : Int) * B ≥ (2 : Int)) →
  (F + (-1 : Int) * K ≥ (2 : Int)) →
  (F + H ≥ (7 : Int)) →
  (F + I ≥ (9 : Int)) →
  (F + G ≥ (11 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (9 : Int)) →
  (F + B ≥ (7 : Int)) →
  (F + A ≥ (11 : Int)) →
  (F + K ≥ (8 : Int)) →
  (E + (-1 : Int) * H ≥ (3 : Int)) →
  (E + (-1 : Int) * I ≥ (2 : Int)) →
  (E + (-1 : Int) * D ≥ (1 : Int)) →
  (E + (-1 : Int) * C ≥ (2 : Int)) →
  (E + (-1 : Int) * B ≥ (3 : Int)) →
  (E + (-1 : Int) * K ≥ (3 : Int)) →
  (E + H ≥ (8 : Int)) →
  (E + I ≥ (10 : Int)) →
  (E + G ≥ (12 : Int)) →
  (E + F ≥ (11 : Int)) →
  (E + D ≥ (11 : Int)) →
  (E + C ≥ (10 : Int)) →
  (E + B ≥ (8 : Int)) →
  (E + A ≥ (12 : Int)) →
  (E + K ≥ (9 : Int)) →
  (D + (-1 : Int) * H ≥ (2 : Int)) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (D + H ≥ (7 : Int)) →
  (D + I ≥ (9 : Int)) →
  (D + G ≥ (11 : Int)) →
  (C + (-1 : Int) * H ≥ (1 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * D ≥ (-1 : Int)) →
  (C + H ≥ (6 : Int)) →
  (C + I ≥ (8 : Int)) →
  (C + G ≥ (10 : Int)) →
  (C + D ≥ (9 : Int)) →
  (B + (-1 : Int) * H ≥ (0 : Int)) →
  (B + H ≥ (4 : Int)) →
  (B + I ≥ (6 : Int)) →
  (B + G ≥ (8 : Int)) →
  (B + D ≥ (7 : Int)) →
  (B + C ≥ (6 : Int)) →
  (A + (-1 : Int) * H ≥ (3 : Int)) →
  (A + (-1 : Int) * I ≥ (2 : Int)) →
  (A + (-1 : Int) * G ≥ (0 : Int)) →
  (A + (-1 : Int) * D ≥ (1 : Int)) →
  (A + (-1 : Int) * C ≥ (2 : Int)) →
  (A + (-1 : Int) * B ≥ (3 : Int)) →
  (A + (-1 : Int) * K ≥ (3 : Int)) →
  (A + H ≥ (8 : Int)) →
  (A + I ≥ (10 : Int)) →
  (A + G ≥ (12 : Int)) →
  (A + D ≥ (11 : Int)) →
  (A + C ≥ (10 : Int)) →
  (A + B ≥ (8 : Int)) →
  (A + K ≥ (9 : Int)) →
  (K + H ≥ (5 : Int)) →
  (K + I ≥ (7 : Int)) →
  (K + G ≥ (9 : Int)) →
  (K + D ≥ (8 : Int)) →
  (K + C ≥ (7 : Int)) →
  (K + B ≥ (5 : Int)) →
  (H ≥ (2 : Int)) →
  (I ≥ (4 : Int)) →
  (G ≥ (6 : Int)) →
  (F ≥ (5 : Int)) →
  (E ≥ (6 : Int)) →
  (D ≥ (5 : Int)) →
  (C ≥ (4 : Int)) →
  (B ≥ (2 : Int)) →
  (A ≥ (6 : Int)) →
  (K ≥ (3 : Int)) →
  ((-1 : Int) * H + G ≥ (3 : Int)) →
  r0 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 A B C D K E F G H I J) →
  (True) →
  r1 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 A B C D K E F G H I J) →
  (True) →
  r1 A B C D K E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 A B C D H E F J I K G) →
  (True) →
  r3 A B C D H E F K J I G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r0 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r3 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r1 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r3 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r3 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r3 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r3 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r3 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r3 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r3 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 A B C D H E F J I K G) →
  (True) →
  r0 A B C D H E F K J I G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r0 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r0 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r1 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r0 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r0 A B C D H E F L K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r0 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r0 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r0 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r0 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r0 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_13 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r0 A B C D H E F v_14 K J G) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r0 A B C D H E F v_13 J K G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r0 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F v_13 J K G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F v_13 J K G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r0 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F v_13 J K G) →
  (r1 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (r1 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F v_13 J K G) →
  (r1 A B C D H E F L K J G) →
  (r0 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 : Int),
  (r1 A B C D H E F v_12 K I G) →
  (r1 A B C D H E F v_13 J K G) →
  (r0 A B C D H E F L K J G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (r1 A B C D H E F v_14 L K G) →
  (v_12 = H) →
  (v_13 = H) →
  (v_14 = H) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r0 A B C D H E F L J K G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D H E F I J L G) →
  (r1 A B C D H E F L J K G) →
  (r1 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r1 A B C D H E F L J K G) →
  (r1 A B C D H E F I K J G) →
  (r0 A B C D H E F I L K G) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D H E F I J L G) →
  (r1 A B C D H E F L J K G) →
  (r0 A B C D H E F I K J G) →
  (r1 A B C D H E F I L K G) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r1 A B C D H E F K J I G) →
  (r0 A B C D H E F K I J G) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 A B C D H E F K J I G) →
  (r1 A B C D H E F K I J G) →
  (True) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  False)))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«point-location.47_000»
