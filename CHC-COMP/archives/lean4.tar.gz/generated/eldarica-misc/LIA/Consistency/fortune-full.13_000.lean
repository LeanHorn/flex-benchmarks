import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«fortune-full.13_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2299:1-2299:12 (check-sat, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":9:1-289:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":290:1-679:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":680:1-952:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":953:1-1263:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1264:1-1554:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1555:1-1839:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1840:1-1850:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1851:1-1861:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1862:1-1872:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1873:1-1885:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1886:1-1898:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1899:1-1911:2 (clause 12, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1912:1-1926:2 (clause 13, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1927:1-1941:2 (clause 14, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1942:1-1956:2 (clause 15, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1957:1-1971:2 (clause 16, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1972:1-1986:2 (clause 17, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1987:1-1997:2 (clause 18, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":1998:1-2010:2 (clause 19, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2011:1-2023:2 (clause 20, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2024:1-2036:2 (clause 21, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2037:1-2051:2 (clause 22, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2052:1-2066:2 (clause 23, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2067:1-2081:2 (clause 24, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2082:1-2096:2 (clause 25, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2097:1-2111:2 (clause 26, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2112:1-2127:2 (clause 27, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2128:1-2143:2 (clause 28, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2144:1-2159:2 (clause 29, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2160:1-2175:2 (clause 30, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2176:1-2191:2 (clause 31, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2192:1-2207:2 (clause 32, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2208:1-2221:2 (clause 33, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2222:1-2235:2 (clause 34, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2236:1-2249:2 (clause 35, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2250:1-2263:2 (clause 36, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2264:1-2275:2 (clause 37, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2276:1-2287:2 (clause 38, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/Consistency/fortune-full.13_000.smt2":2288:1-2297:2 (clause 39, command 44)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + B ≥ (3 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  ((-1 : Int) * S + O ≥ (3 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (1 : Int)) →
  ((-1 : Int) * N + K ≥ (2 : Int)) →
  ((-1 : Int) * M + N ≥ (0 : Int)) →
  ((-1 : Int) * M + L ≥ (1 : Int)) →
  ((-1 : Int) * M + K ≥ (2 : Int)) →
  ((-1 : Int) * M + B ≥ (0 : Int)) →
  ((-1 : Int) * M + O ≥ (0 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * J + S ≥ (-1 : Int)) →
  ((-1 : Int) * J + P ≥ (1 : Int)) →
  ((-1 : Int) * J + B ≥ (2 : Int)) →
  ((-1 : Int) * J + A ≥ (0 : Int)) →
  ((-1 : Int) * J + O ≥ (2 : Int)) →
  ((-1 : Int) * I + S ≥ (0 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (2 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + B ≥ (3 : Int)) →
  ((-1 : Int) * I + A ≥ (1 : Int)) →
  ((-1 : Int) * I + O ≥ (3 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + S ≥ (0 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (2 : Int)) →
  ((-1 : Int) * E + N ≥ (3 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (4 : Int)) →
  ((-1 : Int) * E + K ≥ (5 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (4 : Int)) →
  ((-1 : Int) * E + D ≥ (4 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (3 : Int)) →
  ((-1 : Int) * E + A ≥ (1 : Int)) →
  ((-1 : Int) * E + O ≥ (3 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + L ≥ (0 : Int)) →
  ((-1 : Int) * D + K ≥ (1 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + S ≥ (0 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (2 : Int)) →
  ((-1 : Int) * C + N ≥ (3 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (4 : Int)) →
  ((-1 : Int) * C + K ≥ (5 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + D ≥ (4 : Int)) →
  ((-1 : Int) * C + B ≥ (3 : Int)) →
  ((-1 : Int) * C + A ≥ (1 : Int)) →
  ((-1 : Int) * C + O ≥ (3 : Int)) →
  ((-1 : Int) * B + O ≥ (0 : Int)) →
  ((-1 : Int) * A + P ≥ (1 : Int)) →
  ((-1 : Int) * A + B ≥ (2 : Int)) →
  ((-1 : Int) * A + O ≥ (2 : Int)) →
  (S + (-1 : Int) * A ≥ (-1 : Int)) →
  (S + Q ≥ (2 : Int)) →
  (S + P ≥ (4 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (3 : Int)) →
  (S + O ≥ (5 : Int)) →
  (Q + P ≥ (4 : Int)) →
  (Q + O ≥ (5 : Int)) →
  (P + O ≥ (7 : Int)) →
  (N + (-1 : Int) * S ≥ (3 : Int)) →
  (N + (-1 : Int) * Q ≥ (2 : Int)) →
  (N + (-1 : Int) * P ≥ (1 : Int)) →
  (N + (-1 : Int) * K ≥ (-2 : Int)) →
  (N + (-1 : Int) * J ≥ (2 : Int)) →
  (N + (-1 : Int) * I ≥ (3 : Int)) →
  (N + (-1 : Int) * B ≥ (0 : Int)) →
  (N + (-1 : Int) * A ≥ (2 : Int)) →
  (N + (-1 : Int) * O ≥ (0 : Int)) →
  (N + S ≥ (5 : Int)) →
  (N + Q ≥ (5 : Int)) →
  (N + P ≥ (7 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (6 : Int)) →
  (N + I ≥ (5 : Int)) →
  (N + B ≥ (8 : Int)) →
  (N + A ≥ (6 : Int)) →
  (N + O ≥ (8 : Int)) →
  (M + (-1 : Int) * S ≥ (3 : Int)) →
  (M + (-1 : Int) * Q ≥ (2 : Int)) →
  (M + (-1 : Int) * P ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (2 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * B ≥ (0 : Int)) →
  (M + (-1 : Int) * A ≥ (2 : Int)) →
  (M + (-1 : Int) * O ≥ (0 : Int)) →
  (M + S ≥ (5 : Int)) →
  (M + Q ≥ (5 : Int)) →
  (M + P ≥ (7 : Int)) →
  (M + N ≥ (8 : Int)) →
  (M + L ≥ (9 : Int)) →
  (M + K ≥ (10 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + B ≥ (8 : Int)) →
  (M + A ≥ (6 : Int)) →
  (M + O ≥ (8 : Int)) →
  (L + (-1 : Int) * S ≥ (4 : Int)) →
  (L + (-1 : Int) * Q ≥ (3 : Int)) →
  (L + (-1 : Int) * P ≥ (2 : Int)) →
  (L + (-1 : Int) * J ≥ (3 : Int)) →
  (L + (-1 : Int) * I ≥ (4 : Int)) →
  (L + (-1 : Int) * B ≥ (1 : Int)) →
  (L + (-1 : Int) * A ≥ (3 : Int)) →
  (L + (-1 : Int) * O ≥ (1 : Int)) →
  (L + S ≥ (6 : Int)) →
  (L + Q ≥ (6 : Int)) →
  (L + P ≥ (8 : Int)) →
  (L + J ≥ (7 : Int)) →
  (L + I ≥ (6 : Int)) →
  (L + B ≥ (9 : Int)) →
  (L + A ≥ (7 : Int)) →
  (L + O ≥ (9 : Int)) →
  (K + (-1 : Int) * S ≥ (5 : Int)) →
  (K + (-1 : Int) * Q ≥ (4 : Int)) →
  (K + (-1 : Int) * P ≥ (3 : Int)) →
  (K + (-1 : Int) * J ≥ (4 : Int)) →
  (K + (-1 : Int) * I ≥ (5 : Int)) →
  (K + (-1 : Int) * B ≥ (2 : Int)) →
  (K + (-1 : Int) * A ≥ (4 : Int)) →
  (K + (-1 : Int) * O ≥ (2 : Int)) →
  (K + S ≥ (7 : Int)) →
  (K + Q ≥ (7 : Int)) →
  (K + P ≥ (9 : Int)) →
  (K + L ≥ (11 : Int)) →
  (K + J ≥ (8 : Int)) →
  (K + I ≥ (7 : Int)) →
  (K + B ≥ (10 : Int)) →
  (K + A ≥ (8 : Int)) →
  (K + O ≥ (10 : Int)) →
  (J + (-1 : Int) * S ≥ (1 : Int)) →
  (J + (-1 : Int) * A ≥ (0 : Int)) →
  (J + S ≥ (3 : Int)) →
  (J + Q ≥ (3 : Int)) →
  (J + P ≥ (5 : Int)) →
  (J + B ≥ (6 : Int)) →
  (J + A ≥ (4 : Int)) →
  (J + O ≥ (6 : Int)) →
  (I + S ≥ (2 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (4 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + B ≥ (5 : Int)) →
  (I + A ≥ (3 : Int)) →
  (I + O ≥ (5 : Int)) →
  (F + (-1 : Int) * S ≥ (4 : Int)) →
  (F + (-1 : Int) * Q ≥ (3 : Int)) →
  (F + (-1 : Int) * P ≥ (2 : Int)) →
  (F + (-1 : Int) * N ≥ (1 : Int)) →
  (F + (-1 : Int) * M ≥ (1 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (4 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (4 : Int)) →
  (F + (-1 : Int) * B ≥ (1 : Int)) →
  (F + (-1 : Int) * A ≥ (3 : Int)) →
  (F + (-1 : Int) * O ≥ (1 : Int)) →
  (F + S ≥ (6 : Int)) →
  (F + Q ≥ (6 : Int)) →
  (F + P ≥ (8 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (9 : Int)) →
  (F + L ≥ (10 : Int)) →
  (F + K ≥ (11 : Int)) →
  (F + J ≥ (7 : Int)) →
  (F + I ≥ (6 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (6 : Int)) →
  (F + B ≥ (9 : Int)) →
  (F + A ≥ (7 : Int)) →
  (F + O ≥ (9 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + S ≥ (2 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (4 : Int)) →
  (E + N ≥ (5 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (6 : Int)) →
  (E + K ≥ (7 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + F ≥ (6 : Int)) →
  (E + D ≥ (6 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (5 : Int)) →
  (E + A ≥ (3 : Int)) →
  (E + O ≥ (5 : Int)) →
  (D + (-1 : Int) * S ≥ (4 : Int)) →
  (D + (-1 : Int) * Q ≥ (3 : Int)) →
  (D + (-1 : Int) * P ≥ (2 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (1 : Int)) →
  (D + (-1 : Int) * K ≥ (-1 : Int)) →
  (D + (-1 : Int) * J ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (4 : Int)) →
  (D + (-1 : Int) * B ≥ (1 : Int)) →
  (D + (-1 : Int) * A ≥ (3 : Int)) →
  (D + (-1 : Int) * O ≥ (1 : Int)) →
  (D + S ≥ (6 : Int)) →
  (D + Q ≥ (6 : Int)) →
  (D + P ≥ (8 : Int)) →
  (D + N ≥ (9 : Int)) →
  (D + M ≥ (9 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (7 : Int)) →
  (D + I ≥ (6 : Int)) →
  (D + B ≥ (9 : Int)) →
  (D + A ≥ (7 : Int)) →
  (D + O ≥ (9 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + S ≥ (2 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (4 : Int)) →
  (C + N ≥ (5 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (6 : Int)) →
  (C + K ≥ (7 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + D ≥ (6 : Int)) →
  (C + B ≥ (5 : Int)) →
  (C + A ≥ (3 : Int)) →
  (C + O ≥ (5 : Int)) →
  (B + (-1 : Int) * Q ≥ (2 : Int)) →
  (B + (-1 : Int) * P ≥ (1 : Int)) →
  (B + (-1 : Int) * O ≥ (0 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (7 : Int)) →
  (B + O ≥ (8 : Int)) →
  (A + Q ≥ (3 : Int)) →
  (A + P ≥ (5 : Int)) →
  (A + B ≥ (6 : Int)) →
  (A + O ≥ (6 : Int)) →
  (S ≥ (1 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (3 : Int)) →
  (N ≥ (4 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (5 : Int)) →
  (K ≥ (6 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (F ≥ (5 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (5 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (4 : Int)) →
  (A ≥ (2 : Int)) →
  (O ≥ (4 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * S + P ≥ (2 : Int)) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * S + (-1 : Int) * B ≥ (-5 : Int)) →
  ((-1 : Int) * S + (-1 : Int) * A ≥ (-3 : Int)) →
  ((-1 : Int) * S + (-1 : Int) * O ≥ (-4 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + B ≥ (3 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  ((-1 : Int) * S + O ≥ (2 : Int)) →
  ((-1 : Int) * Q + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * Q + (-1 : Int) * O ≥ (-4 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + (-1 : Int) * O ≥ (-5 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (1 : Int)) →
  ((-1 : Int) * N + K ≥ (2 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * S ≥ (-5 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * Q ≥ (-5 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * P ≥ (-6 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * J ≥ (-6 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * I ≥ (-5 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * B ≥ (-8 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * A ≥ (-6 : Int)) →
  ((-1 : Int) * M + (-1 : Int) * O ≥ (-7 : Int)) →
  ((-1 : Int) * M + S ≥ (-3 : Int)) →
  ((-1 : Int) * M + Q ≥ (-3 : Int)) →
  ((-1 : Int) * M + P ≥ (-2 : Int)) →
  ((-1 : Int) * M + N ≥ (0 : Int)) →
  ((-1 : Int) * M + L ≥ (1 : Int)) →
  ((-1 : Int) * M + K ≥ (2 : Int)) →
  ((-1 : Int) * M + J ≥ (-2 : Int)) →
  ((-1 : Int) * M + I ≥ (-3 : Int)) →
  ((-1 : Int) * M + B ≥ (0 : Int)) →
  ((-1 : Int) * M + A ≥ (-2 : Int)) →
  ((-1 : Int) * M + O ≥ (-1 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * S ≥ (-3 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * Q ≥ (-3 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * P ≥ (-4 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * B ≥ (-6 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * A ≥ (-4 : Int)) →
  ((-1 : Int) * J + (-1 : Int) * O ≥ (-5 : Int)) →
  ((-1 : Int) * J + S ≥ (-1 : Int)) →
  ((-1 : Int) * J + Q ≥ (-1 : Int)) →
  ((-1 : Int) * J + P ≥ (0 : Int)) →
  ((-1 : Int) * J + B ≥ (2 : Int)) →
  ((-1 : Int) * J + A ≥ (0 : Int)) →
  ((-1 : Int) * J + O ≥ (1 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * Q ≥ (-2 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * J ≥ (-3 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * B ≥ (-5 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * A ≥ (-3 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * O ≥ (-4 : Int)) →
  ((-1 : Int) * I + S ≥ (0 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + B ≥ (3 : Int)) →
  ((-1 : Int) * I + A ≥ (1 : Int)) →
  ((-1 : Int) * I + O ≥ (2 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * Q ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * M ≥ (-5 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * J ≥ (-3 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * B ≥ (-5 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * A ≥ (-3 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * O ≥ (-4 : Int)) →
  ((-1 : Int) * E + S ≥ (0 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (1 : Int)) →
  ((-1 : Int) * E + N ≥ (3 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (4 : Int)) →
  ((-1 : Int) * E + K ≥ (5 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (4 : Int)) →
  ((-1 : Int) * E + D ≥ (4 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (3 : Int)) →
  ((-1 : Int) * E + A ≥ (1 : Int)) →
  ((-1 : Int) * E + O ≥ (2 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + L ≥ (0 : Int)) →
  ((-1 : Int) * D + K ≥ (1 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * Q ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * M ≥ (-5 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * J ≥ (-3 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * B ≥ (-5 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * A ≥ (-3 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * O ≥ (-4 : Int)) →
  ((-1 : Int) * C + S ≥ (0 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + N ≥ (3 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (4 : Int)) →
  ((-1 : Int) * C + K ≥ (5 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + D ≥ (4 : Int)) →
  ((-1 : Int) * C + B ≥ (3 : Int)) →
  ((-1 : Int) * C + A ≥ (1 : Int)) →
  ((-1 : Int) * C + O ≥ (2 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * Q ≥ (-5 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * P ≥ (-6 : Int)) →
  ((-1 : Int) * B + (-1 : Int) * O ≥ (-7 : Int)) →
  ((-1 : Int) * B + Q ≥ (-3 : Int)) →
  ((-1 : Int) * B + P ≥ (-2 : Int)) →
  ((-1 : Int) * B + O ≥ (-1 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * Q ≥ (-3 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * P ≥ (-4 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * B ≥ (-6 : Int)) →
  ((-1 : Int) * A + (-1 : Int) * O ≥ (-5 : Int)) →
  ((-1 : Int) * A + Q ≥ (-1 : Int)) →
  ((-1 : Int) * A + P ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (2 : Int)) →
  ((-1 : Int) * A + O ≥ (1 : Int)) →
  (S + (-1 : Int) * Q ≥ (0 : Int)) →
  (S + (-1 : Int) * P ≥ (-1 : Int)) →
  (S + (-1 : Int) * B ≥ (-3 : Int)) →
  (S + (-1 : Int) * A ≥ (-1 : Int)) →
  (S + (-1 : Int) * O ≥ (-2 : Int)) →
  (S + Q ≥ (2 : Int)) →
  (S + P ≥ (3 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (3 : Int)) →
  (S + O ≥ (4 : Int)) →
  (Q + (-1 : Int) * P ≥ (-1 : Int)) →
  (Q + (-1 : Int) * O ≥ (-2 : Int)) →
  (Q + P ≥ (3 : Int)) →
  (Q + O ≥ (4 : Int)) →
  (P + (-1 : Int) * O ≥ (-1 : Int)) →
  (P + O ≥ (5 : Int)) →
  (N + (-1 : Int) * S ≥ (3 : Int)) →
  (N + (-1 : Int) * Q ≥ (3 : Int)) →
  (N + (-1 : Int) * P ≥ (2 : Int)) →
  (N + (-1 : Int) * K ≥ (-2 : Int)) →
  (N + (-1 : Int) * J ≥ (2 : Int)) →
  (N + (-1 : Int) * I ≥ (3 : Int)) →
  (N + (-1 : Int) * B ≥ (0 : Int)) →
  (N + (-1 : Int) * A ≥ (2 : Int)) →
  (N + (-1 : Int) * O ≥ (1 : Int)) →
  (N + S ≥ (5 : Int)) →
  (N + Q ≥ (5 : Int)) →
  (N + P ≥ (6 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (6 : Int)) →
  (N + I ≥ (5 : Int)) →
  (N + B ≥ (8 : Int)) →
  (N + A ≥ (6 : Int)) →
  (N + O ≥ (7 : Int)) →
  (M + (-1 : Int) * S ≥ (3 : Int)) →
  (M + (-1 : Int) * Q ≥ (3 : Int)) →
  (M + (-1 : Int) * P ≥ (2 : Int)) →
  (M + (-1 : Int) * J ≥ (2 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * B ≥ (0 : Int)) →
  (M + (-1 : Int) * A ≥ (2 : Int)) →
  (M + (-1 : Int) * O ≥ (1 : Int)) →
  (M + S ≥ (5 : Int)) →
  (M + Q ≥ (5 : Int)) →
  (M + P ≥ (6 : Int)) →
  (M + N ≥ (8 : Int)) →
  (M + L ≥ (9 : Int)) →
  (M + K ≥ (10 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + B ≥ (8 : Int)) →
  (M + A ≥ (6 : Int)) →
  (M + O ≥ (7 : Int)) →
  (L + (-1 : Int) * S ≥ (4 : Int)) →
  (L + (-1 : Int) * Q ≥ (4 : Int)) →
  (L + (-1 : Int) * P ≥ (3 : Int)) →
  (L + (-1 : Int) * J ≥ (3 : Int)) →
  (L + (-1 : Int) * I ≥ (4 : Int)) →
  (L + (-1 : Int) * B ≥ (1 : Int)) →
  (L + (-1 : Int) * A ≥ (3 : Int)) →
  (L + (-1 : Int) * O ≥ (2 : Int)) →
  (L + S ≥ (6 : Int)) →
  (L + Q ≥ (6 : Int)) →
  (L + P ≥ (7 : Int)) →
  (L + J ≥ (7 : Int)) →
  (L + I ≥ (6 : Int)) →
  (L + B ≥ (9 : Int)) →
  (L + A ≥ (7 : Int)) →
  (L + O ≥ (8 : Int)) →
  (K + (-1 : Int) * S ≥ (5 : Int)) →
  (K + (-1 : Int) * Q ≥ (5 : Int)) →
  (K + (-1 : Int) * P ≥ (4 : Int)) →
  (K + (-1 : Int) * J ≥ (4 : Int)) →
  (K + (-1 : Int) * I ≥ (5 : Int)) →
  (K + (-1 : Int) * B ≥ (2 : Int)) →
  (K + (-1 : Int) * A ≥ (4 : Int)) →
  (K + (-1 : Int) * O ≥ (3 : Int)) →
  (K + S ≥ (7 : Int)) →
  (K + Q ≥ (7 : Int)) →
  (K + P ≥ (8 : Int)) →
  (K + L ≥ (11 : Int)) →
  (K + J ≥ (8 : Int)) →
  (K + I ≥ (7 : Int)) →
  (K + B ≥ (10 : Int)) →
  (K + A ≥ (8 : Int)) →
  (K + O ≥ (9 : Int)) →
  (J + (-1 : Int) * S ≥ (1 : Int)) →
  (J + (-1 : Int) * Q ≥ (1 : Int)) →
  (J + (-1 : Int) * P ≥ (0 : Int)) →
  (J + (-1 : Int) * B ≥ (-2 : Int)) →
  (J + (-1 : Int) * A ≥ (0 : Int)) →
  (J + (-1 : Int) * O ≥ (-1 : Int)) →
  (J + S ≥ (3 : Int)) →
  (J + Q ≥ (3 : Int)) →
  (J + P ≥ (4 : Int)) →
  (J + B ≥ (6 : Int)) →
  (J + A ≥ (4 : Int)) →
  (J + O ≥ (5 : Int)) →
  (I + (-1 : Int) * S ≥ (0 : Int)) →
  (I + (-1 : Int) * Q ≥ (0 : Int)) →
  (I + (-1 : Int) * P ≥ (-1 : Int)) →
  (I + (-1 : Int) * J ≥ (-1 : Int)) →
  (I + (-1 : Int) * B ≥ (-3 : Int)) →
  (I + (-1 : Int) * A ≥ (-1 : Int)) →
  (I + (-1 : Int) * O ≥ (-2 : Int)) →
  (I + S ≥ (2 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (3 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + B ≥ (5 : Int)) →
  (I + A ≥ (3 : Int)) →
  (I + O ≥ (4 : Int)) →
  (F + (-1 : Int) * S ≥ (4 : Int)) →
  (F + (-1 : Int) * Q ≥ (4 : Int)) →
  (F + (-1 : Int) * P ≥ (3 : Int)) →
  (F + (-1 : Int) * N ≥ (1 : Int)) →
  (F + (-1 : Int) * M ≥ (1 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (4 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (4 : Int)) →
  (F + (-1 : Int) * B ≥ (1 : Int)) →
  (F + (-1 : Int) * A ≥ (3 : Int)) →
  (F + (-1 : Int) * O ≥ (2 : Int)) →
  (F + S ≥ (6 : Int)) →
  (F + Q ≥ (6 : Int)) →
  (F + P ≥ (7 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (9 : Int)) →
  (F + L ≥ (10 : Int)) →
  (F + K ≥ (11 : Int)) →
  (F + J ≥ (7 : Int)) →
  (F + I ≥ (6 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (6 : Int)) →
  (F + B ≥ (9 : Int)) →
  (F + A ≥ (7 : Int)) →
  (F + O ≥ (8 : Int)) →
  (E + (-1 : Int) * S ≥ (0 : Int)) →
  (E + (-1 : Int) * Q ≥ (0 : Int)) →
  (E + (-1 : Int) * P ≥ (-1 : Int)) →
  (E + (-1 : Int) * M ≥ (-3 : Int)) →
  (E + (-1 : Int) * J ≥ (-1 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + (-1 : Int) * B ≥ (-3 : Int)) →
  (E + (-1 : Int) * A ≥ (-1 : Int)) →
  (E + (-1 : Int) * O ≥ (-2 : Int)) →
  (E + S ≥ (2 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + N ≥ (5 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (6 : Int)) →
  (E + K ≥ (7 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + F ≥ (6 : Int)) →
  (E + D ≥ (6 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (5 : Int)) →
  (E + A ≥ (3 : Int)) →
  (E + O ≥ (4 : Int)) →
  (D + (-1 : Int) * S ≥ (4 : Int)) →
  (D + (-1 : Int) * Q ≥ (4 : Int)) →
  (D + (-1 : Int) * P ≥ (3 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (1 : Int)) →
  (D + (-1 : Int) * K ≥ (-1 : Int)) →
  (D + (-1 : Int) * J ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (4 : Int)) →
  (D + (-1 : Int) * B ≥ (1 : Int)) →
  (D + (-1 : Int) * A ≥ (3 : Int)) →
  (D + (-1 : Int) * O ≥ (2 : Int)) →
  (D + S ≥ (6 : Int)) →
  (D + Q ≥ (6 : Int)) →
  (D + P ≥ (7 : Int)) →
  (D + N ≥ (9 : Int)) →
  (D + M ≥ (9 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (7 : Int)) →
  (D + I ≥ (6 : Int)) →
  (D + B ≥ (9 : Int)) →
  (D + A ≥ (7 : Int)) →
  (D + O ≥ (8 : Int)) →
  (C + (-1 : Int) * S ≥ (0 : Int)) →
  (C + (-1 : Int) * Q ≥ (0 : Int)) →
  (C + (-1 : Int) * P ≥ (-1 : Int)) →
  (C + (-1 : Int) * M ≥ (-3 : Int)) →
  (C + (-1 : Int) * J ≥ (-1 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + (-1 : Int) * B ≥ (-3 : Int)) →
  (C + (-1 : Int) * A ≥ (-1 : Int)) →
  (C + (-1 : Int) * O ≥ (-2 : Int)) →
  (C + S ≥ (2 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + N ≥ (5 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (6 : Int)) →
  (C + K ≥ (7 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + D ≥ (6 : Int)) →
  (C + B ≥ (5 : Int)) →
  (C + A ≥ (3 : Int)) →
  (C + O ≥ (4 : Int)) →
  (B + (-1 : Int) * Q ≥ (3 : Int)) →
  (B + (-1 : Int) * P ≥ (2 : Int)) →
  (B + (-1 : Int) * O ≥ (1 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (6 : Int)) →
  (B + O ≥ (7 : Int)) →
  (A + (-1 : Int) * Q ≥ (1 : Int)) →
  (A + (-1 : Int) * P ≥ (0 : Int)) →
  (A + (-1 : Int) * B ≥ (-2 : Int)) →
  (A + (-1 : Int) * O ≥ (-1 : Int)) →
  (A + Q ≥ (3 : Int)) →
  (A + P ≥ (4 : Int)) →
  (A + B ≥ (6 : Int)) →
  (A + O ≥ (5 : Int)) →
  (S ≥ (1 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (2 : Int)) →
  (N ≥ (4 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (5 : Int)) →
  (K ≥ (6 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (F ≥ (5 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (5 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (4 : Int)) →
  (A ≥ (2 : Int)) →
  (O ≥ (3 : Int)) →
  (S ≤ (1 : Int)) →
  (Q ≤ (1 : Int)) →
  (P ≤ (2 : Int)) →
  (M ≤ (4 : Int)) →
  (J ≤ (2 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  (B ≤ (4 : Int)) →
  (A ≤ (2 : Int)) →
  (O ≤ (3 : Int)) →
  ((-1 : Int) * S + (-1 : Int) * Q ≥ (-2 : Int)) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (1 : Int)) →
  ((-1 : Int) * N + K ≥ (2 : Int)) →
  ((-1 : Int) * M + N ≥ (0 : Int)) →
  ((-1 : Int) * M + L ≥ (1 : Int)) →
  ((-1 : Int) * M + K ≥ (2 : Int)) →
  ((-1 : Int) * M + B ≥ (0 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * J + S ≥ (-1 : Int)) →
  ((-1 : Int) * J + B ≥ (2 : Int)) →
  ((-1 : Int) * J + A ≥ (0 : Int)) →
  ((-1 : Int) * I + S ≥ (0 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + B ≥ (3 : Int)) →
  ((-1 : Int) * I + A ≥ (1 : Int)) →
  ((-1 : Int) * I + O ≥ (2 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + S ≥ (0 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (1 : Int)) →
  ((-1 : Int) * E + N ≥ (3 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (4 : Int)) →
  ((-1 : Int) * E + K ≥ (5 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (4 : Int)) →
  ((-1 : Int) * E + D ≥ (4 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (3 : Int)) →
  ((-1 : Int) * E + A ≥ (1 : Int)) →
  ((-1 : Int) * E + O ≥ (2 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + L ≥ (0 : Int)) →
  ((-1 : Int) * D + K ≥ (1 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + S ≥ (0 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + N ≥ (3 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (4 : Int)) →
  ((-1 : Int) * C + K ≥ (5 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + D ≥ (4 : Int)) →
  ((-1 : Int) * C + B ≥ (3 : Int)) →
  ((-1 : Int) * C + A ≥ (1 : Int)) →
  ((-1 : Int) * C + O ≥ (2 : Int)) →
  ((-1 : Int) * A + B ≥ (2 : Int)) →
  (S + (-1 : Int) * A ≥ (-1 : Int)) →
  (S + Q ≥ (2 : Int)) →
  (S + P ≥ (3 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (3 : Int)) →
  (S + O ≥ (4 : Int)) →
  (Q + P ≥ (3 : Int)) →
  (Q + O ≥ (4 : Int)) →
  (P + O ≥ (5 : Int)) →
  (N + (-1 : Int) * S ≥ (3 : Int)) →
  (N + (-1 : Int) * Q ≥ (3 : Int)) →
  (N + (-1 : Int) * P ≥ (2 : Int)) →
  (N + (-1 : Int) * K ≥ (-2 : Int)) →
  (N + (-1 : Int) * J ≥ (2 : Int)) →
  (N + (-1 : Int) * I ≥ (3 : Int)) →
  (N + (-1 : Int) * B ≥ (0 : Int)) →
  (N + (-1 : Int) * A ≥ (2 : Int)) →
  (N + (-1 : Int) * O ≥ (1 : Int)) →
  (N + S ≥ (5 : Int)) →
  (N + Q ≥ (5 : Int)) →
  (N + P ≥ (6 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (6 : Int)) →
  (N + I ≥ (5 : Int)) →
  (N + B ≥ (8 : Int)) →
  (N + A ≥ (6 : Int)) →
  (N + O ≥ (7 : Int)) →
  (M + (-1 : Int) * S ≥ (3 : Int)) →
  (M + (-1 : Int) * Q ≥ (3 : Int)) →
  (M + (-1 : Int) * P ≥ (2 : Int)) →
  (M + (-1 : Int) * J ≥ (2 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * B ≥ (0 : Int)) →
  (M + (-1 : Int) * A ≥ (2 : Int)) →
  (M + (-1 : Int) * O ≥ (1 : Int)) →
  (M + S ≥ (5 : Int)) →
  (M + Q ≥ (5 : Int)) →
  (M + P ≥ (6 : Int)) →
  (M + N ≥ (8 : Int)) →
  (M + L ≥ (9 : Int)) →
  (M + K ≥ (10 : Int)) →
  (M + J ≥ (6 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + B ≥ (8 : Int)) →
  (M + A ≥ (6 : Int)) →
  (M + O ≥ (7 : Int)) →
  (L + (-1 : Int) * S ≥ (4 : Int)) →
  (L + (-1 : Int) * Q ≥ (4 : Int)) →
  (L + (-1 : Int) * P ≥ (3 : Int)) →
  (L + (-1 : Int) * J ≥ (3 : Int)) →
  (L + (-1 : Int) * I ≥ (4 : Int)) →
  (L + (-1 : Int) * B ≥ (1 : Int)) →
  (L + (-1 : Int) * A ≥ (3 : Int)) →
  (L + (-1 : Int) * O ≥ (2 : Int)) →
  (L + S ≥ (6 : Int)) →
  (L + Q ≥ (6 : Int)) →
  (L + P ≥ (7 : Int)) →
  (L + J ≥ (7 : Int)) →
  (L + I ≥ (6 : Int)) →
  (L + B ≥ (9 : Int)) →
  (L + A ≥ (7 : Int)) →
  (L + O ≥ (8 : Int)) →
  (K + (-1 : Int) * S ≥ (5 : Int)) →
  (K + (-1 : Int) * Q ≥ (5 : Int)) →
  (K + (-1 : Int) * P ≥ (4 : Int)) →
  (K + (-1 : Int) * J ≥ (4 : Int)) →
  (K + (-1 : Int) * I ≥ (5 : Int)) →
  (K + (-1 : Int) * B ≥ (2 : Int)) →
  (K + (-1 : Int) * A ≥ (4 : Int)) →
  (K + (-1 : Int) * O ≥ (3 : Int)) →
  (K + S ≥ (7 : Int)) →
  (K + Q ≥ (7 : Int)) →
  (K + P ≥ (8 : Int)) →
  (K + L ≥ (11 : Int)) →
  (K + J ≥ (8 : Int)) →
  (K + I ≥ (7 : Int)) →
  (K + B ≥ (10 : Int)) →
  (K + A ≥ (8 : Int)) →
  (K + O ≥ (9 : Int)) →
  (J + (-1 : Int) * S ≥ (1 : Int)) →
  (J + (-1 : Int) * A ≥ (0 : Int)) →
  (J + S ≥ (3 : Int)) →
  (J + Q ≥ (3 : Int)) →
  (J + P ≥ (4 : Int)) →
  (J + B ≥ (6 : Int)) →
  (J + A ≥ (4 : Int)) →
  (J + O ≥ (5 : Int)) →
  (I + S ≥ (2 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (3 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + B ≥ (5 : Int)) →
  (I + A ≥ (3 : Int)) →
  (I + O ≥ (4 : Int)) →
  (F + (-1 : Int) * S ≥ (4 : Int)) →
  (F + (-1 : Int) * Q ≥ (4 : Int)) →
  (F + (-1 : Int) * P ≥ (3 : Int)) →
  (F + (-1 : Int) * N ≥ (1 : Int)) →
  (F + (-1 : Int) * M ≥ (1 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (3 : Int)) →
  (F + (-1 : Int) * I ≥ (4 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (4 : Int)) →
  (F + (-1 : Int) * B ≥ (1 : Int)) →
  (F + (-1 : Int) * A ≥ (3 : Int)) →
  (F + (-1 : Int) * O ≥ (2 : Int)) →
  (F + S ≥ (6 : Int)) →
  (F + Q ≥ (6 : Int)) →
  (F + P ≥ (7 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (9 : Int)) →
  (F + L ≥ (10 : Int)) →
  (F + K ≥ (11 : Int)) →
  (F + J ≥ (7 : Int)) →
  (F + I ≥ (6 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (6 : Int)) →
  (F + B ≥ (9 : Int)) →
  (F + A ≥ (7 : Int)) →
  (F + O ≥ (8 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + S ≥ (2 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + N ≥ (5 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (6 : Int)) →
  (E + K ≥ (7 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + F ≥ (6 : Int)) →
  (E + D ≥ (6 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (5 : Int)) →
  (E + A ≥ (3 : Int)) →
  (E + O ≥ (4 : Int)) →
  (D + (-1 : Int) * S ≥ (4 : Int)) →
  (D + (-1 : Int) * Q ≥ (4 : Int)) →
  (D + (-1 : Int) * P ≥ (3 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (1 : Int)) →
  (D + (-1 : Int) * K ≥ (-1 : Int)) →
  (D + (-1 : Int) * J ≥ (3 : Int)) →
  (D + (-1 : Int) * I ≥ (4 : Int)) →
  (D + (-1 : Int) * B ≥ (1 : Int)) →
  (D + (-1 : Int) * A ≥ (3 : Int)) →
  (D + (-1 : Int) * O ≥ (2 : Int)) →
  (D + S ≥ (6 : Int)) →
  (D + Q ≥ (6 : Int)) →
  (D + P ≥ (7 : Int)) →
  (D + N ≥ (9 : Int)) →
  (D + M ≥ (9 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (7 : Int)) →
  (D + I ≥ (6 : Int)) →
  (D + B ≥ (9 : Int)) →
  (D + A ≥ (7 : Int)) →
  (D + O ≥ (8 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + S ≥ (2 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + N ≥ (5 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (6 : Int)) →
  (C + K ≥ (7 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + D ≥ (6 : Int)) →
  (C + B ≥ (5 : Int)) →
  (C + A ≥ (3 : Int)) →
  (C + O ≥ (4 : Int)) →
  (B + (-1 : Int) * Q ≥ (3 : Int)) →
  (B + (-1 : Int) * P ≥ (2 : Int)) →
  (B + (-1 : Int) * O ≥ (1 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (6 : Int)) →
  (B + O ≥ (7 : Int)) →
  (A + Q ≥ (3 : Int)) →
  (A + P ≥ (4 : Int)) →
  (A + B ≥ (6 : Int)) →
  (A + O ≥ (5 : Int)) →
  (S ≥ (1 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (2 : Int)) →
  (N ≥ (4 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (5 : Int)) →
  (K ≥ (6 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (F ≥ (5 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (5 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (4 : Int)) →
  (A ≥ (2 : Int)) →
  (O ≥ (3 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * S + B ≥ (3 : Int)) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + B ≥ (3 : Int)) →
  ((-1 : Int) * S + A ≥ (2 : Int)) →
  ((-1 : Int) * S + O ≥ (2 : Int)) →
  ((-1 : Int) * Q + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (1 : Int)) →
  ((-1 : Int) * N + K ≥ (2 : Int)) →
  ((-1 : Int) * M + N ≥ (0 : Int)) →
  ((-1 : Int) * M + L ≥ (1 : Int)) →
  ((-1 : Int) * M + K ≥ (2 : Int)) →
  ((-1 : Int) * M + J ≥ (-1 : Int)) →
  ((-1 : Int) * M + B ≥ (0 : Int)) →
  ((-1 : Int) * M + A ≥ (-1 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * J + B ≥ (1 : Int)) →
  ((-1 : Int) * J + A ≥ (0 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * Q ≥ (-2 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * I + S ≥ (0 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (2 : Int)) →
  ((-1 : Int) * I + B ≥ (3 : Int)) →
  ((-1 : Int) * I + A ≥ (2 : Int)) →
  ((-1 : Int) * I + O ≥ (2 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * Q ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + S ≥ (0 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (1 : Int)) →
  ((-1 : Int) * E + N ≥ (3 : Int)) →
  ((-1 : Int) * E + M ≥ (3 : Int)) →
  ((-1 : Int) * E + L ≥ (4 : Int)) →
  ((-1 : Int) * E + K ≥ (5 : Int)) →
  ((-1 : Int) * E + J ≥ (2 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (4 : Int)) →
  ((-1 : Int) * E + D ≥ (4 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (3 : Int)) →
  ((-1 : Int) * E + A ≥ (2 : Int)) →
  ((-1 : Int) * E + O ≥ (2 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + L ≥ (0 : Int)) →
  ((-1 : Int) * D + K ≥ (1 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * Q ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * P ≥ (-3 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + S ≥ (0 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + N ≥ (3 : Int)) →
  ((-1 : Int) * C + M ≥ (3 : Int)) →
  ((-1 : Int) * C + L ≥ (4 : Int)) →
  ((-1 : Int) * C + K ≥ (5 : Int)) →
  ((-1 : Int) * C + J ≥ (2 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + D ≥ (4 : Int)) →
  ((-1 : Int) * C + B ≥ (3 : Int)) →
  ((-1 : Int) * C + A ≥ (2 : Int)) →
  ((-1 : Int) * C + O ≥ (2 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  (S + (-1 : Int) * Q ≥ (0 : Int)) →
  (S + (-1 : Int) * P ≥ (-1 : Int)) →
  (S + Q ≥ (2 : Int)) →
  (S + P ≥ (3 : Int)) →
  (S + B ≥ (5 : Int)) →
  (S + A ≥ (4 : Int)) →
  (S + O ≥ (4 : Int)) →
  (Q + (-1 : Int) * P ≥ (-1 : Int)) →
  (Q + P ≥ (3 : Int)) →
  (Q + O ≥ (4 : Int)) →
  (P + O ≥ (5 : Int)) →
  (N + (-1 : Int) * S ≥ (3 : Int)) →
  (N + (-1 : Int) * Q ≥ (3 : Int)) →
  (N + (-1 : Int) * P ≥ (2 : Int)) →
  (N + (-1 : Int) * K ≥ (-2 : Int)) →
  (N + (-1 : Int) * J ≥ (1 : Int)) →
  (N + (-1 : Int) * I ≥ (3 : Int)) →
  (N + (-1 : Int) * B ≥ (0 : Int)) →
  (N + (-1 : Int) * A ≥ (1 : Int)) →
  (N + (-1 : Int) * O ≥ (1 : Int)) →
  (N + S ≥ (5 : Int)) →
  (N + Q ≥ (5 : Int)) →
  (N + P ≥ (6 : Int)) →
  (N + L ≥ (9 : Int)) →
  (N + K ≥ (10 : Int)) →
  (N + J ≥ (7 : Int)) →
  (N + I ≥ (5 : Int)) →
  (N + B ≥ (8 : Int)) →
  (N + A ≥ (7 : Int)) →
  (N + O ≥ (7 : Int)) →
  (M + (-1 : Int) * S ≥ (3 : Int)) →
  (M + (-1 : Int) * Q ≥ (3 : Int)) →
  (M + (-1 : Int) * P ≥ (2 : Int)) →
  (M + (-1 : Int) * J ≥ (1 : Int)) →
  (M + (-1 : Int) * I ≥ (3 : Int)) →
  (M + (-1 : Int) * B ≥ (0 : Int)) →
  (M + (-1 : Int) * A ≥ (1 : Int)) →
  (M + (-1 : Int) * O ≥ (1 : Int)) →
  (M + S ≥ (5 : Int)) →
  (M + Q ≥ (5 : Int)) →
  (M + P ≥ (6 : Int)) →
  (M + N ≥ (8 : Int)) →
  (M + L ≥ (9 : Int)) →
  (M + K ≥ (10 : Int)) →
  (M + J ≥ (7 : Int)) →
  (M + I ≥ (5 : Int)) →
  (M + B ≥ (8 : Int)) →
  (M + A ≥ (7 : Int)) →
  (M + O ≥ (7 : Int)) →
  (L + (-1 : Int) * S ≥ (4 : Int)) →
  (L + (-1 : Int) * Q ≥ (4 : Int)) →
  (L + (-1 : Int) * P ≥ (3 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (4 : Int)) →
  (L + (-1 : Int) * B ≥ (1 : Int)) →
  (L + (-1 : Int) * A ≥ (2 : Int)) →
  (L + (-1 : Int) * O ≥ (2 : Int)) →
  (L + S ≥ (6 : Int)) →
  (L + Q ≥ (6 : Int)) →
  (L + P ≥ (7 : Int)) →
  (L + J ≥ (8 : Int)) →
  (L + I ≥ (6 : Int)) →
  (L + B ≥ (9 : Int)) →
  (L + A ≥ (8 : Int)) →
  (L + O ≥ (8 : Int)) →
  (K + (-1 : Int) * S ≥ (5 : Int)) →
  (K + (-1 : Int) * Q ≥ (5 : Int)) →
  (K + (-1 : Int) * P ≥ (4 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (5 : Int)) →
  (K + (-1 : Int) * B ≥ (2 : Int)) →
  (K + (-1 : Int) * A ≥ (3 : Int)) →
  (K + (-1 : Int) * O ≥ (3 : Int)) →
  (K + S ≥ (7 : Int)) →
  (K + Q ≥ (7 : Int)) →
  (K + P ≥ (8 : Int)) →
  (K + L ≥ (11 : Int)) →
  (K + J ≥ (9 : Int)) →
  (K + I ≥ (7 : Int)) →
  (K + B ≥ (10 : Int)) →
  (K + A ≥ (9 : Int)) →
  (K + O ≥ (9 : Int)) →
  (J + (-1 : Int) * S ≥ (2 : Int)) →
  (J + (-1 : Int) * Q ≥ (2 : Int)) →
  (J + (-1 : Int) * P ≥ (1 : Int)) →
  (J + (-1 : Int) * B ≥ (-1 : Int)) →
  (J + (-1 : Int) * A ≥ (0 : Int)) →
  (J + (-1 : Int) * O ≥ (0 : Int)) →
  (J + S ≥ (4 : Int)) →
  (J + Q ≥ (4 : Int)) →
  (J + P ≥ (5 : Int)) →
  (J + B ≥ (7 : Int)) →
  (J + A ≥ (6 : Int)) →
  (J + O ≥ (6 : Int)) →
  (I + (-1 : Int) * S ≥ (0 : Int)) →
  (I + (-1 : Int) * Q ≥ (0 : Int)) →
  (I + (-1 : Int) * P ≥ (-1 : Int)) →
  (I + S ≥ (2 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (3 : Int)) →
  (I + J ≥ (4 : Int)) →
  (I + B ≥ (5 : Int)) →
  (I + A ≥ (4 : Int)) →
  (I + O ≥ (4 : Int)) →
  (F + (-1 : Int) * S ≥ (4 : Int)) →
  (F + (-1 : Int) * Q ≥ (4 : Int)) →
  (F + (-1 : Int) * P ≥ (3 : Int)) →
  (F + (-1 : Int) * N ≥ (1 : Int)) →
  (F + (-1 : Int) * M ≥ (1 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (4 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (4 : Int)) →
  (F + (-1 : Int) * B ≥ (1 : Int)) →
  (F + (-1 : Int) * A ≥ (2 : Int)) →
  (F + (-1 : Int) * O ≥ (2 : Int)) →
  (F + S ≥ (6 : Int)) →
  (F + Q ≥ (6 : Int)) →
  (F + P ≥ (7 : Int)) →
  (F + N ≥ (9 : Int)) →
  (F + M ≥ (9 : Int)) →
  (F + L ≥ (10 : Int)) →
  (F + K ≥ (11 : Int)) →
  (F + J ≥ (8 : Int)) →
  (F + I ≥ (6 : Int)) →
  (F + D ≥ (10 : Int)) →
  (F + C ≥ (6 : Int)) →
  (F + B ≥ (9 : Int)) →
  (F + A ≥ (8 : Int)) →
  (F + O ≥ (8 : Int)) →
  (E + (-1 : Int) * S ≥ (0 : Int)) →
  (E + (-1 : Int) * Q ≥ (0 : Int)) →
  (E + (-1 : Int) * P ≥ (-1 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + S ≥ (2 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + N ≥ (5 : Int)) →
  (E + M ≥ (5 : Int)) →
  (E + L ≥ (6 : Int)) →
  (E + K ≥ (7 : Int)) →
  (E + J ≥ (4 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + F ≥ (6 : Int)) →
  (E + D ≥ (6 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (5 : Int)) →
  (E + A ≥ (4 : Int)) →
  (E + O ≥ (4 : Int)) →
  (D + (-1 : Int) * S ≥ (4 : Int)) →
  (D + (-1 : Int) * Q ≥ (4 : Int)) →
  (D + (-1 : Int) * P ≥ (3 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (1 : Int)) →
  (D + (-1 : Int) * K ≥ (-1 : Int)) →
  (D + (-1 : Int) * J ≥ (2 : Int)) →
  (D + (-1 : Int) * I ≥ (4 : Int)) →
  (D + (-1 : Int) * B ≥ (1 : Int)) →
  (D + (-1 : Int) * A ≥ (2 : Int)) →
  (D + (-1 : Int) * O ≥ (2 : Int)) →
  (D + S ≥ (6 : Int)) →
  (D + Q ≥ (6 : Int)) →
  (D + P ≥ (7 : Int)) →
  (D + N ≥ (9 : Int)) →
  (D + M ≥ (9 : Int)) →
  (D + L ≥ (10 : Int)) →
  (D + K ≥ (11 : Int)) →
  (D + J ≥ (8 : Int)) →
  (D + I ≥ (6 : Int)) →
  (D + B ≥ (9 : Int)) →
  (D + A ≥ (8 : Int)) →
  (D + O ≥ (8 : Int)) →
  (C + (-1 : Int) * S ≥ (0 : Int)) →
  (C + (-1 : Int) * Q ≥ (0 : Int)) →
  (C + (-1 : Int) * P ≥ (-1 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + S ≥ (2 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + N ≥ (5 : Int)) →
  (C + M ≥ (5 : Int)) →
  (C + L ≥ (6 : Int)) →
  (C + K ≥ (7 : Int)) →
  (C + J ≥ (4 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + D ≥ (6 : Int)) →
  (C + B ≥ (5 : Int)) →
  (C + A ≥ (4 : Int)) →
  (C + O ≥ (4 : Int)) →
  (B + (-1 : Int) * Q ≥ (3 : Int)) →
  (B + (-1 : Int) * P ≥ (2 : Int)) →
  (B + (-1 : Int) * O ≥ (1 : Int)) →
  (B + Q ≥ (5 : Int)) →
  (B + P ≥ (6 : Int)) →
  (B + O ≥ (7 : Int)) →
  (A + (-1 : Int) * Q ≥ (2 : Int)) →
  (A + (-1 : Int) * P ≥ (1 : Int)) →
  (A + (-1 : Int) * B ≥ (-1 : Int)) →
  (A + (-1 : Int) * O ≥ (0 : Int)) →
  (A + Q ≥ (4 : Int)) →
  (A + P ≥ (5 : Int)) →
  (A + B ≥ (7 : Int)) →
  (A + O ≥ (6 : Int)) →
  (S ≥ (1 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (2 : Int)) →
  (N ≥ (4 : Int)) →
  (M ≥ (4 : Int)) →
  (L ≥ (5 : Int)) →
  (K ≥ (6 : Int)) →
  (J ≥ (3 : Int)) →
  (I ≥ (1 : Int)) →
  (F ≥ (5 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (5 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (4 : Int)) →
  (A ≥ (3 : Int)) →
  (O ≥ (3 : Int)) →
  (S ≤ (1 : Int)) →
  (Q ≤ (1 : Int)) →
  (P ≤ (2 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * S + (-1 : Int) * Q ≥ (-2 : Int)) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + B ≥ (4 : Int)) →
  ((-1 : Int) * S + A ≥ (3 : Int)) →
  ((-1 : Int) * S + O ≥ (2 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (1 : Int)) →
  ((-1 : Int) * N + K ≥ (2 : Int)) →
  ((-1 : Int) * M + N ≥ (0 : Int)) →
  ((-1 : Int) * M + L ≥ (1 : Int)) →
  ((-1 : Int) * M + K ≥ (2 : Int)) →
  ((-1 : Int) * M + J ≥ (-1 : Int)) →
  ((-1 : Int) * M + B ≥ (0 : Int)) →
  ((-1 : Int) * M + A ≥ (-1 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * J + B ≥ (1 : Int)) →
  ((-1 : Int) * J + A ≥ (0 : Int)) →
  ((-1 : Int) * I + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * I + S ≥ (0 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (3 : Int)) →
  ((-1 : Int) * I + B ≥ (4 : Int)) →
  ((-1 : Int) * I + A ≥ (3 : Int)) →
  ((-1 : Int) * I + O ≥ (2 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + S ≥ (0 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (1 : Int)) →
  ((-1 : Int) * E + N ≥ (4 : Int)) →
  ((-1 : Int) * E + M ≥ (4 : Int)) →
  ((-1 : Int) * E + L ≥ (5 : Int)) →
  ((-1 : Int) * E + K ≥ (6 : Int)) →
  ((-1 : Int) * E + J ≥ (3 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (5 : Int)) →
  ((-1 : Int) * E + D ≥ (5 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (4 : Int)) →
  ((-1 : Int) * E + A ≥ (3 : Int)) →
  ((-1 : Int) * E + O ≥ (2 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + L ≥ (0 : Int)) →
  ((-1 : Int) * D + K ≥ (1 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * S ≥ (-2 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + S ≥ (0 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + N ≥ (4 : Int)) →
  ((-1 : Int) * C + M ≥ (4 : Int)) →
  ((-1 : Int) * C + L ≥ (5 : Int)) →
  ((-1 : Int) * C + K ≥ (6 : Int)) →
  ((-1 : Int) * C + J ≥ (3 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + D ≥ (5 : Int)) →
  ((-1 : Int) * C + B ≥ (4 : Int)) →
  ((-1 : Int) * C + A ≥ (3 : Int)) →
  ((-1 : Int) * C + O ≥ (2 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  (S + Q ≥ (2 : Int)) →
  (S + P ≥ (3 : Int)) →
  (S + B ≥ (6 : Int)) →
  (S + A ≥ (5 : Int)) →
  (S + O ≥ (4 : Int)) →
  (Q + P ≥ (3 : Int)) →
  (Q + O ≥ (4 : Int)) →
  (P + O ≥ (5 : Int)) →
  (N + (-1 : Int) * S ≥ (4 : Int)) →
  (N + (-1 : Int) * Q ≥ (3 : Int)) →
  (N + (-1 : Int) * P ≥ (2 : Int)) →
  (N + (-1 : Int) * K ≥ (-2 : Int)) →
  (N + (-1 : Int) * J ≥ (1 : Int)) →
  (N + (-1 : Int) * I ≥ (4 : Int)) →
  (N + (-1 : Int) * B ≥ (0 : Int)) →
  (N + (-1 : Int) * A ≥ (1 : Int)) →
  (N + (-1 : Int) * O ≥ (1 : Int)) →
  (N + S ≥ (6 : Int)) →
  (N + Q ≥ (6 : Int)) →
  (N + P ≥ (7 : Int)) →
  (N + L ≥ (11 : Int)) →
  (N + K ≥ (12 : Int)) →
  (N + J ≥ (9 : Int)) →
  (N + I ≥ (6 : Int)) →
  (N + B ≥ (10 : Int)) →
  (N + A ≥ (9 : Int)) →
  (N + O ≥ (8 : Int)) →
  (M + (-1 : Int) * S ≥ (4 : Int)) →
  (M + (-1 : Int) * Q ≥ (3 : Int)) →
  (M + (-1 : Int) * P ≥ (2 : Int)) →
  (M + (-1 : Int) * J ≥ (1 : Int)) →
  (M + (-1 : Int) * I ≥ (4 : Int)) →
  (M + (-1 : Int) * B ≥ (0 : Int)) →
  (M + (-1 : Int) * A ≥ (1 : Int)) →
  (M + (-1 : Int) * O ≥ (1 : Int)) →
  (M + S ≥ (6 : Int)) →
  (M + Q ≥ (6 : Int)) →
  (M + P ≥ (7 : Int)) →
  (M + N ≥ (10 : Int)) →
  (M + L ≥ (11 : Int)) →
  (M + K ≥ (12 : Int)) →
  (M + J ≥ (9 : Int)) →
  (M + I ≥ (6 : Int)) →
  (M + B ≥ (10 : Int)) →
  (M + A ≥ (9 : Int)) →
  (M + O ≥ (8 : Int)) →
  (L + (-1 : Int) * S ≥ (5 : Int)) →
  (L + (-1 : Int) * Q ≥ (4 : Int)) →
  (L + (-1 : Int) * P ≥ (3 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (5 : Int)) →
  (L + (-1 : Int) * B ≥ (1 : Int)) →
  (L + (-1 : Int) * A ≥ (2 : Int)) →
  (L + (-1 : Int) * O ≥ (2 : Int)) →
  (L + S ≥ (7 : Int)) →
  (L + Q ≥ (7 : Int)) →
  (L + P ≥ (8 : Int)) →
  (L + J ≥ (10 : Int)) →
  (L + I ≥ (7 : Int)) →
  (L + B ≥ (11 : Int)) →
  (L + A ≥ (10 : Int)) →
  (L + O ≥ (9 : Int)) →
  (K + (-1 : Int) * S ≥ (6 : Int)) →
  (K + (-1 : Int) * Q ≥ (5 : Int)) →
  (K + (-1 : Int) * P ≥ (4 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (6 : Int)) →
  (K + (-1 : Int) * B ≥ (2 : Int)) →
  (K + (-1 : Int) * A ≥ (3 : Int)) →
  (K + (-1 : Int) * O ≥ (3 : Int)) →
  (K + S ≥ (8 : Int)) →
  (K + Q ≥ (8 : Int)) →
  (K + P ≥ (9 : Int)) →
  (K + L ≥ (13 : Int)) →
  (K + J ≥ (11 : Int)) →
  (K + I ≥ (8 : Int)) →
  (K + B ≥ (12 : Int)) →
  (K + A ≥ (11 : Int)) →
  (K + O ≥ (10 : Int)) →
  (J + (-1 : Int) * S ≥ (3 : Int)) →
  (J + (-1 : Int) * Q ≥ (2 : Int)) →
  (J + (-1 : Int) * P ≥ (1 : Int)) →
  (J + (-1 : Int) * B ≥ (-1 : Int)) →
  (J + (-1 : Int) * A ≥ (0 : Int)) →
  (J + (-1 : Int) * O ≥ (0 : Int)) →
  (J + S ≥ (5 : Int)) →
  (J + Q ≥ (5 : Int)) →
  (J + P ≥ (6 : Int)) →
  (J + B ≥ (9 : Int)) →
  (J + A ≥ (8 : Int)) →
  (J + O ≥ (7 : Int)) →
  (I + (-1 : Int) * S ≥ (0 : Int)) →
  (I + S ≥ (2 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (3 : Int)) →
  (I + J ≥ (5 : Int)) →
  (I + B ≥ (6 : Int)) →
  (I + A ≥ (5 : Int)) →
  (I + O ≥ (4 : Int)) →
  (F + (-1 : Int) * S ≥ (5 : Int)) →
  (F + (-1 : Int) * Q ≥ (4 : Int)) →
  (F + (-1 : Int) * P ≥ (3 : Int)) →
  (F + (-1 : Int) * N ≥ (1 : Int)) →
  (F + (-1 : Int) * M ≥ (1 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (5 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (5 : Int)) →
  (F + (-1 : Int) * B ≥ (1 : Int)) →
  (F + (-1 : Int) * A ≥ (2 : Int)) →
  (F + (-1 : Int) * O ≥ (2 : Int)) →
  (F + S ≥ (7 : Int)) →
  (F + Q ≥ (7 : Int)) →
  (F + P ≥ (8 : Int)) →
  (F + N ≥ (11 : Int)) →
  (F + M ≥ (11 : Int)) →
  (F + L ≥ (12 : Int)) →
  (F + K ≥ (13 : Int)) →
  (F + J ≥ (10 : Int)) →
  (F + I ≥ (7 : Int)) →
  (F + D ≥ (12 : Int)) →
  (F + C ≥ (7 : Int)) →
  (F + B ≥ (11 : Int)) →
  (F + A ≥ (10 : Int)) →
  (F + O ≥ (9 : Int)) →
  (E + (-1 : Int) * S ≥ (0 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + S ≥ (2 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + N ≥ (6 : Int)) →
  (E + M ≥ (6 : Int)) →
  (E + L ≥ (7 : Int)) →
  (E + K ≥ (8 : Int)) →
  (E + J ≥ (5 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + F ≥ (7 : Int)) →
  (E + D ≥ (7 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (6 : Int)) →
  (E + A ≥ (5 : Int)) →
  (E + O ≥ (4 : Int)) →
  (D + (-1 : Int) * S ≥ (5 : Int)) →
  (D + (-1 : Int) * Q ≥ (4 : Int)) →
  (D + (-1 : Int) * P ≥ (3 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (1 : Int)) →
  (D + (-1 : Int) * K ≥ (-1 : Int)) →
  (D + (-1 : Int) * J ≥ (2 : Int)) →
  (D + (-1 : Int) * I ≥ (5 : Int)) →
  (D + (-1 : Int) * B ≥ (1 : Int)) →
  (D + (-1 : Int) * A ≥ (2 : Int)) →
  (D + (-1 : Int) * O ≥ (2 : Int)) →
  (D + S ≥ (7 : Int)) →
  (D + Q ≥ (7 : Int)) →
  (D + P ≥ (8 : Int)) →
  (D + N ≥ (11 : Int)) →
  (D + M ≥ (11 : Int)) →
  (D + L ≥ (12 : Int)) →
  (D + K ≥ (13 : Int)) →
  (D + J ≥ (10 : Int)) →
  (D + I ≥ (7 : Int)) →
  (D + B ≥ (11 : Int)) →
  (D + A ≥ (10 : Int)) →
  (D + O ≥ (9 : Int)) →
  (C + (-1 : Int) * S ≥ (0 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + S ≥ (2 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + N ≥ (6 : Int)) →
  (C + M ≥ (6 : Int)) →
  (C + L ≥ (7 : Int)) →
  (C + K ≥ (8 : Int)) →
  (C + J ≥ (5 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + D ≥ (7 : Int)) →
  (C + B ≥ (6 : Int)) →
  (C + A ≥ (5 : Int)) →
  (C + O ≥ (4 : Int)) →
  (B + (-1 : Int) * Q ≥ (3 : Int)) →
  (B + (-1 : Int) * P ≥ (2 : Int)) →
  (B + (-1 : Int) * O ≥ (1 : Int)) →
  (B + Q ≥ (6 : Int)) →
  (B + P ≥ (7 : Int)) →
  (B + O ≥ (8 : Int)) →
  (A + (-1 : Int) * Q ≥ (2 : Int)) →
  (A + (-1 : Int) * P ≥ (1 : Int)) →
  (A + (-1 : Int) * B ≥ (-1 : Int)) →
  (A + (-1 : Int) * O ≥ (0 : Int)) →
  (A + Q ≥ (5 : Int)) →
  (A + P ≥ (6 : Int)) →
  (A + B ≥ (9 : Int)) →
  (A + O ≥ (7 : Int)) →
  (S ≥ (1 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (2 : Int)) →
  (N ≥ (5 : Int)) →
  (M ≥ (5 : Int)) →
  (L ≥ (6 : Int)) →
  (K ≥ (7 : Int)) →
  (J ≥ (4 : Int)) →
  (I ≥ (1 : Int)) →
  (F ≥ (6 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (6 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (5 : Int)) →
  (A ≥ (4 : Int)) →
  (O ≥ (3 : Int)) →
  (S ≤ (1 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  r0 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  ((-1 : Int) * S + P ≥ (1 : Int)) →
  ((-1 : Int) * S + B ≥ (2 : Int)) →
  ((-1 : Int) * S + A ≥ (1 : Int)) →
  ((-1 : Int) * S + O ≥ (2 : Int)) →
  ((-1 : Int) * Q + P ≥ (1 : Int)) →
  ((-1 : Int) * Q + O ≥ (2 : Int)) →
  ((-1 : Int) * P + O ≥ (1 : Int)) →
  ((-1 : Int) * N + L ≥ (1 : Int)) →
  ((-1 : Int) * N + K ≥ (2 : Int)) →
  ((-1 : Int) * M + N ≥ (0 : Int)) →
  ((-1 : Int) * M + L ≥ (1 : Int)) →
  ((-1 : Int) * M + K ≥ (2 : Int)) →
  ((-1 : Int) * M + B ≥ (0 : Int)) →
  ((-1 : Int) * M + O ≥ (0 : Int)) →
  ((-1 : Int) * K + L ≥ (-1 : Int)) →
  ((-1 : Int) * J + P ≥ (0 : Int)) →
  ((-1 : Int) * J + B ≥ (1 : Int)) →
  ((-1 : Int) * J + A ≥ (0 : Int)) →
  ((-1 : Int) * J + O ≥ (1 : Int)) →
  ((-1 : Int) * I + S ≥ (0 : Int)) →
  ((-1 : Int) * I + Q ≥ (0 : Int)) →
  ((-1 : Int) * I + P ≥ (1 : Int)) →
  ((-1 : Int) * I + J ≥ (1 : Int)) →
  ((-1 : Int) * I + B ≥ (2 : Int)) →
  ((-1 : Int) * I + A ≥ (1 : Int)) →
  ((-1 : Int) * I + O ≥ (2 : Int)) →
  ((-1 : Int) * F + L ≥ (0 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * E + (-1 : Int) * C ≥ (-2 : Int)) →
  ((-1 : Int) * E + S ≥ (0 : Int)) →
  ((-1 : Int) * E + Q ≥ (0 : Int)) →
  ((-1 : Int) * E + P ≥ (1 : Int)) →
  ((-1 : Int) * E + N ≥ (2 : Int)) →
  ((-1 : Int) * E + M ≥ (2 : Int)) →
  ((-1 : Int) * E + L ≥ (3 : Int)) →
  ((-1 : Int) * E + K ≥ (4 : Int)) →
  ((-1 : Int) * E + J ≥ (1 : Int)) →
  ((-1 : Int) * E + I ≥ (0 : Int)) →
  ((-1 : Int) * E + F ≥ (3 : Int)) →
  ((-1 : Int) * E + D ≥ (3 : Int)) →
  ((-1 : Int) * E + C ≥ (0 : Int)) →
  ((-1 : Int) * E + B ≥ (2 : Int)) →
  ((-1 : Int) * E + A ≥ (1 : Int)) →
  ((-1 : Int) * E + O ≥ (2 : Int)) →
  ((-1 : Int) * D + N ≥ (-1 : Int)) →
  ((-1 : Int) * D + L ≥ (0 : Int)) →
  ((-1 : Int) * D + K ≥ (1 : Int)) →
  ((-1 : Int) * C + (-1 : Int) * I ≥ (-2 : Int)) →
  ((-1 : Int) * C + S ≥ (0 : Int)) →
  ((-1 : Int) * C + Q ≥ (0 : Int)) →
  ((-1 : Int) * C + P ≥ (1 : Int)) →
  ((-1 : Int) * C + N ≥ (2 : Int)) →
  ((-1 : Int) * C + M ≥ (2 : Int)) →
  ((-1 : Int) * C + L ≥ (3 : Int)) →
  ((-1 : Int) * C + K ≥ (4 : Int)) →
  ((-1 : Int) * C + J ≥ (1 : Int)) →
  ((-1 : Int) * C + I ≥ (0 : Int)) →
  ((-1 : Int) * C + D ≥ (3 : Int)) →
  ((-1 : Int) * C + B ≥ (2 : Int)) →
  ((-1 : Int) * C + A ≥ (1 : Int)) →
  ((-1 : Int) * C + O ≥ (2 : Int)) →
  ((-1 : Int) * B + O ≥ (0 : Int)) →
  ((-1 : Int) * A + P ≥ (0 : Int)) →
  ((-1 : Int) * A + B ≥ (1 : Int)) →
  ((-1 : Int) * A + O ≥ (1 : Int)) →
  (S + (-1 : Int) * Q ≥ (0 : Int)) →
  (S + Q ≥ (2 : Int)) →
  (S + P ≥ (3 : Int)) →
  (S + B ≥ (4 : Int)) →
  (S + A ≥ (3 : Int)) →
  (S + O ≥ (4 : Int)) →
  (Q + P ≥ (3 : Int)) →
  (Q + O ≥ (4 : Int)) →
  (P + O ≥ (5 : Int)) →
  (N + (-1 : Int) * S ≥ (2 : Int)) →
  (N + (-1 : Int) * Q ≥ (2 : Int)) →
  (N + (-1 : Int) * P ≥ (1 : Int)) →
  (N + (-1 : Int) * K ≥ (-2 : Int)) →
  (N + (-1 : Int) * J ≥ (1 : Int)) →
  (N + (-1 : Int) * I ≥ (2 : Int)) →
  (N + (-1 : Int) * B ≥ (0 : Int)) →
  (N + (-1 : Int) * A ≥ (1 : Int)) →
  (N + (-1 : Int) * O ≥ (0 : Int)) →
  (N + S ≥ (4 : Int)) →
  (N + Q ≥ (4 : Int)) →
  (N + P ≥ (5 : Int)) →
  (N + L ≥ (7 : Int)) →
  (N + K ≥ (8 : Int)) →
  (N + J ≥ (5 : Int)) →
  (N + I ≥ (4 : Int)) →
  (N + B ≥ (6 : Int)) →
  (N + A ≥ (5 : Int)) →
  (N + O ≥ (6 : Int)) →
  (M + (-1 : Int) * S ≥ (2 : Int)) →
  (M + (-1 : Int) * Q ≥ (2 : Int)) →
  (M + (-1 : Int) * P ≥ (1 : Int)) →
  (M + (-1 : Int) * J ≥ (1 : Int)) →
  (M + (-1 : Int) * I ≥ (2 : Int)) →
  (M + (-1 : Int) * B ≥ (0 : Int)) →
  (M + (-1 : Int) * A ≥ (1 : Int)) →
  (M + (-1 : Int) * O ≥ (0 : Int)) →
  (M + S ≥ (4 : Int)) →
  (M + Q ≥ (4 : Int)) →
  (M + P ≥ (5 : Int)) →
  (M + N ≥ (6 : Int)) →
  (M + L ≥ (7 : Int)) →
  (M + K ≥ (8 : Int)) →
  (M + J ≥ (5 : Int)) →
  (M + I ≥ (4 : Int)) →
  (M + B ≥ (6 : Int)) →
  (M + A ≥ (5 : Int)) →
  (M + O ≥ (6 : Int)) →
  (L + (-1 : Int) * S ≥ (3 : Int)) →
  (L + (-1 : Int) * Q ≥ (3 : Int)) →
  (L + (-1 : Int) * P ≥ (2 : Int)) →
  (L + (-1 : Int) * J ≥ (2 : Int)) →
  (L + (-1 : Int) * I ≥ (3 : Int)) →
  (L + (-1 : Int) * B ≥ (1 : Int)) →
  (L + (-1 : Int) * A ≥ (2 : Int)) →
  (L + (-1 : Int) * O ≥ (1 : Int)) →
  (L + S ≥ (5 : Int)) →
  (L + Q ≥ (5 : Int)) →
  (L + P ≥ (6 : Int)) →
  (L + J ≥ (6 : Int)) →
  (L + I ≥ (5 : Int)) →
  (L + B ≥ (7 : Int)) →
  (L + A ≥ (6 : Int)) →
  (L + O ≥ (7 : Int)) →
  (K + (-1 : Int) * S ≥ (4 : Int)) →
  (K + (-1 : Int) * Q ≥ (4 : Int)) →
  (K + (-1 : Int) * P ≥ (3 : Int)) →
  (K + (-1 : Int) * J ≥ (3 : Int)) →
  (K + (-1 : Int) * I ≥ (4 : Int)) →
  (K + (-1 : Int) * B ≥ (2 : Int)) →
  (K + (-1 : Int) * A ≥ (3 : Int)) →
  (K + (-1 : Int) * O ≥ (2 : Int)) →
  (K + S ≥ (6 : Int)) →
  (K + Q ≥ (6 : Int)) →
  (K + P ≥ (7 : Int)) →
  (K + L ≥ (9 : Int)) →
  (K + J ≥ (7 : Int)) →
  (K + I ≥ (6 : Int)) →
  (K + B ≥ (8 : Int)) →
  (K + A ≥ (7 : Int)) →
  (K + O ≥ (8 : Int)) →
  (J + (-1 : Int) * S ≥ (1 : Int)) →
  (J + (-1 : Int) * Q ≥ (1 : Int)) →
  (J + (-1 : Int) * P ≥ (0 : Int)) →
  (J + (-1 : Int) * A ≥ (0 : Int)) →
  (J + S ≥ (3 : Int)) →
  (J + Q ≥ (3 : Int)) →
  (J + P ≥ (4 : Int)) →
  (J + B ≥ (5 : Int)) →
  (J + A ≥ (4 : Int)) →
  (J + O ≥ (5 : Int)) →
  (I + S ≥ (2 : Int)) →
  (I + Q ≥ (2 : Int)) →
  (I + P ≥ (3 : Int)) →
  (I + J ≥ (3 : Int)) →
  (I + B ≥ (4 : Int)) →
  (I + A ≥ (3 : Int)) →
  (I + O ≥ (4 : Int)) →
  (F + (-1 : Int) * S ≥ (3 : Int)) →
  (F + (-1 : Int) * Q ≥ (3 : Int)) →
  (F + (-1 : Int) * P ≥ (2 : Int)) →
  (F + (-1 : Int) * N ≥ (1 : Int)) →
  (F + (-1 : Int) * M ≥ (1 : Int)) →
  (F + (-1 : Int) * L ≥ (0 : Int)) →
  (F + (-1 : Int) * K ≥ (-1 : Int)) →
  (F + (-1 : Int) * J ≥ (2 : Int)) →
  (F + (-1 : Int) * I ≥ (3 : Int)) →
  (F + (-1 : Int) * D ≥ (0 : Int)) →
  (F + (-1 : Int) * C ≥ (3 : Int)) →
  (F + (-1 : Int) * B ≥ (1 : Int)) →
  (F + (-1 : Int) * A ≥ (2 : Int)) →
  (F + (-1 : Int) * O ≥ (1 : Int)) →
  (F + S ≥ (5 : Int)) →
  (F + Q ≥ (5 : Int)) →
  (F + P ≥ (6 : Int)) →
  (F + N ≥ (7 : Int)) →
  (F + M ≥ (7 : Int)) →
  (F + L ≥ (8 : Int)) →
  (F + K ≥ (9 : Int)) →
  (F + J ≥ (6 : Int)) →
  (F + I ≥ (5 : Int)) →
  (F + D ≥ (8 : Int)) →
  (F + C ≥ (5 : Int)) →
  (F + B ≥ (7 : Int)) →
  (F + A ≥ (6 : Int)) →
  (F + O ≥ (7 : Int)) →
  (E + (-1 : Int) * I ≥ (0 : Int)) →
  (E + (-1 : Int) * C ≥ (0 : Int)) →
  (E + S ≥ (2 : Int)) →
  (E + Q ≥ (2 : Int)) →
  (E + P ≥ (3 : Int)) →
  (E + N ≥ (4 : Int)) →
  (E + M ≥ (4 : Int)) →
  (E + L ≥ (5 : Int)) →
  (E + K ≥ (6 : Int)) →
  (E + J ≥ (3 : Int)) →
  (E + I ≥ (2 : Int)) →
  (E + F ≥ (5 : Int)) →
  (E + D ≥ (5 : Int)) →
  (E + C ≥ (2 : Int)) →
  (E + B ≥ (4 : Int)) →
  (E + A ≥ (3 : Int)) →
  (E + O ≥ (4 : Int)) →
  (D + (-1 : Int) * S ≥ (3 : Int)) →
  (D + (-1 : Int) * Q ≥ (3 : Int)) →
  (D + (-1 : Int) * P ≥ (2 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (D + (-1 : Int) * M ≥ (1 : Int)) →
  (D + (-1 : Int) * K ≥ (-1 : Int)) →
  (D + (-1 : Int) * J ≥ (2 : Int)) →
  (D + (-1 : Int) * I ≥ (3 : Int)) →
  (D + (-1 : Int) * B ≥ (1 : Int)) →
  (D + (-1 : Int) * A ≥ (2 : Int)) →
  (D + (-1 : Int) * O ≥ (1 : Int)) →
  (D + S ≥ (5 : Int)) →
  (D + Q ≥ (5 : Int)) →
  (D + P ≥ (6 : Int)) →
  (D + N ≥ (7 : Int)) →
  (D + M ≥ (7 : Int)) →
  (D + L ≥ (8 : Int)) →
  (D + K ≥ (9 : Int)) →
  (D + J ≥ (6 : Int)) →
  (D + I ≥ (5 : Int)) →
  (D + B ≥ (7 : Int)) →
  (D + A ≥ (6 : Int)) →
  (D + O ≥ (7 : Int)) →
  (C + (-1 : Int) * I ≥ (0 : Int)) →
  (C + S ≥ (2 : Int)) →
  (C + Q ≥ (2 : Int)) →
  (C + P ≥ (3 : Int)) →
  (C + N ≥ (4 : Int)) →
  (C + M ≥ (4 : Int)) →
  (C + L ≥ (5 : Int)) →
  (C + K ≥ (6 : Int)) →
  (C + J ≥ (3 : Int)) →
  (C + I ≥ (2 : Int)) →
  (C + D ≥ (5 : Int)) →
  (C + B ≥ (4 : Int)) →
  (C + A ≥ (3 : Int)) →
  (C + O ≥ (4 : Int)) →
  (B + (-1 : Int) * Q ≥ (2 : Int)) →
  (B + (-1 : Int) * P ≥ (1 : Int)) →
  (B + (-1 : Int) * O ≥ (0 : Int)) →
  (B + Q ≥ (4 : Int)) →
  (B + P ≥ (5 : Int)) →
  (B + O ≥ (6 : Int)) →
  (A + (-1 : Int) * Q ≥ (1 : Int)) →
  (A + (-1 : Int) * P ≥ (0 : Int)) →
  (A + Q ≥ (3 : Int)) →
  (A + P ≥ (4 : Int)) →
  (A + B ≥ (5 : Int)) →
  (A + O ≥ (5 : Int)) →
  (S ≥ (1 : Int)) →
  (Q ≥ (1 : Int)) →
  (P ≥ (2 : Int)) →
  (N ≥ (3 : Int)) →
  (M ≥ (3 : Int)) →
  (L ≥ (4 : Int)) →
  (K ≥ (5 : Int)) →
  (J ≥ (2 : Int)) →
  (I ≥ (1 : Int)) →
  (F ≥ (4 : Int)) →
  (E ≥ (1 : Int)) →
  (D ≥ (4 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≥ (3 : Int)) →
  (A ≥ (2 : Int)) →
  (O ≥ (3 : Int)) →
  (I ≤ (1 : Int)) →
  (E ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  ((-1 : Int) * S + Q ≥ (0 : Int)) →
  r3 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r0 S A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 S A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r1 S A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 P A B C D E F G H I J K L M N R Q S O) →
  (True) →
  r0 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r3 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r0 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r3 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r0 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r3 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r0 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r3 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r0 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r3 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r0 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r3 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r0 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r3 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r0 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r3 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r0 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 P A B C D E F G H I J K L M N R Q S O) →
  (True) →
  r3 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r3 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r3 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r3 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r3 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r3 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r3 P A B C D E F G H I J K L M N S R Q O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r3 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r3 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r3 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r3 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r3 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r3 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r3 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r3 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r3 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r3 Q A B C D E F G H I J K L M N P S R O) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r3 Q A B C D E F G H I J K L M N P R S O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r3 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N P R S O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N P R S O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r3 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N P R S O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r3 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N P R S O) →
  (r1 Q A B C D E F G H I J K L M N T S R O) →
  (r3 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T v_20 v_21 v_22 : Int),
  (r1 Q A B C D E F G H I J K L M N P S v_20 O) →
  (r1 Q A B C D E F G H I J K L M N P R S O) →
  (r3 Q A B C D E F G H I J K L M N T S R O) →
  (r1 Q A B C D E F G H I J K L M N v_21 S R O) →
  (r1 Q A B C D E F G H I J K L M N v_22 T S O) →
  (r1 Q A B C D E F G H I J K L M N P T S O) →
  (v_20 = Q) →
  (v_21 = Q) →
  (v_22 = Q) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r3 P A B C D E F G H I J K L M N S Q R O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r3 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N S Q R O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N S Q R O) →
  (r1 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r3 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 : Int),
  (r1 P A B C D E F G H I J K L M N v_19 Q S O) →
  (r1 P A B C D E F G H I J K L M N S Q R O) →
  (r3 P A B C D E F G H I J K L M N v_20 R Q O) →
  (r1 P A B C D E F G H I J K L M N v_21 S R O) →
  (v_19 = P) →
  (v_20 = P) →
  (v_21 = P) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r1 P A B C D E F G H I J K L M N S R Q O) →
  (r3 P A B C D E F G H I J K L M N S Q R O) →
  (True) →
  r2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 P A B C D E F G H I J K L M N S R Q O) →
  (r1 P A B C D E F G H I J K L M N S Q R O) →
  (True) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  False))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«Consistency».«fortune-full.13_000»
