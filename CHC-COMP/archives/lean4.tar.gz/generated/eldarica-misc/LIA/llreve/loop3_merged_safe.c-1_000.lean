import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«loop3_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":155:1-155:12 (check-sat, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":11:1-20:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":21:1-31:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":32:1-42:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":43:1-53:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":54:1-64:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":65:1-76:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":77:1-88:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":89:1-99:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":100:1-110:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":111:1-121:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":122:1-132:2 (clause 11, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":133:1-143:2 (clause 12, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop3_merged_safe.c-1_000.smt2":144:1-153:2 (clause 13, command 20)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Prop),
  (∀ (A v_1 v_2 v_3 v_4 : Int),
  (True) →
  ((1 : Int) = v_1) →
  ((0 : Int) = v_2) →
  ((1 : Int) = v_3) →
  ((2 : Int) = v_4) →
  r2 A v_1 v_2 v_3 v_4) ∧
  ((∀ (A B C D E v_5 : Int),
  (r2 B E A C D) →
  (B ≤ (0 : Int)) →
  ((1 : Int) = v_5) →
  r1 v_5 E A C D) ∧
  ((∀ (A B C D E : Int),
  (r2 B E A C D) →
  (¬B ≤ (0 : Int)) →
  r1 B E A C D) ∧
  ((∀ (A B C D E F : Int),
  (r1 C F B D E) →
  ((0 : Int) ≤ C + (-1 : Int) * F) →
  (A = (2 : Int) + B) →
  r3 C F A D E) ∧
  ((∀ (A B C D E F : Int),
  (r3 C F B D E) →
  (A = (1 : Int) + F) →
  r1 C A B D E) ∧
  ((∀ (A B C D E : Int),
  let a!1 := ¬(1 : Int) ≤ B + (-1 : Int) * C;
  let a!2 := ¬(0 : Int) ≤ B + (-1 : Int) * E;
  r1 B E A C D → ¬(1 : Int) ≤ B + (-1 : Int) * C → ¬(0 : Int) ≤ B + (-1 : Int) * E → r0 B E A C D) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ¬(0 : Int) ≤ D + (-1 : Int) * G;
  r1 D G C E F →
    B = (1 : Int) + E →
      ¬(0 : Int) ≤ D + (-1 : Int) * G → (1 : Int) ≤ D + (-1 : Int) * E → A = (2 : Int) + F → r5 D G C B A) ∧
  ((∀ (A B C D E : Int),
  (r5 B E A C D) →
  (¬(1 : Int) ≤ B + (-1 : Int) * C) →
  r0 B E A C D) ∧
  ((∀ (A B C D E F G : Int),
  (r5 D G C E F) →
  (B = (1 : Int) + E) →
  ((1 : Int) ≤ D + (-1 : Int) * E) →
  (A = (2 : Int) + F) →
  r5 D G C B A) ∧
  ((∀ (A B C D E : Int),
  (r3 B E A C D) →
  (¬A + (-2 : Int) * E = (0 : Int)) →
  r4) ∧
  ((∀ (A B C D E : Int),
  (r5 B E A C D) →
  (¬D + (-2 : Int) * C = (0 : Int)) →
  r4) ∧
  ((∀ (A B C D E : Int),
  (r0 B E A C D) →
  (¬A = D) →
  r4) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r4) →
  False))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«loop3_merged_safe.c-1_000»
