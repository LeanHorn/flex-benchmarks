import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«nested-while_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":222:1-222:12 (check-sat, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":13:1-22:2 (clause 1, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":23:1-33:2 (clause 2, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":34:1-44:2 (clause 3, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":45:1-55:2 (clause 4, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":56:1-66:2 (clause 5, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":67:1-78:2 (clause 6, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":79:1-90:2 (clause 7, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":91:1-101:2 (clause 8, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":102:1-112:2 (clause 9, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":113:1-124:2 (clause 10, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":125:1-136:2 (clause 11, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":137:1-147:2 (clause 12, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":148:1-164:2 (clause 13, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":165:1-175:2 (clause 14, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":176:1-187:2 (clause 15, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":188:1-199:2 (clause 16, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":200:1-210:2 (clause 17, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_merged_safe.c-1_000.smt2":211:1-220:2 (clause 18, command 27)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r0) ∧
  ((∀ (A B C D E F G H : Int),
  (r3 B E F C H G D A) →
  (True) →
  r1 B E F C H G D A) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 B E F C H G D A) →
  (True) →
  r7 B E F C H G D A) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r1 D G H E J I F C) →
  (B = (1 : Int) + G) →
  ((1 : Int) ≤ F + (-1 : Int) * G) →
  (A = (1 : Int) + J) →
  r1 D B H E A I F C) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r5 D G H E J I F C) →
  (B = (1 : Int) + H) →
  ((1 : Int) ≤ C + (-1 : Int) * H) →
  (A = (1 : Int) + I) →
  r5 D G B E J A F C) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬(1 : Int) ≤ E + (-1 : Int) * D;
  let a!2 := ¬(1 : Int) ≤ D + (-1 : Int) * E;
  r1 B E F C H G D A → ¬(1 : Int) ≤ E + (-1 : Int) * D → ¬(1 : Int) ≤ D + (-1 : Int) * E → r4 B E F C H G D A) ∧
  ((∀ (A B C D E F G H I J : Int),
  let a!1 := ¬(1 : Int) ≤ F + (-1 : Int) * G;
  r1 D G H E J I F C →
    B = (-1 : Int) + J →
      ¬(1 : Int) ≤ F + (-1 : Int) * G → (1 : Int) ≤ G + (-1 : Int) * F → A = (1 : Int) + F → r3 D G H E B I A C) ∧
  ((∀ (A B C D E F G H : Int),
  (r4 B E F C H G D A) →
  (¬(1 : Int) ≤ F + (-1 : Int) * A) →
  r2 B E F C H G D A) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r4 D G H E J I F C) →
  (B = (-1 : Int) + I) →
  ((1 : Int) ≤ H + (-1 : Int) * C) →
  (A = (1 : Int) + C) →
  r5 D G H E J B F A) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬(1 : Int) ≤ F + (-1 : Int) * A;
  let a!2 := ¬(1 : Int) ≤ A + (-1 : Int) * F;
  r5 B E F C H G D A → ¬(1 : Int) ≤ F + (-1 : Int) * A → ¬(1 : Int) ≤ A + (-1 : Int) * F → r2 B E F C H G D A) ∧
  ((∀ (A B C D E F G H I J : Int),
  let a!1 := ¬(1 : Int) ≤ C + (-1 : Int) * H;
  r5 D G H E J I F C →
    B = (-1 : Int) + I →
      ¬(1 : Int) ≤ C + (-1 : Int) * H → (1 : Int) ≤ H + (-1 : Int) * C → A = (1 : Int) + C → r5 D G H E J B F A) ∧
  ((∀ (A B v_2 v_3 v_4 v_5 v_6 v_7 : Int),
  (r0) →
  (¬(1 : Int) ≤ A) →
  (v_2 = A) →
  (v_3 = A) →
  (v_4 = B) →
  (v_5 = B) →
  ((0 : Int) = v_6) →
  ((0 : Int) = v_7) →
  r4 A v_2 v_3 B v_4 v_5 v_6 v_7) ∧
  ((∀ (A B C v_3 v_4 v_5 v_6 v_7 : Int),
  (r0) →
  ((1 : Int) ≤ C) →
  (A = (-1 : Int) + B) →
  (v_3 = C) →
  (v_4 = C) →
  (v_5 = B) →
  ((1 : Int) = v_6) →
  ((0 : Int) = v_7) →
  r3 C v_3 v_4 B A v_5 v_6 v_7) ∧
  ((∀ (A B C D E F G H : Int),
  (r3 B E F C H G D A) →
  (¬(0 : Int) ≤ E + (-1 : Int) * D) →
  r6) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬H = C + (-1 : Int) * B;
  r4 B E F C H G D A → ¬B ≤ (0 : Int) ∨ ¬H = C → ¬(1 : Int) ≤ B ∨ a!1 → r6) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬G = C + (-1 : Int) * B;
  r2 B E F C H G D A → ¬B ≤ (0 : Int) ∨ ¬G = C → ¬(1 : Int) ≤ B ∨ a!1 → r6) ∧
  ((∀ (A B C D E F G H : Int),
  (r7 B E F C H G D A) →
  (¬E = F) →
  r6) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r6) →
  False)))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«nested-while_merged_safe.c-1_000»
