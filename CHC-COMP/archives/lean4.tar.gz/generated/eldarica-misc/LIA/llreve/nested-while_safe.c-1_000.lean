import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«nested-while_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_safe.c-1_000.smt2":135:1-135:12 (check-sat, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_safe.c-1_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_safe.c-1_000.smt2":19:1-29:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_safe.c-1_000.smt2":30:1-41:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_safe.c-1_000.smt2":42:1-52:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_safe.c-1_000.smt2":53:1-64:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_safe.c-1_000.smt2":65:1-75:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_safe.c-1_000.smt2":76:1-87:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_safe.c-1_000.smt2":88:1-99:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_safe.c-1_000.smt2":100:1-111:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_safe.c-1_000.smt2":112:1-122:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/nested-while_safe.c-1_000.smt2":123:1-133:2 (clause 11, command 16)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Prop),
  (∀ (A B : Int),
  (True) →
  r3 A B) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 F D H E G C) →
  (B = (1 : Int) + E) →
  ((1 : Int) ≤ C + (-1 : Int) * E) →
  (A = (1 : Int) + G) →
  r1 F D H B A C) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬(1 : Int) ≤ C + (-1 : Int) * E;
  r1 F D H E G C →
    B = (-1 : Int) + G →
      ¬(1 : Int) ≤ C + (-1 : Int) * E → (1 : Int) ≤ E + (-1 : Int) * C → A = (1 : Int) + C → r1 F D H E B A) ∧
  ((∀ (A B C D E F G : Int),
  (r0 G E D C F) →
  (B = (1 : Int) + D) →
  ((1 : Int) ≤ F + (-1 : Int) * D) →
  (A = (1 : Int) + C) →
  r0 G E B A F) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ¬(1 : Int) ≤ F + (-1 : Int) * D;
  r0 G E D C F →
    B = (-1 : Int) + C →
      (1 : Int) ≤ D + (-1 : Int) * F → ¬(1 : Int) ≤ F + (-1 : Int) * D → A = (1 : Int) + F → r0 G E D B A) ∧
  ((∀ (A B C v_3 v_4 : Int),
  (r3 C B) →
  ((1 : Int) ≤ C) →
  (A = (-1 : Int) + B) →
  (v_3 = C) →
  ((1 : Int) = v_4) →
  r0 C B v_3 A v_4) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := ¬(1 : Int) ≤ C + (-1 : Int) * A;
  let a!2 := ¬(1 : Int) ≤ A + (-1 : Int) * C;
  r1 D B F C E A → ¬(1 : Int) ≤ C + (-1 : Int) * A → ¬(1 : Int) ≤ A + (-1 : Int) * C → r2 D B F E) ∧
  ((∀ (A B C D E F v_6 v_7 : Int),
  let a!1 := ¬(1 : Int) ≤ C + (-1 : Int) * E;
  let a!2 := ¬(1 : Int) ≤ E + (-1 : Int) * C;
  r0 F D C B E →
    ¬(1 : Int) ≤ C + (-1 : Int) * E →
      ¬(1 : Int) ≤ E + (-1 : Int) * C →
        (1 : Int) ≤ F → A = (-1 : Int) + D → v_6 = F → (1 : Int) = v_7 → r1 F D B v_6 A v_7) ∧
  ((∀ (A B C D E v_5 : Int),
  let a!1 := ¬(1 : Int) ≤ D + (-1 : Int) * B;
  let a!2 := ¬(1 : Int) ≤ B + (-1 : Int) * D;
  r0 E C B A D →
    ¬(1 : Int) ≤ D + (-1 : Int) * B → ¬(1 : Int) ≤ E → ¬(1 : Int) ≤ B + (-1 : Int) * D → v_5 = C → r2 E C A v_5) ∧
  ((∀ (A B v_2 v_3 : Int),
  (r3 B A) →
  (¬(1 : Int) ≤ B) →
  (v_2 = A) →
  (v_3 = A) →
  r2 B A v_2 v_3) ∧
  (∀ (A B C D : Int),
  (r2 C B D A) →
  (¬D = A) →
  False))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«nested-while_safe.c-1_000»
