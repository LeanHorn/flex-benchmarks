import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«fib_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/fib_merged_safe.c-1_000.smt2":56:1-56:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/fib_merged_safe.c-1_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/fib_merged_safe.c-1_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/fib_merged_safe.c-1_000.smt2":28:1-43:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/fib_merged_safe.c-1_000.smt2":44:1-54:2 (clause 4, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A v_1 v_2 v_3 v_4 v_5 v_6 : Int),
  (True) →
  ((0 : Int) = v_1) →
  ((1 : Int) = v_2) →
  ((1 : Int) = v_3) →
  ((1 : Int) = v_4) →
  ((0 : Int) = v_5) →
  ((0 : Int) = v_6) →
  r0 A v_1 v_2 v_3 v_4 v_5 v_6) ∧
  ((∀ (A B C D E F G : Int),
  (r1 F A G B E C D) →
  (True) →
  r0 F A G B E C D) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 K F L G J H I) →
  (B = F + G) →
  (C = L + J) →
  (D = F + G) →
  (E = (-1 : Int) + K) →
  ((1 : Int) ≤ K) →
  (A = L + J) →
  r1 E G J D C B A) ∧
  (∀ (A B C D E F G : Int),
  (r1 F A G B E C D) →
  (¬D = C + A) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«fib_merged_safe.c-1_000»
