import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«loop_unswitching_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":212:1-212:12 (check-sat, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":14:1-23:2 (clause 1, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":24:1-34:2 (clause 2, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":35:1-45:2 (clause 3, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":46:1-56:2 (clause 4, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":57:1-67:2 (clause 5, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":68:1-78:2 (clause 6, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":79:1-89:2 (clause 7, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":90:1-100:2 (clause 8, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":101:1-111:2 (clause 9, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":112:1-122:2 (clause 10, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":123:1-133:2 (clause 11, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":134:1-144:2 (clause 12, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":145:1-155:2 (clause 13, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":156:1-166:2 (clause 14, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":167:1-177:2 (clause 15, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":178:1-189:2 (clause 16, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":190:1-200:2 (clause 17, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_unswitching_merged_safe.c-1_000.smt2":201:1-210:2 (clause 18, command 28)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Prop),
  (∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r0) ∧
  ((∀ (A B C D E F : Int),
  (r8 F A B D C E) →
  (¬(1 : Int) ≤ B) →
  r6 F A B D C E) ∧
  ((∀ (A B C D E F : Int),
  (r6 F A B D C E) →
  (True) →
  r1 F A B D C E) ∧
  ((∀ (A B C D E F : Int),
  (r3 F A B D C E) →
  (¬(1 : Int) ≤ B) →
  r2 F A B D C E) ∧
  ((∀ (A B C D E F : Int),
  (r2 F A B D C E) →
  (True) →
  r1 F A B D C E) ∧
  ((∀ (A B C D E F : Int),
  (r1 F A B D C E) →
  (¬(1 : Int) ≤ D) →
  r4 F A B D C E) ∧
  ((∀ (A B C D E F : Int),
  (r4 F A B D C E) →
  (True) →
  r5 F A B D C E) ∧
  ((∀ (A B C D E F G H : Int),
  (r8 H C D F E G) →
  (B = (-1 : Int) + D) →
  ((1 : Int) ≤ D) →
  (A = (1 : Int) + E) →
  r8 H C B F A G) ∧
  ((∀ (A B C D E F G H : Int),
  (r3 H C D F E G) →
  (B = (-1 : Int) + D) →
  ((1 : Int) ≤ D) →
  (A = (-1 : Int) + E) →
  r3 H C B F A G) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 H C D F E G) →
  (B = (-1 : Int) + F) →
  ((1 : Int) ≤ F) →
  ((1 : Int) ≤ H) →
  (A = (1 : Int) + G) →
  r1 H C D B E A) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 H C D F E G) →
  (B = (-1 : Int) + F) →
  ((1 : Int) ≤ F) →
  (¬(1 : Int) ≤ H) →
  (A = (-1 : Int) + G) →
  r1 H C D B E A) ∧
  ((∀ (A B v_2 v_3 v_4 v_5 : Int),
  (r0) →
  ((1 : Int) ≤ B) →
  (v_2 = A) →
  (v_3 = A) →
  ((0 : Int) = v_4) →
  ((0 : Int) = v_5) →
  r8 B A v_2 v_3 v_4 v_5) ∧
  ((∀ (A B v_2 v_3 v_4 v_5 : Int),
  (r0) →
  (¬(1 : Int) ≤ B) →
  (v_2 = A) →
  (v_3 = A) →
  ((0 : Int) = v_4) →
  ((0 : Int) = v_5) →
  r3 B A v_2 v_3 v_4 v_5) ∧
  ((∀ (A B C D E F : Int),
  (r6 F A B D C E) →
  (¬A ≤ (0 : Int)) →
  (¬C = A) →
  r7) ∧
  ((∀ (A B C D E F : Int),
  (r2 F A B D C E) →
  (¬A ≤ (0 : Int)) →
  (¬C + A = (0 : Int)) →
  r7) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := ¬(1 : Int) ≤ A ∨ ¬F ≤ (0 : Int) ∨ ¬E + A = (0 : Int);
  r4 F A B D C E →
    ¬(1 : Int) ≤ F ∨ ¬(1 : Int) ≤ A ∨ ¬E = A → ¬(1 : Int) ≤ A ∨ ¬F ≤ (0 : Int) ∨ ¬E + A = (0 : Int) → ¬A ≤ (0 : Int) → r7) ∧
  ((∀ (A B C D E F : Int),
  (r5 F A B D C E) →
  (¬C = E) →
  r7) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r7) →
  False)))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«loop_unswitching_merged_safe.c-1_000»
