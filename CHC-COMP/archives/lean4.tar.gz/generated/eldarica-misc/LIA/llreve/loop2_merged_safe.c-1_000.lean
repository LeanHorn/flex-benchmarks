import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«loop2_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop2_merged_safe.c-1_000.smt2":132:1-132:12 (check-sat, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop2_merged_safe.c-1_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop2_merged_safe.c-1_000.smt2":20:1-30:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop2_merged_safe.c-1_000.smt2":31:1-41:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop2_merged_safe.c-1_000.smt2":42:1-53:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop2_merged_safe.c-1_000.smt2":54:1-65:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop2_merged_safe.c-1_000.smt2":66:1-76:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop2_merged_safe.c-1_000.smt2":77:1-87:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop2_merged_safe.c-1_000.smt2":88:1-98:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop2_merged_safe.c-1_000.smt2":99:1-109:2 (clause 9, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop2_merged_safe.c-1_000.smt2":110:1-120:2 (clause 10, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop2_merged_safe.c-1_000.smt2":121:1-130:2 (clause 11, command 17)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Prop),
  (∀ (A v_1 v_2 v_3 v_4 : Int),
  (True) →
  ((1 : Int) = v_1) →
  ((0 : Int) = v_2) →
  ((0 : Int) = v_3) →
  ((0 : Int) = v_4) →
  r2 A v_1 v_2 v_3 v_4) ∧
  ((∀ (A B C D E F : Int),
  (r2 E B D F C) →
  ((0 : Int) ≤ E + (-1 : Int) * B) →
  (A = (2 : Int) + D) →
  r1 E B A F C) ∧
  ((∀ (A B C D E F : Int),
  (r1 E B D F C) →
  (A = (1 : Int) + B) →
  r2 E A D F C) ∧
  ((∀ (A B C D E : Int),
  let a!1 := ¬(1 : Int) ≤ D + (-1 : Int) * E;
  let a!2 := ¬(0 : Int) ≤ D + (-1 : Int) * A;
  r2 D A C E B → ¬(1 : Int) ≤ D + (-1 : Int) * E → ¬(0 : Int) ≤ D + (-1 : Int) * A → r4 D A C E B) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ¬(0 : Int) ≤ F + (-1 : Int) * C;
  r2 F C E G D →
    B = (1 : Int) + G →
      ¬(0 : Int) ≤ F + (-1 : Int) * C → (1 : Int) ≤ F + (-1 : Int) * G → A = (2 : Int) + D → r0 F C E B A) ∧
  ((∀ (A B C D E : Int),
  (r0 D A C E B) →
  (¬(1 : Int) ≤ D + (-1 : Int) * E) →
  r4 D A C E B) ∧
  ((∀ (A B C D E F G : Int),
  (r0 F C E G D) →
  (B = (1 : Int) + G) →
  ((1 : Int) ≤ F + (-1 : Int) * G) →
  (A = (2 : Int) + D) →
  r0 F C E B A) ∧
  ((∀ (A B C D E : Int),
  (r1 D A C E B) →
  (¬C + (-2 : Int) * A = (0 : Int)) →
  r3) ∧
  ((∀ (A B C D E : Int),
  (r0 D A C E B) →
  (¬B + (-2 : Int) * E = (0 : Int)) →
  r3) ∧
  ((∀ (A B C D E : Int),
  (r4 D A C E B) →
  (¬C = B) →
  r3) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r3) →
  False))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«loop2_merged_safe.c-1_000»
