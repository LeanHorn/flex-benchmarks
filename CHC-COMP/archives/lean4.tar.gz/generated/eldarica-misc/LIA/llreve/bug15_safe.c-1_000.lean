import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«bug15_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/bug15_safe.c-1_000.smt2":86:1-86:12 (check-sat, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/bug15_safe.c-1_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/bug15_safe.c-1_000.smt2":19:1-29:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/bug15_safe.c-1_000.smt2":30:1-40:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/bug15_safe.c-1_000.smt2":41:1-51:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/bug15_safe.c-1_000.smt2":52:1-62:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/bug15_safe.c-1_000.smt2":63:1-73:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/bug15_safe.c-1_000.smt2":74:1-84:2 (clause 7, command 12)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  (∀ (A : Int),
  (True) →
  r2 A) ∧
  ((∀ (A B C D E F G : Int),
  (r0 C G F E D) →
  (B = (2 : Int) + D) →
  (D ≤ (9 : Int)) →
  (A = (4 : Int) + (2 : Int) * D) →
  r0 C G F B A) ∧
  ((∀ (A B C D E F : Int),
  (r1 C F D E) →
  (B = (4 : Int) + (2 : Int) * D) →
  (D ≤ (9 : Int)) →
  (A = (2 : Int) + D) →
  r1 C F B A) ∧
  ((∀ (A B C D E F : Int),
  (r0 B F E D C) →
  (¬C ≤ (9 : Int)) →
  (A = (2 : Int) * C) →
  r3 B F A) ∧
  ((∀ (A v_1 v_2 v_3 : Int),
  (r2 A) →
  (v_1 = A) →
  ((1 : Int) = v_2) →
  ((0 : Int) = v_3) →
  r1 A v_1 v_2 v_3) ∧
  ((∀ (A B C D E v_5 v_6 v_7 : Int),
  (r1 B E C D) →
  (¬C ≤ (9 : Int)) →
  (A = (2 : Int) * C) →
  (v_5 = B) →
  ((0 : Int) = v_6) →
  ((1 : Int) = v_7) →
  r0 B A v_5 v_6 v_7) ∧
  (∀ (A B C : Int),
  (r3 B C A) →
  (¬C = A) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«bug15_safe.c-1_000»
