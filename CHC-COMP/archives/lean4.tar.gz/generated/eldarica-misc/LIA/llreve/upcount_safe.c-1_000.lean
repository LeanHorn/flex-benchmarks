import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«upcount_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/upcount_safe.c-1_000.smt2":86:1-86:12 (check-sat, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/upcount_safe.c-1_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/upcount_safe.c-1_000.smt2":19:1-29:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/upcount_safe.c-1_000.smt2":30:1-40:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/upcount_safe.c-1_000.smt2":41:1-51:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/upcount_safe.c-1_000.smt2":52:1-62:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/upcount_safe.c-1_000.smt2":63:1-73:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/upcount_safe.c-1_000.smt2":74:1-84:2 (clause 7, command 12)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Prop),
  (∀ (_CHC_COMP_UNUSED : Prop),
  (True) →
  r0) ∧
  ((∀ (A B C D E : Int),
  (r2 A E D C B) →
  (¬(0 : Int) ≤ E) →
  r3 A E D C B) ∧
  ((∀ (A B C D E : Int),
  (r3 A E D C B) →
  (¬(1 : Int) ≤ D) →
  r1 A E D C B) ∧
  ((∀ (A B C D E F G : Int),
  (r2 C G F E D) →
  (B = (-1 : Int) + G) →
  ((0 : Int) ≤ G) →
  (A = (1 : Int) + E) →
  r2 C B F A D) ∧
  ((∀ (A B C D E F G : Int),
  (r3 C G F E D) →
  (B = (-1 : Int) + F) →
  ((1 : Int) ≤ F) →
  (A = (1 : Int) + D) →
  r3 C G B E A) ∧
  ((∀ (A v_1 v_2 v_3 v_4 : Int),
  (r0) →
  (v_1 = A) →
  (v_2 = A) →
  ((0 : Int) = v_3) →
  ((0 : Int) = v_4) →
  r2 A v_1 v_2 v_3 v_4) ∧
  (∀ (A B C D E : Int),
  (r1 A E D C B) →
  (¬A ≤ (-1 : Int)) →
  (¬C = (1 : Int) + B) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«upcount_safe.c-1_000»
