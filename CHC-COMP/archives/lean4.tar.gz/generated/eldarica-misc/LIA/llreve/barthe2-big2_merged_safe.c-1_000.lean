import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«barthe2-big2_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2-big2_merged_safe.c-1_000.smt2":129:1-129:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2-big2_merged_safe.c-1_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2-big2_merged_safe.c-1_000.smt2":19:1-29:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2-big2_merged_safe.c-1_000.smt2":30:1-40:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2-big2_merged_safe.c-1_000.smt2":41:1-52:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2-big2_merged_safe.c-1_000.smt2":53:1-64:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2-big2_merged_safe.c-1_000.smt2":65:1-76:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2-big2_merged_safe.c-1_000.smt2":77:1-88:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2-big2_merged_safe.c-1_000.smt2":89:1-100:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2-big2_merged_safe.c-1_000.smt2":101:1-116:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2-big2_merged_safe.c-1_000.smt2":117:1-127:2 (clause 10, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Prop),
  (∀ (A v_1 v_2 v_3 : Int),
  (True) →
  ((1 : Int) = v_1) →
  ((1 : Int) = v_2) →
  ((1 : Int) = v_3) →
  r3 A v_1 v_2 v_3) ∧
  ((∀ (A B C D E F G : Int),
  (r3 E F G D) →
  (B = G) →
  (C = (1 : Int) + F) →
  ((0 : Int) ≤ E + (-1 : Int) * F) →
  (A = D) →
  r3 E C B A) ∧
  ((∀ (A B C D E F : Int),
  (r2 D E F C B A) →
  (True) →
  r0 D E F C B A) ∧
  ((∀ (A B C D v_4 v_5 : Int),
  let a!1 := ¬(0 : Int) ≤ B + (-1 : Int) * C;
  r3 B C D A → ¬(0 : Int) ≤ B + (-1 : Int) * C → (0 : Int) = v_4 → (1 : Int) = v_5 → r0 B C D A v_4 v_5) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := ¬(1 : Int) ≤ B + (-1 : Int) * D;
  let a!2 := ¬(1 : Int) ≤ A + (-1 : Int) * D;
  r1 D E F C B A → a!1 ∨ a!2 → r2 D E F C B A) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := ¬(0 : Int) ≤ D + (-1 : Int) * B;
  let a!2 := ¬(0 : Int) ≤ D + (-1 : Int) * A;
  r0 D E F C B A → ¬(0 : Int) ≤ D + (-1 : Int) * B → ¬(0 : Int) ≤ D + (-1 : Int) * A → r1 D E F C B A) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬(0 : Int) ≤ F + (-1 : Int) * D;
  r0 F G H E D C →
    B = E + C → (0 : Int) ≤ F + (-1 : Int) * C → ¬(0 : Int) ≤ F + (-1 : Int) * D → A = (1 : Int) + C → r1 F G H B D A) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬(0 : Int) ≤ F + (-1 : Int) * C;
  r0 F G H E D C →
    B = H + D → ¬(0 : Int) ≤ F + (-1 : Int) * C → (0 : Int) ≤ F + (-1 : Int) * D → A = (1 : Int) + D → r1 F G B E A C) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 H I J G F E) →
  (B = (1 : Int) + F) →
  (C = G + E) →
  (D = J + F) →
  ((0 : Int) ≤ H + (-1 : Int) * E) →
  ((0 : Int) ≤ H + (-1 : Int) * F) →
  (A = (1 : Int) + E) →
  r1 H I D C B A) ∧
  (∀ (A B C D E F : Int),
  (r2 D E F C B A) →
  (¬C = F + B) →
  False)))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«barthe2-big2_merged_safe.c-1_000»
