import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«break_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_merged_safe.c-1_000.smt2":97:1-97:12 (check-sat, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_merged_safe.c-1_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_merged_safe.c-1_000.smt2":18:1-28:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_merged_safe.c-1_000.smt2":29:1-39:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_merged_safe.c-1_000.smt2":40:1-50:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_merged_safe.c-1_000.smt2":51:1-61:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_merged_safe.c-1_000.smt2":62:1-72:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_merged_safe.c-1_000.smt2":73:1-84:2 (clause 7, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_merged_safe.c-1_000.smt2":85:1-95:2 (clause 8, command 12)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  (∀ (A v_1 v_2 : Int),
  (True) →
  ((0 : Int) = v_1) →
  ((10 : Int) = v_2) →
  r1 A v_1 v_2) ∧
  ((∀ (A B C : Int),
  (r1 C A B) →
  (¬A ≤ (10 : Int)) →
  r0 C A B) ∧
  ((∀ (A B C : Int),
  (r0 C A B) →
  (¬(0 : Int) ≤ B) →
  r2 C A B) ∧
  ((∀ (A B C : Int),
  (r1 C A B) →
  (A ≤ (10 : Int)) →
  (A = C) →
  r0 C A B) ∧
  ((∀ (A B C D : Int),
  (r1 D B C) →
  (¬B = D) →
  (B ≤ (10 : Int)) →
  (A = (1 : Int) + B) →
  r1 D A C) ∧
  ((∀ (A B C : Int),
  (r0 C A B) →
  ((0 : Int) ≤ B) →
  (B = (10 : Int) + (-1 : Int) * C) →
  r2 C A B) ∧
  ((∀ (A B C D : Int),
  let a!1 := ¬C = (10 : Int) + (-1 : Int) * D;
  r0 D B C → ¬C = (10 : Int) + (-1 : Int) * D → (0 : Int) ≤ C → A = (-1 : Int) + C → r0 D B A) ∧
  (∀ (A B C : Int),
  (r2 C A B) →
  (¬A = (10 : Int) + (-1 : Int) * B) →
  False)))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«break_merged_safe.c-1_000»
