import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«square_twice_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_merged_safe.c-1_000.smt2":124:1-124:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_merged_safe.c-1_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_merged_safe.c-1_000.smt2":19:1-29:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_merged_safe.c-1_000.smt2":30:1-40:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_merged_safe.c-1_000.smt2":41:1-51:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_merged_safe.c-1_000.smt2":52:1-62:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_merged_safe.c-1_000.smt2":63:1-73:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_merged_safe.c-1_000.smt2":74:1-89:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_merged_safe.c-1_000.smt2":90:1-100:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_merged_safe.c-1_000.smt2":101:1-111:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_merged_safe.c-1_000.smt2":112:1-122:2 (clause 10, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Prop),
  (∀ (A v_1 : Int),
  (True) →
  ((0 : Int) = v_1) →
  r1 A v_1) ∧
  ((∀ (A B v_2 : Int),
  (r1 B A) →
  (v_2 = B) →
  r2 B A v_2) ∧
  ((∀ (A B C D E : Int),
  (r0 D C B A E) →
  (True) →
  r3 D C B A E) ∧
  ((∀ (A B C D E : Int),
  (r3 D C B A E) →
  (¬(1 : Int) ≤ E) →
  (¬(1 : Int) ≤ B) →
  r0 D C B A E) ∧
  ((∀ (A B C D E F G : Int),
  (r3 F E D C G) →
  (B = C + F) →
  (¬(1 : Int) ≤ D) →
  ((1 : Int) ≤ G) →
  (A = (-1 : Int) + G) →
  r0 F E D B A) ∧
  ((∀ (A B C D E F G : Int),
  (r3 F E D C G) →
  (B = E + F) →
  ((1 : Int) ≤ D) →
  (¬(1 : Int) ≤ G) →
  (A = (-1 : Int) + D) →
  r0 F B A C G) ∧
  ((∀ (A B C D E F G H I : Int),
  (r3 H G F E I) →
  (B = E + H) →
  (C = (-1 : Int) + F) →
  (D = G + H) →
  ((1 : Int) ≤ F) →
  ((1 : Int) ≤ I) →
  (A = (-1 : Int) + I) →
  r0 H D C B A) ∧
  ((∀ (A B C D E : Int),
  (r2 E D C) →
  (B = D + E) →
  ((1 : Int) ≤ C) →
  (A = (-1 : Int) + C) →
  r2 E B A) ∧
  ((∀ (A B C v_3 v_4 v_5 v_6 : Int),
  (r2 C B A) →
  (¬(1 : Int) ≤ A) →
  ((0 : Int) = v_3) →
  (v_4 = C) →
  ((0 : Int) = v_5) →
  (v_6 = C) →
  r3 C v_3 v_4 v_5 v_6) ∧
  (∀ (A B C D E : Int),
  (r0 D C B A E) →
  (¬C = A) →
  False)))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«square_twice_merged_safe.c-1_000»
