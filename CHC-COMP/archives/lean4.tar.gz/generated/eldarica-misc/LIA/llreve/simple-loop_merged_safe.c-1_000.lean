import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«simple-loop_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/simple-loop_merged_safe.c-1_000.smt2":86:1-86:12 (check-sat, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/simple-loop_merged_safe.c-1_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/simple-loop_merged_safe.c-1_000.smt2":19:1-29:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/simple-loop_merged_safe.c-1_000.smt2":30:1-40:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/simple-loop_merged_safe.c-1_000.smt2":41:1-51:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/simple-loop_merged_safe.c-1_000.smt2":52:1-62:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/simple-loop_merged_safe.c-1_000.smt2":63:1-73:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/simple-loop_merged_safe.c-1_000.smt2":74:1-84:2 (clause 7, command 12)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  (∀ (A : Int),
  (True) →
  r1 A) ∧
  ((∀ (A B C D E : Int),
  (r0 C E D B) →
  (B ≤ (10 : Int)) →
  (A = (1 : Int) + B) →
  r0 C E D A) ∧
  ((∀ (A B C D : Int),
  (r2 B D C) →
  (C ≤ (10 : Int)) →
  (A = (1 : Int) + C) →
  r2 B D A) ∧
  ((∀ (A B C D : Int),
  (r0 B D C A) →
  (¬A ≤ (10 : Int)) →
  r3 B D A) ∧
  ((∀ (A v_1 v_2 : Int),
  (r1 A) →
  (v_1 = A) →
  ((0 : Int) = v_2) →
  r2 A v_1 v_2) ∧
  ((∀ (A B C v_3 v_4 : Int),
  (r2 A C B) →
  (¬B ≤ (10 : Int)) →
  (v_3 = A) →
  ((1 : Int) = v_4) →
  r0 A B v_3 v_4) ∧
  (∀ (A B C : Int),
  (r3 A B C) →
  (¬B = C) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«simple-loop_merged_safe.c-1_000»
