import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«while_after_while_if_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":154:1-154:12 (check-sat, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":11:1-20:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":21:1-31:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":32:1-42:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":43:1-53:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":54:1-64:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":65:1-75:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":76:1-86:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":87:1-97:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":98:1-108:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":109:1-119:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":120:1-130:2 (clause 11, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":131:1-141:2 (clause 12, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/while_after_while_if_merged_safe.c-1_000.smt2":142:1-152:2 (clause 13, command 20)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (v_0 v_1 : Int),
  (True) →
  ((0 : Int) = v_0) →
  ((0 : Int) = v_1) →
  r4 v_0 v_1) ∧
  ((∀ (A B C D E F G H I : Int),
  (r5 A C E B D I G H F) →
  (¬(1 : Int) ≤ B) →
  r2 A C E B D I G H F) ∧
  ((∀ (A B C D E F G H I : Int),
  (r2 A C E B D I G H F) →
  (¬(1 : Int) ≤ H) →
  r1 A C E B D I G H F) ∧
  ((∀ (A B C D E F G H I : Int),
  (r1 A C E B D I G H F) →
  (¬(1 : Int) ≤ D) →
  r0 A C E B D I G H F) ∧
  ((∀ (A B C D E F G H I : Int),
  (r0 A C E B D I G H F) →
  (¬(1 : Int) ≤ F) →
  r3 A C E B D I G H F) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r5 C E G D F K I J H) →
  (B = (1 : Int) + C) →
  ((1 : Int) ≤ D) →
  (A = (-1 : Int) + D) →
  r5 B E G A F K I J H) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r2 C E G D F K I J H) →
  (B = (2 : Int) + C) →
  ((1 : Int) ≤ J) →
  (A = (-1 : Int) + J) →
  r2 B E G D F K I A H) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 C E G D F K I J H) →
  (B = (2 : Int) + E) →
  ((1 : Int) ≤ H) →
  (A = (-1 : Int) + H) →
  r0 C B G D F K I J A) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r1 C E G D F K I J H) →
  (B = (1 : Int) + E) →
  ((1 : Int) ≤ F) →
  ((1 : Int) ≤ K) →
  (A = (-1 : Int) + F) →
  r1 C B G D A K I J H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r1 B D F C E J H I G) →
  ((1 : Int) ≤ E) →
  (¬(1 : Int) ≤ J) →
  (A = (-1 : Int) + E) →
  r1 B D F C A J H I G) ∧
  ((∀ (A B C D E v_5 v_6 v_7 v_8 : Int),
  (r4 B D) →
  ((1 : Int) ≤ A) →
  (v_5 = E) →
  (v_6 = E) →
  (v_7 = C) →
  (v_8 = C) →
  r5 B D E v_5 v_6 A C v_7 v_8) ∧
  ((∀ (A B C D E v_5 v_6 v_7 v_8 : Int),
  (r4 B C) →
  (¬(1 : Int) ≤ A) →
  (v_5 = E) →
  (v_6 = E) →
  (v_7 = D) →
  (v_8 = D) →
  r2 B C E v_5 v_6 A D v_7 v_8) ∧
  (∀ (A B C D E F G H I : Int),
  (r3 A C E B D I G H F) →
  (¬A = C) →
  False))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«while_after_while_if_merged_safe.c-1_000»
