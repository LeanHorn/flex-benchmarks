import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«break_single_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_single_merged_safe.c-1_000.smt2":85:1-85:12 (check-sat, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_single_merged_safe.c-1_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_single_merged_safe.c-1_000.smt2":18:1-28:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_single_merged_safe.c-1_000.smt2":29:1-39:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_single_merged_safe.c-1_000.smt2":40:1-50:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_single_merged_safe.c-1_000.smt2":51:1-61:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_single_merged_safe.c-1_000.smt2":62:1-72:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_single_merged_safe.c-1_000.smt2":73:1-83:2 (clause 7, command 11)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  (∀ (A v_1 : Int),
  (True) →
  ((0 : Int) = v_1) →
  r1 A v_1) ∧
  ((∀ (A B C : Int),
  (r2 B C A) →
  (¬A ≤ (10 : Int) ∨ A = B) →
  r0 B C A) ∧
  ((∀ (A B C D : Int),
  (r2 C D B) →
  (¬B = C) →
  (B ≤ (10 : Int)) →
  (A = (1 : Int) + B) →
  r2 C D A) ∧
  ((∀ (A B C : Int),
  (r1 B C) →
  (¬C = B) →
  (C ≤ (10 : Int)) →
  (A = (1 : Int) + C) →
  r1 B A) ∧
  ((∀ (A B v_2 : Int),
  (r1 A B) →
  (¬B ≤ (10 : Int)) →
  ((0 : Int) = v_2) →
  r2 A B v_2) ∧
  ((∀ (A B v_2 : Int),
  (r1 A B) →
  (B ≤ (10 : Int)) →
  (B = A) →
  ((0 : Int) = v_2) →
  r2 A B v_2) ∧
  (∀ (A B C : Int),
  (r0 B C A) →
  (¬C = A) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«break_single_merged_safe.c-1_000»
