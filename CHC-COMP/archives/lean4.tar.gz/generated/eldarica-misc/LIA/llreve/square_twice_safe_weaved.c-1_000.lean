import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«square_twice_safe_weaved.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_safe_weaved.c-1_000.smt2":109:1-109:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_safe_weaved.c-1_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_safe_weaved.c-1_000.smt2":20:1-30:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_safe_weaved.c-1_000.smt2":31:1-41:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_safe_weaved.c-1_000.smt2":42:1-52:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_safe_weaved.c-1_000.smt2":53:1-63:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_safe_weaved.c-1_000.smt2":64:1-74:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_safe_weaved.c-1_000.smt2":75:1-85:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_safe_weaved.c-1_000.smt2":86:1-96:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/square_twice_safe_weaved.c-1_000.smt2":97:1-107:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Prop),
  (∀ (A : Int),
  (True) →
  r2 A) ∧
  ((∀ (A B C D E F G : Int),
  (r3 F D G E C) →
  (B = E + G) →
  ((1 : Int) ≤ C) →
  (A = (-1 : Int) + C) →
  r3 F D G B A) ∧
  ((∀ (A B C D E F : Int),
  (r4 D F E C) →
  (B = E + F) →
  ((1 : Int) ≤ C) →
  (A = (-1 : Int) + C) →
  r4 D F B A) ∧
  ((∀ (A B C D v_4 v_5 : Int),
  (r4 B D C A) →
  (¬(1 : Int) ≤ A) →
  ((0 : Int) = v_4) →
  (v_5 = D) →
  r1 B D v_4 v_5) ∧
  ((∀ (A B C D E F : Int),
  (r1 D F E C) →
  (B = E + F) →
  ((1 : Int) ≤ C) →
  (A = (-1 : Int) + C) →
  r1 D F B A) ∧
  ((∀ (A B C D E : Int),
  (r3 D B E C A) →
  (¬(1 : Int) ≤ A) →
  r0 D B C) ∧
  ((∀ (A v_1 v_2 v_3 : Int),
  (r2 A) →
  (v_1 = A) →
  ((0 : Int) = v_2) →
  (v_3 = A) →
  r4 A v_1 v_2 v_3) ∧
  ((∀ (A B C D v_4 v_5 v_6 : Int),
  (r1 B D C A) →
  (¬(1 : Int) ≤ A) →
  (v_4 = B) →
  ((0 : Int) = v_5) →
  (v_6 = B) →
  r3 B C v_4 v_5 v_6) ∧
  (∀ (A B C : Int),
  (r0 C B A) →
  (¬B = A) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«square_twice_safe_weaved.c-1_000»
