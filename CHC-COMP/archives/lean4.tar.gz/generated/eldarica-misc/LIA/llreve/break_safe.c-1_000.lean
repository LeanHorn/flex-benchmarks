import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«break_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_safe.c-1_000.smt2":109:1-109:12 (check-sat, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_safe.c-1_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_safe.c-1_000.smt2":19:1-30:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_safe.c-1_000.smt2":31:1-41:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_safe.c-1_000.smt2":42:1-52:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_safe.c-1_000.smt2":53:1-63:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_safe.c-1_000.smt2":64:1-74:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_safe.c-1_000.smt2":75:1-85:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_safe.c-1_000.smt2":86:1-96:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/break_safe.c-1_000.smt2":97:1-107:2 (clause 9, command 14)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Prop),
  (∀ (A : Int),
  (True) →
  r0 A) ∧
  ((∀ (A B C D E : Int),
  let a!1 := ¬D = (10 : Int) + (-1 : Int) * C;
  r3 B E C D → ¬D = (10 : Int) + (-1 : Int) * C → (0 : Int) ≤ D → A = (-1 : Int) + D → r3 B E C A) ∧
  ((∀ (A B C D : Int),
  (r2 B C D) →
  (¬D = C) →
  (D ≤ (10 : Int)) →
  (A = (1 : Int) + D) →
  r2 B C A) ∧
  ((∀ (A B C D E : Int),
  (r3 B E C D) →
  (¬(0 : Int) ≤ D) →
  (A = (10 : Int) + (-1 : Int) * D) →
  r1 B E A) ∧
  ((∀ (A B C D E : Int),
  (r3 B E C D) →
  (D = (10 : Int) + (-1 : Int) * C) →
  ((0 : Int) ≤ D) →
  (A = (10 : Int) + (-1 : Int) * D) →
  r1 B E A) ∧
  ((∀ (A v_1 v_2 : Int),
  (r0 A) →
  (v_1 = A) →
  ((0 : Int) = v_2) →
  r2 A v_1 v_2) ∧
  ((∀ (A B C v_3 v_4 : Int),
  (r2 A B C) →
  (¬C ≤ (10 : Int)) →
  (v_3 = A) →
  ((10 : Int) = v_4) →
  r3 A C v_3 v_4) ∧
  ((∀ (A B C v_3 v_4 : Int),
  (r2 A B C) →
  (C ≤ (10 : Int)) →
  (C = B) →
  (v_3 = A) →
  ((10 : Int) = v_4) →
  r3 A C v_3 v_4) ∧
  (∀ (A B C : Int),
  (r1 A C B) →
  (¬C = B) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«break_safe.c-1_000»
