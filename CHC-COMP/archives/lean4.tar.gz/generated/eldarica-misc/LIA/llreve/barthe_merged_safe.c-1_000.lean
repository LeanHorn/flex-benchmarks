import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«barthe_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe_merged_safe.c-1_000.smt2":85:1-85:12 (check-sat, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe_merged_safe.c-1_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe_merged_safe.c-1_000.smt2":19:1-29:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe_merged_safe.c-1_000.smt2":30:1-40:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe_merged_safe.c-1_000.smt2":41:1-51:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe_merged_safe.c-1_000.smt2":52:1-62:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe_merged_safe.c-1_000.smt2":63:1-73:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe_merged_safe.c-1_000.smt2":74:1-83:2 (clause 7, command 12)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B v_2 v_3 v_4 : Int),
  (True) →
  ((0 : Int) = v_2) →
  ((0 : Int) = v_3) →
  ((0 : Int) = v_4) →
  r0 B A v_2 v_3 v_4) ∧
  ((∀ (A B C D E F G H I : Int),
  (r3 E C I D F H G) →
  (B = F + D) →
  (A = G + H) →
  r2 E C I D B H A) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r2 F D J E G I H) →
  (B = (5 : Int) + (5 : Int) * J + D) →
  (C = (1 : Int) + J) →
  ((2 : Int) ≤ F + (-1 : Int) * J) →
  (A = (5 : Int) + I) →
  r3 F D C B G A H) ∧
  ((∀ (A B C D E F v_6 v_7 : Int),
  (r0 D B F C E) →
  ((1 : Int) ≤ D + (-1 : Int) * F) →
  (A = (5 : Int) * F + B) →
  (v_6 = B) →
  ((0 : Int) = v_7) →
  r3 D B F A E v_6 v_7) ∧
  ((∀ (A B C D E F G : Int),
  (r3 C A G B D F E) →
  (¬B = F) →
  r1) ∧
  ((∀ (A B C D E F G : Int),
  (r2 C A G B D F E) →
  (¬D = E) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«barthe_merged_safe.c-1_000»
