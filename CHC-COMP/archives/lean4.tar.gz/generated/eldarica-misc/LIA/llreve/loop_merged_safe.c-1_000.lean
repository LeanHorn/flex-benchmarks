import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«loop_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_merged_safe.c-1_000.smt2":143:1-143:12 (check-sat, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_merged_safe.c-1_000.smt2":11:1-20:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_merged_safe.c-1_000.smt2":21:1-31:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_merged_safe.c-1_000.smt2":32:1-42:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_merged_safe.c-1_000.smt2":43:1-53:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_merged_safe.c-1_000.smt2":54:1-64:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_merged_safe.c-1_000.smt2":65:1-75:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_merged_safe.c-1_000.smt2":76:1-87:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_merged_safe.c-1_000.smt2":88:1-98:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_merged_safe.c-1_000.smt2":99:1-109:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_merged_safe.c-1_000.smt2":110:1-120:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_merged_safe.c-1_000.smt2":121:1-131:2 (clause 11, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/loop_merged_safe.c-1_000.smt2":132:1-141:2 (clause 12, command 19)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Prop),
  (∀ (A v_1 v_2 : Int),
  (True) →
  ((0 : Int) = v_1) →
  ((0 : Int) = v_2) →
  r1 A v_1 v_2) ∧
  ((∀ (A B C D E : Int),
  (r2 A B C E D) →
  (¬(0 : Int) ≤ E) →
  r5 A B C E D) ∧
  ((∀ (A B C D E : Int),
  (r0 A B C E D) →
  (True) →
  r2 A B C E D) ∧
  ((∀ (A B C D E F G : Int),
  (r2 C D E G F) →
  (B = (-1 : Int) + G) →
  ((0 : Int) ≤ G) →
  (A = (1 : Int) + F) →
  r0 C D E B A) ∧
  ((∀ (A B C D E : Int),
  (r3 A B C E D) →
  (¬(0 : Int) ≤ A + (-1 : Int) * B) →
  r2 A B C E D) ∧
  ((∀ (A B C D E F G : Int),
  (r3 C D E G F) →
  (B = (1 : Int) + D) →
  ((0 : Int) ≤ C + (-1 : Int) * D) →
  (A = (1 : Int) + E) →
  r3 C B A G F) ∧
  ((∀ (A B C v_3 v_4 : Int),
  let a!1 := ¬(0 : Int) ≤ A + (-1 : Int) * B;
  r1 A B C → ¬(0 : Int) ≤ A + (-1 : Int) * B → v_3 = A → (0 : Int) = v_4 → r2 A B C v_3 v_4) ∧
  ((∀ (A B C D E v_5 v_6 : Int),
  (r1 C D E) →
  (A = (1 : Int) + E) →
  ((0 : Int) ≤ C + (-1 : Int) * D) →
  (B = (1 : Int) + D) →
  (v_5 = C) →
  ((0 : Int) = v_6) →
  r3 C B A v_5 v_6) ∧
  ((∀ (A B C D E : Int),
  (r3 A B C E D) →
  (¬B = C) →
  r4) ∧
  ((∀ (A B C D E : Int),
  (r0 A B C E D) →
  (¬E + D = A) →
  r4) ∧
  ((∀ (A B C D E : Int),
  (r5 A B C E D) →
  (¬C = D) →
  r4) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r4) →
  False)))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«loop_merged_safe.c-1_000»
