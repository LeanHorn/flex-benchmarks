import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«barthe2_merged_safe.c-1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2_merged_safe.c-1_000.smt2":101:1-101:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2_merged_safe.c-1_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2_merged_safe.c-1_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2_merged_safe.c-1_000.smt2":28:1-42:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2_merged_safe.c-1_000.smt2":43:1-56:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2_merged_safe.c-1_000.smt2":57:1-70:2 (clause 5, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2_merged_safe.c-1_000.smt2":71:1-88:2 (clause 6, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/llreve/barthe2_merged_safe.c-1_000.smt2":89:1-99:2 (clause 7, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Prop),
  (∀ (A v_1 v_2 v_3 v_4 : Int),
  (True) →
  ((0 : Int) = v_1) →
  ((0 : Int) = v_2) →
  ((0 : Int) = v_3) →
  ((1 : Int) = v_4) →
  r0 A v_1 v_2 v_3 v_4) ∧
  ((∀ (A B C D E : Int),
  (r1 B D C A E) →
  (True) →
  r0 B D C A E) ∧
  ((∀ (A B C D E : Int),
  let a!1 := ¬(0 : Int) ≤ B + (-1 : Int) * E;
  let a!2 := ¬(1 : Int) ≤ E + (-1 : Int) * B;
  let a!3 := ¬(1 : Int) ≤ A + (-1 : Int) * B;
  let a!4 := ¬(0 : Int) ≤ B + (-1 : Int) * A;
  r0 B D C A E → ¬(0 : Int) ≤ B + (-1 : Int) * E → a!2 ∨ a!3 → ¬(0 : Int) ≤ B + (-1 : Int) * A → r1 B D C A E) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ¬(0 : Int) ≤ D + (-1 : Int) * C;
  let a!2 := ¬(0 : Int) ≤ G + (-1 : Int) * D;
  let a!3 := ¬(1 : Int) ≤ C + (-1 : Int) * D;
  r0 D F E C G →
    B = E + G →
      ¬(0 : Int) ≤ D + (-1 : Int) * C → (0 : Int) ≤ D + (-1 : Int) * G → a!2 ∨ a!3 → A = (1 : Int) + G → r1 D F B C A) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ¬(0 : Int) ≤ D + (-1 : Int) * G;
  let a!2 := ¬(0 : Int) ≤ C + (-1 : Int) * D;
  let a!3 := ¬(1 : Int) ≤ G + (-1 : Int) * D;
  r0 D F E C G →
    B = F + C →
      (0 : Int) ≤ D + (-1 : Int) * C → ¬(0 : Int) ≤ D + (-1 : Int) * G → a!2 ∨ a!3 → A = (1 : Int) + C → r1 D B E A G) ∧
  ((∀ (A B C D E F G H I : Int),
  let a!1 := ¬(0 : Int) ≤ I + (-1 : Int) * F;
  let a!2 := ¬(0 : Int) ≤ E + (-1 : Int) * F;
  r0 F H G E I →
    B = (1 : Int) + E →
      C = G + I →
        D = H + E →
          (0 : Int) ≤ F + (-1 : Int) * E → (0 : Int) ≤ F + (-1 : Int) * I → a!1 ∨ a!2 → A = (1 : Int) + I → r1 F D C B A) ∧
  (∀ (A B C D E : Int),
  (r1 B D C A E) →
  (¬C = D + A) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«llreve».«barthe2_merged_safe.c-1_000»
