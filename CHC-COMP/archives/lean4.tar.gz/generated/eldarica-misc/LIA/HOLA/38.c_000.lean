import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«38.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":323:1-323:12 (check-sat, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":27:1-36:2 (clause 1, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":37:1-47:2 (clause 2, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":48:1-58:2 (clause 3, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":59:1-69:2 (clause 4, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":70:1-80:2 (clause 5, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":81:1-91:2 (clause 6, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":92:1-102:2 (clause 7, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":103:1-113:2 (clause 8, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":114:1-124:2 (clause 9, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":125:1-135:2 (clause 10, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":136:1-146:2 (clause 11, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":147:1-157:2 (clause 12, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":158:1-168:2 (clause 13, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":169:1-179:2 (clause 14, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":180:1-190:2 (clause 15, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":191:1-201:2 (clause 16, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":202:1-212:2 (clause 17, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":213:1-223:2 (clause 18, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":224:1-234:2 (clause 19, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":235:1-245:2 (clause 20, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":246:1-256:2 (clause 21, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":257:1-267:2 (clause 22, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":268:1-278:2 (clause 23, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":279:1-289:2 (clause 24, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":290:1-300:2 (clause 25, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":301:1-311:2 (clause 26, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/38.c_000.smt2":312:1-321:2 (clause 27, command 50)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D v_4 v_5 v_6 v_7 : Int),
  (True) →
  (v_4 = A) →
  (v_5 = B) →
  (v_6 = C) →
  (v_7 = D) →
  r9 A B C D v_4 v_5 v_6 v_7) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r9 A B C D E I J K) →
  (F = (0 : Int)) →
  (H = (0 : Int)) →
  (G = (0 : Int)) →
  r6 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r6 A B C D E F G H) →
  (True) →
  r18 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r18 A B C D E F G H) →
  (True) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 A B C D E F G H) →
  (True) →
  r21 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 A B C D E F G H) →
  (True) →
  r21 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r17 A B C D E F G H) →
  (True) →
  r21 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r3 A B C D E F G H) →
  (True) →
  r21 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r21 A B C D E F G H) →
  (True) →
  r5 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r5 A B C D E F G H) →
  (E + (-1 : Int) * H ≥ (1 : Int)) →
  r15 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r15 A B C D E J G I) →
  (I = (-1 : Int) + H) →
  (J = (-1 : Int) + F) →
  r10 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r5 A B C D E F G H) →
  (E + (-1 : Int) * H ≤ (0 : Int)) →
  r19 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r19 A B C D E F G H) →
  (True) →
  r13 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r13 A B C D E F G H) →
  (True) →
  r20 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r10 A B C D E F G H) →
  (True) →
  r12 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r12 A B C D E F G H) →
  (H % (2 : Int) = (0 : Int)) →
  r11 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r11 A B C D E F I H) →
  (I = (-1 : Int) + G) →
  r3 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r12 A B C D E F G H) →
  (¬H % (2 : Int) = (0 : Int)) →
  r2 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r12 A B C D E F G H) →
  (¬H % (2 : Int) = (0 : Int)) →
  r17 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r20 A B C D E F G H) →
  (True) →
  r16 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r16 A B C D E F G H) →
  (H % (2 : Int) = (0 : Int)) →
  r7 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r7 A B C D E F G H) →
  (True) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 A B C D E F G H) →
  (F + (-2 : Int) * G ≤ (-1 : Int)) →
  r14 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 A B C D E F G H) →
  (F + (-2 : Int) * G ≥ (1 : Int)) →
  r4 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r14 A B C D E F G H) →
  (True) →
  r8) ∧
  ((∀ (A B C D E F G H : Int),
  (r4 A B C D E F G H) →
  (True) →
  r8) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r8) →
  False))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«38.c_000»
