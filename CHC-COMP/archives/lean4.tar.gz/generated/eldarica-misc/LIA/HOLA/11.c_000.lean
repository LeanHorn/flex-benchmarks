import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«11.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":217:1-217:12 (check-sat, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":20:1-29:2 (clause 1, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":30:1-40:2 (clause 2, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":41:1-51:2 (clause 3, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":52:1-62:2 (clause 4, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":63:1-73:2 (clause 5, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":74:1-84:2 (clause 6, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":85:1-95:2 (clause 7, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":96:1-106:2 (clause 8, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":107:1-117:2 (clause 9, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":118:1-128:2 (clause 10, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":129:1-139:2 (clause 11, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":140:1-150:2 (clause 12, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":151:1-161:2 (clause 13, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":162:1-172:2 (clause 14, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":173:1-183:2 (clause 15, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":184:1-194:2 (clause 16, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":195:1-205:2 (clause 17, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/11.c_000.smt2":206:1-215:2 (clause 18, command 34)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C v_3 v_4 v_5 : Int),
  (True) →
  (v_3 = A) →
  (v_4 = B) →
  (v_5 = C) →
  r1 A B C v_3 v_4 v_5) ∧
  ((∀ (A B C D E F G H I : Int),
  (r1 A B C G H I) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (F = (100 : Int)) →
  r2 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r2 A B C D E F) →
  (True) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r3 A B C D E F) →
  (True) →
  r12 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r12 A B C D E F) →
  (True) →
  r8 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r10 A B C D E F) →
  (True) →
  r8 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r8 A B C D E F) →
  (True) →
  r14 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r14 A B C D E F) →
  (E + (-1 : Int) * F ≤ (-1 : Int)) →
  r4 A B C D E F) ∧
  ((∀ (A B C D E F G H : Int),
  (r4 A B C G H F) →
  (G = (-2 : Int) + D) →
  (H = (-1 : Int) + E) →
  r10 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r14 A B C D E F) →
  (E + (-1 : Int) * F ≥ (0 : Int)) →
  r6 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r6 A B C D E F) →
  (True) →
  r7 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r7 A B C D E F) →
  (True) →
  r13 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r13 A B C D E F) →
  (True) →
  r11 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r11 A B C D E F) →
  (D + (-2 : Int) * F ≤ (-1 : Int)) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r11 A B C D E F) →
  (D + (-2 : Int) * F ≥ (1 : Int)) →
  r5 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r0 A B C D E F) →
  (True) →
  r9) ∧
  ((∀ (A B C D E F : Int),
  (r5 A B C D E F) →
  (True) →
  r9) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r9) →
  False)))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«11.c_000»
