import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«36.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":1100:1-1100:12 (check-sat, command 164)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":78:1-131:2 (clause 1, command 75)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":132:1-142:2 (clause 2, command 76)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":143:1-153:2 (clause 3, command 77)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":154:1-164:2 (clause 4, command 78)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":165:1-175:2 (clause 5, command 79)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":176:1-186:2 (clause 6, command 80)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":187:1-197:2 (clause 7, command 81)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":198:1-208:2 (clause 8, command 82)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":209:1-219:2 (clause 9, command 83)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":220:1-230:2 (clause 10, command 84)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":231:1-241:2 (clause 11, command 85)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":242:1-252:2 (clause 12, command 86)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":253:1-263:2 (clause 13, command 87)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":264:1-274:2 (clause 14, command 88)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":275:1-285:2 (clause 15, command 89)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":286:1-296:2 (clause 16, command 90)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":297:1-307:2 (clause 17, command 91)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":308:1-318:2 (clause 18, command 92)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":319:1-329:2 (clause 19, command 93)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":330:1-340:2 (clause 20, command 94)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":341:1-351:2 (clause 21, command 95)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":352:1-362:2 (clause 22, command 96)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":363:1-373:2 (clause 23, command 97)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":374:1-384:2 (clause 24, command 98)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":385:1-395:2 (clause 25, command 99)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":396:1-406:2 (clause 26, command 100)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":407:1-417:2 (clause 27, command 101)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":418:1-428:2 (clause 28, command 102)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":429:1-439:2 (clause 29, command 103)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":440:1-450:2 (clause 30, command 104)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":451:1-461:2 (clause 31, command 105)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":462:1-472:2 (clause 32, command 106)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":473:1-483:2 (clause 33, command 107)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":484:1-494:2 (clause 34, command 108)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":495:1-505:2 (clause 35, command 109)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":506:1-516:2 (clause 36, command 110)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":517:1-527:2 (clause 37, command 111)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":528:1-538:2 (clause 38, command 112)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":539:1-549:2 (clause 39, command 113)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":550:1-560:2 (clause 40, command 114)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":561:1-571:2 (clause 41, command 115)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":572:1-582:2 (clause 42, command 116)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":583:1-593:2 (clause 43, command 117)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":594:1-604:2 (clause 44, command 118)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":605:1-615:2 (clause 45, command 119)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":616:1-626:2 (clause 46, command 120)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":627:1-637:2 (clause 47, command 121)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":638:1-648:2 (clause 48, command 122)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":649:1-659:2 (clause 49, command 123)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":660:1-670:2 (clause 50, command 124)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":671:1-681:2 (clause 51, command 125)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":682:1-692:2 (clause 52, command 126)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":693:1-703:2 (clause 53, command 127)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":704:1-714:2 (clause 54, command 128)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":715:1-725:2 (clause 55, command 129)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":726:1-736:2 (clause 56, command 130)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":737:1-747:2 (clause 57, command 131)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":748:1-758:2 (clause 58, command 132)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":759:1-769:2 (clause 59, command 133)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":770:1-780:2 (clause 60, command 134)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":781:1-791:2 (clause 61, command 135)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":792:1-802:2 (clause 62, command 136)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":803:1-813:2 (clause 63, command 137)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":814:1-824:2 (clause 64, command 138)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":825:1-835:2 (clause 65, command 139)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":836:1-846:2 (clause 66, command 140)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":847:1-857:2 (clause 67, command 141)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":858:1-868:2 (clause 68, command 142)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":869:1-879:2 (clause 69, command 143)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":880:1-890:2 (clause 70, command 144)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":891:1-901:2 (clause 71, command 145)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":902:1-912:2 (clause 72, command 146)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":913:1-923:2 (clause 73, command 147)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":924:1-934:2 (clause 74, command 148)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":935:1-945:2 (clause 75, command 149)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":946:1-956:2 (clause 76, command 150)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":957:1-967:2 (clause 77, command 151)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":968:1-978:2 (clause 78, command 152)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":979:1-989:2 (clause 79, command 153)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":990:1-1000:2 (clause 80, command 154)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":1001:1-1011:2 (clause 81, command 155)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":1012:1-1022:2 (clause 82, command 156)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":1023:1-1033:2 (clause 83, command 157)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":1034:1-1044:2 (clause 84, command 158)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":1045:1-1055:2 (clause 85, command 159)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":1056:1-1066:2 (clause 86, command 160)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":1067:1-1077:2 (clause 87, command 161)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":1078:1-1088:2 (clause 88, command 162)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/36.c_000.smt2":1089:1-1098:2 (clause 89, command 163)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r28 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r29 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r30 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r31 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r32 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r33 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r34 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r35 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r36 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r37 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r38 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r39 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r40 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r41 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r42 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r43 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r44 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r45 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r46 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r47 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r48 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r49 : Prop),
  ∃ (r50 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r51 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r52 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r53 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r54 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r55 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r56 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r57 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r58 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r59 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r60 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r61 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r62 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r63 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r64 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r65 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r66 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r67 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r68 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r69 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r70 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r71 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r72 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (((((((∀ (A B C D E F G H I J K L M N O v_15 v_16 v_17 v_18 v_19 v_20 v_21 v_22 v_23 v_24 v_25 v_26 v_27 v_28 v_29 : Int),
  (True) →
  (v_15 = A) →
  (v_16 = B) →
  (v_17 = C) →
  (v_18 = D) →
  (v_19 = E) →
  (v_20 = F) →
  (v_21 = G) →
  (v_22 = H) →
  (v_23 = I) →
  (v_24 = J) →
  (v_25 = K) →
  (v_26 = L) →
  (v_27 = M) →
  (v_28 = N) →
  (v_29 = O) →
  r2 A B C D E F G H I J K L M N O v_15 v_16 v_17 v_18 v_19 v_20 v_21 v_22 v_23 v_24 v_25 v_26 v_27 v_28 v_29) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r2 A B C D E F G H I J K L M N O P E1 F1 S T G1 H1 W X Y Z A1 B1 C1 D1) →
  (Q = (0 : Int)) →
  (V = (0 : Int)) →
  (U = (0 : Int)) →
  (R = (0 : Int)) →
  r67 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r67 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r9 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r9 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r72 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r72 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r20 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r40 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r20 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r20 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r62 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r62 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r64 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r64 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r0 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r0 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (A1 ≤ (-1 : Int)) →
  r22 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 : Int),
  (r22 A B C D E F G H I J K L M N O P Q R S T U V E1 F1 G1 Z A1 B1 C1 D1) →
  (V = X) →
  (U = W) →
  (Y = (0 : Int)) →
  r52 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 : Int),
  (r36 A B C D E F G H I J K L M N O P Q R S T U V E1 F1 G1 Z A1 B1 C1 D1) →
  (V = X) →
  (U = W) →
  (Y = (0 : Int)) →
  r52 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r0 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (A1 ≥ (1 : Int)) →
  r36 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r0 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (A1 = (0 : Int)) →
  r3 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r3 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r35 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r35 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r54 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))))) ∧
  (((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r52 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r1 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r1 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r56 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r56 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r15 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r46 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r15 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r15 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r24 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r24 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (W + (-1 : Int) * X ≤ (-1 : Int)) →
  r41 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r41 A B C D E F G H I J K L M N O P Q R S T U V F1 X E1 Z A1 B1 C1 D1) →
  (E1 = (-1 : Int) + Y) →
  (F1 = (-1 : Int) + W) →
  r46 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r24 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (W + (-1 : Int) * X ≥ (0 : Int)) →
  r34 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r34 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r13 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r13 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r63 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r63 A B C D E F G H I J K L M N O P Q R E1 F1 U V W X Y Z A1 B1 C1 D1) →
  (U = S) →
  (Y = T) →
  r14 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r14 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r7 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r7 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r43 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r43 A B C D E F G H I J K L M N O P Q R E1 F1 U V W X Y Z A1 B1 C1 D1) →
  (E1 = (-1 : Int) + S) →
  (F1 = (1 : Int) + T) →
  r65 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r7 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r23 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r23 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r12 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)))))) ∧
  ((((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r59 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r12 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r65 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r12 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r7 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r59 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r12 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r11 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r11 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r51 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r68 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r51 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r38 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r51 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r51 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r27 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r27 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r69 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r69 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r25 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r25 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (Z ≤ (-1 : Int)) →
  r8 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r8 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r17 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r4 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r17 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r25 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (Z ≥ (1 : Int)) →
  r4 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r25 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (Z = (0 : Int)) →
  r26 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r26 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r10 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))))) ∧
  (((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r10 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r58 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r17 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r60 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r60 A B C D E F G H I J K L M N O P Q R E1 F1 U V W X Y Z A1 B1 C1 D1) →
  (E1 = (-2 : Int) + S) →
  (F1 = (2 : Int) + T) →
  r68 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r17 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r28 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r28 A B C D E F G H I J K L M N O P Q R E1 F1 U V W X Y Z A1 B1 C1 D1) →
  (E1 = (1 : Int) + S) →
  (F1 = (1 : Int) + T) →
  r38 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r47 A B C D E F G H I J K L M N O P Q R E1 F1 U V W X Y Z A1 B1 C1 D1) →
  (E1 = (1 : Int) + S) →
  (F1 = (1 : Int) + T) →
  r38 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r17 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r47 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r58 A B C D E F G H I J K L M N O P Q R S T E1 F1 W X Y Z A1 B1 C1 D1) →
  (S = (-1 : Int) + (-1 : Int) * T + V) →
  (E1 = (-1 : Int) + U) →
  r40 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r54 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 E1 F1 D1) →
  (B1 = (0 : Int)) →
  (C1 = (0 : Int)) →
  r37 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r37 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r57 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r57 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r45 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r45 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r70 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r66 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r70 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r16 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r70 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r70 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r39 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r39 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r53 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))))))) ∧
  ((((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r53 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r18 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r18 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (D1 ≤ (-1 : Int)) →
  r71 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r71 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 E1 F1 D1) →
  (E1 = (-1 : Int) + B1) →
  (F1 = (-1 : Int) + C1) →
  r29 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r61 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 E1 F1 D1) →
  (E1 = (-1 : Int) + B1) →
  (F1 = (-1 : Int) + C1) →
  r29 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r18 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (D1 ≥ (1 : Int)) →
  r61 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r18 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (D1 = (0 : Int)) →
  r55 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r55 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r31 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r31 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r48 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r29 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r19 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r19 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (P ≤ (-1 : Int)) →
  r42 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r42 A B C D E F G H I J K L M N O P E1 F1 S T U V W X Y Z A1 B1 C1 D1) →
  (E1 = (-1 : Int) + Q) →
  (F1 = (-1 : Int) + R) →
  r66 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r21 A B C D E F G H I J K L M N O P E1 F1 S T U V W X Y Z A1 B1 C1 D1) →
  (E1 = (-1 : Int) + Q) →
  (F1 = (-1 : Int) + R) →
  r66 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r19 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (P ≥ (1 : Int)) →
  r21 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r19 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (P = (0 : Int)) →
  r44 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r44 A B C D E F G H I J K L M N O P E1 F1 S T U V W X Y Z A1 B1 C1 D1) →
  (E1 = (-1 : Int) * B1 + Q) →
  (F1 = (-1 : Int) * C1 + R) →
  r16 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r48 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r30 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))))) ∧
  (((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r30 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (U + (-1 : Int) * V ≤ (0 : Int)) →
  r32 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r32 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r33 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r30 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (U + (-1 : Int) * V ≥ (1 : Int)) →
  r50 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r33 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (Q + (-1 : Int) * R ≤ (-1 : Int)) →
  r6 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r33 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (Q + (-1 : Int) * R ≥ (1 : Int)) →
  r5 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r50 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r49)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r6 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r49) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r5 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1) →
  (True) →
  r49)))) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r49) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«36.c_000»
