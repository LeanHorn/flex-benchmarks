import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«04.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":183:1-183:12 (check-sat, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":18:1-27:2 (clause 1, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":28:1-38:2 (clause 2, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":39:1-49:2 (clause 3, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":50:1-60:2 (clause 4, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":61:1-71:2 (clause 5, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":72:1-82:2 (clause 6, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":83:1-93:2 (clause 7, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":94:1-104:2 (clause 8, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":105:1-115:2 (clause 9, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":116:1-126:2 (clause 10, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":127:1-137:2 (clause 11, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":138:1-148:2 (clause 12, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":149:1-159:2 (clause 13, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":160:1-170:2 (clause 14, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/04.c_000.smt2":171:1-181:2 (clause 15, command 29)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Prop),
  (∀ (A B v_2 v_3 : Int),
  (True) →
  (v_2 = A) →
  (v_3 = B) →
  r12 A B v_2 v_3) ∧
  ((∀ (A B C D E : Int),
  (r12 A B E D) →
  (C = (-50 : Int)) →
  r10 A B C D) ∧
  ((∀ (A B C D : Int),
  (r10 A B C D) →
  (True) →
  r9 A B C D) ∧
  ((∀ (A B C D : Int),
  (r9 A B C D) →
  (True) →
  r5 A B C D) ∧
  ((∀ (A B C D : Int),
  (r5 A B C D) →
  (True) →
  r6 A B C D) ∧
  ((∀ (A B C D : Int),
  (r1 A B C D) →
  (True) →
  r6 A B C D) ∧
  ((∀ (A B C D : Int),
  (r6 A B C D) →
  (True) →
  r0 A B C D) ∧
  ((∀ (A B C D : Int),
  (r0 A B C D) →
  (C ≤ (-1 : Int)) →
  r4 A B C D) ∧
  ((∀ (A B C D E F : Int),
  (r4 A B E F) →
  (E = (1 : Int) + C + (-1 : Int) * D) →
  (F = (-1 : Int) + D) →
  r1 A B C D) ∧
  ((∀ (A B C D : Int),
  (r0 A B C D) →
  (C ≥ (0 : Int)) →
  r3 A B C D) ∧
  ((∀ (A B C D : Int),
  (r3 A B C D) →
  (True) →
  r7 A B C D) ∧
  ((∀ (A B C D : Int),
  (r7 A B C D) →
  (True) →
  r2 A B C D) ∧
  ((∀ (A B C D : Int),
  (r2 A B C D) →
  (True) →
  r8 A B C D) ∧
  ((∀ (A B C D : Int),
  (r8 A B C D) →
  (D ≤ (0 : Int)) →
  r11 A B C D) ∧
  (∀ (A B C D : Int),
  (r11 A B C D) →
  (True) →
  False))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«04.c_000»
