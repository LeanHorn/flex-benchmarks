import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«32.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":355:1-355:12 (check-sat, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":26:1-35:2 (clause 1, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":36:1-46:2 (clause 2, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":47:1-57:2 (clause 3, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":58:1-68:2 (clause 4, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":69:1-79:2 (clause 5, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":80:1-90:2 (clause 6, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":91:1-101:2 (clause 7, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":102:1-112:2 (clause 8, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":113:1-123:2 (clause 9, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":124:1-134:2 (clause 10, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":135:1-145:2 (clause 11, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":146:1-156:2 (clause 12, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":157:1-167:2 (clause 13, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":168:1-178:2 (clause 14, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":179:1-189:2 (clause 15, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":190:1-200:2 (clause 16, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":201:1-211:2 (clause 17, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":212:1-222:2 (clause 18, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":223:1-233:2 (clause 19, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":234:1-244:2 (clause 20, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":245:1-255:2 (clause 21, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":256:1-266:2 (clause 22, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":267:1-277:2 (clause 23, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":278:1-288:2 (clause 24, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":289:1-299:2 (clause 25, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":300:1-310:2 (clause 26, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":311:1-321:2 (clause 27, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":322:1-332:2 (clause 28, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":333:1-343:2 (clause 29, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/32.c_000.smt2":344:1-353:2 (clause 30, command 52)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E v_5 v_6 v_7 v_8 v_9 : Int),
  (True) →
  (v_5 = A) →
  (v_6 = B) →
  (v_7 = C) →
  (v_8 = D) →
  (v_9 = E) →
  r18 A B C D E v_5 v_6 v_7 v_8 v_9) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r18 A B C D E K G L I M) →
  (J = (0 : Int)) →
  (I = H) →
  (F = (100 : Int)) →
  r16 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r16 A B C D E F G H I J) →
  (True) →
  r7 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r7 A B C D E F G H I J) →
  (True) →
  r10 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r10 A B C D E F G H I J) →
  (True) →
  r6 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r11 A B C D E F G H I J) →
  (True) →
  r6 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r6 A B C D E F G H I J) →
  (True) →
  r13 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r13 A B C D E F G H I J) →
  ((2 : Int) * F + (-1 : Int) * J ≥ (1 : Int)) →
  r20 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r20 A B C D E F G H I J) →
  (True) →
  r12 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r13 A B C D E F G H I J) →
  ((2 : Int) * F + (-1 : Int) * J ≤ (0 : Int)) →
  r17 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r17 A B C D E F G H I J) →
  (True) →
  r2 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r2 A B C D E F G H I J) →
  (True) →
  r15 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r12 A B C D E F G H I J) →
  (G ≤ (-1 : Int)) →
  r19 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r19 A B C D E F G K I J) →
  (K = (-1 : Int) + H) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r4 A B C D E F G K I J) →
  (K = (-1 : Int) + H) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r12 A B C D E F G H I J) →
  (G ≥ (1 : Int)) →
  r4 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r12 A B C D E F G H I J) →
  (G = (0 : Int)) →
  r1 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r1 A B C D E F G H K J) →
  (K = (-1 : Int) + I) →
  r8 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D E F K H I L) →
  (L = (-1 : Int) + J) →
  (K = (0 : Int)) →
  (G = (1 : Int)) →
  r11 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D E F L H I K) →
  (K = (-1 : Int) + J) →
  (L ≥ (1 : Int)) →
  (G = (0 : Int)) →
  r11 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D E F L H I K) →
  (K = (-1 : Int) + J) →
  (L ≤ (-1 : Int)) →
  (G = (0 : Int)) →
  r11 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r8 A B C D E F K H I L) →
  (L = (-1 : Int) + J) →
  (K = (0 : Int)) →
  (G = (1 : Int)) →
  r11 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r8 A B C D E F L H I K) →
  (K = (-1 : Int) + J) →
  (L ≥ (1 : Int)) →
  (G = (0 : Int)) →
  r11 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r8 A B C D E F L H I K) →
  (K = (-1 : Int) + J) →
  (L ≤ (-1 : Int)) →
  (G = (0 : Int)) →
  r11 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r15 A B C D E F G H I J) →
  (True) →
  r9 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r9 A B C D E F G H I J) →
  (H + (-1 : Int) * I ≤ (-1 : Int)) →
  r3 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r9 A B C D E F G H I J) →
  (H + (-1 : Int) * I ≥ (1 : Int)) →
  r14 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 A B C D E F G H I J) →
  (True) →
  r5) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r14 A B C D E F G H I J) →
  (True) →
  r5) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r5) →
  False)))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«32.c_000»
