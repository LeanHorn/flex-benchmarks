import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«37.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":371:1-371:12 (check-sat, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":31:1-40:2 (clause 1, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":41:1-51:2 (clause 2, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":52:1-62:2 (clause 3, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":63:1-73:2 (clause 4, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":74:1-84:2 (clause 5, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":85:1-95:2 (clause 6, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":96:1-106:2 (clause 7, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":107:1-117:2 (clause 8, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":118:1-128:2 (clause 9, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":129:1-139:2 (clause 10, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":140:1-150:2 (clause 11, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":151:1-161:2 (clause 12, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":162:1-172:2 (clause 13, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":173:1-183:2 (clause 14, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":184:1-194:2 (clause 15, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":195:1-205:2 (clause 16, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":206:1-216:2 (clause 17, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":217:1-227:2 (clause 18, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":228:1-238:2 (clause 19, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":239:1-249:2 (clause 20, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":250:1-260:2 (clause 21, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":261:1-271:2 (clause 22, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":272:1-282:2 (clause 23, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":283:1-293:2 (clause 24, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":294:1-304:2 (clause 25, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":305:1-315:2 (clause 26, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":316:1-326:2 (clause 27, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":327:1-337:2 (clause 28, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":338:1-348:2 (clause 29, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":349:1-359:2 (clause 30, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/37.c_000.smt2":360:1-369:2 (clause 31, command 58)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D v_4 v_5 v_6 v_7 : Int),
  (True) →
  (v_4 = A) →
  (v_5 = B) →
  (v_6 = C) →
  (v_7 = D) →
  r14 A B C D v_4 v_5 v_6 v_7) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r14 A B C D E I J H) →
  (G = (0 : Int)) →
  (F = (0 : Int)) →
  r11 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r11 A B C D E F G H) →
  (True) →
  r22 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r22 A B C D E F G H) →
  (True) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 A B C D E F G H) →
  (True) →
  r25 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r12 A B C D E F G H) →
  (True) →
  r25 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r25 A B C D E F G H) →
  (True) →
  r7 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r7 A B C D E F G H) →
  (E + (-1 : Int) * F ≥ (1 : Int)) →
  r19 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r19 A B C D E F G H) →
  (True) →
  r15 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r7 A B C D E F G H) →
  (E + (-1 : Int) * F ≤ (0 : Int)) →
  r23 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r23 A B C D E F G H) →
  (True) →
  r18 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r18 A B C D E F G H) →
  (True) →
  r24 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r15 A B C D E F G H) →
  (True) →
  r17 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r17 A B C D E F G H) →
  (True) →
  r16 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r16 A B C D E F G H) →
  (H ≤ (-1 : Int)) →
  r5 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r5 A B C D E F I H) →
  (F = G) →
  r3 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r21 A B C D E F I H) →
  (F = G) →
  r3 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r16 A B C D E F G H) →
  (H ≥ (1 : Int)) →
  r21 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r16 A B C D E F G H) →
  (H = (0 : Int)) →
  r20 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r20 A B C D E I G H) →
  (I = (-1 : Int) + F) →
  r12 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r3 A B C D E I G H) →
  (I = (-1 : Int) + F) →
  r12 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r24 A B C D E F G H) →
  (True) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 A B C D E F G H) →
  (E ≥ (1 : Int)) →
  r2 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 A B C D E F G H) →
  (True) →
  r9 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r9 A B C D E F G H) →
  (G ≥ (0 : Int)) →
  r6 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r6 A B C D E F G H) →
  (True) →
  r8 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r9 A B C D E F G H) →
  (G ≤ (-1 : Int)) →
  r4 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r8 A B C D E F G H) →
  (E + (-1 : Int) * G ≤ (0 : Int)) →
  r10 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r4 A B C D E F G H) →
  (True) →
  r13) ∧
  ((∀ (A B C D E F G H : Int),
  (r10 A B C D E F G H) →
  (True) →
  r13) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r13) →
  False))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«37.c_000»
