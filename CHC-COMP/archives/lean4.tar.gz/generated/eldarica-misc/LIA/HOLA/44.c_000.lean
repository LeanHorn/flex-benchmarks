import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«44.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":347:1-347:12 (check-sat, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":29:1-38:2 (clause 1, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":39:1-49:2 (clause 2, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":50:1-60:2 (clause 3, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":61:1-71:2 (clause 4, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":72:1-82:2 (clause 5, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":83:1-93:2 (clause 6, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":94:1-104:2 (clause 7, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":105:1-115:2 (clause 8, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":116:1-126:2 (clause 9, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":127:1-137:2 (clause 10, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":138:1-148:2 (clause 11, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":149:1-159:2 (clause 12, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":160:1-170:2 (clause 13, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":171:1-181:2 (clause 14, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":182:1-192:2 (clause 15, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":193:1-203:2 (clause 16, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":204:1-214:2 (clause 17, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":215:1-225:2 (clause 18, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":226:1-236:2 (clause 19, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":237:1-247:2 (clause 20, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":248:1-258:2 (clause 21, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":259:1-269:2 (clause 22, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":270:1-280:2 (clause 23, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":281:1-291:2 (clause 24, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":292:1-302:2 (clause 25, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":303:1-313:2 (clause 26, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":314:1-324:2 (clause 27, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":325:1-335:2 (clause 28, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/44.c_000.smt2":336:1-345:2 (clause 29, command 54)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F v_6 v_7 v_8 v_9 v_10 v_11 : Int),
  (True) →
  (v_6 = A) →
  (v_7 = B) →
  (v_8 = C) →
  (v_9 = D) →
  (v_10 = E) →
  (v_11 = F) →
  r6 A B C D E F v_6 v_7 v_8 v_9 v_10 v_11) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r6 A B C D E F G H I M K L) →
  (J = (0 : Int)) →
  r17 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r17 A B C D E F G H I J K L) →
  (True) →
  r8 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r8 A B C D E F G H I J K L) →
  (H = (1 : Int)) →
  r1 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r1 A B C D E F G H I J M L) →
  (K = (1 : Int)) →
  r13 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r8 A B C D E F G H I J K L) →
  (H ≤ (0 : Int)) →
  r23 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r23 A B C D E F G H I J M L) →
  (K = (2 : Int)) →
  r5 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r2 A B C D E F G H I J M L) →
  (K = (2 : Int)) →
  r5 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r8 A B C D E F G H I J K L) →
  (H ≥ (2 : Int)) →
  r2 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r13 A B C D E F G H M J K L) →
  (I = (0 : Int)) →
  r11 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r5 A B C D E F G H M J K L) →
  (I = (0 : Int)) →
  r11 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r11 A B C D E F G H I J K L) →
  (True) →
  r9 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r9 A B C D E F G H I J K L) →
  (True) →
  r18 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r18 A B C D E F G H I J K L) →
  (True) →
  r3 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r10 A B C D E F G H I J K L) →
  (True) →
  r3 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A B C D E F G H I J K L) →
  (True) →
  r16 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r16 A B C D E F G H I J K L) →
  (G + (-1 : Int) * I ≥ (0 : Int)) →
  r20 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r20 A B C D E F G H M N K L) →
  (M = (-1 : Int) + I) →
  (N = (-1 : Int) * K + J) →
  r10 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r16 A B C D E F G H I J K L) →
  (G + (-1 : Int) * I ≤ (-1 : Int)) →
  r4 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r4 A B C D E F G H I J K L) →
  (True) →
  r19 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r19 A B C D E F G H I J K L) →
  (True) →
  r21 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r21 A B C D E F G H I J K L) →
  (True) →
  r22 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r22 A B C D E F G H I J K L) →
  (H = (1 : Int)) →
  r0 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D E F G H I J K L) →
  (True) →
  r12 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r12 A B C D E F G H I J K L) →
  (I + (-1 : Int) * J ≥ (1 : Int)) →
  r7 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r12 A B C D E F G H I J K L) →
  (I + (-1 : Int) * J ≤ (-1 : Int)) →
  r15 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r7 A B C D E F G H I J K L) →
  (True) →
  r14) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r15 A B C D E F G H I J K L) →
  (True) →
  r14) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r14) →
  False))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«44.c_000»
