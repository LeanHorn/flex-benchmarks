import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«25.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":537:1-537:12 (check-sat, command 84)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":42:1-51:2 (clause 1, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":52:1-62:2 (clause 2, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":63:1-73:2 (clause 3, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":74:1-84:2 (clause 4, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":85:1-95:2 (clause 5, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":96:1-106:2 (clause 6, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":107:1-117:2 (clause 7, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":118:1-128:2 (clause 8, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":129:1-139:2 (clause 9, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":140:1-150:2 (clause 10, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":151:1-161:2 (clause 11, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":162:1-172:2 (clause 12, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":173:1-183:2 (clause 13, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":184:1-194:2 (clause 14, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":195:1-205:2 (clause 15, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":206:1-216:2 (clause 16, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":217:1-227:2 (clause 17, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":228:1-238:2 (clause 18, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":239:1-249:2 (clause 19, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":250:1-260:2 (clause 20, command 58)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":261:1-271:2 (clause 21, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":272:1-282:2 (clause 22, command 60)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":283:1-293:2 (clause 23, command 61)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":294:1-304:2 (clause 24, command 62)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":305:1-315:2 (clause 25, command 63)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":316:1-326:2 (clause 26, command 64)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":327:1-337:2 (clause 27, command 65)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":338:1-348:2 (clause 28, command 66)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":349:1-359:2 (clause 29, command 67)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":360:1-370:2 (clause 30, command 68)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":371:1-381:2 (clause 31, command 69)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":382:1-392:2 (clause 32, command 70)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":393:1-403:2 (clause 33, command 71)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":404:1-414:2 (clause 34, command 72)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":415:1-425:2 (clause 35, command 73)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":426:1-436:2 (clause 36, command 74)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":437:1-447:2 (clause 37, command 75)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":448:1-458:2 (clause 38, command 76)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":459:1-469:2 (clause 39, command 77)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":470:1-480:2 (clause 40, command 78)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":481:1-491:2 (clause 41, command 79)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":492:1-502:2 (clause 42, command 80)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":503:1-513:2 (clause 43, command 81)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":514:1-524:2 (clause 44, command 82)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/25.c_000.smt2":525:1-535:2 (clause 45, command 83)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r28 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r29 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r30 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r31 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r32 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r33 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r34 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r35 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r36 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F v_6 v_7 v_8 v_9 v_10 v_11 : Int),
  (True) →
  (v_6 = A) →
  (v_7 = B) →
  (v_8 = C) →
  (v_9 = D) →
  (v_10 = E) →
  (v_11 = F) →
  r9 A B C D E F v_6 v_7 v_8 v_9 v_10 v_11) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r9 A B C D E F M N O P K L) →
  (I = (0 : Int)) →
  (H = (0 : Int)) →
  (G = (0 : Int)) →
  (J = (0 : Int)) →
  r26 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r26 A B C D E F G H I J K L) →
  (True) →
  r14 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r14 A B C D E F G H I J K L) →
  (True) →
  r1 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D E F G H I J K L) →
  (True) →
  r20 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r18 A B C D E F G H I J K L) →
  (True) →
  r20 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r11 A B C D E F G H I J K L) →
  (True) →
  r20 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r20 A B C D E F G H I J K L) →
  (True) →
  r35 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r35 A B C D E F G H I J K L) →
  (True) →
  r7 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r7 A B C D E F G H I J K L) →
  (True) →
  r2 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D E F G H I J K L) →
  (L ≤ (-1 : Int)) →
  r17 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r17 A B C D E F G H I J K L) →
  (True) →
  r15 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r28 A B C D E F G H I J K L) →
  (True) →
  r15 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D E F G H I J K L) →
  (L ≥ (1 : Int)) →
  r28 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D E F G H I J K L) →
  (L = (0 : Int)) →
  r3 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A B C D E F G H I J K L) →
  (True) →
  r23 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r23 A B C D E F G H I J K L) →
  (True) →
  r32 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r15 A B C D E F G H I J K L) →
  (True) →
  r16 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r16 A B C D E F G H I J K L) →
  (True) →
  r6 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r4 A B C D E F G H I J K L) →
  (True) →
  r6 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r10 A B C D E F G H I J K L) →
  (True) →
  r6 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r6 A B C D E F G H I J K L) →
  (True) →
  r30 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r30 A B C D E F G H I J K L) →
  (True) →
  r33 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r33 A B C D E F G H I J K L) →
  (True) →
  r34 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r34 A B C D E F G H I J K L) →
  (K ≤ (-1 : Int)) →
  r0 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D E F G H I J K L) →
  (True) →
  r19 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r5 A B C D E F G H I J K L) →
  (True) →
  r19 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r34 A B C D E F G H I J K L) →
  (K ≥ (1 : Int)) →
  r5 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r34 A B C D E F G H I J K L) →
  (K = (0 : Int)) →
  r8 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r8 A B C D E F G H I J K L) →
  (True) →
  r21 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r21 A B C D E F G H I J K L) →
  (True) →
  r12 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r19 A B C D E F G H I J K L) →
  (G = H) →
  r22 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r22 A B C D E F G H M J K L) →
  (M = (-1 : Int) + I) →
  r4 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r19 A B C D E F G H I J K L) →
  (G + (-1 : Int) * H ≤ (-1 : Int)) →
  r27 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r27 A B C D E F G H I M K L) →
  (M = (-1 : Int) + J) →
  r10 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r29 A B C D E F G H I M K L) →
  (M = (-1 : Int) + J) →
  r10 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r19 A B C D E F G H I J K L) →
  (G + (-1 : Int) * H ≥ (1 : Int)) →
  r29 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r12 A B C D E F G H I J K L) →
  (True) →
  r31 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r31 A B C D E F G H I J K L) →
  (I + (-1 : Int) * J ≥ (0 : Int)) →
  r36 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r36 A B C D E F M N I J K L) →
  (M = (-1 : Int) + G) →
  (N = (-1 : Int) + H) →
  r18 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r31 A B C D E F G H I J K L) →
  (I + (-1 : Int) * J ≤ (-1 : Int)) →
  r13 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r13 A B C D E F G M I J K L) →
  (M = (-1 : Int) + H) →
  r11 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r32 A B C D E F G H I J K L) →
  (True) →
  r24 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r24 A B C D E F G H I J K L) →
  (I + (-1 : Int) * J ≤ (-1 : Int)) →
  r25 A B C D E F G H I J K L) ∧
  (∀ (A B C D E F G H I J K L : Int),
  (r25 A B C D E F G H I J K L) →
  (True) →
  False))))))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«25.c_000»
