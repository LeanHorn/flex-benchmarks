import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«17.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":314:1-314:12 (check-sat, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":28:1-37:2 (clause 1, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":38:1-48:2 (clause 2, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":49:1-59:2 (clause 3, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":60:1-70:2 (clause 4, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":71:1-81:2 (clause 5, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":82:1-92:2 (clause 6, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":93:1-103:2 (clause 7, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":104:1-114:2 (clause 8, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":115:1-125:2 (clause 9, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":126:1-136:2 (clause 10, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":137:1-147:2 (clause 11, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":148:1-158:2 (clause 12, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":159:1-169:2 (clause 13, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":170:1-180:2 (clause 14, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":181:1-191:2 (clause 15, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":192:1-202:2 (clause 16, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":203:1-213:2 (clause 17, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":214:1-224:2 (clause 18, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":225:1-235:2 (clause 19, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":236:1-246:2 (clause 20, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":247:1-257:2 (clause 21, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":258:1-268:2 (clause 22, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":269:1-279:2 (clause 23, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":280:1-290:2 (clause 24, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":291:1-301:2 (clause 25, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/17.c_000.smt2":302:1-312:2 (clause 26, command 50)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D v_4 v_5 v_6 v_7 : Int),
  (True) →
  (v_4 = A) →
  (v_5 = B) →
  (v_6 = C) →
  (v_7 = D) →
  r10 A B C D v_4 v_5 v_6 v_7) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r10 A B C D E I J H) →
  (G = (1 : Int)) →
  (F = (1 : Int)) →
  r7 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r7 A B C D E F G H) →
  (True) →
  r19 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r19 A B C D E F G H) →
  (True) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 A B C D E F G H) →
  (True) →
  r22 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r6 A B C D E F G H) →
  (True) →
  r22 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r22 A B C D E F G H) →
  (True) →
  r5 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r5 A B C D E F G H) →
  (E + (-1 : Int) * G ≥ (1 : Int)) →
  r16 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r16 A B C D E F G I) →
  (H = (0 : Int)) →
  r11 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r5 A B C D E F G H) →
  (E + (-1 : Int) * G ≤ (0 : Int)) →
  r20 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r20 A B C D E F G H) →
  (True) →
  r14 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r14 A B C D E F G H) →
  (True) →
  r21 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r11 A B C D E F G H) →
  (True) →
  r13 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r13 A B C D E F G H) →
  (True) →
  r12 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r12 A B C D E F G H) →
  (True) →
  r4 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r17 A B C D E F G H) →
  (True) →
  r4 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r4 A B C D E F G H) →
  (True) →
  r3 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r3 A B C D E F G H) →
  (G + (-1 : Int) * H ≥ (1 : Int)) →
  r18 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r18 A B C D E I G J) →
  (I = (-1 : Int) + (-1 : Int) * G + F + H) →
  (J = (-1 : Int) + H) →
  r17 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r3 A B C D E F G H) →
  (G + (-1 : Int) * H ≤ (0 : Int)) →
  r8 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r8 A B C D E F G H) →
  (True) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 A B C D E F G H) →
  (True) →
  r2 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r2 A B C D E F I H) →
  (I = (-1 : Int) + G) →
  r6 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r21 A B C D E F G H) →
  (True) →
  r9 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r9 A B C D E F G H) →
  (E + (-1 : Int) * F ≥ (1 : Int)) →
  r15 A B C D E F G H) ∧
  (∀ (A B C D E F G H : Int),
  (r15 A B C D E F G H) →
  (True) →
  False)))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«17.c_000»
