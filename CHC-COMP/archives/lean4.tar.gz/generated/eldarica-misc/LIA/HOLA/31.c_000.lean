import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«31.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":604:1-604:12 (check-sat, command 95)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":48:1-64:2 (clause 1, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":65:1-75:2 (clause 2, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":76:1-86:2 (clause 3, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":87:1-97:2 (clause 4, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":98:1-108:2 (clause 5, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":109:1-119:2 (clause 6, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":120:1-130:2 (clause 7, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":131:1-141:2 (clause 8, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":142:1-152:2 (clause 9, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":153:1-163:2 (clause 10, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":164:1-174:2 (clause 11, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":175:1-185:2 (clause 12, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":186:1-196:2 (clause 13, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":197:1-207:2 (clause 14, command 58)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":208:1-218:2 (clause 15, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":219:1-229:2 (clause 16, command 60)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":230:1-240:2 (clause 17, command 61)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":241:1-251:2 (clause 18, command 62)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":252:1-262:2 (clause 19, command 63)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":263:1-273:2 (clause 20, command 64)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":274:1-284:2 (clause 21, command 65)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":285:1-295:2 (clause 22, command 66)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":296:1-306:2 (clause 23, command 67)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":307:1-317:2 (clause 24, command 68)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":318:1-328:2 (clause 25, command 69)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":329:1-339:2 (clause 26, command 70)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":340:1-350:2 (clause 27, command 71)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":351:1-361:2 (clause 28, command 72)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":362:1-372:2 (clause 29, command 73)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":373:1-383:2 (clause 30, command 74)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":384:1-394:2 (clause 31, command 75)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":395:1-405:2 (clause 32, command 76)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":406:1-416:2 (clause 33, command 77)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":417:1-427:2 (clause 34, command 78)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":428:1-438:2 (clause 35, command 79)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":439:1-449:2 (clause 36, command 80)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":450:1-460:2 (clause 37, command 81)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":461:1-471:2 (clause 38, command 82)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":472:1-482:2 (clause 39, command 83)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":483:1-493:2 (clause 40, command 84)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":494:1-504:2 (clause 41, command 85)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":505:1-515:2 (clause 42, command 86)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":516:1-526:2 (clause 43, command 87)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":527:1-537:2 (clause 44, command 88)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":538:1-548:2 (clause 45, command 89)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":549:1-559:2 (clause 46, command 90)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":560:1-570:2 (clause 47, command 91)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":571:1-581:2 (clause 48, command 92)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":582:1-592:2 (clause 49, command 93)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/31.c_000.smt2":593:1-602:2 (clause 50, command 94)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r28 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r29 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r30 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r31 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r32 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r33 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r34 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r35 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r36 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r37 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r38 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r39 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r40 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r41 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r42 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G v_7 v_8 v_9 v_10 v_11 v_12 v_13 : Int),
  (True) →
  (v_7 = A) →
  (v_8 = B) →
  (v_9 = C) →
  (v_10 = D) →
  (v_11 = E) →
  (v_12 = F) →
  (v_13 = G) →
  r21 A B C D E F G v_7 v_8 v_9 v_10 v_11 v_12 v_13) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r21 A B C D E F G H I J K L M N) →
  (True) →
  r32 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r32 A B C D E F G H I J K L M N) →
  (K + (-1 : Int) * L ≥ (2 : Int)) →
  r31 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r31 A B C D E F G O I J K L M N) →
  (H = (0 : Int)) →
  r5 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r5 A B C D E F G H I J K L M N) →
  (True) →
  r41 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r41 A B C D E F G H I J K L M N) →
  (True) →
  r8 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r8 A B C D E F G H I J K L M N) →
  (True) →
  r23 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r11 A B C D E F G H I J K L M N) →
  (True) →
  r23 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r23 A B C D E F G H I J K L M N) →
  (True) →
  r25 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r25 A B C D E F G H I J K L M N) →
  (H + (-1 : Int) * K ≤ (-1 : Int)) →
  r12 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r12 A B C D E F G H O J K L M N) →
  (H = I) →
  r10 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r10 A B C D E F G H I J K L M N) →
  (True) →
  r18 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r18 A B C D E F G H I J K L M N) →
  (True) →
  r1 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r1 A B C D E F G H I J K L M N) →
  (True) →
  r28 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r22 A B C D E F G H I J K L M N) →
  (True) →
  r28 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r17 A B C D E F G H I J K L M N) →
  (True) →
  r28 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r28 A B C D E F G H I J K L M N) →
  (True) →
  r42 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r42 A B C D E F G H I J K L M N) →
  (I + (-1 : Int) * L ≤ (-1 : Int)) →
  r29 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r29 A B C D E F G H I J K L M N) →
  (True) →
  r39 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r42 A B C D E F G H I J K L M N) →
  (I + (-1 : Int) * L ≥ (0 : Int)) →
  r24 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r24 A B C D E F G H I J K L M N) →
  (True) →
  r16 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r16 A B C D E F G H I J K L M N) →
  (True) →
  r14 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r39 A B C D E F G H I J K L M N) →
  (True) →
  r38 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r38 A B C D E F G H I J K L M N) →
  (True) →
  r40 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r40 A B C D E F G H I J K L M N) →
  (M ≤ (-1 : Int)) →
  r36 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r36 A B C D E F G H I J K L M N) →
  (True) →
  r2 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r34 A B C D E F G H I J K L M N) →
  (True) →
  r2 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r40 A B C D E F G H I J K L M N) →
  (M ≥ (1 : Int)) →
  r34 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r40 A B C D E F G H I J K L M N) →
  (M = (0 : Int)) →
  r35 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r35 A B C D E F G H I J K L M N) →
  (True) →
  r19 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r2 A B C D E F G H I J K L M N) →
  (I ≤ (-1 : Int)) →
  r26 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r2 A B C D E F G H I J K L M N) →
  (I ≥ (0 : Int)) →
  r6 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r6 A B C D E F G H O P K L M N) →
  (J = (0 : Int)) →
  (O = (-1 : Int) + I) →
  r27 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r27 A B C D E F G H I J K L M N) →
  (True) →
  r9 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r9 A B C D E F G H I J K L M N) →
  (True) →
  r13 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r13 A B C D E F G H I J K L M N) →
  (True) →
  r3 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r4 A B C D E F G H I J K L M N) →
  (True) →
  r3 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r3 A B C D E F G H I J K L M N) →
  (True) →
  r37 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r37 A B C D E F G H I J K L M N) →
  (I + (-1 : Int) * J ≥ (1 : Int)) →
  r30 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r30 A B C D E F G H I O K L M N) →
  (O = (-1 : Int) + J) →
  r4 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r37 A B C D E F G H I J K L M N) →
  (I + (-1 : Int) * J ≤ (0 : Int)) →
  r7 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r7 A B C D E F G H I J K L M N) →
  (True) →
  r0 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r0 A B C D E F G H I J K L M N) →
  (True) →
  r22 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r19 A B C D E F G H I J K L M N) →
  (H + (-1 : Int) * I + (-1 : Int) * K ≥ (5 : Int)) →
  r20 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r19 A B C D E F G H I J K L M N) →
  (H + (-1 : Int) * I + (-1 : Int) * K ≤ (4 : Int)) →
  r33 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r33 A B C D E F G H O J K L M N) →
  (O = (-2 : Int) + I) →
  r17 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r14 A B C D E F G O I J K L M N) →
  (O = (-4 : Int) + H) →
  r11 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r26 A B C D E F G H I J K L M N) →
  (True) →
  r15) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r20 A B C D E F G H I J K L M N) →
  (True) →
  r15) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r15) →
  False)))))))))))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«31.c_000»
