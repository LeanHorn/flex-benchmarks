import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«35.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":241:1-241:12 (check-sat, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":22:1-31:2 (clause 1, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":32:1-42:2 (clause 2, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":43:1-53:2 (clause 3, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":54:1-64:2 (clause 4, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":65:1-75:2 (clause 5, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":76:1-86:2 (clause 6, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":87:1-97:2 (clause 7, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":98:1-108:2 (clause 8, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":109:1-119:2 (clause 9, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":120:1-130:2 (clause 10, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":131:1-141:2 (clause 11, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":142:1-152:2 (clause 12, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":153:1-163:2 (clause 13, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":164:1-174:2 (clause 14, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":175:1-185:2 (clause 15, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":186:1-196:2 (clause 16, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":197:1-207:2 (clause 17, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":208:1-218:2 (clause 18, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":219:1-229:2 (clause 19, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/35.c_000.smt2":230:1-239:2 (clause 20, command 38)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Prop),
  ∃ (r9 : Prop),
  ∃ (r10 : Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Prop),
  (∀ (A B v_2 v_3 : Int),
  (True) →
  (v_2 = A) →
  (v_3 = B) →
  r16 A B v_2 v_3) ∧
  ((∀ (A B C D E : Int),
  (r16 A B C E) →
  (D = (0 : Int)) →
  r14 A B C D) ∧
  ((∀ (A B C D : Int),
  (r14 A B C D) →
  (True) →
  r13 A B C D) ∧
  ((∀ (A B C D : Int),
  (r13 A B C D) →
  (True) →
  r8 A B C D) ∧
  ((∀ (A B C D : Int),
  (r8 A B C D) →
  (True) →
  r10 A B C D) ∧
  ((∀ (A B C D : Int),
  (r1 A B C D) →
  (True) →
  r10 A B C D) ∧
  ((∀ (A B C D : Int),
  (r10 A B C D) →
  (True) →
  r0 A B C D) ∧
  ((∀ (A B C D : Int),
  (r0 A B C D) →
  (C + (-1 : Int) * D ≥ (1 : Int)) →
  r6 A B C D) ∧
  ((∀ (A B C D E : Int),
  (r6 A B C E) →
  (E = (-1 : Int) + D) →
  r1 A B C D) ∧
  ((∀ (A B C D : Int),
  (r0 A B C D) →
  (C + (-1 : Int) * D ≤ (0 : Int)) →
  r4 A B C D) ∧
  ((∀ (A B C D : Int),
  (r4 A B C D) →
  (True) →
  r11 A B C D) ∧
  ((∀ (A B C D : Int),
  (r11 A B C D) →
  (True) →
  r2 A B C D) ∧
  ((∀ (A B C D : Int),
  (r2 A B C D) →
  (True) →
  r12 A B C D) ∧
  ((∀ (A B C D : Int),
  (r12 A B C D) →
  (C ≥ (1 : Int)) →
  r15 A B C D) ∧
  ((∀ (A B C D : Int),
  (r15 A B C D) →
  (True) →
  r7 A B C D) ∧
  ((∀ (A B C D : Int),
  (r7 A B C D) →
  (C + (-1 : Int) * D ≥ (1 : Int)) →
  r3 A B C D) ∧
  ((∀ (A B C D : Int),
  (r7 A B C D) →
  (C + (-1 : Int) * D ≤ (-1 : Int)) →
  r5 A B C D) ∧
  ((∀ (A B C D : Int),
  (r3 A B C D) →
  (True) →
  r9) ∧
  ((∀ (A B C D : Int),
  (r5 A B C D) →
  (True) →
  r9) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r9) →
  False)))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«35.c_000»
