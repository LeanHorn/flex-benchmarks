import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«07.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":367:1-367:12 (check-sat, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":30:1-47:2 (clause 1, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":48:1-58:2 (clause 2, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":59:1-69:2 (clause 3, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":70:1-80:2 (clause 4, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":81:1-91:2 (clause 5, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":92:1-102:2 (clause 6, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":103:1-113:2 (clause 7, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":114:1-124:2 (clause 8, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":125:1-135:2 (clause 9, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":136:1-146:2 (clause 10, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":147:1-157:2 (clause 11, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":158:1-168:2 (clause 12, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":169:1-179:2 (clause 13, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":180:1-190:2 (clause 14, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":191:1-201:2 (clause 15, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":202:1-212:2 (clause 16, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":213:1-223:2 (clause 17, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":224:1-234:2 (clause 18, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":235:1-245:2 (clause 19, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":246:1-256:2 (clause 20, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":257:1-267:2 (clause 21, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":268:1-278:2 (clause 22, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":279:1-289:2 (clause 23, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":290:1-300:2 (clause 24, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":301:1-311:2 (clause 25, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":312:1-322:2 (clause 26, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":323:1-333:2 (clause 27, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":334:1-344:2 (clause 28, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":345:1-355:2 (clause 29, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/07.c_000.smt2":356:1-365:2 (clause 30, command 56)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H v_8 v_9 v_10 v_11 v_12 v_13 v_14 v_15 : Int),
  (True) →
  (v_8 = A) →
  (v_9 = B) →
  (v_10 = C) →
  (v_11 = D) →
  (v_12 = E) →
  (v_13 = F) →
  (v_14 = G) →
  (v_15 = H) →
  r16 A B C D E F G H v_8 v_9 v_10 v_11 v_12 v_13 v_14 v_15) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r16 A B C D E F G H I J K L M N O P) →
  (True) →
  r24 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r24 A B C D E F G H I J K L M N O P) →
  (L ≥ (0 : Int)) →
  r13 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r13 A B C D E F G H I J Q L R S O P) →
  (N = (0 : Int)) →
  (M = (0 : Int)) →
  (K = (0 : Int)) →
  r8 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r8 A B C D E F G H I J K L M N O P) →
  (True) →
  r19 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r19 A B C D E F G H I J K L M N O P) →
  (True) →
  r15 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r15 A B C D E F G H I J K L M N O P) →
  (True) →
  r20 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r0 A B C D E F G H I J K L M N O P) →
  (True) →
  r20 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r20 A B C D E F G H I J K L M N O P) →
  (True) →
  r6 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r6 A B C D E F G H I J K L M N O P) →
  (K + (-1 : Int) * L ≤ (-1 : Int)) →
  r23 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r23 A B C D E F G H I J K L M N O P) →
  (True) →
  r1 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r6 A B C D E F G H I J K L M N O P) →
  (K + (-1 : Int) * L ≥ (0 : Int)) →
  r10 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r10 A B C D E F G H I J K L M N O P) →
  (True) →
  r18 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r18 A B C D E F G H I J K L M N O P) →
  (True) →
  r11 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r1 A B C D E F G H I J K L M N O P) →
  (True) →
  r17 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r17 A B C D E F G H I J K L M N O P) →
  (True) →
  r3 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r3 A B C D E F G H I J K L M N O P) →
  (O ≤ (-1 : Int)) →
  r7 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r7 A B C D E F G H I J K L Q R O P) →
  (Q = (-1 : Int) + M) →
  (R = (-2 : Int) + N) →
  r14 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r22 A B C D E F G H I J K L Q R O P) →
  (Q = (-1 : Int) + M) →
  (R = (-2 : Int) + N) →
  r14 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r3 A B C D E F G H I J K L M N O P) →
  (O ≥ (1 : Int)) →
  r22 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r3 A B C D E F G H I J K L M N O P) →
  (O = (0 : Int)) →
  r21 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r21 A B C D E F G H I J K L Q R O P) →
  (Q = (-2 : Int) + M) →
  (R = (-1 : Int) + N) →
  r5 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  (r14 A B C D E F G H I J Q L M N O P) →
  (Q = (-1 : Int) + K) →
  r0 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  (r5 A B C D E F G H I J Q L M N O P) →
  (Q = (-1 : Int) + K) →
  r0 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r11 A B C D E F G H I J K L M N O P) →
  (True) →
  r2 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r2 A B C D E F G H I J K L M N O P) →
  ((3 : Int) * L + (-1 : Int) * M + (-1 : Int) * N ≥ (1 : Int)) →
  r4 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r2 A B C D E F G H I J K L M N O P) →
  ((3 : Int) * L + (-1 : Int) * M + (-1 : Int) * N ≤ (-1 : Int)) →
  r9 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r4 A B C D E F G H I J K L M N O P) →
  (True) →
  r12) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r9 A B C D E F G H I J K L M N O P) →
  (True) →
  r12) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r12) →
  False)))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«07.c_000»
