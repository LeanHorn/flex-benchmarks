import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«45.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":929:1-929:12 (check-sat, command 141)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":67:1-86:2 (clause 1, command 64)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":87:1-97:2 (clause 2, command 65)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":98:1-108:2 (clause 3, command 66)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":109:1-119:2 (clause 4, command 67)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":120:1-130:2 (clause 5, command 68)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":131:1-141:2 (clause 6, command 69)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":142:1-152:2 (clause 7, command 70)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":153:1-163:2 (clause 8, command 71)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":164:1-174:2 (clause 9, command 72)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":175:1-185:2 (clause 10, command 73)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":186:1-196:2 (clause 11, command 74)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":197:1-210:2 (clause 12, command 75)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":211:1-224:2 (clause 13, command 76)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":225:1-235:2 (clause 14, command 77)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":236:1-246:2 (clause 15, command 78)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":247:1-257:2 (clause 16, command 79)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":258:1-268:2 (clause 17, command 80)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":269:1-279:2 (clause 18, command 81)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":280:1-290:2 (clause 19, command 82)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":291:1-301:2 (clause 20, command 83)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":302:1-312:2 (clause 21, command 84)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":313:1-323:2 (clause 22, command 85)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":324:1-334:2 (clause 23, command 86)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":335:1-345:2 (clause 24, command 87)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":346:1-356:2 (clause 25, command 88)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":357:1-367:2 (clause 26, command 89)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":368:1-378:2 (clause 27, command 90)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":379:1-389:2 (clause 28, command 91)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":390:1-400:2 (clause 29, command 92)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":401:1-411:2 (clause 30, command 93)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":412:1-422:2 (clause 31, command 94)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":423:1-433:2 (clause 32, command 95)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":434:1-444:2 (clause 33, command 96)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":445:1-455:2 (clause 34, command 97)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":456:1-466:2 (clause 35, command 98)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":467:1-477:2 (clause 36, command 99)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":478:1-488:2 (clause 37, command 100)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":489:1-499:2 (clause 38, command 101)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":500:1-510:2 (clause 39, command 102)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":511:1-521:2 (clause 40, command 103)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":522:1-532:2 (clause 41, command 104)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":533:1-543:2 (clause 42, command 105)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":544:1-554:2 (clause 43, command 106)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":555:1-565:2 (clause 44, command 107)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":566:1-576:2 (clause 45, command 108)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":577:1-587:2 (clause 46, command 109)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":588:1-598:2 (clause 47, command 110)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":599:1-609:2 (clause 48, command 111)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":610:1-620:2 (clause 49, command 112)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":621:1-631:2 (clause 50, command 113)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":632:1-642:2 (clause 51, command 114)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":643:1-653:2 (clause 52, command 115)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":654:1-664:2 (clause 53, command 116)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":665:1-675:2 (clause 54, command 117)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":676:1-686:2 (clause 55, command 118)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":687:1-697:2 (clause 56, command 119)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":698:1-708:2 (clause 57, command 120)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":709:1-719:2 (clause 58, command 121)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":720:1-730:2 (clause 59, command 122)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":731:1-741:2 (clause 60, command 123)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":742:1-752:2 (clause 61, command 124)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":753:1-763:2 (clause 62, command 125)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":764:1-774:2 (clause 63, command 126)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":775:1-785:2 (clause 64, command 127)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":786:1-796:2 (clause 65, command 128)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":797:1-807:2 (clause 66, command 129)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":808:1-818:2 (clause 67, command 130)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":819:1-829:2 (clause 68, command 131)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":830:1-840:2 (clause 69, command 132)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":841:1-851:2 (clause 70, command 133)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":852:1-862:2 (clause 71, command 134)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":863:1-873:2 (clause 72, command 135)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":874:1-884:2 (clause 73, command 136)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":885:1-895:2 (clause 74, command 137)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":896:1-906:2 (clause 75, command 138)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":907:1-917:2 (clause 76, command 139)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/45.c_000.smt2":918:1-927:2 (clause 77, command 140)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r28 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r29 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r30 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r31 : Prop),
  ∃ (r32 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r33 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r34 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r35 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r36 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r37 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r38 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r39 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r40 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r41 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r42 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r43 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r44 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r45 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r46 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r47 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r48 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r49 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r50 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r51 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r52 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r53 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r54 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r55 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r56 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r57 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r58 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r59 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r60 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r61 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (((((((∀ (A B C D E F G H I J v_10 v_11 v_12 v_13 v_14 v_15 v_16 v_17 v_18 v_19 : Int),
  (True) →
  (v_10 = A) →
  (v_11 = B) →
  (v_12 = C) →
  (v_13 = D) →
  (v_14 = E) →
  (v_15 = F) →
  (v_16 = G) →
  (v_17 = H) →
  (v_18 = I) →
  (v_19 = J) →
  r23 A B C D E F G H I J v_10 v_11 v_12 v_13 v_14 v_15 v_16 v_17 v_18 v_19) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X : Int),
  (r23 A B C D E F G H I J K U V W X P Q R S T) →
  (M = (0 : Int)) →
  (L = (0 : Int)) →
  (O = (0 : Int)) →
  (N = (0 : Int)) →
  r30 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r30 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r50 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r50 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r10 A B C D E F G H I J K L M N O P Q R S T))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r10 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r12 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r24 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r12 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r56 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r12 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r12 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r55 A B C D E F G H I J K L M N O P Q R S T)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r55 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r49 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r49 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r41 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r41 A B C D E F G H I J K L M N O P Q R S T) →
  (P ≤ (-1 : Int)) →
  r36 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X : Int),
  (r36 A B C D E F G H I J K U W X V P Q R S T) →
  (W = (-1 : Int) + M) →
  (V = (-1 : Int) * L + O) →
  (U = (-1 : Int) + L) →
  (X = (-1 : Int) * M + N) →
  r61 A B C D E F G H I J K L M N O P Q R S T))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X : Int),
  (r32 A B C D E F G H I J K U W X V P Q R S T) →
  (W = (-1 : Int) + M) →
  (V = (-1 : Int) * L + O) →
  (U = (-1 : Int) + L) →
  (X = (-1 : Int) * M + N) →
  r61 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r41 A B C D E F G H I J K L M N O P Q R S T) →
  (P ≥ (1 : Int)) →
  r32 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r41 A B C D E F G H I J K L M N O P Q R S T) →
  (P = (0 : Int)) →
  r3 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r3 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r60 A B C D E F G H I J K L M N O P Q R S T))))) ∧
  (((((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r60 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r48 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r61 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r21 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r21 A B C D E F G H I J K L M N O P Q R S T) →
  (K ≤ (-1 : Int)) →
  r51 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r51 A B C D E F G H I J K L M U O P Q R S T) →
  (U = (-1 : Int) + N) →
  r56 A B C D E F G H I J K L M N O P Q R S T))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r47 A B C D E F G H I J K L M U O P Q R S T) →
  (U = (-1 : Int) + N) →
  r56 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r21 A B C D E F G H I J K L M N O P Q R S T) →
  (K ≥ (1 : Int)) →
  r47 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r21 A B C D E F G H I J K L M N O P Q R S T) →
  (K = (0 : Int)) →
  r24 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r48 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r7 A B C D E F G H I J K L M N O P Q R S T)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r7 A B C D E F G H I J K L M N O P Q R S T) →
  (N + (-1 : Int) * O ≥ (0 : Int)) →
  r8 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r8 A B C D E F G H I J K U M N O P Q R S T) →
  (M = L) →
  r11 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r7 A B C D E F G H I J K L M N O P Q R S T) →
  (N + (-1 : Int) * O ≤ (-1 : Int)) →
  r45 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r45 A B C D E F G H I J K U M N O P Q R S T) →
  (M = (-1 : Int) + L) →
  r40 A B C D E F G H I J K L M N O P Q R S T))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V : Int),
  (r11 A B C D E F G H I J K L M N O P U V S T) →
  (Q = (1 : Int)) →
  (R = (0 : Int)) →
  r6 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V : Int),
  (r40 A B C D E F G H I J K L M N O P U V S T) →
  (Q = (1 : Int)) →
  (R = (0 : Int)) →
  r6 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r6 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r57 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r57 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r34 A B C D E F G H I J K L M N O P Q R S T)))))) ∧
  ((((((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r34 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r14 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r52 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r14 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r14 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r27 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r27 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r42 A B C D E F G H I J K L M N O P Q R S T))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r42 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r13 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r13 A B C D E F G H I J K L M N O P Q R S T) →
  (T ≤ (-1 : Int)) →
  r53 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r53 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r18 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r15 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r18 A B C D E F G H I J K L M N O P Q R S T)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r13 A B C D E F G H I J K L M N O P Q R S T) →
  (T ≥ (1 : Int)) →
  r15 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r13 A B C D E F G H I J K L M N O P Q R S T) →
  (T = (0 : Int)) →
  r17 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r17 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r0 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r28 A B C D E F G H I J K L M N O P Q R S T))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r18 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r43 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r43 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r35 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r37 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r35 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r58 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r35 A B C D E F G H I J K L M N O P Q R S T))))) ∧
  (((((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r4 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r35 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r35 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r5 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r5 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r19 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r19 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r44 A B C D E F G H I J K L M N O P Q R S T))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r44 A B C D E F G H I J K L M N O P Q R S T) →
  (S ≤ (-1 : Int)) →
  r16 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r16 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r46 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r22 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r46 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r44 A B C D E F G H I J K L M N O P Q R S T) →
  (S ≥ (1 : Int)) →
  r22 A B C D E F G H I J K L M N O P Q R S T)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r44 A B C D E F G H I J K L M N O P Q R S T) →
  (S = (0 : Int)) →
  r26 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r26 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r1 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r1 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r33 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r46 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r25 A B C D E F G H I J K L M N O P Q R S T))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r25 A B C D E F G H I J K U M N O P Q R S T) →
  (U = (-1 : Int) + L) →
  r59 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r46 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r38 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r38 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r2 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r39 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r2 A B C D E F G H I J K L M N O P Q R S T))))))) ∧
  (((((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r59 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r2 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r46 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r39 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r2 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r29 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r29 A B C D E F G H I J K L U N O P Q R S T) →
  (U = (-1 : Int) + M) →
  r4 A B C D E F G H I J K L M N O P Q R S T))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r2 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r37 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r2 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r58 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V : Int),
  (r33 A B C D E F G H I J K L M N O P U V S T) →
  (Q = (1 : Int) + R) →
  (L = (-1 : Int) * M + R) →
  r52 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r28 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r9 A B C D E F G H I J K L M N O P Q R S T)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r9 A B C D E F G H I J K L M N O P Q R S T) →
  (L + (-1 : Int) * M ≤ (-1 : Int)) →
  r20 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r9 A B C D E F G H I J K L M N O P Q R S T) →
  (L + (-1 : Int) * M ≥ (1 : Int)) →
  r54 A B C D E F G H I J K L M N O P Q R S T)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r20 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r31) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r54 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r31))) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r31) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«45.c_000»
