import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«23.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":219:1-219:12 (check-sat, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":21:1-30:2 (clause 1, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":31:1-41:2 (clause 2, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":42:1-52:2 (clause 3, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":53:1-63:2 (clause 4, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":64:1-74:2 (clause 5, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":75:1-85:2 (clause 6, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":86:1-96:2 (clause 7, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":97:1-107:2 (clause 8, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":108:1-118:2 (clause 9, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":119:1-129:2 (clause 10, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":130:1-140:2 (clause 11, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":141:1-151:2 (clause 12, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":152:1-162:2 (clause 13, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":163:1-173:2 (clause 14, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":174:1-184:2 (clause 15, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":185:1-195:2 (clause 16, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":196:1-206:2 (clause 17, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/23.c_000.smt2":207:1-217:2 (clause 18, command 35)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D v_4 v_5 v_6 v_7 : Int),
  (True) →
  (v_4 = A) →
  (v_5 = B) →
  (v_6 = C) →
  (v_7 = D) →
  r0 A B C D v_4 v_5 v_6 v_7) ∧
  ((∀ (A B C D E F G H I : Int),
  (r0 A B C D E F I H) →
  (G = (0 : Int)) →
  r6 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r6 A B C D E F G H) →
  (True) →
  r4 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r4 A B C D E F G H) →
  (E ≥ (0 : Int)) →
  r3 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r3 A B C D E I G H) →
  (F = (0 : Int)) →
  r15 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r15 A B C D E F G H) →
  (True) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 A B C D E F G H) →
  (True) →
  r13 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r13 A B C D E F G H) →
  (True) →
  r5 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r7 A B C D E F G H) →
  (True) →
  r5 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r5 A B C D E F G H) →
  (True) →
  r8 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r8 A B C D E F G H) →
  (E + (-1 : Int) * F ≥ (1 : Int)) →
  r11 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r11 A B C D E J I H) →
  (I = (1 : Int) + (-1 : Int) * F + G) →
  (J = (-1 : Int) + F) →
  r7 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r8 A B C D E F G H) →
  (E + (-1 : Int) * F ≤ (0 : Int)) →
  r9 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r9 A B C D E F G H) →
  (True) →
  r10 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r10 A B C D E F G H) →
  (True) →
  r14 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r14 A B C D E F G H) →
  (True) →
  r12 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r12 A B C D E F G H) →
  (G ≤ (-1 : Int)) →
  r2 A B C D E F G H) ∧
  (∀ (A B C D E F G H : Int),
  (r2 A B C D E F G H) →
  (True) →
  False)))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«23.c_000»
