import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«26.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":743:1-743:12 (check-sat, command 114)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":55:1-71:2 (clause 1, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":72:1-82:2 (clause 2, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":83:1-93:2 (clause 3, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":94:1-104:2 (clause 4, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":105:1-115:2 (clause 5, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":116:1-126:2 (clause 6, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":127:1-137:2 (clause 7, command 58)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":138:1-148:2 (clause 8, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":149:1-159:2 (clause 9, command 60)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":160:1-170:2 (clause 10, command 61)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":171:1-181:2 (clause 11, command 62)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":182:1-192:2 (clause 12, command 63)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":193:1-203:2 (clause 13, command 64)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":204:1-214:2 (clause 14, command 65)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":215:1-225:2 (clause 15, command 66)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":226:1-236:2 (clause 16, command 67)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":237:1-247:2 (clause 17, command 68)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":248:1-258:2 (clause 18, command 69)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":259:1-269:2 (clause 19, command 70)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":270:1-280:2 (clause 20, command 71)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":281:1-291:2 (clause 21, command 72)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":292:1-302:2 (clause 22, command 73)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":303:1-313:2 (clause 23, command 74)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":314:1-324:2 (clause 24, command 75)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":325:1-335:2 (clause 25, command 76)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":336:1-346:2 (clause 26, command 77)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":347:1-357:2 (clause 27, command 78)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":358:1-368:2 (clause 28, command 79)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":369:1-379:2 (clause 29, command 80)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":380:1-390:2 (clause 30, command 81)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":391:1-401:2 (clause 31, command 82)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":402:1-412:2 (clause 32, command 83)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":413:1-423:2 (clause 33, command 84)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":424:1-434:2 (clause 34, command 85)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":435:1-445:2 (clause 35, command 86)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":446:1-456:2 (clause 36, command 87)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":457:1-467:2 (clause 37, command 88)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":468:1-478:2 (clause 38, command 89)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":479:1-489:2 (clause 39, command 90)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":490:1-500:2 (clause 40, command 91)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":501:1-511:2 (clause 41, command 92)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":512:1-522:2 (clause 42, command 93)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":523:1-533:2 (clause 43, command 94)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":534:1-544:2 (clause 44, command 95)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":545:1-555:2 (clause 45, command 96)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":556:1-566:2 (clause 46, command 97)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":567:1-577:2 (clause 47, command 98)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":578:1-588:2 (clause 48, command 99)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":589:1-599:2 (clause 49, command 100)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":600:1-610:2 (clause 50, command 101)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":611:1-621:2 (clause 51, command 102)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":622:1-632:2 (clause 52, command 103)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":633:1-643:2 (clause 53, command 104)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":644:1-654:2 (clause 54, command 105)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":655:1-665:2 (clause 55, command 106)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":666:1-676:2 (clause 56, command 107)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":677:1-687:2 (clause 57, command 108)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":688:1-698:2 (clause 58, command 109)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":699:1-709:2 (clause 59, command 110)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":710:1-720:2 (clause 60, command 111)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":721:1-731:2 (clause 61, command 112)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/26.c_000.smt2":732:1-741:2 (clause 62, command 113)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r28 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r29 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r30 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r31 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r32 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r33 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r34 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r35 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r36 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r37 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r38 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r39 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r40 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r41 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r42 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r43 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r44 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r45 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r46 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r47 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r48 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r49 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G v_7 v_8 v_9 v_10 v_11 v_12 v_13 : Int),
  (True) →
  (v_7 = A) →
  (v_8 = B) →
  (v_9 = C) →
  (v_10 = D) →
  (v_11 = E) →
  (v_12 = F) →
  (v_13 = G) →
  r23 A B C D E F G v_7 v_8 v_9 v_10 v_11 v_12 v_13) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r23 A B C D E F G O P Q R L M N) →
  (J = (0 : Int)) →
  (I = (0 : Int)) →
  (H = (1 : Int)) →
  (K = (0 : Int)) →
  r35 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r35 A B C D E F G H I J K L M N) →
  (True) →
  r34 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r34 A B C D E F G H I J K L M N) →
  (True) →
  r6 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r6 A B C D E F G H I J K L M N) →
  (True) →
  r41 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r22 A B C D E F G H I J K L M N) →
  (True) →
  r41 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r41 A B C D E F G H I J K L M N) →
  (True) →
  r36 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r36 A B C D E F G H I J K L M N) →
  (True) →
  r8 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r8 A B C D E F G H I J K L M N) →
  (True) →
  r47 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r47 A B C D E F G H I J K L M N) →
  (N ≤ (-1 : Int)) →
  r48 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r48 A B C D E F G H I J K L M N) →
  (True) →
  r10 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r25 A B C D E F G H I J K L M N) →
  (True) →
  r10 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r47 A B C D E F G H I J K L M N) →
  (N ≥ (1 : Int)) →
  r25 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r47 A B C D E F G H I J K L M N) →
  (N = (0 : Int)) →
  r27 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r27 A B C D E F G H I J K L M N) →
  (True) →
  r14 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r14 A B C D E F G H I J K L M N) →
  (True) →
  r12 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r10 A B C D E F G H I J K L M N) →
  (True) →
  r30 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r30 A B C D E F G H I J K L M N) →
  (True) →
  r4 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r21 A B C D E F G H I J K L M N) →
  (True) →
  r4 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r26 A B C D E F G H I J K L M N) →
  (True) →
  r4 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r40 A B C D E F G H I J K L M N) →
  (True) →
  r4 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r4 A B C D E F G H I J K L M N) →
  (True) →
  r37 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r37 A B C D E F G H I J K L M N) →
  (True) →
  r20 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r20 A B C D E F G H I J K L M N) →
  (True) →
  r1 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r1 A B C D E F G H I J K L M N) →
  (L ≤ (-1 : Int)) →
  r31 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r31 A B C D E F G H I J K L M N) →
  (True) →
  r49 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r32 A B C D E F G H I J K L M N) →
  (True) →
  r49 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r1 A B C D E F G H I J K L M N) →
  (L ≥ (1 : Int)) →
  r32 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r1 A B C D E F G H I J K L M N) →
  (L = (0 : Int)) →
  r45 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r45 A B C D E F G H I J K L M N) →
  (True) →
  r28 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r28 A B C D E F G H I J K L M N) →
  (True) →
  r18 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r49 A B C D E F G H I J K L M N) →
  (True) →
  r16 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r16 A B C D E F G H I O K L M N) →
  (O = (-1 : Int) + J) →
  r44 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r49 A B C D E F G H I J K L M N) →
  (True) →
  r46 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r46 A B C D E F G H I J K L M N) →
  (True) →
  r42 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r2 A B C D E F G H I J K L M N) →
  (True) →
  r42 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r44 A B C D E F G H I J K L M N) →
  (True) →
  r42 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r49 A B C D E F G H I J K L M N) →
  (True) →
  r2 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r42 A B C D E F G H I J K L M N) →
  (True) →
  r39 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r39 A B C D E F G H I J O L M N) →
  (O = (-1 : Int) + K) →
  r40 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r42 A B C D E F G H I J K L M N) →
  (True) →
  r21 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r42 A B C D E F G H I J K L M N) →
  (True) →
  r26 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r18 A B C D E F G H I J K L M N) →
  (True) →
  r7 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r7 A B C D E F G H I J K L M N) →
  (True) →
  r29 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r29 A B C D E F G H I J K L M N) →
  (True) →
  r11 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r5 A B C D E F G H I J K L M N) →
  (True) →
  r11 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r11 A B C D E F G H I J K L M N) →
  (True) →
  r15 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r15 A B C D E F G H I J K L M N) →
  (True) →
  r3 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r3 A B C D E F G H I J K L M N) →
  (True) →
  r43 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r43 A B C D E F G H I J K L M N) →
  (M ≤ (-1 : Int)) →
  r33 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r33 A B C D E F G O P J K L M N) →
  (J = (-1 : Int) * K + I) →
  (H = (1 : Int) + I) →
  r5 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r9 A B C D E F G O P J K L M N) →
  (J = (-1 : Int) * K + I) →
  (H = (1 : Int) + I) →
  r5 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r43 A B C D E F G H I J K L M N) →
  (M ≥ (1 : Int)) →
  r9 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r43 A B C D E F G H I J K L M N) →
  (M = (0 : Int)) →
  r0 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r0 A B C D E F G H I J K L M N) →
  (True) →
  r24 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r24 A B C D E F G H I J K L M N) →
  (True) →
  r22 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r12 A B C D E F G H I J K L M N) →
  (True) →
  r38 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r38 A B C D E F G H I J K L M N) →
  (J + (-1 : Int) * K ≤ (-1 : Int)) →
  r19 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r38 A B C D E F G H I J K L M N) →
  (J + (-1 : Int) * K ≥ (1 : Int)) →
  r13 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r19 A B C D E F G H I J K L M N) →
  (True) →
  r17) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r13 A B C D E F G H I J K L M N) →
  (True) →
  r17) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r17) →
  False)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«26.c_000»
