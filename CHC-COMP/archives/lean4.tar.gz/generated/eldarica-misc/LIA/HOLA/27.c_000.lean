import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«27.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":445:1-445:12 (check-sat, command 72)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":38:1-47:2 (clause 1, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":48:1-58:2 (clause 2, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":59:1-69:2 (clause 3, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":70:1-80:2 (clause 4, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":81:1-91:2 (clause 5, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":92:1-102:2 (clause 6, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":103:1-113:2 (clause 7, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":114:1-124:2 (clause 8, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":125:1-135:2 (clause 9, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":136:1-146:2 (clause 10, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":147:1-157:2 (clause 11, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":158:1-168:2 (clause 12, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":169:1-179:2 (clause 13, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":180:1-190:2 (clause 14, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":191:1-201:2 (clause 15, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":202:1-212:2 (clause 16, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":213:1-223:2 (clause 17, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":224:1-234:2 (clause 18, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":235:1-245:2 (clause 19, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":246:1-256:2 (clause 20, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":257:1-267:2 (clause 21, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":268:1-278:2 (clause 22, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":279:1-289:2 (clause 23, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":290:1-300:2 (clause 24, command 58)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":301:1-311:2 (clause 25, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":312:1-322:2 (clause 26, command 60)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":323:1-333:2 (clause 27, command 61)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":334:1-344:2 (clause 28, command 62)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":345:1-355:2 (clause 29, command 63)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":356:1-366:2 (clause 30, command 64)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":367:1-377:2 (clause 31, command 65)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":378:1-388:2 (clause 32, command 66)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":389:1-399:2 (clause 33, command 67)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":400:1-410:2 (clause 34, command 68)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":411:1-421:2 (clause 35, command 69)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":422:1-432:2 (clause 36, command 70)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/27.c_000.smt2":433:1-443:2 (clause 37, command 71)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r28 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r29 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r30 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r31 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r32 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D v_4 v_5 v_6 v_7 : Int),
  (True) →
  (v_4 = A) →
  (v_5 = B) →
  (v_6 = C) →
  (v_7 = D) →
  r17 A B C D v_4 v_5 v_6 v_7) ∧
  ((∀ (A B C D E F G H : Int),
  (r17 A B C D E F G H) →
  (True) →
  r13 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r13 A B C D E F G H) →
  (H ≥ (1 : Int)) →
  r27 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r27 A B C D E I G H) →
  (F = (1 : Int)) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 A B C D E F G H) →
  (True) →
  r32 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r32 A B C D E F G H) →
  (True) →
  r9 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r9 A B C D E F G H) →
  (True) →
  r24 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r15 A B C D E F G H) →
  (True) →
  r24 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r24 A B C D E F G H) →
  (True) →
  r20 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r20 A B C D E F G H) →
  (F + (-1 : Int) * G ≤ (-1 : Int)) →
  r28 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r28 A B C D I F G H) →
  (H = E) →
  r21 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r21 A B C D E F G H) →
  (True) →
  r6 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r6 A B C D E F G H) →
  (True) →
  r3 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r3 A B C D E F G H) →
  (True) →
  r26 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 A B C D E F G H) →
  (True) →
  r26 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r26 A B C D E F G H) →
  (True) →
  r25 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r25 A B C D E F G H) →
  (E + (-1 : Int) * G ≤ (-1 : Int)) →
  r14 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r14 A B C D I F G H) →
  (I = (-1 : Int) + E) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r25 A B C D E F G H) →
  (E + (-1 : Int) * G ≥ (0 : Int)) →
  r2 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 A B C D E F G H) →
  (True) →
  r11 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r11 A B C D E F G H) →
  (True) →
  r16 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r16 A B C D I F G H) →
  (H = E) →
  r23 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r23 A B C D E F G H) →
  (True) →
  r7 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r7 A B C D E F G H) →
  (True) →
  r10 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r10 A B C D E F G H) →
  (True) →
  r5 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r18 A B C D E F G H) →
  (True) →
  r5 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r5 A B C D E F G H) →
  (True) →
  r19 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r19 A B C D E F G H) →
  (E + (-1 : Int) * G ≤ (-1 : Int)) →
  r12 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r12 A B C D E F G H) →
  (True) →
  r29 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r19 A B C D E F G H) →
  (E + (-1 : Int) * G ≥ (0 : Int)) →
  r4 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r4 A B C D E F G H) →
  (True) →
  r8 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r8 A B C D E F G H) →
  (True) →
  r31 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r29 A B C D E F G H) →
  (F ≤ (0 : Int)) →
  r30 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r29 A B C D E F G H) →
  (F ≥ (1 : Int)) →
  r22 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r22 A B C D I F G H) →
  (I = (-1 : Int) + E) →
  r18 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r31 A B C D E I G H) →
  (I = (-1 : Int) + F) →
  r15 A B C D E F G H) ∧
  (∀ (A B C D E F G H : Int),
  (r30 A B C D E F G H) →
  (True) →
  False))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«27.c_000»
