import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«09.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":736:1-736:12 (check-sat, command 115)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":57:1-74:2 (clause 1, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":75:1-85:2 (clause 2, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":86:1-96:2 (clause 3, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":97:1-107:2 (clause 4, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":108:1-118:2 (clause 5, command 58)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":119:1-129:2 (clause 6, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":130:1-140:2 (clause 7, command 60)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":141:1-151:2 (clause 8, command 61)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":152:1-162:2 (clause 9, command 62)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":163:1-173:2 (clause 10, command 63)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":174:1-184:2 (clause 11, command 64)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":185:1-195:2 (clause 12, command 65)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":196:1-206:2 (clause 13, command 66)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":207:1-217:2 (clause 14, command 67)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":218:1-228:2 (clause 15, command 68)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":229:1-239:2 (clause 16, command 69)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":240:1-250:2 (clause 17, command 70)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":251:1-261:2 (clause 18, command 71)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":262:1-272:2 (clause 19, command 72)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":273:1-283:2 (clause 20, command 73)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":284:1-294:2 (clause 21, command 74)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":295:1-305:2 (clause 22, command 75)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":306:1-316:2 (clause 23, command 76)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":317:1-327:2 (clause 24, command 77)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":328:1-338:2 (clause 25, command 78)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":339:1-349:2 (clause 26, command 79)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":350:1-360:2 (clause 27, command 80)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":361:1-371:2 (clause 28, command 81)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":372:1-382:2 (clause 29, command 82)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":383:1-393:2 (clause 30, command 83)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":394:1-404:2 (clause 31, command 84)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":405:1-415:2 (clause 32, command 85)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":416:1-426:2 (clause 33, command 86)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":427:1-437:2 (clause 34, command 87)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":438:1-448:2 (clause 35, command 88)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":449:1-459:2 (clause 36, command 89)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":460:1-470:2 (clause 37, command 90)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":471:1-481:2 (clause 38, command 91)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":482:1-492:2 (clause 39, command 92)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":493:1-503:2 (clause 40, command 93)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":504:1-514:2 (clause 41, command 94)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":515:1-525:2 (clause 42, command 95)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":526:1-536:2 (clause 43, command 96)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":537:1-547:2 (clause 44, command 97)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":548:1-558:2 (clause 45, command 98)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":559:1-569:2 (clause 46, command 99)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":570:1-580:2 (clause 47, command 100)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":581:1-591:2 (clause 48, command 101)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":592:1-602:2 (clause 49, command 102)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":603:1-613:2 (clause 50, command 103)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":614:1-624:2 (clause 51, command 104)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":625:1-635:2 (clause 52, command 105)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":636:1-646:2 (clause 53, command 106)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":647:1-657:2 (clause 54, command 107)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":658:1-668:2 (clause 55, command 108)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":669:1-679:2 (clause 56, command 109)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":680:1-690:2 (clause 57, command 110)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":691:1-701:2 (clause 58, command 111)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":702:1-712:2 (clause 59, command 112)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":713:1-723:2 (clause 60, command 113)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/09.c_000.smt2":724:1-734:2 (clause 61, command 114)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r28 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r29 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r30 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r31 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r32 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r33 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r34 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r35 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r36 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r37 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r38 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r39 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r40 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r41 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r42 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r43 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r44 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r45 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r46 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r47 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r48 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r49 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r50 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r51 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H v_8 v_9 v_10 v_11 v_12 v_13 v_14 v_15 : Int),
  (True) →
  (v_8 = A) →
  (v_9 = B) →
  (v_10 = C) →
  (v_11 = D) →
  (v_12 = E) →
  (v_13 = F) →
  (v_14 = G) →
  (v_15 = H) →
  r36 A B C D E F G H v_8 v_9 v_10 v_11 v_12 v_13 v_14 v_15) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r36 A B C D E F G H Q J R L M N O P) →
  (K = (0 : Int)) →
  (I = (0 : Int)) →
  r50 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r50 A B C D E F G H I J K L M N O P) →
  (True) →
  r30 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r30 A B C D E F G H I J K L M N O P) →
  (True) →
  r22 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r22 A B C D E F G H I J K L M N O P) →
  (True) →
  r40 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r2 A B C D E F G H I J K L M N O P) →
  (True) →
  r40 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r40 A B C D E F G H I J K L M N O P) →
  (True) →
  r32 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r32 A B C D E F G H I J K L M N O P) →
  (True) →
  r41 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r41 A B C D E F G H I J K L M N O P) →
  (True) →
  r19 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r19 A B C D E F G H I J K L M N O P) →
  (M ≤ (-1 : Int)) →
  r45 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  (r45 A B C D E F G H Q J K L M N O P) →
  (Q = (-1 : Int) + I) →
  r2 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  (r24 A B C D E F G H Q J K L M N O P) →
  (Q = (-1 : Int) + I) →
  r2 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r19 A B C D E F G H I J K L M N O P) →
  (M ≥ (1 : Int)) →
  r24 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r19 A B C D E F G H I J K L M N O P) →
  (M = (0 : Int)) →
  r39 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r39 A B C D E F G H I J K L M N O P) →
  (True) →
  r25 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r25 A B C D E F G H I J K L M N O P) →
  (True) →
  r38 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r38 A B C D E F G H I J K L M N O P) →
  (True) →
  r14 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r14 A B C D E F G H I J K L M N O P) →
  (I + (-1 : Int) * J ≥ (1 : Int)) →
  r20 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r20 A B C D E F G H I J K L M N O P) →
  (True) →
  r31 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r14 A B C D E F G H I J K L M N O P) →
  (I + (-1 : Int) * J ≤ (0 : Int)) →
  r43 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  (r43 A B C D E F G H Q J K L M N O P) →
  (I = (0 : Int)) →
  r42 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  (r31 A B C D E F G H Q J K L M N O P) →
  (I = (0 : Int)) →
  r42 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r42 A B C D E F G H I J K L M N O P) →
  (True) →
  r17 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r17 A B C D E F G H I J K L M N O P) →
  (True) →
  r3 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r3 A B C D E F G H I J K L M N O P) →
  (True) →
  r5 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r1 A B C D E F G H I J K L M N O P) →
  (True) →
  r5 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r5 A B C D E F G H I J K L M N O P) →
  (True) →
  r15 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r15 A B C D E F G H I J K L M N O P) →
  (True) →
  r23 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r23 A B C D E F G H I J K L M N O P) →
  (True) →
  r26 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r26 A B C D E F G H I J K L M N O P) →
  (N ≤ (-1 : Int)) →
  r0 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 A B C D E F G H Q J R L M N O P) →
  (Q = (-1 : Int) + I) →
  (R = (-1 : Int) + K) →
  r1 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r49 A B C D E F G H Q J R L M N O P) →
  (Q = (-1 : Int) + I) →
  (R = (-1 : Int) + K) →
  r1 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r26 A B C D E F G H I J K L M N O P) →
  (N ≥ (1 : Int)) →
  r49 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r26 A B C D E F G H I J K L M N O P) →
  (N = (0 : Int)) →
  r29 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r29 A B C D E F G H I J K L M N O P) →
  (True) →
  r33 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r33 A B C D E F G H I J K L M N O P) →
  (True) →
  r8 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r8 A B C D E F G H I J K L M N O P) →
  (True) →
  r4 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r4 A B C D E F G H I J K L M N O P) →
  (True) →
  r13 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r13 A B C D E F G H I J K L M N O P) →
  (True) →
  r46 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r51 A B C D E F G H I J K L M N O P) →
  (True) →
  r46 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r47 A B C D E F G H I J K L M N O P) →
  (True) →
  r46 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r46 A B C D E F G H I J K L M N O P) →
  (True) →
  r9 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r9 A B C D E F G H I J K L M N O P) →
  (True) →
  r37 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r37 A B C D E F G H I J K L M N O P) →
  (True) →
  r27 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r27 A B C D E F G H I J K L M N O P) →
  (O ≤ (-1 : Int)) →
  r51 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r27 A B C D E F G H I J K L M N O P) →
  (O ≥ (1 : Int)) →
  r47 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r27 A B C D E F G H I J K L M N O P) →
  (O = (0 : Int)) →
  r6 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r6 A B C D E F G H I J K L M N O P) →
  (True) →
  r21 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r21 A B C D E F G H I J K L M N O P) →
  (True) →
  r10 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r10 A B C D E F G H I J K Q M N O R) →
  (P = (0 : Int)) →
  (I = L) →
  r18 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r18 A B C D E F G H I J K L M N O P) →
  (True) →
  r48 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r48 A B C D E F G H I J K L M N O P) →
  (True) →
  r34 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r34 A B C D E F G H I J K L M N O P) →
  (True) →
  r35 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r12 A B C D E F G H I J K L M N O P) →
  (True) →
  r35 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r35 A B C D E F G H I J K L M N O P) →
  (True) →
  r28 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r28 A B C D E F G H I J K L M N O P) →
  (K ≤ (-1 : Int)) →
  r7 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r28 A B C D E F G H I J K L M N O P) →
  (K ≥ (0 : Int)) →
  r11 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r11 A B C D E F G H I J Q L M N O R) →
  (Q = (1 : Int) + K) →
  (R = (-1 : Int) + P) →
  r16 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r16 A B C D E F G H I J K L M N O P) →
  (True) →
  r44 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r44 A B C D E F G H I J K L M N O P) →
  (L + (-1 : Int) * P ≥ (1 : Int)) →
  r12 A B C D E F G H I J K L M N O P) ∧
  (∀ (A B C D E F G H I J K L M N O P : Int),
  (r7 A B C D E F G H I J K L M N O P) →
  (True) →
  False))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«09.c_000»
