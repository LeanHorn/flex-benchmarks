import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«15.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":255:1-255:12 (check-sat, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":24:1-33:2 (clause 1, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":34:1-44:2 (clause 2, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":45:1-55:2 (clause 3, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":56:1-66:2 (clause 4, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":67:1-77:2 (clause 5, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":78:1-88:2 (clause 6, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":89:1-99:2 (clause 7, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":100:1-110:2 (clause 8, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":111:1-121:2 (clause 9, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":122:1-132:2 (clause 10, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":133:1-143:2 (clause 11, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":144:1-154:2 (clause 12, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":155:1-165:2 (clause 13, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":166:1-176:2 (clause 14, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":177:1-187:2 (clause 15, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":188:1-198:2 (clause 16, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":199:1-209:2 (clause 17, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":210:1-220:2 (clause 18, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":221:1-231:2 (clause 19, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":232:1-242:2 (clause 20, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/15.c_000.smt2":243:1-253:2 (clause 21, command 41)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F v_6 v_7 v_8 v_9 v_10 v_11 : Int),
  (True) →
  (v_6 = A) →
  (v_7 = B) →
  (v_8 = C) →
  (v_9 = D) →
  (v_10 = E) →
  (v_11 = F) →
  r5 A B C D E F v_6 v_7 v_8 v_9 v_10 v_11) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r5 A B C D E F G H I J K L) →
  (True) →
  r12 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r12 A B C D E F G H I J K L) →
  (True) →
  r6 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r6 A B C D E F G H I J K L) →
  (True) →
  r0 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D E F G H I J K L) →
  (I ≥ (1 : Int)) →
  r10 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r10 A B C D E F G H I J K L) →
  (True) →
  r18 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r18 A B C D E F G H I J K L) →
  (I + (-1 : Int) * J ≤ (-1 : Int)) →
  r4 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r4 A B C D E F G H I J M L) →
  (K = (0 : Int)) →
  r1 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D E F G H I J K L) →
  (True) →
  r9 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r9 A B C D E F G H I J K L) →
  (True) →
  r7 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r7 A B C D E F G H I J K L) →
  (True) →
  r13 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r15 A B C D E F G H I J K L) →
  (True) →
  r13 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r13 A B C D E F G H I J K L) →
  (True) →
  r2 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D E F G H I J K L) →
  (I + (-1 : Int) * K ≥ (1 : Int)) →
  r11 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r11 A B C D E F G H I N M L) →
  (M = (-1 : Int) + K) →
  (N = (1 : Int) + J) →
  r15 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D E F G H I J K L) →
  (I + (-1 : Int) * K ≤ (0 : Int)) →
  r8 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r8 A B C D E F G H I J K L) →
  (True) →
  r3 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A B C D E F G H I J K L) →
  (True) →
  r14 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r14 A B C D E F G H I J K L) →
  (True) →
  r16 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r16 A B C D E F G H I J K L) →
  (J ≤ (-1 : Int)) →
  r17 A B C D E F G H I J K L) ∧
  (∀ (A B C D E F G H I J K L : Int),
  (r17 A B C D E F G H I J K L) →
  (True) →
  False))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«15.c_000»
