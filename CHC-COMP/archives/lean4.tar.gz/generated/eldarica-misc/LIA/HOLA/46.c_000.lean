import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«46.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":382:1-382:12 (check-sat, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":30:1-39:2 (clause 1, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":40:1-50:2 (clause 2, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":51:1-61:2 (clause 3, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":62:1-72:2 (clause 4, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":73:1-83:2 (clause 5, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":84:1-94:2 (clause 6, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":95:1-105:2 (clause 7, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":106:1-116:2 (clause 8, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":117:1-127:2 (clause 9, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":128:1-138:2 (clause 10, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":139:1-149:2 (clause 11, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":150:1-160:2 (clause 12, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":161:1-171:2 (clause 13, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":172:1-182:2 (clause 14, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":183:1-193:2 (clause 15, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":194:1-204:2 (clause 16, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":205:1-215:2 (clause 17, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":216:1-226:2 (clause 18, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":227:1-237:2 (clause 19, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":238:1-248:2 (clause 20, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":249:1-259:2 (clause 21, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":260:1-270:2 (clause 22, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":271:1-281:2 (clause 23, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":282:1-292:2 (clause 24, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":293:1-303:2 (clause 25, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":304:1-314:2 (clause 26, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":315:1-325:2 (clause 27, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":326:1-336:2 (clause 28, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":337:1-347:2 (clause 29, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":348:1-358:2 (clause 30, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":359:1-369:2 (clause 31, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/46.c_000.smt2":370:1-380:2 (clause 32, command 58)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E v_5 v_6 v_7 v_8 v_9 : Int),
  (True) →
  (v_5 = A) →
  (v_6 = B) →
  (v_7 = C) →
  (v_8 = D) →
  (v_9 = E) →
  r20 A B C D E v_5 v_6 v_7 v_8 v_9) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r20 A B C D E K L M N J) →
  (H = (0 : Int)) →
  (G = (0 : Int)) →
  (F = (1 : Int)) →
  (I = (0 : Int)) →
  r16 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r16 A B C D E F G H I J) →
  (True) →
  r7 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r7 A B C D E F G H I J) →
  (True) →
  r9 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r9 A B C D E F G H I J) →
  (True) →
  r6 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r1 A B C D E F G H I J) →
  (True) →
  r6 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r18 A B C D E F G H I J) →
  (True) →
  r6 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r17 A B C D E F G H I J) →
  (True) →
  r6 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r6 A B C D E F G H I J) →
  (True) →
  r13 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r13 A B C D E F G H I J) →
  (True) →
  r24 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r24 A B C D E F G H I J) →
  (True) →
  r12 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r12 A B C D E F G H I J) →
  (J ≤ (-1 : Int)) →
  r19 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r19 A B C D E F G H I J) →
  (True) →
  r3 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r15 A B C D E F G H I J) →
  (True) →
  r3 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r12 A B C D E F G H I J) →
  (J ≥ (1 : Int)) →
  r15 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r12 A B C D E F G H I J) →
  (J = (0 : Int)) →
  r23 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r23 A B C D E F G H I J) →
  (True) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B C D E F G H I J) →
  (True) →
  r5 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 A B C D E F G H I J) →
  (True) →
  r2 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D E L G K I J) →
  (K = (-1 : Int) + H) →
  (L = (-1 : Int) + F) →
  r8 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 A B C D E F G H I J) →
  (True) →
  r11 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r11 A B C D E F G H I J) →
  (True) →
  r10 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r4 A B C D E F G H I J) →
  (True) →
  r10 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r8 A B C D E F G H I J) →
  (True) →
  r10 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 A B C D E F G H I J) →
  (True) →
  r4 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r10 A B C D E F G H I J) →
  (True) →
  r14 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r14 A B C D E F K H I J) →
  (K = (-1 : Int) + G) →
  r17 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r10 A B C D E F G H I J) →
  (True) →
  r1 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r10 A B C D E F G H I J) →
  (True) →
  r18 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r5 A B C D E F G H I J) →
  (True) →
  r21 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r21 A B C D E F G H I J) →
  (H ≥ (2 : Int)) →
  r22 A B C D E F G H I J) ∧
  (∀ (A B C D E F G H I J : Int),
  (r22 A B C D E F G H I J) →
  (True) →
  False)))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«46.c_000»
