import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«21.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":464:1-464:12 (check-sat, command 72)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":37:1-55:2 (clause 1, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":56:1-66:2 (clause 2, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":67:1-77:2 (clause 3, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":78:1-88:2 (clause 4, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":89:1-99:2 (clause 5, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":100:1-110:2 (clause 6, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":111:1-121:2 (clause 7, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":122:1-132:2 (clause 8, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":133:1-143:2 (clause 9, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":144:1-154:2 (clause 10, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":155:1-165:2 (clause 11, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":166:1-176:2 (clause 12, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":177:1-187:2 (clause 13, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":188:1-198:2 (clause 14, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":199:1-209:2 (clause 15, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":210:1-220:2 (clause 16, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":221:1-231:2 (clause 17, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":232:1-242:2 (clause 18, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":243:1-253:2 (clause 19, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":254:1-264:2 (clause 20, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":265:1-275:2 (clause 21, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":276:1-286:2 (clause 22, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":287:1-297:2 (clause 23, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":298:1-308:2 (clause 24, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":309:1-319:2 (clause 25, command 58)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":320:1-330:2 (clause 26, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":331:1-341:2 (clause 27, command 60)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":342:1-352:2 (clause 28, command 61)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":353:1-363:2 (clause 29, command 62)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":364:1-374:2 (clause 30, command 63)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":375:1-385:2 (clause 31, command 64)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":386:1-396:2 (clause 32, command 65)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":397:1-407:2 (clause 33, command 66)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":408:1-418:2 (clause 34, command 67)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":419:1-429:2 (clause 35, command 68)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":430:1-440:2 (clause 36, command 69)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":441:1-451:2 (clause 37, command 70)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/21.c_000.smt2":452:1-462:2 (clause 38, command 71)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r28 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r29 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r30 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r31 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I v_9 v_10 v_11 v_12 v_13 v_14 v_15 v_16 v_17 : Int),
  (True) →
  (v_9 = A) →
  (v_10 = B) →
  (v_11 = C) →
  (v_12 = D) →
  (v_13 = E) →
  (v_14 = F) →
  (v_15 = G) →
  (v_16 = H) →
  (v_17 = I) →
  r14 A B C D E F G H I v_9 v_10 v_11 v_12 v_13 v_14 v_15 v_16 v_17) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r14 A B C D E F G H I J K S T N O P Q R) →
  (L = (4000 : Int)) →
  (M = (2000 : Int)) →
  r15 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r15 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r23 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r23 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r25 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r25 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r4 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r4 A B C D E F G H I J K L M N O P Q R) →
  (N ≥ (1 : Int)) →
  r20 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r20 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r21 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r21 A B C D E F G H I J K L M N O P Q R) →
  (N ≤ (9 : Int)) →
  r7 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r7 A B C D E F G H I J K L M N O S T R) →
  (P = (0 : Int)) →
  (Q = (0 : Int)) →
  r9 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r9 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r19 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r19 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r1 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r1 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r28 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r8 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r28 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r24 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r28 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r28 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r0 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 A B C D E F G H I J K L M N O P Q R) →
  (N + (-1 : Int) * P ≥ (1 : Int)) →
  r17 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r17 A B C D E F G H I J K L M N O S Q R) →
  (S = (-1 : Int) + P) →
  r31 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 A B C D E F G H I J K L M N O P Q R) →
  (N + (-1 : Int) * P ≤ (0 : Int)) →
  r16 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r16 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r10 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r10 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r27 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r31 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r2 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r2 A B C D E F G H I J K L M N O P Q R) →
  (J = (0 : Int)) →
  r11 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r11 A B C D E F G H I J K L M N S P Q R) →
  (O = (0 : Int)) →
  r22 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r2 A B C D E F G H I J K L M N O P Q R) →
  (J ≤ (-1 : Int)) →
  r30 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r30 A B C D E F G H I J K L M N S P Q R) →
  (O = (1 : Int)) →
  r5 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r12 A B C D E F G H I J K L M N S P Q R) →
  (O = (1 : Int)) →
  r5 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r2 A B C D E F G H I J K L M N O P Q R) →
  (J ≥ (1 : Int)) →
  r12 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r22 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r18 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r5 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r18 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r18 A B C D E F G H I J K L M N O P Q R) →
  (O = (0 : Int)) →
  r13 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r13 A B C D E F G H I J K L M N O P S R) →
  (L = (-1 : Int) * S + Q) →
  r8 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r18 A B C D E F G H I J K L M N O P Q R) →
  (O ≤ (-1 : Int)) →
  r3 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r3 A B C D E F G H I J K L M N O P S R) →
  (M = (-1 : Int) * S + Q) →
  r24 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r29 A B C D E F G H I J K L M N O P S R) →
  (M = (-1 : Int) * S + Q) →
  r24 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r18 A B C D E F G H I J K L M N O P Q R) →
  (O ≥ (1 : Int)) →
  r29 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r27 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  r26 A B C D E F G H I J K L M N O P Q R) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r26 A B C D E F G H I J K L M N O P Q R) →
  (N + (-1 : Int) * Q ≥ (0 : Int)) →
  r6 A B C D E F G H I J K L M N O P Q R) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r6 A B C D E F G H I J K L M N O P Q R) →
  (True) →
  False)))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«21.c_000»
