import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«05.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":318:1-318:12 (check-sat, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":26:1-35:2 (clause 1, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":36:1-46:2 (clause 2, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":47:1-57:2 (clause 3, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":58:1-68:2 (clause 4, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":69:1-79:2 (clause 5, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":80:1-90:2 (clause 6, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":91:1-101:2 (clause 7, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":102:1-112:2 (clause 8, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":113:1-123:2 (clause 9, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":124:1-134:2 (clause 10, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":135:1-145:2 (clause 11, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":146:1-159:2 (clause 12, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":160:1-173:2 (clause 13, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":174:1-184:2 (clause 14, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":185:1-195:2 (clause 15, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":196:1-206:2 (clause 16, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":207:1-217:2 (clause 17, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":218:1-228:2 (clause 18, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":229:1-239:2 (clause 19, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":240:1-250:2 (clause 20, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":251:1-261:2 (clause 21, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":262:1-272:2 (clause 22, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":273:1-283:2 (clause 23, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":284:1-294:2 (clause 24, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":295:1-305:2 (clause 25, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/05.c_000.smt2":306:1-316:2 (clause 26, command 48)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F v_6 v_7 v_8 v_9 v_10 v_11 : Int),
  (True) →
  (v_6 = A) →
  (v_7 = B) →
  (v_8 = C) →
  (v_9 = D) →
  (v_10 = E) →
  (v_11 = F) →
  r6 A B C D E F v_6 v_7 v_8 v_9 v_10 v_11) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r6 A B C D E F G M N O P L) →
  (I = (0 : Int)) →
  (H = (0 : Int)) →
  (K = (0 : Int)) →
  (J = (0 : Int)) →
  r14 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r14 A B C D E F G H I J K L) →
  (True) →
  r7 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r7 A B C D E F G H I J K L) →
  (True) →
  r1 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A B C D E F G H I J K L) →
  (True) →
  r12 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r19 A B C D E F G H I J K L) →
  (True) →
  r12 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r16 A B C D E F G H I J K L) →
  (True) →
  r12 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r12 A B C D E F G H I J K L) →
  (True) →
  r20 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r20 A B C D E F G H I J K L) →
  (True) →
  r5 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r5 A B C D E F G H I J K L) →
  (True) →
  r2 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D E F G H I J K L) →
  (L ≤ (-1 : Int)) →
  r10 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r10 A B C D E F G M O P N L) →
  (O = (-1 : Int) + I) →
  (N = (-1 : Int) * H + K) →
  (M = (-1 : Int) + H) →
  (P = (-1 : Int) * I + J) →
  r8 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r15 A B C D E F G M O P N L) →
  (O = (-1 : Int) + I) →
  (N = (-1 : Int) * H + K) →
  (M = (-1 : Int) + H) →
  (P = (-1 : Int) * I + J) →
  r8 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D E F G H I J K L) →
  (L ≥ (1 : Int)) →
  r15 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D E F G H I J K L) →
  (L = (0 : Int)) →
  r3 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A B C D E F G H I J K L) →
  (True) →
  r13 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r13 A B C D E F G H I J K L) →
  (True) →
  r17 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r8 A B C D E F G H I J K L) →
  (True) →
  r9 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r9 A B C D E F G H I J K L) →
  (G ≤ (-1 : Int)) →
  r4 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r4 A B C D E F G H I M K L) →
  (M = (-1 : Int) + J) →
  r16 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r18 A B C D E F G H I M K L) →
  (M = (-1 : Int) + J) →
  r16 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r9 A B C D E F G H I J K L) →
  (G ≥ (1 : Int)) →
  r18 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r9 A B C D E F G H I J K L) →
  (G = (0 : Int)) →
  r19 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r17 A B C D E F G H I J K L) →
  (True) →
  r0 A B C D E F G H I J K L) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D E F G H I J K L) →
  (J + (-1 : Int) * K ≤ (-1 : Int)) →
  r11 A B C D E F G H I J K L) ∧
  (∀ (A B C D E F G H I J K L : Int),
  (r11 A B C D E F G H I J K L) →
  (True) →
  False)))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«05.c_000»
