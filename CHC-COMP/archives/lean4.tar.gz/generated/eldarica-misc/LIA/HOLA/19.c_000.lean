import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«19.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":348:1-348:12 (check-sat, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":30:1-39:2 (clause 1, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":40:1-50:2 (clause 2, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":51:1-61:2 (clause 3, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":62:1-72:2 (clause 4, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":73:1-83:2 (clause 5, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":84:1-94:2 (clause 6, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":95:1-105:2 (clause 7, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":106:1-116:2 (clause 8, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":117:1-127:2 (clause 9, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":128:1-138:2 (clause 10, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":139:1-149:2 (clause 11, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":150:1-160:2 (clause 12, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":161:1-171:2 (clause 13, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":172:1-182:2 (clause 14, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":183:1-193:2 (clause 15, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":194:1-204:2 (clause 16, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":205:1-215:2 (clause 17, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":216:1-226:2 (clause 18, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":227:1-237:2 (clause 19, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":238:1-248:2 (clause 20, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":249:1-259:2 (clause 21, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":260:1-270:2 (clause 22, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":271:1-281:2 (clause 23, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":282:1-292:2 (clause 24, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":293:1-303:2 (clause 25, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":304:1-314:2 (clause 26, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":315:1-325:2 (clause 27, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":326:1-336:2 (clause 28, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/19.c_000.smt2":337:1-346:2 (clause 29, command 55)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D v_4 v_5 v_6 v_7 : Int),
  (True) →
  (v_4 = A) →
  (v_5 = B) →
  (v_6 = C) →
  (v_7 = D) →
  r12 A B C D v_4 v_5 v_6 v_7) ∧
  ((∀ (A B C D E F G H : Int),
  (r12 A B C D E F G H) →
  (True) →
  r8 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r8 A B C D E F G H) →
  (E ≥ (0 : Int)) →
  r21 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r21 A B C D E F G H) →
  (True) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 A B C D E F G H) →
  (F ≥ (0 : Int)) →
  r24 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r24 A B C D E F G H) →
  (True) →
  r6 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r6 A B C D E F G H) →
  (E + (-1 : Int) * F ≥ (1 : Int)) →
  r18 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r18 A B C D E F I J) →
  (G = (0 : Int)) →
  (F = H) →
  r13 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r13 A B C D E F G H) →
  (True) →
  r22 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r22 A B C D E F G H) →
  (True) →
  r16 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r16 A B C D E F G H) →
  (True) →
  r23 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r7 A B C D E F G H) →
  (True) →
  r23 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 A B C D E F G H) →
  (True) →
  r23 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r23 A B C D E F G H) →
  (True) →
  r15 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r15 A B C D E F G H) →
  (E + (-1 : Int) * G ≥ (1 : Int)) →
  r14 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r14 A B C D E F I H) →
  (I = (-1 : Int) + G) →
  r4 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r15 A B C D E F G H) →
  (E + (-1 : Int) * G ≤ (0 : Int)) →
  r3 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r3 A B C D E F G H) →
  (True) →
  r20 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r20 A B C D E F G H) →
  (True) →
  r19 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r4 A B C D E F G H) →
  (True) →
  r9 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r9 A B C D E F G H) →
  (F + (-1 : Int) * G ≤ (-1 : Int)) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I : Int),
  (r1 A B C D E F G I) →
  (I = (-1 : Int) + H) →
  r2 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r9 A B C D E F G H) →
  (F + (-1 : Int) * G ≥ (0 : Int)) →
  r7 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r19 A B C D E F G H) →
  (True) →
  r11 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r11 A B C D E F G H) →
  (E + (-1 : Int) * H ≥ (1 : Int)) →
  r17 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r11 A B C D E F G H) →
  (E + (-1 : Int) * H ≤ (-1 : Int)) →
  r5 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (r17 A B C D E F G H) →
  (True) →
  r10) ∧
  ((∀ (A B C D E F G H : Int),
  (r5 A B C D E F G H) →
  (True) →
  r10) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r10) →
  False))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«19.c_000»
