import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«14.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":395:1-395:12 (check-sat, command 63)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":33:1-42:2 (clause 1, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":43:1-53:2 (clause 2, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":54:1-64:2 (clause 3, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":65:1-75:2 (clause 4, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":76:1-86:2 (clause 5, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":87:1-97:2 (clause 6, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":98:1-108:2 (clause 7, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":109:1-119:2 (clause 8, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":120:1-130:2 (clause 9, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":131:1-141:2 (clause 10, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":142:1-152:2 (clause 11, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":153:1-163:2 (clause 12, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":164:1-174:2 (clause 13, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":175:1-185:2 (clause 14, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":186:1-196:2 (clause 15, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":197:1-207:2 (clause 16, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":208:1-218:2 (clause 17, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":219:1-229:2 (clause 18, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":230:1-240:2 (clause 19, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":241:1-251:2 (clause 20, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":252:1-262:2 (clause 21, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":263:1-273:2 (clause 22, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":274:1-284:2 (clause 23, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":285:1-295:2 (clause 24, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":296:1-306:2 (clause 25, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":307:1-317:2 (clause 26, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":318:1-328:2 (clause 27, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":329:1-339:2 (clause 28, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":340:1-350:2 (clause 29, command 58)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":351:1-361:2 (clause 30, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":362:1-372:2 (clause 31, command 60)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":373:1-383:2 (clause 32, command 61)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/14.c_000.smt2":384:1-393:2 (clause 33, command 62)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E v_5 v_6 v_7 v_8 v_9 : Int),
  (True) →
  (v_5 = A) →
  (v_6 = B) →
  (v_7 = C) →
  (v_8 = D) →
  (v_9 = E) →
  r23 A B C D E v_5 v_6 v_7 v_8 v_9) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r23 A B C D E K G H I J) →
  (F = (0 : Int)) →
  r20 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r20 A B C D E F G H I J) →
  (True) →
  r11 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r11 A B C D E F G H I J) →
  (H ≥ (1 : Int)) →
  r15 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r15 A B C D E F K H I J) →
  (G = (1 : Int)) →
  r5 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r5 A B C D E F G H I J) →
  (True) →
  r3 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 A B C D E F G H I J) →
  (True) →
  r18 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r18 A B C D E F G H I J) →
  (True) →
  r26 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r27 A B C D E F G H I J) →
  (True) →
  r26 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r26 A B C D E F G H I J) →
  (True) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B C D E F G H I J) →
  (G + (-1 : Int) * H ≤ (0 : Int)) →
  r8 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r8 A B C D E F G H I J) →
  (True) →
  r2 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B C D E F G H I J) →
  (G + (-1 : Int) * H ≥ (1 : Int)) →
  r12 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r12 A B C D E F G H I J) →
  (True) →
  r14 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r14 A B C D E F G H I J) →
  (True) →
  r13 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r2 A B C D E F G H I J) →
  (True) →
  r6 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r6 A B C D E F G H I J) →
  (True) →
  r16 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r16 A B C D E F G H I J) →
  (I ≤ (-1 : Int)) →
  r21 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r21 A B C D E K G H I J) →
  (K = (-1 : Int) + F) →
  r1 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r22 A B C D E K G H I J) →
  (K = (-1 : Int) + F) →
  r1 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r16 A B C D E F G H I J) →
  (I ≥ (1 : Int)) →
  r22 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r16 A B C D E F G H I J) →
  (I = (0 : Int)) →
  r25 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r25 A B C D E K G H I J) →
  (K = (1 : Int) + F) →
  r24 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r1 A B C D E F K H I J) →
  (K = (-1 : Int) + G) →
  r27 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r24 A B C D E F K H I J) →
  (K = (-1 : Int) + G) →
  r27 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r13 A B C D E F G H I J) →
  (True) →
  r4 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r4 A B C D E F G H I J) →
  (F + H ≤ (-1 : Int)) →
  r10 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r4 A B C D E F G H I J) →
  (F + H ≥ (0 : Int)) →
  r7 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r7 A B C D E F G H I J) →
  (True) →
  r19 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r19 A B C D E F G H I J) →
  (F + (-1 : Int) * H ≥ (1 : Int)) →
  r17 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r10 A B C D E F G H I J) →
  (True) →
  r9) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r17 A B C D E F G H I J) →
  (True) →
  r9) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r9) →
  False))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«14.c_000»
