import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«40.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":684:1-684:12 (check-sat, command 105)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":51:1-67:2 (clause 1, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":68:1-78:2 (clause 2, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":79:1-89:2 (clause 3, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":90:1-100:2 (clause 4, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":101:1-111:2 (clause 5, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":112:1-122:2 (clause 6, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":123:1-133:2 (clause 7, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":134:1-144:2 (clause 8, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":145:1-155:2 (clause 9, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":156:1-166:2 (clause 10, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":167:1-177:2 (clause 11, command 58)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":178:1-188:2 (clause 12, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":189:1-199:2 (clause 13, command 60)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":200:1-210:2 (clause 14, command 61)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":211:1-221:2 (clause 15, command 62)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":222:1-232:2 (clause 16, command 63)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":233:1-243:2 (clause 17, command 64)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":244:1-254:2 (clause 18, command 65)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":255:1-265:2 (clause 19, command 66)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":266:1-276:2 (clause 20, command 67)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":277:1-287:2 (clause 21, command 68)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":288:1-298:2 (clause 22, command 69)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":299:1-309:2 (clause 23, command 70)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":310:1-320:2 (clause 24, command 71)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":321:1-331:2 (clause 25, command 72)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":332:1-342:2 (clause 26, command 73)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":343:1-353:2 (clause 27, command 74)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":354:1-364:2 (clause 28, command 75)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":365:1-375:2 (clause 29, command 76)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":376:1-386:2 (clause 30, command 77)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":387:1-397:2 (clause 31, command 78)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":398:1-408:2 (clause 32, command 79)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":409:1-419:2 (clause 33, command 80)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":420:1-430:2 (clause 34, command 81)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":431:1-441:2 (clause 35, command 82)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":442:1-452:2 (clause 36, command 83)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":453:1-463:2 (clause 37, command 84)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":464:1-474:2 (clause 38, command 85)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":475:1-485:2 (clause 39, command 86)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":486:1-496:2 (clause 40, command 87)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":497:1-507:2 (clause 41, command 88)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":508:1-518:2 (clause 42, command 89)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":519:1-529:2 (clause 43, command 90)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":530:1-540:2 (clause 44, command 91)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":541:1-551:2 (clause 45, command 92)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":552:1-562:2 (clause 46, command 93)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":563:1-573:2 (clause 47, command 94)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":574:1-584:2 (clause 48, command 95)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":585:1-595:2 (clause 49, command 96)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":596:1-606:2 (clause 50, command 97)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":607:1-617:2 (clause 51, command 98)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":618:1-628:2 (clause 52, command 99)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":629:1-639:2 (clause 53, command 100)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":640:1-650:2 (clause 54, command 101)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":651:1-661:2 (clause 55, command 102)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":662:1-672:2 (clause 56, command 103)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/40.c_000.smt2":673:1-682:2 (clause 57, command 104)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r28 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r29 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r30 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r31 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r32 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r33 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r34 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r35 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r36 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r37 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r38 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r39 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r40 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r41 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r42 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r43 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r44 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r45 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G v_7 v_8 v_9 v_10 v_11 v_12 v_13 : Int),
  (True) →
  (v_7 = A) →
  (v_8 = B) →
  (v_9 = C) →
  (v_10 = D) →
  (v_11 = E) →
  (v_12 = F) →
  (v_13 = G) →
  r20 A B C D E F G v_7 v_8 v_9 v_10 v_11 v_12 v_13) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r20 A B C D E F G H I O K L M N) →
  (J = (1 : Int)) →
  r31 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r31 A B C D E F G H I J K L M N) →
  (True) →
  r30 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r30 A B C D E F G H I J K L M N) →
  (H ≤ (-1 : Int)) →
  r5 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r5 A B C D E F G H O J K L M N) →
  (I = (0 : Int)) →
  r37 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r32 A B C D E F G H O J K L M N) →
  (I = (0 : Int)) →
  r37 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r30 A B C D E F G H I J K L M N) →
  (H ≥ (1 : Int)) →
  r32 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r30 A B C D E F G H I J K L M N) →
  (H = (0 : Int)) →
  r7 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r7 A B C D E F G H O J K L M N) →
  (I = (1 : Int)) →
  r43 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r37 A B C D E F G H I J K L M N) →
  (True) →
  r44 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r43 A B C D E F G H I J K L M N) →
  (True) →
  r44 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r44 A B C D E F G H I J K L M N) →
  (True) →
  r9 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r9 A B C D E F G H I J K L M N) →
  (True) →
  r21 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r41 A B C D E F G H I J K L M N) →
  (True) →
  r21 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r16 A B C D E F G H I J K L M N) →
  (True) →
  r21 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r21 A B C D E F G H I J K L M N) →
  (True) →
  r23 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r23 A B C D E F G H I J K L M N) →
  (True) →
  r12 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r12 A B C D E F G H I J K L M N) →
  (True) →
  r11 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r11 A B C D E F G H I J K L M N) →
  (K ≤ (-1 : Int)) →
  r26 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r26 A B C D E F G H O J K L M N) →
  (O = (-2 : Int) + I) →
  r3 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r33 A B C D E F G H O J K L M N) →
  (O = (-2 : Int) + I) →
  r3 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r11 A B C D E F G H I J K L M N) →
  (K ≥ (1 : Int)) →
  r33 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r11 A B C D E F G H I J K L M N) →
  (K = (0 : Int)) →
  r17 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r17 A B C D E F G H I J K L M N) →
  (True) →
  r0 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r0 A B C D E F G H I J K L M N) →
  (True) →
  r27 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r3 A B C D E F G H I J K L M N) →
  (True) →
  r45 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r45 A B C D E F G H I J K L M N) →
  (True) →
  r28 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r28 A B C D E F G H I O K L M N) →
  (O = (-2 : Int) + J) →
  r41 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r45 A B C D E F G H I J K L M N) →
  (True) →
  r22 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r22 A B C D E F G H I O K L M N) →
  (O = (-1 : Int) + J) →
  r16 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r14 A B C D E F G H I O K L M N) →
  (O = (-1 : Int) + J) →
  r16 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r45 A B C D E F G H I J K L M N) →
  (True) →
  r14 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r27 A B C D E F G H I J K O P N) →
  (L = (0 : Int)) →
  (M = (0 : Int)) →
  r40 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r40 A B C D E F G H I J K L M N) →
  (True) →
  r42 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r42 A B C D E F G H I J K L M N) →
  (True) →
  r38 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r38 A B C D E F G H I J K L M N) →
  (True) →
  r1 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r6 A B C D E F G H I J K L M N) →
  (True) →
  r1 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r1 A B C D E F G H I J K L M N) →
  (True) →
  r35 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r35 A B C D E F G H I J K L M N) →
  (True) →
  r36 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r36 A B C D E F G H I J K L M N) →
  (True) →
  r18 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r18 A B C D E F G H I J K L M N) →
  (N ≤ (-1 : Int)) →
  r24 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r24 A B C D E F G H I J K O P N) →
  (O = (-1 : Int) + L) →
  (I = J + P + (-1 : Int) * M) →
  r6 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r25 A B C D E F G H I J K O P N) →
  (O = (-1 : Int) + L) →
  (I = J + P + (-1 : Int) * M) →
  r6 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r18 A B C D E F G H I J K L M N) →
  (N ≥ (1 : Int)) →
  r25 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r18 A B C D E F G H I J K L M N) →
  (N = (0 : Int)) →
  r10 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r10 A B C D E F G H I J K L M N) →
  (True) →
  r13 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r13 A B C D E F G H I J K L M N) →
  (True) →
  r2 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r2 A B C D E F G H I J K L M N) →
  (True) →
  r39 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r39 A B C D E F G H I J K L M N) →
  (H ≤ (-1 : Int)) →
  r29 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r29 A B C D E F G H I J K L M N) →
  (True) →
  r4 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r8 A B C D E F G H I J K L M N) →
  (True) →
  r4 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r39 A B C D E F G H I J K L M N) →
  (H ≥ (1 : Int)) →
  r8 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r4 A B C D E F G H I J K L M N) →
  (L + (-1 : Int) * M ≤ (-1 : Int)) →
  r19 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r4 A B C D E F G H I J K L M N) →
  (L + (-1 : Int) * M ≥ (1 : Int)) →
  r34 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r19 A B C D E F G H I J K L M N) →
  (True) →
  r15) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r34 A B C D E F G H I J K L M N) →
  (True) →
  r15) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r15) →
  False))))))))))))))))))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«40.c_000»
