import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«10.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":482:1-482:12 (check-sat, command 70)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":32:1-41:2 (clause 1, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":42:1-52:2 (clause 2, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":53:1-63:2 (clause 3, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":64:1-74:2 (clause 4, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":75:1-85:2 (clause 5, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":86:1-96:2 (clause 6, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":97:1-107:2 (clause 7, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":108:1-118:2 (clause 8, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":119:1-129:2 (clause 9, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":130:1-140:2 (clause 10, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":141:1-151:2 (clause 11, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":152:1-162:2 (clause 12, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":163:1-173:2 (clause 13, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":174:1-184:2 (clause 14, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":185:1-195:2 (clause 15, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":196:1-206:2 (clause 16, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":207:1-217:2 (clause 17, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":218:1-228:2 (clause 18, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":229:1-239:2 (clause 19, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":240:1-250:2 (clause 20, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":251:1-261:2 (clause 21, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":262:1-272:2 (clause 22, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":273:1-283:2 (clause 23, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":284:1-294:2 (clause 24, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":295:1-305:2 (clause 25, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":306:1-316:2 (clause 26, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":317:1-327:2 (clause 27, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":328:1-338:2 (clause 28, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":339:1-349:2 (clause 29, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":350:1-360:2 (clause 30, command 58)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":361:1-371:2 (clause 31, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":372:1-382:2 (clause 32, command 60)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":383:1-393:2 (clause 33, command 61)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":394:1-404:2 (clause 34, command 62)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":405:1-415:2 (clause 35, command 63)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":416:1-426:2 (clause 36, command 64)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":427:1-437:2 (clause 37, command 65)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":438:1-448:2 (clause 38, command 66)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":449:1-459:2 (clause 39, command 67)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":460:1-470:2 (clause 40, command 68)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/10.c_000.smt2":471:1-480:2 (clause 41, command 69)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E v_5 v_6 v_7 v_8 v_9 : Int),
  (True) →
  (v_5 = A) →
  (v_6 = B) →
  (v_7 = C) →
  (v_8 = D) →
  (v_9 = E) →
  r22 A B C D E v_5 v_6 v_7 v_8 v_9) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r22 A B C D E K L M N J) →
  (H = (0 : Int)) →
  (G = (0 : Int)) →
  (F = (1 : Int)) →
  (I = (0 : Int)) →
  r18 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r18 A B C D E F G H I J) →
  (True) →
  r9 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r9 A B C D E F G H I J) →
  (True) →
  r11 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r11 A B C D E F G H I J) →
  (True) →
  r8 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r1 A B C D E F G H I J) →
  (True) →
  r8 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r20 A B C D E F G H I J) →
  (True) →
  r8 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r19 A B C D E F G H I J) →
  (True) →
  r8 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r8 A B C D E F G H I J) →
  (True) →
  r15 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r15 A B C D E F G H I J) →
  (True) →
  r26 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r26 A B C D E F G H I J) →
  (True) →
  r14 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r14 A B C D E F G H I J) →
  (J ≤ (-1 : Int)) →
  r21 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r21 A B C D E F G H I J) →
  (True) →
  r3 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r17 A B C D E F G H I J) →
  (True) →
  r3 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r14 A B C D E F G H I J) →
  (J ≥ (1 : Int)) →
  r17 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r14 A B C D E F G H I J) →
  (J = (0 : Int)) →
  r25 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r25 A B C D E F G H I J) →
  (True) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B C D E F G H I J) →
  (True) →
  r6 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 A B C D E F G H I J) →
  (F ≤ (-1 : Int)) →
  r2 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D E L G K I J) →
  (K = (-1 : Int) + H) →
  (L ≤ (-1 : Int)) →
  (F = (0 : Int)) →
  r10 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D E L G K I J) →
  (K = (-1 : Int) + H) →
  (L ≥ (1 : Int)) →
  (F = (0 : Int)) →
  r10 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A B C D E K G L I J) →
  (L = (-1 : Int) + H) →
  (K = (0 : Int)) →
  (F = (1 : Int)) →
  r10 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r13 A B C D E L G K I J) →
  (K = (-1 : Int) + H) →
  (L ≤ (-1 : Int)) →
  (F = (0 : Int)) →
  r10 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r13 A B C D E L G K I J) →
  (K = (-1 : Int) + H) →
  (L ≥ (1 : Int)) →
  (F = (0 : Int)) →
  r10 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r13 A B C D E K G L I J) →
  (L = (-1 : Int) + H) →
  (K = (0 : Int)) →
  (F = (1 : Int)) →
  r10 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 A B C D E F G H I J) →
  (F ≥ (1 : Int)) →
  r13 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 A B C D E F G H I J) →
  (F = (0 : Int)) →
  r12 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r12 A B C D E F G H I J) →
  (True) →
  r5 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r10 A B C D E F G H I J) →
  (True) →
  r5 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r5 A B C D E F G H I J) →
  (G = (0 : Int)) →
  r16 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r16 A B C D E F L H K J) →
  (K = (-1 : Int) + I) →
  (L ≤ (-1 : Int)) →
  (G = (0 : Int)) →
  r19 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r16 A B C D E F L H K J) →
  (K = (-1 : Int) + I) →
  (L ≥ (1 : Int)) →
  (G = (0 : Int)) →
  r19 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r16 A B C D E F K H L J) →
  (L = (-1 : Int) + I) →
  (K = (0 : Int)) →
  (G = (1 : Int)) →
  r19 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r5 A B C D E F G H I J) →
  (G ≤ (-1 : Int)) →
  r1 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r5 A B C D E F G H I J) →
  (G ≥ (1 : Int)) →
  r20 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r6 A B C D E F G H I J) →
  (True) →
  r23 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r23 A B C D E F G H I J) →
  (H + (-1 : Int) * I ≤ (-1 : Int)) →
  r24 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r23 A B C D E F G H I J) →
  (H + (-1 : Int) * I ≥ (1 : Int)) →
  r4 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r24 A B C D E F G H I J) →
  (True) →
  r7) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r4 A B C D E F G H I J) →
  (True) →
  r7) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r7) →
  False))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«10.c_000»
