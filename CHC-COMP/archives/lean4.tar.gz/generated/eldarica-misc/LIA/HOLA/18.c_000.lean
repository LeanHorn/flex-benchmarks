import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«18.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":346:1-346:12 (check-sat, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":28:1-37:2 (clause 1, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":38:1-48:2 (clause 2, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":49:1-59:2 (clause 3, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":60:1-70:2 (clause 4, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":71:1-81:2 (clause 5, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":82:1-92:2 (clause 6, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":93:1-103:2 (clause 7, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":104:1-114:2 (clause 8, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":115:1-125:2 (clause 9, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":126:1-136:2 (clause 10, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":137:1-147:2 (clause 11, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":148:1-158:2 (clause 12, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":159:1-169:2 (clause 13, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":170:1-180:2 (clause 14, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":181:1-191:2 (clause 15, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":192:1-202:2 (clause 16, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":203:1-213:2 (clause 17, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":214:1-224:2 (clause 18, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":225:1-235:2 (clause 19, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":236:1-246:2 (clause 20, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":247:1-257:2 (clause 21, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":258:1-268:2 (clause 22, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":269:1-279:2 (clause 23, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":280:1-290:2 (clause 24, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":291:1-301:2 (clause 25, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":302:1-312:2 (clause 26, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":313:1-323:2 (clause 27, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":324:1-334:2 (clause 28, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/18.c_000.smt2":335:1-344:2 (clause 29, command 53)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E v_5 v_6 v_7 v_8 v_9 : Int),
  (True) →
  (v_5 = A) →
  (v_6 = B) →
  (v_7 = C) →
  (v_8 = D) →
  (v_9 = E) →
  r19 A B C D E v_5 v_6 v_7 v_8 v_9) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r19 A B C D E F G K L J) →
  (H = (0 : Int)) →
  (I = (0 : Int)) →
  r16 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r16 A B C D E F G H I J) →
  (True) →
  r7 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r7 A B C D E F G H I J) →
  (True) →
  r10 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r10 A B C D E F G H I J) →
  (True) →
  r6 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r8 A B C D E F G H I J) →
  (True) →
  r6 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r6 A B C D E F G H I J) →
  (True) →
  r13 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r13 A B C D E F G H I J) →
  (H ≤ (99 : Int)) →
  r22 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r22 A B C D E F G H I J) →
  (True) →
  r12 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r13 A B C D E F G H I J) →
  (H ≥ (100 : Int)) →
  r18 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r18 A B C D E F G H I J) →
  (True) →
  r2 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r2 A B C D E F G H I J) →
  (True) →
  r15 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r12 A B C D E F G H I J) →
  (F ≤ (-1 : Int)) →
  r21 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r21 A B C D E F G H K J) →
  (K = (-1 : Int) + I) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r4 A B C D E F G H K J) →
  (K = (-1 : Int) + I) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r12 A B C D E F G H I J) →
  (F ≥ (1 : Int)) →
  r4 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r12 A B C D E F G H I J) →
  (F = (0 : Int)) →
  r1 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r1 A B C D E F G K I J) →
  (K = (-1 : Int) + H) →
  r8 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 A B C D E F G K I J) →
  (K = (-1 : Int) + H) →
  r8 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r15 A B C D E F G H I J) →
  (True) →
  r11 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r11 A B C D E F G H I J) →
  (F ≤ (-1 : Int)) →
  r9 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r9 A B C D E F G H I J) →
  (True) →
  r3 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r14 A B C D E F G H I J) →
  (True) →
  r3 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r11 A B C D E F G H I J) →
  (F ≥ (1 : Int)) →
  r14 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 A B C D E F G H I J) →
  (I ≤ (99 : Int)) →
  r17 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 A B C D E F G H I J) →
  (I ≥ (101 : Int)) →
  r20 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r17 A B C D E F G H I J) →
  (True) →
  r5) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r20 A B C D E F G H I J) →
  (True) →
  r5) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r5) →
  False))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«18.c_000»
