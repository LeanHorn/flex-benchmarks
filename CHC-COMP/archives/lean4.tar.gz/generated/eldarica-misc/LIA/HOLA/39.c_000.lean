import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«39.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":299:1-299:12 (check-sat, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":26:1-45:2 (clause 1, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":46:1-56:2 (clause 2, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":57:1-67:2 (clause 3, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":68:1-78:2 (clause 4, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":79:1-89:2 (clause 5, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":90:1-100:2 (clause 6, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":101:1-111:2 (clause 7, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":112:1-122:2 (clause 8, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":123:1-133:2 (clause 9, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":134:1-144:2 (clause 10, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":145:1-155:2 (clause 11, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":156:1-166:2 (clause 12, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":167:1-177:2 (clause 13, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":178:1-188:2 (clause 14, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":189:1-199:2 (clause 15, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":200:1-210:2 (clause 16, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":211:1-221:2 (clause 17, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":222:1-232:2 (clause 18, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":233:1-243:2 (clause 19, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":244:1-254:2 (clause 20, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":255:1-265:2 (clause 21, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":266:1-276:2 (clause 22, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":277:1-287:2 (clause 23, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/39.c_000.smt2":288:1-297:2 (clause 24, command 46)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Prop),
  ∃ (r11 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J v_10 v_11 v_12 v_13 v_14 v_15 v_16 v_17 v_18 v_19 : Int),
  (True) →
  (v_10 = A) →
  (v_11 = B) →
  (v_12 = C) →
  (v_13 = D) →
  (v_14 = E) →
  (v_15 = F) →
  (v_16 = G) →
  (v_17 = H) →
  (v_18 = I) →
  (v_19 = J) →
  r6 A B C D E F G H I J v_10 v_11 v_12 v_13 v_14 v_15 v_16 v_17 v_18 v_19) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r6 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r9 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r9 A B C D E F G H I J K L M N O P Q R S T) →
  (K ≥ (1 : Int)) →
  r18 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z : Int),
  (r18 A B C D E F G H I J K L U V W X Y Z S T) →
  (O = Q) →
  (N = (0 : Int)) →
  (M = (0 : Int)) →
  (K = Q) →
  (R = (0 : Int)) →
  (P = (0 : Int)) →
  r3 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r3 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r14 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r14 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r12 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r12 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r20 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r8 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r20 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r20 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r11 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r11 A B C D E F G H I J K L M N O P Q R S T) →
  (P + (-1 : Int) * Q + R ≤ (-1 : Int)) →
  r17 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r17 A B C D E F G H I J K L M N O P Q U S T) →
  (U = (-1 : Int) + R) →
  r5 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r5 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r19 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r19 A B C D E F G H I J K L M N O P Q R S T) →
  (R ≤ (-1 : Int)) →
  r16 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r19 A B C D E F G H I J K L M N O P Q R S T) →
  (R ≥ (0 : Int)) →
  r7 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r7 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r1 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r1 A B C D E F G H I J K L M N O P Q R S T) →
  (K + (-1 : Int) * R ≤ (-1 : Int)) →
  r2 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r1 A B C D E F G H I J K L M N O P Q R S T) →
  (K + (-1 : Int) * R ≥ (0 : Int)) →
  r4 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r4 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r15 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r15 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r13 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r13 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r0 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N O P Q R S T) →
  (S = (0 : Int)) →
  r8 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r16 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r10) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r2 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r10) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r10) →
  False)))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«39.c_000»
