import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«41.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":356:1-356:12 (check-sat, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":30:1-46:2 (clause 1, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":47:1-57:2 (clause 2, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":58:1-68:2 (clause 3, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":69:1-79:2 (clause 4, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":80:1-90:2 (clause 5, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":91:1-101:2 (clause 6, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":102:1-112:2 (clause 7, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":113:1-123:2 (clause 8, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":124:1-134:2 (clause 9, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":135:1-145:2 (clause 10, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":146:1-156:2 (clause 11, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":157:1-167:2 (clause 12, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":168:1-178:2 (clause 13, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":179:1-189:2 (clause 14, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":190:1-200:2 (clause 15, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":201:1-211:2 (clause 16, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":212:1-222:2 (clause 17, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":223:1-233:2 (clause 18, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":234:1-244:2 (clause 19, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":245:1-255:2 (clause 20, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":256:1-266:2 (clause 21, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":267:1-277:2 (clause 22, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":278:1-288:2 (clause 23, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":289:1-299:2 (clause 24, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":300:1-310:2 (clause 25, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":311:1-321:2 (clause 26, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":322:1-332:2 (clause 27, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":333:1-343:2 (clause 28, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/41.c_000.smt2":344:1-354:2 (clause 29, command 55)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G v_7 v_8 v_9 v_10 v_11 v_12 v_13 : Int),
  (True) →
  (v_7 = A) →
  (v_8 = B) →
  (v_9 = C) →
  (v_10 = D) →
  (v_11 = E) →
  (v_12 = F) →
  (v_13 = G) →
  r9 A B C D E F G v_7 v_8 v_9 v_10 v_11 v_12 v_13) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r9 A B C D E F G H I J K L M N) →
  (True) →
  r17 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r17 A B C D E F G H I J K L M N) →
  (H ≥ (0 : Int)) →
  r16 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r16 A B C D E F G H I O K L M N) →
  (J = (1 : Int)) →
  r2 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r2 A B C D E F G H I J K L M N) →
  (True) →
  r20 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r20 A B C D E F G H I J K L M N) →
  (I ≤ (-1 : Int)) →
  r18 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r18 A B C D E F G H I J K L M N) →
  (True) →
  r3 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r22 A B C D E F G H I J K L M N) →
  (True) →
  r3 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r20 A B C D E F G H I J K L M N) →
  (I ≥ (1 : Int)) →
  r22 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r20 A B C D E F G H I J K L M N) →
  (I = (0 : Int)) →
  r23 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r23 A B C D E F G H I J O P M N) →
  (K = (0 : Int)) →
  (L = (0 : Int)) →
  r4 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r6 A B C D E F G H I J O P M N) →
  (K = (0 : Int)) →
  (L = (0 : Int)) →
  r4 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r3 A B C D E F G H I J K L M N) →
  (True) →
  r10 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r10 A B C D E F G H I J K L M N) →
  (True) →
  r12 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r12 A B C D E F G H I J K L M N) →
  (J ≥ (0 : Int)) →
  r6 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r4 A B C D E F G H I J K L M N) →
  (True) →
  r5 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r5 A B C D E F G H I J K L M N) →
  (True) →
  r13 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r13 A B C D E F G H I J K L M N) →
  (True) →
  r1 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r0 A B C D E F G H I J K L M N) →
  (True) →
  r1 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r1 A B C D E F G H I J K L M N) →
  (True) →
  r19 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r19 A B C D E F G H I J K L M N) →
  (H + (-1 : Int) * K ≥ (0 : Int)) →
  r8 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r8 A B C D E F G H I J O P M N) →
  (O = (-1 : Int) + K) →
  (P = (-1 : Int) * K + L) →
  r0 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r19 A B C D E F G H I J K L M N) →
  (H + (-1 : Int) * K ≤ (-1 : Int)) →
  r14 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r14 A B C D E F G H I J K L M N) →
  (True) →
  r24 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r24 A B C D E F G H I J K L M N) →
  (True) →
  r15 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r15 A B C D E F G H I J K L O N) →
  (J = (-1 : Int) * K + (-1 : Int) * L + M) →
  r21 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r21 A B C D E F G H I J K L M N) →
  (True) →
  r11 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r11 A B C D E F G H I J K L M N) →
  ((2 : Int) * H + (-1 : Int) * M ≥ (0 : Int)) →
  r7 A B C D E F G H I J K L M N) ∧
  (∀ (A B C D E F G H I J K L M N : Int),
  (r7 A B C D E F G H I J K L M N) →
  (True) →
  False))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«41.c_000»
