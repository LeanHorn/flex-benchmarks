import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«20.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":567:1-567:12 (check-sat, command 87)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":43:1-60:2 (clause 1, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":61:1-71:2 (clause 2, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":72:1-82:2 (clause 3, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":83:1-93:2 (clause 4, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":94:1-104:2 (clause 5, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":105:1-115:2 (clause 6, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":116:1-126:2 (clause 7, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":127:1-137:2 (clause 8, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":138:1-148:2 (clause 9, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":149:1-159:2 (clause 10, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":160:1-170:2 (clause 11, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":171:1-181:2 (clause 12, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":182:1-192:2 (clause 13, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":193:1-203:2 (clause 14, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":204:1-214:2 (clause 15, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":215:1-225:2 (clause 16, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":226:1-236:2 (clause 17, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":237:1-247:2 (clause 18, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":248:1-258:2 (clause 19, command 58)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":259:1-269:2 (clause 20, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":270:1-280:2 (clause 21, command 60)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":281:1-291:2 (clause 22, command 61)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":292:1-302:2 (clause 23, command 62)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":303:1-313:2 (clause 24, command 63)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":314:1-324:2 (clause 25, command 64)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":325:1-335:2 (clause 26, command 65)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":336:1-346:2 (clause 27, command 66)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":347:1-357:2 (clause 28, command 67)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":358:1-368:2 (clause 29, command 68)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":369:1-379:2 (clause 30, command 69)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":380:1-390:2 (clause 31, command 70)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":391:1-401:2 (clause 32, command 71)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":402:1-412:2 (clause 33, command 72)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":413:1-423:2 (clause 34, command 73)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":424:1-434:2 (clause 35, command 74)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":435:1-445:2 (clause 36, command 75)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":446:1-456:2 (clause 37, command 76)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":457:1-467:2 (clause 38, command 77)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":468:1-478:2 (clause 39, command 78)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":479:1-489:2 (clause 40, command 79)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":490:1-500:2 (clause 41, command 80)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":501:1-511:2 (clause 42, command 81)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":512:1-522:2 (clause 43, command 82)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":523:1-533:2 (clause 44, command 83)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":534:1-544:2 (clause 45, command 84)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":545:1-555:2 (clause 46, command 85)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/20.c_000.smt2":556:1-565:2 (clause 47, command 86)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r28 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r29 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r30 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r31 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r32 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r33 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r34 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r35 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r36 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r37 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H v_8 v_9 v_10 v_11 v_12 v_13 v_14 v_15 : Int),
  (True) →
  (v_8 = A) →
  (v_9 = B) →
  (v_10 = C) →
  (v_11 = D) →
  (v_12 = E) →
  (v_13 = F) →
  (v_14 = G) →
  (v_15 = H) →
  r25 A B C D E F G H v_8 v_9 v_10 v_11 v_12 v_13 v_14 v_15) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r25 A B C D E F G H I J K L M N O P) →
  (True) →
  r36 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r36 A B C D E F G H I J K L M N O P) →
  (I = (-1 : Int) * J + K) →
  r21 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r21 A B C D E F G H I J K Q M N R P) →
  (L = (0 : Int)) →
  (O = (0 : Int)) →
  r13 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r13 A B C D E F G H I J K L M N O P) →
  (True) →
  r29 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r29 A B C D E F G H I J K L M N O P) →
  (True) →
  r23 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r23 A B C D E F G H I J K L M N O P) →
  (True) →
  r30 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r0 A B C D E F G H I J K L M N O P) →
  (True) →
  r30 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r30 A B C D E F G H I J K L M N O P) →
  (True) →
  r11 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r11 A B C D E F G H I J K L M N O P) →
  (L + (-1 : Int) * N ≤ (-1 : Int)) →
  r33 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r33 A B C D E F G H I J K L M N O P) →
  (True) →
  r2 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r11 A B C D E F G H I J K L M N O P) →
  (L + (-1 : Int) * N ≥ (0 : Int)) →
  r15 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r15 A B C D E F G H I J K L M N O P) →
  (True) →
  r28 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r28 A B C D E F G H I J K L M N O P) →
  (True) →
  r16 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r2 A B C D E F G H I J K L M N O P) →
  (L = M) →
  r27 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r27 A B C D E F G H Q R K L M N O P) →
  (Q = (-1 : Int) + I) →
  (R = (1 : Int) + J) →
  r8 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r2 A B C D E F G H I J K L M N O P) →
  (L + (-1 : Int) * M ≤ (-1 : Int)) →
  r12 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r12 A B C D E F G H R Q K L M N O P) →
  (Q = (-1 : Int) + J) →
  (R = (1 : Int) + I) →
  r22 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r32 A B C D E F G H R Q K L M N O P) →
  (Q = (-1 : Int) + J) →
  (R = (1 : Int) + I) →
  r22 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r2 A B C D E F G H I J K L M N O P) →
  (L + (-1 : Int) * M ≥ (1 : Int)) →
  r32 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r8 A B C D E F G H I J K L M N O P) →
  (True) →
  r31 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r22 A B C D E F G H I J K L M N O P) →
  (True) →
  r31 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r31 A B C D E F G H I J K L M N O P) →
  (True) →
  r10 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r10 A B C D E F G H I J K L M N O P) →
  (True) →
  r3 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r3 A B C D E F G H I J K L M N O P) →
  (P ≤ (-1 : Int)) →
  r5 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  (r5 A B C D E F G H I J K L M N Q P) →
  (L = O) →
  r9 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  (r14 A B C D E F G H I J K L M N Q P) →
  (L = O) →
  r9 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r3 A B C D E F G H I J K L M N O P) →
  (P ≥ (1 : Int)) →
  r14 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r3 A B C D E F G H I J K L M N O P) →
  (P = (0 : Int)) →
  r17 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  (r17 A B C D E F G H I J K Q M N O P) →
  (Q = (-1 : Int) + L) →
  r0 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  (r9 A B C D E F G H I J K Q M N O P) →
  (Q = (-1 : Int) + L) →
  r0 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r16 A B C D E F G H I J K L M N O P) →
  (True) →
  r1 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r1 A B C D E F G H I J K L M N O P) →
  (I + J + (-1 : Int) * K ≤ (-1 : Int)) →
  r35 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r1 A B C D E F G H I J K L M N O P) →
  (I + J + (-1 : Int) * K ≥ (1 : Int)) →
  r20 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r1 A B C D E F G H I J K L M N O P) →
  (I = (-1 : Int) * J + K) →
  r24 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r24 A B C D E F G H I J K L M N O P) →
  (True) →
  r6 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r6 A B C D E F G H I J K L M N O P) →
  (N ≥ (1 : Int)) →
  r4 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r4 A B C D E F G H I J K L M N O P) →
  (True) →
  r7 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r7 A B C D E F G H I J K L M N O P) →
  (O ≤ (-1 : Int)) →
  r26 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r7 A B C D E F G H I J K L M N O P) →
  (O ≥ (0 : Int)) →
  r18 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r18 A B C D E F G H I J K L M N O P) →
  (True) →
  r37 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r37 A B C D E F G H I J K L M N O P) →
  (N + (-1 : Int) * O ≤ (0 : Int)) →
  r34 A B C D E F G H I J K L M N O P) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r35 A B C D E F G H I J K L M N O P) →
  (True) →
  r19) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r20 A B C D E F G H I J K L M N O P) →
  (True) →
  r19) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r26 A B C D E F G H I J K L M N O P) →
  (True) →
  r19) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r34 A B C D E F G H I J K L M N O P) →
  (True) →
  r19) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r19) →
  False))))))))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«20.c_000»
