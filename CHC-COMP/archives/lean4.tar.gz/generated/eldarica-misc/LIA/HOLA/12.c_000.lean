import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«12.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":659:1-659:12 (check-sat, command 100)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":49:1-68:2 (clause 1, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":69:1-79:2 (clause 2, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":80:1-90:2 (clause 3, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":91:1-101:2 (clause 4, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":102:1-112:2 (clause 5, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":113:1-123:2 (clause 6, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":124:1-134:2 (clause 7, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":135:1-145:2 (clause 8, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":146:1-156:2 (clause 9, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":157:1-167:2 (clause 10, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":168:1-178:2 (clause 11, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":179:1-192:2 (clause 12, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":193:1-206:2 (clause 13, command 58)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":207:1-217:2 (clause 14, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":218:1-228:2 (clause 15, command 60)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":229:1-239:2 (clause 16, command 61)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":240:1-250:2 (clause 17, command 62)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":251:1-261:2 (clause 18, command 63)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":262:1-272:2 (clause 19, command 64)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":273:1-283:2 (clause 20, command 65)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":284:1-294:2 (clause 21, command 66)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":295:1-305:2 (clause 22, command 67)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":306:1-316:2 (clause 23, command 68)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":317:1-327:2 (clause 24, command 69)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":328:1-338:2 (clause 25, command 70)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":339:1-349:2 (clause 26, command 71)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":350:1-360:2 (clause 27, command 72)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":361:1-371:2 (clause 28, command 73)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":372:1-382:2 (clause 29, command 74)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":383:1-393:2 (clause 30, command 75)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":394:1-404:2 (clause 31, command 76)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":405:1-415:2 (clause 32, command 77)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":416:1-426:2 (clause 33, command 78)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":427:1-437:2 (clause 34, command 79)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":438:1-448:2 (clause 35, command 80)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":449:1-459:2 (clause 36, command 81)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":460:1-470:2 (clause 37, command 82)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":471:1-481:2 (clause 38, command 83)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":482:1-492:2 (clause 39, command 84)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":493:1-503:2 (clause 40, command 85)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":504:1-514:2 (clause 41, command 86)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":515:1-525:2 (clause 42, command 87)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":526:1-536:2 (clause 43, command 88)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":537:1-547:2 (clause 44, command 89)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":548:1-558:2 (clause 45, command 90)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":559:1-569:2 (clause 46, command 91)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":570:1-580:2 (clause 47, command 92)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":581:1-591:2 (clause 48, command 93)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":592:1-602:2 (clause 49, command 94)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":603:1-613:2 (clause 50, command 95)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":614:1-624:2 (clause 51, command 96)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":625:1-635:2 (clause 52, command 97)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":636:1-646:2 (clause 53, command 98)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/12.c_000.smt2":647:1-657:2 (clause 54, command 99)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r28 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r29 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r30 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r31 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r32 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r33 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r34 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r35 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r36 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r37 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r38 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r39 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r40 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r41 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r42 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r43 : Int →
    Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J v_10 v_11 v_12 v_13 v_14 v_15 v_16 v_17 v_18 v_19 : Int),
  (True) →
  (v_10 = A) →
  (v_11 = B) →
  (v_12 = C) →
  (v_13 = D) →
  (v_14 = E) →
  (v_15 = F) →
  (v_16 = G) →
  (v_17 = H) →
  (v_18 = I) →
  (v_19 = J) →
  r17 A B C D E F G H I J v_10 v_11 v_12 v_13 v_14 v_15 v_16 v_17 v_18 v_19) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X : Int),
  (r17 A B C D E F G H I J K U V W X P Q R S T) →
  (M = (0 : Int)) →
  (L = (0 : Int)) →
  (O = (0 : Int)) →
  (N = (0 : Int)) →
  r21 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r21 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r36 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r36 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r6 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r6 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r8 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r18 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r8 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r40 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r8 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r8 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r39 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r39 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r35 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r35 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r27 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r27 A B C D E F G H I J K L M N O P Q R S T) →
  (P ≤ (-1 : Int)) →
  r25 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X : Int),
  (r25 A B C D E F G H I J K X V U W P Q R S T) →
  (W = (-1 : Int) + O) →
  (V = M + (-1 : Int) * N) →
  (U = (-1 : Int) + N) →
  (X = L + (-1 : Int) * O) →
  r43 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X : Int),
  (r22 A B C D E F G H I J K X V U W P Q R S T) →
  (W = (-1 : Int) + O) →
  (V = M + (-1 : Int) * N) →
  (U = (-1 : Int) + N) →
  (X = L + (-1 : Int) * O) →
  r43 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r27 A B C D E F G H I J K L M N O P Q R S T) →
  (P ≥ (1 : Int)) →
  r22 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r27 A B C D E F G H I J K L M N O P Q R S T) →
  (P = (0 : Int)) →
  r1 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r1 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r42 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r42 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r34 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r43 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r16 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r16 A B C D E F G H I J K L M N O P Q R S T) →
  (K ≤ (-1 : Int)) →
  r37 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r37 A B C D E F G H I J K U M N O P Q R S T) →
  (U = (-1 : Int) * N + L) →
  r40 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r33 A B C D E F G H I J K U M N O P Q R S T) →
  (U = (-1 : Int) * N + L) →
  r40 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r16 A B C D E F G H I J K L M N O P Q R S T) →
  (K ≥ (1 : Int)) →
  r33 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r16 A B C D E F G H I J K L M N O P Q R S T) →
  (K = (0 : Int)) →
  r18 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r34 A B C D E F G H I J K L M N O P U R S T) →
  (Q = (1 : Int)) →
  r4 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r4 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r5 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r5 A B C D E F G H I J K L M N O P Q R S T) →
  (K ≤ (-1 : Int)) →
  r7 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r7 A B C D E F G H I J K L M N O P U R S T) →
  (L = (-2 : Int) + (2 : Int) * M + Q) →
  r31 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r26 A B C D E F G H I J K L M N O P U R S T) →
  (L = (-2 : Int) + (2 : Int) * M + Q) →
  r31 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r5 A B C D E F G H I J K L M N O P Q R S T) →
  (K ≥ (1 : Int)) →
  r26 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r5 A B C D E F G H I J K L M N O P Q R S T) →
  (K = (0 : Int)) →
  r3 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r3 A B C D E F G H I J K L M N O P Q U S T) →
  (R = (0 : Int)) →
  r41 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r31 A B C D E F G H I J K L M N O P Q U S T) →
  (R = (0 : Int)) →
  r41 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r41 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r23 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r23 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r10 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r10 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r19 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r24 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r19 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r30 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r19 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r19 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r28 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r28 A B C D E F G H I J K L M N O P Q R S T) →
  (Q + (-1 : Int) * R ≥ (0 : Int)) →
  r9 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r9 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r38 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r28 A B C D E F G H I J K L M N O P Q R S T) →
  (Q + (-1 : Int) * R ≤ (-1 : Int)) →
  r14 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r14 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r11 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r11 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r13 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r38 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r0 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r20 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r20 A B C D E F G H I J K L M N O P Q R S T) →
  (S ≤ (-1 : Int)) →
  r29 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r29 A B C D E F G H I J K L M N O P Q U S T) →
  (U = (-1 : Int) + R) →
  r24 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r2 A B C D E F G H I J K L M N O P Q U S T) →
  (U = (-1 : Int) + R) →
  r24 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r20 A B C D E F G H I J K L M N O P Q R S T) →
  (S ≥ (1 : Int)) →
  r2 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r20 A B C D E F G H I J K L M N O P Q R S T) →
  (S = (0 : Int)) →
  r15 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r15 A B C D E F G H I J K L M N O P Q U S T) →
  (U = (-2 : Int) + R) →
  r30 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r13 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  r12 A B C D E F G H I J K L M N O P Q R S T) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r12 A B C D E F G H I J K L M N O P Q R S T) →
  (R ≥ (5 : Int)) →
  r32 A B C D E F G H I J K L M N O P Q R S T) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r32 A B C D E F G H I J K L M N O P Q R S T) →
  (True) →
  False)))))))))))))))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«12.c_000»
