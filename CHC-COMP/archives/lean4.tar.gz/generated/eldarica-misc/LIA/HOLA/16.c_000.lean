import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«16.c_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":264:1-264:12 (check-sat, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":23:1-32:2 (clause 1, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":33:1-43:2 (clause 2, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":44:1-54:2 (clause 3, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":55:1-65:2 (clause 4, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":66:1-76:2 (clause 5, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":77:1-87:2 (clause 6, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":88:1-98:2 (clause 7, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":99:1-109:2 (clause 8, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":110:1-120:2 (clause 9, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":121:1-131:2 (clause 10, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":132:1-142:2 (clause 11, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":143:1-153:2 (clause 12, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":154:1-164:2 (clause 13, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":165:1-175:2 (clause 14, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":176:1-186:2 (clause 15, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":187:1-197:2 (clause 16, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":198:1-208:2 (clause 17, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":209:1-219:2 (clause 18, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":220:1-230:2 (clause 19, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":231:1-241:2 (clause 20, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":242:1-252:2 (clause 21, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/HOLA/16.c_000.smt2":253:1-262:2 (clause 22, command 41)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Prop),
  ∃ (r12 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E v_5 v_6 v_7 v_8 v_9 : Int),
  (True) →
  (v_5 = A) →
  (v_6 = B) →
  (v_7 = C) →
  (v_8 = D) →
  (v_9 = E) →
  r15 A B C D E v_5 v_6 v_7 v_8 v_9) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r15 A B C D E F G K L J) →
  (F = H) →
  (G = I) →
  r2 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r2 A B C D E F G H I J) →
  (True) →
  r14 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r14 A B C D E F G H I J) →
  (True) →
  r16 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r16 A B C D E F G H I J) →
  (True) →
  r12 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r4 A B C D E F G H I J) →
  (True) →
  r12 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r12 A B C D E F G H I J) →
  (True) →
  r7 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r7 A B C D E F G H I J) →
  (H ≤ (-1 : Int)) →
  r3 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A B C D E F G K L J) →
  (K = (1 : Int) + H) →
  (L = (1 : Int) + I) →
  r4 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r8 A B C D E F G K L J) →
  (K = (1 : Int) + H) →
  (L = (1 : Int) + I) →
  r4 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r7 A B C D E F G H I J) →
  (H ≥ (1 : Int)) →
  r8 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r7 A B C D E F G H I J) →
  (H = (0 : Int)) →
  r17 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r17 A B C D E F G H I J) →
  (True) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B C D E F G H I J) →
  (True) →
  r13 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r13 A B C D E F G H I J) →
  (True) →
  r1 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r1 A B C D E F G H I J) →
  (F = G) →
  r10 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r10 A B C D E F G H I J) →
  (True) →
  r5 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r5 A B C D E F G H I J) →
  (I ≤ (-1 : Int)) →
  r6 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r5 A B C D E F G H I J) →
  (I ≥ (1 : Int)) →
  r9 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r6 A B C D E F G H I J) →
  (True) →
  r11) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r9 A B C D E F G H I J) →
  (True) →
  r11) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r11) →
  False)))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«HOLA».«16.c_000»
