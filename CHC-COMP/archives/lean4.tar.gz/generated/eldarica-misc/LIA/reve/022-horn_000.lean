import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«022-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":227:1-227:12 (check-sat, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":9:1-25:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":26:1-38:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":39:1-57:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":58:1-75:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":76:1-93:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":94:1-113:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":114:1-134:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":135:1-154:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":155:1-173:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":174:1-186:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":187:1-203:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":204:1-213:2 (clause 12, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022-horn_000.smt2":214:1-225:2 (clause 13, command 18)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L : Int),
  let a!1 := ¬F + (-1 : Int) * G ≥ (1 : Int);
  r0 F H G A D E →
    I = J →
      E = (-1 : Int) + C →
        D = (1 : Int) + B → ¬F + (-1 : Int) * G ≥ (1 : Int) → A + (-1 : Int) * E ≥ (1 : Int) → K = L → r1 A B C) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  let a!1 := ¬A + (-1 : Int) * C ≥ (1 : Int);
  let a!2 := ¬F + (-1 : Int) * D ≥ (1 : Int);
  r0 A B C G I H →
    r1 D E F →
      J = K →
        ¬A + (-1 : Int) * C ≥ (1 : Int) →
          G + (-1 : Int) * H ≥ (1 : Int) → ¬F + (-1 : Int) * D ≥ (1 : Int) → L = M → r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  let a!1 := ¬F + (-1 : Int) * G ≥ (1 : Int);
  r0 F J G H K I →
    r1 D E C →
      L = M →
        E = (-1 : Int) + B →
          D = (-1 : Int) + A →
            C + (-1 : Int) * D ≥ (1 : Int) →
              H + (-1 : Int) * I ≥ (1 : Int) → ¬F + (-1 : Int) * G ≥ (1 : Int) → N = O → r1 A B C) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r0 A G H D I J) →
  (K = L) →
  (J = (-1 : Int) + F) →
  (I = (1 : Int) + E) →
  (H = (-1 : Int) + C) →
  (G = (1 : Int) + B) →
  (A + (-1 : Int) * H ≥ (1 : Int)) →
  (D + (-1 : Int) * J ≥ (1 : Int)) →
  (M = N) →
  r2 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  let a!1 := ¬C + (-1 : Int) * A ≥ (1 : Int);
  let a!2 := ¬F + (-1 : Int) * D ≥ (1 : Int);
  r0 G K H I L J →
    r2 A B C D E F →
      M = N →
        ¬C + (-1 : Int) * A ≥ (1 : Int) →
          I + (-1 : Int) * J ≥ (1 : Int) →
            G + (-1 : Int) * H ≥ (1 : Int) → ¬F + (-1 : Int) * D ≥ (1 : Int) → O = P → r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  let a!1 := ¬C + (-1 : Int) * A ≥ (1 : Int);
  r0 I M J K N L →
    r2 A B C G H F →
      O = P →
        H = (-1 : Int) + E →
          G = (-1 : Int) + D →
            ¬C + (-1 : Int) * A ≥ (1 : Int) →
              F + (-1 : Int) * G ≥ (1 : Int) →
                K + (-1 : Int) * L ≥ (1 : Int) → I + (-1 : Int) * J ≥ (1 : Int) → Q = R → r2 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 K O L M P N) →
  (r2 G H C I J F) →
  (H = (-1 : Int) + B) →
  (S = T) →
  (Q = R) →
  (J = (-1 : Int) + E) →
  (I = (-1 : Int) + D) →
  (C + (-1 : Int) * G ≥ (1 : Int)) →
  (F + (-1 : Int) * I ≥ (1 : Int)) →
  (M + (-1 : Int) * N ≥ (1 : Int)) →
  (K + (-1 : Int) * L ≥ (1 : Int)) →
  (G = (-1 : Int) + A) →
  r2 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  let a!1 := ¬F + (-1 : Int) * D ≥ (1 : Int);
  r0 I M J K N L →
    r2 G H C D E F →
      O = P →
        H = (-1 : Int) + B →
          G = (-1 : Int) + A →
            C + (-1 : Int) * G ≥ (1 : Int) →
              ¬F + (-1 : Int) * D ≥ (1 : Int) →
                K + (-1 : Int) * L ≥ (1 : Int) → I + (-1 : Int) * J ≥ (1 : Int) → Q = R → r2 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  let a!1 := ¬H + (-1 : Int) * I ≥ (1 : Int);
  r0 F J G H K I →
    r3 D E C →
      L = M →
        E = (-1 : Int) + B →
          D = (-1 : Int) + A →
            C + (-1 : Int) * D ≥ (1 : Int) →
              ¬H + (-1 : Int) * I ≥ (1 : Int) → F + (-1 : Int) * G ≥ (1 : Int) → N = O → r3 A B C) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  let a!1 := ¬D + (-1 : Int) * F ≥ (1 : Int);
  let a!2 := ¬C + (-1 : Int) * A ≥ (1 : Int);
  r0 G I H D E F →
    r3 A B C →
      J = K →
        G + (-1 : Int) * H ≥ (1 : Int) →
          ¬D + (-1 : Int) * F ≥ (1 : Int) → ¬C + (-1 : Int) * A ≥ (1 : Int) → L = M → r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  let a!1 := ¬F + (-1 : Int) * G ≥ (1 : Int);
  r0 A D E F H G →
    I = J →
      E = (-1 : Int) + C →
        D = (1 : Int) + B → ¬F + (-1 : Int) * G ≥ (1 : Int) → A + (-1 : Int) * E ≥ (1 : Int) → K = L → r3 A B C) ∧
  ((∀ (A B C D E F : Int),
  (C = (0 : Int)) →
  (B = E) →
  (A = D) →
  (F = (0 : Int)) →
  r0 A B C D E F) ∧
  (∀ (A B C D E F G H I J : Int),
  let a!1 := ¬E + (-1 : Int) * F ≥ (1 : Int);
  let a!2 := ¬C + (-1 : Int) * D ≥ (1 : Int);
  r0 C A D E B F → G = H → ¬A = B → ¬E + (-1 : Int) * F ≥ (1 : Int) → ¬C + (-1 : Int) * D ≥ (1 : Int) → I = J → False))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«022-horn_000»
