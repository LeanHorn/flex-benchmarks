import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«010-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/010-horn_000.smt2":79:1-79:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/010-horn_000.smt2":6:1-21:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/010-horn_000.smt2":22:1-40:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/010-horn_000.smt2":41:1-56:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/010-horn_000.smt2":57:1-66:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/010-horn_000.smt2":67:1-77:2 (clause 5, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M : Int),
  (r0 A B C D I J F K) →
  (J + F = G) →
  (L = (-1 : Int) + M) →
  (I = (1 : Int) + E) →
  (I ≥ (1 : Int)) →
  (¬A ≥ (1 : Int)) →
  (J + F = H) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r0 I J B M K L F N) →
  (L + F = G) →
  (J + B = C) →
  (J + B = D) →
  (O = (-1 : Int) + P) →
  (K = (1 : Int) + E) →
  (I = (1 : Int) + A) →
  (K ≥ (1 : Int)) →
  (I ≥ (1 : Int)) →
  (L + F = H) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 I J B K E F G H) →
  (J + B = C) →
  (L = (-1 : Int) + M) →
  (I = (1 : Int) + A) →
  (I ≥ (1 : Int)) →
  (¬E ≥ (1 : Int)) →
  (J + B = D) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (G = (1 : Int)) →
  (F = (1 : Int)) →
  (E = (-1 : Int) + A) →
  (D = (0 : Int)) →
  (C = (1 : Int)) →
  (B = (0 : Int)) →
  (H = (0 : Int)) →
  r0 A B C D E F G H) ∧
  (∀ (A B C D E F G H I J : Int),
  (r0 C E A F D G B H) →
  (¬A = B) →
  (¬D ≥ (1 : Int)) →
  (¬C ≥ (1 : Int)) →
  (I = (-1 : Int) + J) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«010-horn_000»
