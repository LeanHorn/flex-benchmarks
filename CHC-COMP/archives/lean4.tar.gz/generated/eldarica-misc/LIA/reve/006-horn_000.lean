import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«006-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":228:1-228:12 (check-sat, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":8:1-18:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":19:1-35:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":36:1-46:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":47:1-64:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":65:1-84:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":85:1-102:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":103:1-123:2 (clause 7, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":124:1-146:2 (clause 8, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":147:1-167:2 (clause 9, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":168:1-185:2 (clause 10, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":186:1-196:2 (clause 11, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":197:1-206:2 (clause 12, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006-horn_000.smt2":207:1-226:2 (clause 13, command 17)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J : Int),
  (r0 A B C D G H) →
  (H = F) →
  (G = (-1 : Int) + E) →
  (D ≥ G) →
  (¬A ≥ B) →
  (I = J) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A G H D I J) →
  (J = F) →
  (I = (-1 : Int) + E) →
  (H = C) →
  (G = (-1 : Int) + B) →
  (A ≥ G) →
  (D ≥ I) →
  (K = L) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A G H D E F) →
  (H = C) →
  (G = (-1 : Int) + B) →
  (¬D ≥ E) →
  (A ≥ G) →
  (I = J) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r0 I J M K L N) →
  (r1 A G H D E F) →
  (O = P) →
  (G = (-1 : Int) + B) →
  (¬D ≥ E) →
  (A ≥ G) →
  (¬K ≥ L) →
  (¬I ≥ J) →
  (H + G = C) →
  r1 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 K L O M N P) →
  (r1 A G H D I J) →
  (J + I = F) →
  (G = (-1 : Int) + B) →
  (Q = R) →
  (I = (-1 : Int) + E) →
  (A ≥ G) →
  (D ≥ I) →
  (¬M ≥ N) →
  (¬K ≥ L) →
  (H + G = C) →
  r1 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r0 I J M K L N) →
  (r1 A B C D G H) →
  (O = P) →
  (G = (-1 : Int) + E) →
  (D ≥ G) →
  (¬A ≥ B) →
  (¬K ≥ L) →
  (¬I ≥ J) →
  (H + G = F) →
  r1 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V : Int),
  (r0 O P S Q R T) →
  (r1 K L M I J N) →
  (r2 A B C D G H) →
  (G = (-1 : Int) + E) →
  (U = V) →
  (D ≥ G) →
  (¬A ≥ B) →
  (¬I ≥ J) →
  (¬K ≥ L) →
  (¬Q ≥ R) →
  (¬O ≥ P) →
  ((2 : Int) * H = F) →
  r2 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X : Int),
  (r0 Q R U S T V) →
  (r1 M N O K L P) →
  (r2 A G H D I J) →
  ((2 : Int) * J = F) →
  (G = (-1 : Int) + B) →
  (I = (-1 : Int) + E) →
  (W = X) →
  (A ≥ G) →
  (D ≥ I) →
  (¬K ≥ L) →
  (¬M ≥ N) →
  (¬S ≥ T) →
  (¬Q ≥ R) →
  ((2 : Int) * H = C) →
  r2 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V : Int),
  (r0 O P S Q R T) →
  (r1 K L M I J N) →
  (r2 A G H D E F) →
  (G = (-1 : Int) + B) →
  (U = V) →
  (¬D ≥ E) →
  (A ≥ G) →
  (¬I ≥ J) →
  (¬K ≥ L) →
  (¬Q ≥ R) →
  (¬O ≥ P) →
  ((2 : Int) * H = C) →
  r2 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r0 I J M K L N) →
  (r1 A H C D G F) →
  (E = (1 : Int)) →
  (O = P) →
  (¬D ≥ G) →
  (¬A ≥ H) →
  (¬K ≥ L) →
  (¬I ≥ J) →
  (B = (1 : Int)) →
  r2 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A G C D H F) →
  (E = (1 : Int)) →
  (B = (0 : Int)) →
  (¬D ≥ H) →
  (¬A ≥ G) →
  (I = J) →
  r1 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (E = (1 : Int)) →
  (C = (1 : Int)) →
  (B = (1 : Int)) →
  (A = D) →
  (F = (1 : Int)) →
  r0 A B C D E F) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 M N Q O P R) →
  (r1 I J K G H L) →
  (r2 C D A E F B) →
  (S = T) →
  (¬C ≥ D) →
  (¬G ≥ H) →
  (¬E ≥ F) →
  (¬I ≥ J) →
  (¬O ≥ P) →
  (¬M ≥ N) →
  (¬A = B) →
  False))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«006-horn_000»
