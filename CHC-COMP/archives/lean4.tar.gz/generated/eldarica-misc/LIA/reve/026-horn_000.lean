import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«026-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/026-horn_000.smt2":61:1-61:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/026-horn_000.smt2":6:1-16:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/026-horn_000.smt2":17:1-27:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/026-horn_000.smt2":28:1-38:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/026-horn_000.smt2":39:1-48:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/026-horn_000.smt2":49:1-59:2 (clause 5, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  (∀ (A B C D E : Int),
  (r0 A C) →
  (C = (-1 : Int) + B) →
  (E ≤ (10 : Int)) →
  (C ≤ (9 : Int)) →
  (¬A ≤ (10 : Int)) →
  (D = E) →
  r0 A B) ∧
  ((∀ (A B C D E F : Int),
  (r0 C D) →
  (D = (-1 : Int) + B) →
  (C = (-1 : Int) + A) →
  (F ≤ (10 : Int)) →
  (D ≤ (9 : Int)) →
  (C ≤ (10 : Int)) →
  (E = F) →
  r0 A B) ∧
  ((∀ (A B C D E : Int),
  (r0 C B) →
  (C = (-1 : Int) + A) →
  (E ≤ (10 : Int)) →
  (C ≤ (10 : Int)) →
  (¬B ≤ (9 : Int)) →
  (D = E) →
  r0 A B) ∧
  ((∀ (A B : Int),
  (B ≤ (10 : Int)) →
  (A = B) →
  r0 A B) ∧
  (∀ (A B C D : Int),
  (r0 A B) →
  (¬A = (1 : Int) + B) →
  (D ≤ (10 : Int)) →
  (¬B ≤ (9 : Int)) →
  (¬A ≤ (10 : Int)) →
  (C = D) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«026-horn_000»
