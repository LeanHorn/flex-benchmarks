import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«022b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":227:1-227:12 (check-sat, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":9:1-25:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":26:1-38:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":39:1-57:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":58:1-75:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":76:1-93:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":94:1-113:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":114:1-134:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":135:1-154:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":155:1-173:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":174:1-186:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":187:1-203:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":204:1-213:2 (clause 12, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/022b-horn_000.smt2":214:1-225:2 (clause 13, command 18)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L : Int),
  let a!1 := ¬F + (-1 : Int) * G ≥ (1 : Int);
  r0 F H G A D E I J K L →
    I = K →
      E = (-1 : Int) + C →
        D = (1 : Int) + B → ¬F + (-1 : Int) * G ≥ (1 : Int) → A + (-1 : Int) * E ≥ (1 : Int) → J = L → r1 A B C) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  let a!1 := ¬A + (-1 : Int) * C ≥ (1 : Int);
  let a!2 := ¬F + (-1 : Int) * D ≥ (1 : Int);
  r0 A B C K M L G H I J →
    r1 D E F →
      G = I →
        ¬A + (-1 : Int) * C ≥ (1 : Int) →
          K + (-1 : Int) * L ≥ (1 : Int) → ¬F + (-1 : Int) * D ≥ (1 : Int) → H = J → r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  let a!1 := ¬F + (-1 : Int) * G ≥ (1 : Int);
  r0 F J G H K I L M N O →
    r1 D E C →
      L = N →
        E = (-1 : Int) + B →
          D = (-1 : Int) + A →
            C + (-1 : Int) * D ≥ (1 : Int) →
              H + (-1 : Int) * I ≥ (1 : Int) → ¬F + (-1 : Int) * G ≥ (1 : Int) → M = O → r1 A B C) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r0 A K L D M N G H I J) →
  (M = (1 : Int) + E) →
  (L = (-1 : Int) + C) →
  (K = (1 : Int) + B) →
  (H = J) →
  (G = I) →
  (A + (-1 : Int) * L ≥ (1 : Int)) →
  (D + (-1 : Int) * N ≥ (1 : Int)) →
  (N = (-1 : Int) + F) →
  r2 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  let a!1 := ¬C + (-1 : Int) * A ≥ (1 : Int);
  let a!2 := ¬F + (-1 : Int) * D ≥ (1 : Int);
  r0 K O L M P N G H I J →
    r2 A B C D E F G H I J →
      G = I →
        ¬C + (-1 : Int) * A ≥ (1 : Int) →
          M + (-1 : Int) * N ≥ (1 : Int) →
            K + (-1 : Int) * L ≥ (1 : Int) → ¬F + (-1 : Int) * D ≥ (1 : Int) → H = J → r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  let a!1 := ¬C + (-1 : Int) * A ≥ (1 : Int);
  r0 M Q N O R P G H I J →
    r2 A B C K L F G H I J →
      K = (-1 : Int) + D →
        H = J →
          G = I →
            ¬C + (-1 : Int) * A ≥ (1 : Int) →
              F + (-1 : Int) * K ≥ (1 : Int) →
                O + (-1 : Int) * P ≥ (1 : Int) →
                  M + (-1 : Int) * N ≥ (1 : Int) → L = (-1 : Int) + E → r2 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 O S P Q T R G H I J) →
  (r2 K L C M N F G H I J) →
  (H = J) →
  (N = (-1 : Int) + E) →
  (M = (-1 : Int) + D) →
  (L = (-1 : Int) + B) →
  (K = (-1 : Int) + A) →
  (C + (-1 : Int) * K ≥ (1 : Int)) →
  (F + (-1 : Int) * M ≥ (1 : Int)) →
  (Q + (-1 : Int) * R ≥ (1 : Int)) →
  (O + (-1 : Int) * P ≥ (1 : Int)) →
  (G = I) →
  r2 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  let a!1 := ¬F + (-1 : Int) * D ≥ (1 : Int);
  r0 M Q N O R P G H I J →
    r2 K L C D E F G H I J →
      K = (-1 : Int) + A →
        H = J →
          G = I →
            C + (-1 : Int) * K ≥ (1 : Int) →
              ¬F + (-1 : Int) * D ≥ (1 : Int) →
                O + (-1 : Int) * P ≥ (1 : Int) →
                  M + (-1 : Int) * N ≥ (1 : Int) → L = (-1 : Int) + B → r2 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  let a!1 := ¬H + (-1 : Int) * I ≥ (1 : Int);
  r0 F J G H K I L M N O →
    r3 D E C →
      L = N →
        E = (-1 : Int) + B →
          D = (-1 : Int) + A →
            C + (-1 : Int) * D ≥ (1 : Int) →
              ¬H + (-1 : Int) * I ≥ (1 : Int) → F + (-1 : Int) * G ≥ (1 : Int) → M = O → r3 A B C) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  let a!1 := ¬D + (-1 : Int) * F ≥ (1 : Int);
  let a!2 := ¬C + (-1 : Int) * A ≥ (1 : Int);
  r0 K M L D E F G H I J →
    r3 A B C →
      G = I →
        K + (-1 : Int) * L ≥ (1 : Int) →
          ¬D + (-1 : Int) * F ≥ (1 : Int) → ¬C + (-1 : Int) * A ≥ (1 : Int) → H = J → r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  let a!1 := ¬F + (-1 : Int) * G ≥ (1 : Int);
  r0 A D E F H G I J K L →
    I = K →
      E = (-1 : Int) + C →
        D = (1 : Int) + B → ¬F + (-1 : Int) * G ≥ (1 : Int) → A + (-1 : Int) * E ≥ (1 : Int) → J = L → r3 A B C) ∧
  ((∀ (A B C D E F v_6 v_7 v_8 v_9 : Int),
  (C = (0 : Int)) →
  (B = E) →
  (A = D) →
  (F = (0 : Int)) →
  (v_6 = A) →
  (v_7 = B) →
  (v_8 = D) →
  (v_9 = E) →
  r0 A B C D E F v_6 v_7 v_8 v_9) ∧
  (∀ (A B C D E F G H I J : Int),
  let a!1 := ¬E + (-1 : Int) * F ≥ (1 : Int);
  let a!2 := ¬C + (-1 : Int) * D ≥ (1 : Int);
  r0 C A D E B F G H I J →
    G = I → ¬A = B → ¬E + (-1 : Int) * F ≥ (1 : Int) → ¬C + (-1 : Int) * D ≥ (1 : Int) → H = J → False))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«022b-horn_000»
