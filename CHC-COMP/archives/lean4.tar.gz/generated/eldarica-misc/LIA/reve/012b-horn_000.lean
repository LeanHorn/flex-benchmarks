import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«012b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/012b-horn_000.smt2":145:1-145:12 (check-sat, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/012b-horn_000.smt2":9:1-19:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/012b-horn_000.smt2":20:1-29:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/012b-horn_000.smt2":30:1-45:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/012b-horn_000.smt2":46:1-56:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/012b-horn_000.smt2":57:1-66:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/012b-horn_000.smt2":67:1-77:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/012b-horn_000.smt2":78:1-87:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/012b-horn_000.smt2":88:1-98:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/012b-horn_000.smt2":99:1-109:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/012b-horn_000.smt2":110:1-121:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/012b-horn_000.smt2":122:1-133:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/012b-horn_000.smt2":134:1-143:2 (clause 12, command 17)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Prop),
  (∀ (A B C D E v_5 : Int),
  (r3 E D) →
  (B = (2 : Int) + E) →
  (A ≤ (1 : Int)) →
  (¬B ≤ (1 : Int)) →
  ((2 : Int) * B + D = (1 : Int) + C) →
  (v_5 = A) →
  r1 A v_5 B C) ∧
  ((∀ (A B v_2 v_3 : Int),
  (A ≤ (1 : Int)) →
  (B ≤ (1 : Int)) →
  (v_2 = A) →
  (v_3 = B) →
  r1 A v_2 B v_3) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 G E H F) →
  (A + E = B) →
  (A = (1 : Int) + G) →
  (C = (2 : Int) + H) →
  (¬A ≤ (1 : Int)) →
  (¬C ≤ (1 : Int)) →
  ((2 : Int) * C + F = (1 : Int) + D) →
  r1 A B C D) ∧
  ((∀ (A B C D E v_5 : Int),
  (r0 E D) →
  (A = (1 : Int) + E) →
  (¬A ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  (A + D = B) →
  (v_5 = C) →
  r1 A B C v_5) ∧
  ((∀ (A v_1 : Int),
  (A ≤ (1 : Int)) →
  (v_1 = A) →
  r0 A v_1) ∧
  ((∀ (A B C D : Int),
  (r0 D C) →
  (A = (1 : Int) + D) →
  (¬A ≤ (1 : Int)) →
  (A + C = B) →
  r0 A B) ∧
  ((∀ (A v_1 : Int),
  (A ≤ (1 : Int)) →
  (v_1 = A) →
  r3 A v_1) ∧
  ((∀ (A B C D : Int),
  (r3 D C) →
  (A = (2 : Int) + D) →
  (¬A ≤ (1 : Int)) →
  ((2 : Int) * A + C = (1 : Int) + B) →
  r3 A B) ∧
  ((∀ (A B C D : Int),
  (r0 D B) →
  (A = (1 : Int) + D) →
  (A = C) →
  (C ≤ (1 : Int)) →
  (¬A ≤ (1 : Int)) →
  (¬A + B = C) →
  r2) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := ¬A + B = (-1 : Int) + (2 : Int) * C + D;
  r1 E B F D →
    A = (1 : Int) + E →
      A = C → C = (2 : Int) + F → ¬A ≤ (1 : Int) → ¬C ≤ (1 : Int) → ¬A + B = (-1 : Int) + (2 : Int) * C + D → r2) ∧
  ((∀ (A B C D : Int),
  let a!1 := ¬A = (-1 : Int) + (2 : Int) * B + C;
  r3 D C → ¬A = (-1 : Int) + (2 : Int) * B + C → A = B → ¬B ≤ (1 : Int) → A ≤ (1 : Int) → B = (2 : Int) + D → r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  False)))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«012b-horn_000»
