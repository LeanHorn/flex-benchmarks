import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«007b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/007b-horn_000.smt2":68:1-68:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/007b-horn_000.smt2":6:1-16:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/007b-horn_000.smt2":17:1-33:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/007b-horn_000.smt2":34:1-44:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/007b-horn_000.smt2":45:1-54:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/007b-horn_000.smt2":55:1-66:2 (clause 5, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D E L K H I J) →
  (K = (-2 : Int) + F) →
  (I = J) →
  (K ≤ (9 : Int)) →
  (¬B ≤ (9 : Int)) →
  ((2 : Int) * K = (-4 : Int) + G) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r0 A K M D E N L H I J) →
  ((2 : Int) * K = (-4 : Int) + B) →
  (L = (-2 : Int) + F) →
  (K = (-2 : Int) + C) →
  (I = J) →
  (L ≤ (9 : Int)) →
  (K ≤ (9 : Int)) →
  ((2 : Int) * L = (-4 : Int) + G) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A K L D E F G H I J) →
  (K = (-2 : Int) + C) →
  (I = J) →
  (K ≤ (9 : Int)) →
  (¬G ≤ (9 : Int)) →
  ((2 : Int) * K = (-4 : Int) + B) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H v_8 v_9 : Int),
  (F = (0 : Int)) →
  (C = (0 : Int)) →
  (B = (1 : Int)) →
  (A = E) →
  (G = (1 : Int)) →
  (v_8 = A) →
  (v_9 = E) →
  r0 A B C D E F G H v_8 v_9) ∧
  (∀ (A B C D E F G H I J : Int),
  let a!1 := ¬(2 : Int) * A + (-2 : Int) * B = (0 : Int);
  r0 C A D E F G B H I J → I = J → ¬B ≤ (9 : Int) → ¬A ≤ (9 : Int) → ¬(2 : Int) * A + (-2 : Int) * B = (0 : Int) → False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«007b-horn_000»
