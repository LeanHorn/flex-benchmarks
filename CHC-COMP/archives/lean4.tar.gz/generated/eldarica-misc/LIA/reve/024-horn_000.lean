import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«024-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/024-horn_000.smt2":110:1-110:12 (check-sat, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/024-horn_000.smt2":8:1-18:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/024-horn_000.smt2":19:1-28:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/024-horn_000.smt2":29:1-44:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/024-horn_000.smt2":45:1-55:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/024-horn_000.smt2":56:1-65:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/024-horn_000.smt2":66:1-76:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/024-horn_000.smt2":77:1-86:2 (clause 7, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/024-horn_000.smt2":87:1-97:2 (clause 8, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/024-horn_000.smt2":98:1-108:2 (clause 9, command 13)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  (∀ (A B C D E F G : Int),
  (r2 F G E) →
  (B = (0 : Int)) →
  (C = (1 : Int) + F) →
  (A ≤ (0 : Int)) →
  (¬C ≤ (0 : Int)) →
  (C + D = G) →
  r1 A B C D E) ∧
  ((∀ (A B C D v_4 : Int),
  (C ≤ (0 : Int)) →
  (A ≤ (0 : Int)) →
  (B = (0 : Int)) →
  (v_4 = D) →
  r1 A B C D v_4) ∧
  ((∀ (A B C D E F G H I : Int),
  (r1 G F H I E) →
  (C + D = I) →
  (A = (1 : Int) + G) →
  (C = (1 : Int) + H) →
  (¬A ≤ (0 : Int)) →
  (¬C ≤ (0 : Int)) →
  (A + F = B) →
  r1 A B C D E) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r0 F E) →
  (A = (1 : Int) + F) →
  (¬A ≤ (0 : Int)) →
  (C ≤ (0 : Int)) →
  (A + E = B) →
  (v_6 = D) →
  r1 A B C D v_6) ∧
  ((∀ (A B : Int),
  (A ≤ (0 : Int)) →
  (B = (0 : Int)) →
  r0 A B) ∧
  ((∀ (A B C D : Int),
  (r0 D C) →
  (A = (1 : Int) + D) →
  (¬A ≤ (0 : Int)) →
  (A + C = B) →
  r0 A B) ∧
  ((∀ (A B v_2 : Int),
  (A ≤ (0 : Int)) →
  (v_2 = B) →
  r2 A B v_2) ∧
  ((∀ (A B C D E : Int),
  (r2 D E C) →
  (A = (1 : Int) + D) →
  (¬A ≤ (0 : Int)) →
  (A + B = E) →
  r2 A B C) ∧
  (∀ (A B C D E : Int),
  (r1 D A E C B) →
  (C = (0 : Int)) →
  (¬A = B) →
  (D = E) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«024-horn_000»
