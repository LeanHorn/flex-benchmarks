import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«005-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005-horn_000.smt2":141:1-141:12 (check-sat, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005-horn_000.smt2":7:1-17:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005-horn_000.smt2":18:1-34:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005-horn_000.smt2":35:1-45:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005-horn_000.smt2":46:1-63:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005-horn_000.smt2":64:1-83:2 (clause 5, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005-horn_000.smt2":84:1-101:2 (clause 6, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005-horn_000.smt2":102:1-112:2 (clause 7, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005-horn_000.smt2":113:1-122:2 (clause 8, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005-horn_000.smt2":123:1-139:2 (clause 9, command 12)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J : Int),
  (r0 A B C D G H) →
  (I = J) →
  (G = (-1 : Int) + E) →
  (D ≥ G) →
  (¬A ≥ B) →
  ((5 : Int) * H = F) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A G H D I J) →
  ((5 : Int) * H = C) →
  (K = L) →
  (I = (-1 : Int) + E) →
  (G = (-1 : Int) + B) →
  (A ≥ G) →
  (D ≥ I) →
  ((5 : Int) * J = F) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A G H D E F) →
  (I = J) →
  (G = (-1 : Int) + B) →
  (¬D ≥ E) →
  (A ≥ G) →
  ((5 : Int) * H = C) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r0 I J M K L N) →
  (r1 A G H D E F) →
  (O = P) →
  (G = (-1 : Int) + B) →
  (¬D ≥ E) →
  (A ≥ G) →
  (¬K ≥ L) →
  (¬I ≥ J) →
  (H + G = C) →
  r1 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 K L O M N P) →
  (r1 A G H D I J) →
  (J + I = F) →
  (G = (-1 : Int) + B) →
  (Q = R) →
  (I = (-1 : Int) + E) →
  (A ≥ G) →
  (D ≥ I) →
  (¬M ≥ N) →
  (¬K ≥ L) →
  (H + G = C) →
  r1 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r0 I J M K L N) →
  (r1 A B C D G H) →
  (O = P) →
  (G = (-1 : Int) + E) →
  (D ≥ G) →
  (¬A ≥ B) →
  (¬K ≥ L) →
  (¬I ≥ J) →
  (H + G = F) →
  r1 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A G C D H F) →
  (E = (1 : Int)) →
  (B = (0 : Int)) →
  (¬D ≥ H) →
  (¬A ≥ G) →
  (I = J) →
  r1 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (E = (1 : Int)) →
  (C = (1 : Int)) →
  (B = (1 : Int)) →
  (A = D) →
  (F = (1 : Int)) →
  r0 A B C D E F) ∧
  (∀ (A B C D E F G H I J K L M N : Int),
  (r0 G H K I J L) →
  (r1 E F A C D B) →
  (M = N) →
  (¬C ≥ D) →
  (¬I ≥ J) →
  (¬G ≥ H) →
  (¬E ≥ F) →
  (¬A = B) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«005-horn_000»
