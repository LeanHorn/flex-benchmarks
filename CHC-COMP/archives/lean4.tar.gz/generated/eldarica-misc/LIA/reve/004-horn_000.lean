import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«004-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/004-horn_000.smt2":67:1-67:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/004-horn_000.smt2":6:1-16:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/004-horn_000.smt2":17:1-33:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/004-horn_000.smt2":34:1-44:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/004-horn_000.smt2":45:1-54:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/004-horn_000.smt2":55:1-65:2 (clause 5, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J : Int),
  (r0 A B C D G H) →
  (I = J) →
  (G = (-1 : Int) + E) →
  (D ≥ G) →
  (¬A ≥ B) →
  (H + G = F) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A G H D I J) →
  (H + G = C) →
  (K = L) →
  (I = (-1 : Int) + E) →
  (G = (-1 : Int) + B) →
  (A ≥ G) →
  (D ≥ I) →
  (J + I = F) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A G H D E F) →
  (I = J) →
  (G = (-1 : Int) + B) →
  (¬D ≥ E) →
  (A ≥ G) →
  (H + G = C) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (E = (1 : Int)) →
  (C = (0 : Int)) →
  (B = (0 : Int)) →
  (A = D) →
  (F = (0 : Int)) →
  r0 A B C D E F) ∧
  (∀ (A B C D E F G H : Int),
  (r0 C D A E F B) →
  (¬A = B) →
  (¬E ≥ F) →
  (¬C ≥ D) →
  (G = H) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«004-horn_000»
