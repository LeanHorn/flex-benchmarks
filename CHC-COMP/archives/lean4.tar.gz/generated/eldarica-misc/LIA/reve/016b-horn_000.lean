import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«016b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/016b-horn_000.smt2":67:1-67:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/016b-horn_000.smt2":6:1-16:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/016b-horn_000.smt2":17:1-33:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/016b-horn_000.smt2":34:1-44:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/016b-horn_000.smt2":45:1-54:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/016b-horn_000.smt2":55:1-65:2 (clause 5, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J : Int),
  (r0 A B C D I J G H) →
  (I = (1 : Int) + E) →
  (G = H) →
  (I ≥ (0 : Int)) →
  (¬A ≥ B) →
  (J = (-1 : Int) + F) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A I J D K L G H) →
  (K = (1 : Int) + E) →
  (J = (-1 : Int) + C) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (A ≥ I) →
  (K ≥ (0 : Int)) →
  (L = (-1 : Int) + F) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A I J D E F G H) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (¬E ≥ (0 : Int)) →
  (A ≥ I) →
  (J = (-1 : Int) + C) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E v_5 v_6 v_7 : Int),
  (C = (0 : Int)) →
  (B = (0 : Int)) →
  (A = D) →
  (E = (0 : Int)) →
  (v_5 = D) →
  (v_6 = A) →
  (v_7 = D) →
  r0 A B C D v_5 E v_6 v_7) ∧
  (∀ (A B C D E F G H : Int),
  (r0 C D A F E B G H) →
  (¬A = B) →
  (¬E ≥ (0 : Int)) →
  (¬C ≥ D) →
  (G = H) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«016b-horn_000»
