import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«010b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/010b-horn_000.smt2":87:1-87:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/010b-horn_000.smt2":6:1-21:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/010b-horn_000.smt2":22:1-40:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/010b-horn_000.smt2":41:1-56:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/010b-horn_000.smt2":57:1-74:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/010b-horn_000.smt2":75:1-85:2 (clause 5, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M : Int),
  (r0 A B C D K L F M I J) →
  (L + F = G) →
  (K = (1 : Int) + E) →
  (J = (-1 : Int) + I) →
  (K ≥ (1 : Int)) →
  (¬A ≥ (1 : Int)) →
  (L + F = H) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r0 K L B O M N F P I J) →
  (N + F = G) →
  (L + B = C) →
  (L + B = D) →
  (M = (1 : Int) + E) →
  (K = (1 : Int) + A) →
  (J = (-1 : Int) + I) →
  (M ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (N + F = H) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 K L B M E F G H I J) →
  (L + B = C) →
  (K = (1 : Int) + A) →
  (J = (-1 : Int) + I) →
  (K ≥ (1 : Int)) →
  (¬E ≥ (1 : Int)) →
  (L + B = D) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H v_8 v_9 : Int),
  (G = (1 : Int)) →
  (F = (1 : Int)) →
  (E = (-1 : Int) + A) →
  (D = (0 : Int)) →
  (C = (1 : Int)) →
  (B = (0 : Int)) →
  (H = (0 : Int)) →
  (v_8 = A) →
  (v_9 = E) →
  r0 A B C D E F G H v_8 v_9) ∧
  (∀ (A B C D E F G H I J : Int),
  (r0 C E A F D G B H I J) →
  (¬A = B) →
  (¬D ≥ (1 : Int)) →
  (¬C ≥ (1 : Int)) →
  (J = (-1 : Int) + I) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«010b-horn_000»
