import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«002-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":235:1-235:12 (check-sat, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":19:1-34:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":35:1-44:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":45:1-60:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":61:1-77:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":78:1-88:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":89:1-98:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":99:1-109:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":110:1-119:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":120:1-130:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":131:1-140:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":141:1-157:2 (clause 12, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":158:1-177:2 (clause 13, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":178:1-195:2 (clause 14, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":196:1-213:2 (clause 15, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":214:1-223:2 (clause 16, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/002-horn_000.smt2":224:1-233:2 (clause 17, command 22)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E v_5 : Int),
  (¬C = (0 : Int)) →
  (C = (1 : Int)) →
  (A = (0 : Int)) →
  (D = (-1 : Int) + E) →
  (v_5 = B) →
  r3 A B v_5 C D E) ∧
  ((∀ (A B C D E F G v_7 : Int),
  (r0 F G E) →
  (¬C = (0 : Int)) →
  (¬C = (1 : Int)) →
  (C = (1 : Int) + F) →
  (A = (0 : Int)) →
  (D = (-1 : Int) + G) →
  (v_7 = B) →
  r3 A B v_7 C D E) ∧
  ((∀ (A B C D v_4 v_5 : Int),
  (A = (0 : Int)) →
  (C = (0 : Int)) →
  (v_4 = B) →
  (v_5 = D) →
  r3 A B v_4 C D v_5) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 G H C) →
  (A = (1 : Int) + G) →
  (E = (-1 : Int) + F) →
  (¬D = (0 : Int)) →
  (D = (1 : Int)) →
  (B = (-1 : Int) + H) →
  (¬A = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 G H C I J F) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + G) →
  (E = (-1 : Int) + J) →
  (¬D = (0 : Int)) →
  (¬D = (1 : Int)) →
  (D = (1 : Int) + I) →
  (B = (-1 : Int) + H) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G v_7 : Int),
  (r2 F G C) →
  (B = (-1 : Int) + G) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + F) →
  (D = (0 : Int)) →
  (v_7 = E) →
  r3 A B C D E v_7) ∧
  ((∀ (A B v_2 : Int),
  (A = (0 : Int)) →
  (v_2 = B) →
  r2 A B v_2) ∧
  ((∀ (A B C D E : Int),
  (r2 D E C) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + D) →
  (B = (-1 : Int) + E) →
  r2 A B C) ∧
  ((∀ (A B v_2 : Int),
  (A = (0 : Int)) →
  (v_2 = B) →
  r0 A B v_2) ∧
  ((∀ (A B C D E : Int),
  (r0 D E C) →
  (¬A = (0 : Int)) →
  (¬A = (1 : Int)) →
  (A = (1 : Int) + D) →
  (B = (-1 : Int) + E) →
  r0 A B C) ∧
  ((∀ (A B C : Int),
  (¬A = (0 : Int)) →
  (A = (1 : Int)) →
  (B = (-1 : Int) + C) →
  r0 A B C) ∧
  ((∀ (A B C D E F G : Int),
  (r2 D F A) →
  (E = (-1 : Int) + F) →
  (E = B) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (C = G) →
  (¬A = B) →
  (G = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 D F A H J B) →
  (C = (1 : Int) + D) →
  (C = G) →
  (¬A = B) →
  (I = (-1 : Int) + J) →
  (¬G = (0 : Int)) →
  (¬G = (1 : Int)) →
  (G = (1 : Int) + H) →
  (E = (-1 : Int) + F) →
  (E = I) →
  (¬C = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D E F G : Int),
  (r2 D F A) →
  (G = (1 : Int)) →
  (E = (-1 : Int) + F) →
  (E = B) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (C = G) →
  (¬A = (1 : Int) + B) →
  (¬G = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D E F G : Int),
  (r0 D F B) →
  (G = C) →
  (E = (-1 : Int) + F) →
  (¬C = (0 : Int)) →
  (¬C = (1 : Int)) →
  (C = (1 : Int) + D) →
  (A = E) →
  (¬A = B) →
  (G = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D : Int),
  (D = C) →
  (¬C = (0 : Int)) →
  (C = (1 : Int)) →
  (¬A = (1 : Int) + B) →
  (A = B) →
  (D = (0 : Int)) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  False))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«002-horn_000»
