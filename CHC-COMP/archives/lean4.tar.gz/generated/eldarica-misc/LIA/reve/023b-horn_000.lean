import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«023b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/023b-horn_000.smt2":61:1-61:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/023b-horn_000.smt2":6:1-16:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/023b-horn_000.smt2":17:1-27:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/023b-horn_000.smt2":28:1-38:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/023b-horn_000.smt2":39:1-48:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/023b-horn_000.smt2":49:1-59:2 (clause 5, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G : Int),
  (r0 A B C G E F) →
  (E = F) →
  (G ≤ (10 : Int)) →
  (¬B ≤ (10 : Int)) →
  (G = (-1 : Int) + D) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 A G C H E F) →
  (G = (-1 : Int) + B) →
  (E = F) →
  (H ≤ (10 : Int)) →
  (G ≤ (10 : Int)) →
  (H = (-1 : Int) + D) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G : Int),
  (r0 A G C D E F) →
  (E = F) →
  (G ≤ (10 : Int)) →
  (¬D ≤ (10 : Int)) →
  (G = (-1 : Int) + B) →
  r0 A B C D E F) ∧
  ((∀ (A B C D v_4 v_5 : Int),
  (B = (0 : Int)) →
  (A = C) →
  (D = (1 : Int)) →
  (v_4 = A) →
  (v_5 = C) →
  r0 A B C D v_4 v_5) ∧
  (∀ (A B C D E F : Int),
  (r0 C A D B E F) →
  (¬A = B) →
  (¬B ≤ (10 : Int)) →
  (¬A ≤ (10 : Int)) →
  (E = F) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«023b-horn_000»
