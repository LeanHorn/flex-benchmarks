import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«009-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":1245:1-1245:12 (check-sat, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":6:1-16:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":17:1-34:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":35:1-54:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":55:1-73:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":74:1-90:2 (clause 5, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":91:1-112:2 (clause 6, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":113:1-168:2 (clause 7, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":169:1-240:2 (clause 8, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":241:1-273:2 (clause 9, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":274:1-297:2 (clause 10, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":298:1-355:2 (clause 11, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":356:1-429:2 (clause 12, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":430:1-464:2 (clause 13, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":465:1-501:2 (clause 14, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":502:1-577:2 (clause 15, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":578:1-637:2 (clause 16, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":638:1-663:2 (clause 17, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":664:1-699:2 (clause 18, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":700:1-774:2 (clause 19, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":775:1-833:2 (clause 20, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":834:1-858:2 (clause 21, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":859:1-892:2 (clause 22, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":893:1-965:2 (clause 23, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":966:1-1022:2 (clause 24, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":1023:1-1045:2 (clause 25, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":1046:1-1064:2 (clause 26, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":1065:1-1117:2 (clause 27, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":1118:1-1186:2 (clause 28, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":1187:1-1216:2 (clause 29, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":1217:1-1232:2 (clause 30, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009-horn_000.smt2":1233:1-1243:2 (clause 31, command 33)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I v_9 : Int),
  (r0 A B C D F G) →
  (¬F = (0 : Int)) →
  (E = (0 : Int)) →
  (¬A ≥ (1 : Int)) →
  (C ≤ (9 : Int)) →
  (H = I) →
  (v_9 = D) →
  r0 A B C D E v_9) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B C D G H) →
  (¬G = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (-2 : Int) + F) →
  (¬A ≥ (1 : Int)) →
  (¬C ≤ (99 : Int)) →
  (C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (I = J) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B H G E F) →
  (G = (-4 : Int) + D) →
  (¬E = (0 : Int)) →
  ((10000 : Int) * C + (-1 : Int) * H ≥ (-9999 : Int)) →
  (H + (-10000 : Int) * C ≥ (0 : Int)) →
  (¬A ≥ (1 : Int)) →
  (¬H ≤ (9999 : Int)) →
  (¬H ≤ (99 : Int)) →
  (¬H ≤ (999 : Int)) →
  (¬H ≤ (9 : Int)) →
  (I = J) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B C D G H) →
  (¬G = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (-3 : Int) + F) →
  (¬A ≥ (1 : Int)) →
  (C ≤ (9999 : Int)) →
  (¬C ≤ (99 : Int)) →
  (¬C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (I = J) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B C D G H) →
  (¬G = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (-1 : Int) + F) →
  (¬A ≥ (1 : Int)) →
  (C ≤ (99 : Int)) →
  (¬C ≤ (9 : Int)) →
  (I = J) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L v_12 : Int),
  (r0 G F C D I J) →
  (¬I = (0 : Int)) →
  (F = (-1 : Int) + B) →
  (E = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * G ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * G ≥ (-9 : Int)) →
  (G + (-10 : Int) * A ≥ (0 : Int)) →
  (G + (-10 : Int) * H ≥ (0 : Int)) →
  (¬H ≥ (1 : Int)) →
  (G ≥ (1 : Int)) →
  (C ≤ (9 : Int)) →
  (K = L) →
  (v_12 = D) →
  r0 A B C D E v_12) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 v_28 : Int),
  (r0 I F C D Y Z) →
  (E = (0 : Int)) →
  (A1 = B1) →
  (¬Y = (0 : Int)) →
  ((10 : Int) * P + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * P ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * G + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * A + (-1 : Int) * G ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * S ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * V ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * I ≥ (-9 : Int)) →
  (M + (-10 : Int) * K ≥ (0 : Int)) →
  (K + (-10 : Int) * A ≥ (0 : Int)) →
  (J + (-10 : Int) * G ≥ (0 : Int)) →
  (I + (-10 : Int) * P ≥ (0 : Int)) →
  (I + (-10 : Int) * M ≥ (0 : Int)) →
  (I + (-10 : Int) * L ≥ (0 : Int)) →
  (I + (-10 : Int) * J ≥ (0 : Int)) →
  (I + (-10 : Int) * H ≥ (0 : Int)) →
  (I + (-10 : Int) * Q ≥ (0 : Int)) →
  (I + (-10 : Int) * S ≥ (0 : Int)) →
  (I + (-10 : Int) * X ≥ (0 : Int)) →
  (I + (-10 : Int) * W ≥ (0 : Int)) →
  (I + (-10 : Int) * V ≥ (0 : Int)) →
  (I + (-10 : Int) * T ≥ (0 : Int)) →
  (R + (-10 : Int) * N ≥ (0 : Int)) →
  (Q + (-10 : Int) * O ≥ (0 : Int)) →
  (W + (-10 : Int) * U ≥ (0 : Int)) →
  (T + (-10 : Int) * R ≥ (0 : Int)) →
  (¬N ≥ (1 : Int)) →
  (I ≥ (1 : Int)) →
  (X ≥ (1 : Int)) →
  (U ≥ (1 : Int)) →
  (C ≤ (9 : Int)) →
  (F = (-3 : Int) + B) →
  (v_28 = D) →
  r0 A B C D E v_28) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 v_36 : Int),
  (r0 J F C D G1 H1) →
  (E = (0 : Int)) →
  (I1 = J1) →
  (¬G1 = (0 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * G + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * A + (-1 : Int) * G ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * X ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * W ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * T ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * Q ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * P ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * A1 ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * F1 + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * E1 + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * D1 + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * C1 + (-1 : Int) * D1 ≥ (-9 : Int)) →
  ((10 : Int) * B1 + (-1 : Int) * J ≥ (-9 : Int)) →
  (U + (-10 : Int) * S ≥ (0 : Int)) →
  (S + (-10 : Int) * O ≥ (0 : Int)) →
  (R + (-10 : Int) * P ≥ (0 : Int)) →
  (O + (-10 : Int) * A ≥ (0 : Int)) →
  (N + (-10 : Int) * L ≥ (0 : Int)) →
  (L + (-10 : Int) * G ≥ (0 : Int)) →
  (K + (-10 : Int) * H ≥ (0 : Int)) →
  (J + (-10 : Int) * X ≥ (0 : Int)) →
  (J + (-10 : Int) * U ≥ (0 : Int)) →
  (J + (-10 : Int) * T ≥ (0 : Int)) →
  (J + (-10 : Int) * R ≥ (0 : Int)) →
  (J + (-10 : Int) * Q ≥ (0 : Int)) →
  (J + (-10 : Int) * N ≥ (0 : Int)) →
  (J + (-10 : Int) * M ≥ (0 : Int)) →
  (J + (-10 : Int) * K ≥ (0 : Int)) →
  (J + (-10 : Int) * I ≥ (0 : Int)) →
  (J + (-10 : Int) * Y ≥ (0 : Int)) →
  (J + (-10 : Int) * A1 ≥ (0 : Int)) →
  (J + (-10 : Int) * F1 ≥ (0 : Int)) →
  (J + (-10 : Int) * E1 ≥ (0 : Int)) →
  (J + (-10 : Int) * D1 ≥ (0 : Int)) →
  (J + (-10 : Int) * B1 ≥ (0 : Int)) →
  (Z + (-10 : Int) * V ≥ (0 : Int)) →
  (Y + (-10 : Int) * W ≥ (0 : Int)) →
  (E1 + (-10 : Int) * C1 ≥ (0 : Int)) →
  (B1 + (-10 : Int) * Z ≥ (0 : Int)) →
  (V ≥ (1 : Int)) →
  (J ≥ (1 : Int)) →
  (F1 ≥ (1 : Int)) →
  (C1 ≥ (1 : Int)) →
  (C ≤ (9 : Int)) →
  (F = (-4 : Int) + B) →
  (v_36 = D) →
  r0 A B C D E v_36) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q v_17 : Int),
  (r0 H F C D N O) →
  (F = (-2 : Int) + B) →
  (P = Q) →
  (¬N = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * G ≥ (-9 : Int)) →
  ((10 : Int) * G + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * H ≥ (-9 : Int)) →
  (H + (-10 : Int) * G ≥ (0 : Int)) →
  (H + (-10 : Int) * M ≥ (0 : Int)) →
  (H + (-10 : Int) * L ≥ (0 : Int)) →
  (H + (-10 : Int) * K ≥ (0 : Int)) →
  (H + (-10 : Int) * I ≥ (0 : Int)) →
  (L + (-10 : Int) * J ≥ (0 : Int)) →
  (I + (-10 : Int) * A ≥ (0 : Int)) →
  (H ≥ (1 : Int)) →
  (M ≥ (1 : Int)) →
  (¬J ≥ (1 : Int)) →
  (C ≤ (9 : Int)) →
  (E = (0 : Int)) →
  (v_17 = D) →
  r0 A B C D E v_17) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 H G C D J K) →
  (L = M) →
  (¬J = (0 : Int)) →
  (G = (-1 : Int) + B) →
  (E = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * H ≥ (-9 : Int)) →
  (H + (-10 : Int) * A ≥ (0 : Int)) →
  (H + (-10 : Int) * I ≥ (0 : Int)) →
  (¬I ≥ (1 : Int)) →
  (H ≥ (1 : Int)) →
  (¬C ≤ (99 : Int)) →
  (C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (D = (-2 : Int) + F) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 : Int),
  (r0 J G C D Z A1) →
  (E = (0 : Int)) →
  (D = (-2 : Int) + F) →
  (B1 = C1) →
  (¬Z = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * Q ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * P ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * T ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * W ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * J ≥ (-9 : Int)) →
  (N + (-10 : Int) * L ≥ (0 : Int)) →
  (L + (-10 : Int) * A ≥ (0 : Int)) →
  (K + (-10 : Int) * H ≥ (0 : Int)) →
  (J + (-10 : Int) * Q ≥ (0 : Int)) →
  (J + (-10 : Int) * N ≥ (0 : Int)) →
  (J + (-10 : Int) * M ≥ (0 : Int)) →
  (J + (-10 : Int) * K ≥ (0 : Int)) →
  (J + (-10 : Int) * I ≥ (0 : Int)) →
  (J + (-10 : Int) * R ≥ (0 : Int)) →
  (J + (-10 : Int) * T ≥ (0 : Int)) →
  (J + (-10 : Int) * Y ≥ (0 : Int)) →
  (J + (-10 : Int) * X ≥ (0 : Int)) →
  (J + (-10 : Int) * W ≥ (0 : Int)) →
  (J + (-10 : Int) * U ≥ (0 : Int)) →
  (S + (-10 : Int) * O ≥ (0 : Int)) →
  (R + (-10 : Int) * P ≥ (0 : Int)) →
  (X + (-10 : Int) * V ≥ (0 : Int)) →
  (U + (-10 : Int) * S ≥ (0 : Int)) →
  (¬O ≥ (1 : Int)) →
  (J ≥ (1 : Int)) →
  (Y ≥ (1 : Int)) →
  (V ≥ (1 : Int)) →
  (¬C ≤ (99 : Int)) →
  (C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (G = (-3 : Int) + B) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 : Int),
  (r0 K G C D H1 I1) →
  (E = (0 : Int)) →
  (D = (-2 : Int) + F) →
  (J1 = K1) →
  (¬H1 = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * Y ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * X ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * U ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * R ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * Q ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * B1 ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * B1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * G1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * F1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * E1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * D1 + (-1 : Int) * E1 ≥ (-9 : Int)) →
  ((10 : Int) * C1 + (-1 : Int) * K ≥ (-9 : Int)) →
  (V + (-10 : Int) * T ≥ (0 : Int)) →
  (T + (-10 : Int) * P ≥ (0 : Int)) →
  (S + (-10 : Int) * Q ≥ (0 : Int)) →
  (P + (-10 : Int) * A ≥ (0 : Int)) →
  (O + (-10 : Int) * M ≥ (0 : Int)) →
  (M + (-10 : Int) * H ≥ (0 : Int)) →
  (L + (-10 : Int) * I ≥ (0 : Int)) →
  (K + (-10 : Int) * Y ≥ (0 : Int)) →
  (K + (-10 : Int) * V ≥ (0 : Int)) →
  (K + (-10 : Int) * U ≥ (0 : Int)) →
  (K + (-10 : Int) * S ≥ (0 : Int)) →
  (K + (-10 : Int) * R ≥ (0 : Int)) →
  (K + (-10 : Int) * O ≥ (0 : Int)) →
  (K + (-10 : Int) * N ≥ (0 : Int)) →
  (K + (-10 : Int) * L ≥ (0 : Int)) →
  (K + (-10 : Int) * J ≥ (0 : Int)) →
  (K + (-10 : Int) * Z ≥ (0 : Int)) →
  (K + (-10 : Int) * B1 ≥ (0 : Int)) →
  (K + (-10 : Int) * G1 ≥ (0 : Int)) →
  (K + (-10 : Int) * F1 ≥ (0 : Int)) →
  (K + (-10 : Int) * E1 ≥ (0 : Int)) →
  (K + (-10 : Int) * C1 ≥ (0 : Int)) →
  (A1 + (-10 : Int) * W ≥ (0 : Int)) →
  (Z + (-10 : Int) * X ≥ (0 : Int)) →
  (F1 + (-10 : Int) * D1 ≥ (0 : Int)) →
  (C1 + (-10 : Int) * A1 ≥ (0 : Int)) →
  (W ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (G1 ≥ (1 : Int)) →
  (D1 ≥ (1 : Int)) →
  (¬C ≤ (99 : Int)) →
  (C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (G = (-4 : Int) + B) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 I G C D O P) →
  (D = (-2 : Int) + F) →
  (G = (-2 : Int) + B) →
  (Q = R) →
  (¬O = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * I ≥ (-9 : Int)) →
  (I + (-10 : Int) * H ≥ (0 : Int)) →
  (I + (-10 : Int) * N ≥ (0 : Int)) →
  (I + (-10 : Int) * M ≥ (0 : Int)) →
  (I + (-10 : Int) * L ≥ (0 : Int)) →
  (I + (-10 : Int) * J ≥ (0 : Int)) →
  (M + (-10 : Int) * K ≥ (0 : Int)) →
  (J + (-10 : Int) * A ≥ (0 : Int)) →
  (I ≥ (1 : Int)) →
  (N ≥ (1 : Int)) →
  (¬K ≥ (1 : Int)) →
  (¬C ≤ (99 : Int)) →
  (C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (E = (0 : Int)) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 K G I H E F) →
  (H = (-4 : Int) + D) →
  (G = (-2 : Int) + B) →
  (Q = R) →
  ((10000 : Int) * C + (-1 : Int) * I ≥ (-9999 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  (I + (-10000 : Int) * C ≥ (0 : Int)) →
  (O + (-10 : Int) * M ≥ (0 : Int)) →
  (L + (-10 : Int) * A ≥ (0 : Int)) →
  (K + (-10 : Int) * P ≥ (0 : Int)) →
  (K + (-10 : Int) * O ≥ (0 : Int)) →
  (K + (-10 : Int) * N ≥ (0 : Int)) →
  (K + (-10 : Int) * L ≥ (0 : Int)) →
  (K + (-10 : Int) * J ≥ (0 : Int)) →
  (P ≥ (1 : Int)) →
  (¬M ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (¬I ≤ (9999 : Int)) →
  (¬I ≤ (99 : Int)) →
  (¬I ≤ (999 : Int)) →
  (¬I ≤ (9 : Int)) →
  (¬E = (0 : Int)) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 : Int),
  (r0 M G I H E F) →
  (G = (-4 : Int) + B) →
  (¬E = (0 : Int)) →
  (J1 = K1) →
  ((10000 : Int) * C + (-1 : Int) * I ≥ (-9999 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * Z ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * W ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * T ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * S ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * P ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * A1 ≥ (-9 : Int)) →
  ((10 : Int) * B1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * I1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * H1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * G1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * F1 + (-1 : Int) * G1 ≥ (-9 : Int)) →
  ((10 : Int) * E1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * D1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * C1 + (-1 : Int) * D1 ≥ (-9 : Int)) →
  (I + (-10000 : Int) * C ≥ (0 : Int)) →
  (X + (-10 : Int) * V ≥ (0 : Int)) →
  (V + (-10 : Int) * R ≥ (0 : Int)) →
  (U + (-10 : Int) * S ≥ (0 : Int)) →
  (R + (-10 : Int) * A ≥ (0 : Int)) →
  (Q + (-10 : Int) * O ≥ (0 : Int)) →
  (O + (-10 : Int) * J ≥ (0 : Int)) →
  (N + (-10 : Int) * K ≥ (0 : Int)) →
  (M + (-10 : Int) * X ≥ (0 : Int)) →
  (M + (-10 : Int) * W ≥ (0 : Int)) →
  (M + (-10 : Int) * U ≥ (0 : Int)) →
  (M + (-10 : Int) * T ≥ (0 : Int)) →
  (M + (-10 : Int) * Q ≥ (0 : Int)) →
  (M + (-10 : Int) * P ≥ (0 : Int)) →
  (M + (-10 : Int) * N ≥ (0 : Int)) →
  (M + (-10 : Int) * L ≥ (0 : Int)) →
  (M + (-10 : Int) * A1 ≥ (0 : Int)) →
  (M + (-10 : Int) * B1 ≥ (0 : Int)) →
  (M + (-10 : Int) * I1 ≥ (0 : Int)) →
  (M + (-10 : Int) * H1 ≥ (0 : Int)) →
  (M + (-10 : Int) * G1 ≥ (0 : Int)) →
  (M + (-10 : Int) * E1 ≥ (0 : Int)) →
  (M + (-10 : Int) * D1 ≥ (0 : Int)) →
  (B1 + (-10 : Int) * Z ≥ (0 : Int)) →
  (H1 + (-10 : Int) * F1 ≥ (0 : Int)) →
  (E1 + (-10 : Int) * C1 ≥ (0 : Int)) →
  (C1 + (-10 : Int) * Y ≥ (0 : Int)) →
  (Y ≥ (1 : Int)) →
  (M ≥ (1 : Int)) →
  (I1 ≥ (1 : Int)) →
  (F1 ≥ (1 : Int)) →
  (¬I ≤ (9999 : Int)) →
  (¬I ≤ (99 : Int)) →
  (¬I ≤ (999 : Int)) →
  (¬I ≤ (9 : Int)) →
  (H = (-4 : Int) + D) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 : Int),
  (r0 L G I H E F) →
  (G = (-3 : Int) + B) →
  (¬E = (0 : Int)) →
  (B1 = C1) →
  ((10000 : Int) * C + (-1 : Int) * I ≥ (-9999 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * R ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * S ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * Y ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * V ≥ (-9 : Int)) →
  (P + (-10 : Int) * N ≥ (0 : Int)) →
  (N + (-10 : Int) * A ≥ (0 : Int)) →
  (M + (-10 : Int) * J ≥ (0 : Int)) →
  (L + (-10 : Int) * P ≥ (0 : Int)) →
  (L + (-10 : Int) * O ≥ (0 : Int)) →
  (L + (-10 : Int) * M ≥ (0 : Int)) →
  (L + (-10 : Int) * K ≥ (0 : Int)) →
  (L + (-10 : Int) * S ≥ (0 : Int)) →
  (L + (-10 : Int) * T ≥ (0 : Int)) →
  (L + (-10 : Int) * A1 ≥ (0 : Int)) →
  (L + (-10 : Int) * Z ≥ (0 : Int)) →
  (L + (-10 : Int) * Y ≥ (0 : Int)) →
  (L + (-10 : Int) * W ≥ (0 : Int)) →
  (L + (-10 : Int) * V ≥ (0 : Int)) →
  (I + (-10000 : Int) * C ≥ (0 : Int)) →
  (T + (-10 : Int) * R ≥ (0 : Int)) →
  (Z + (-10 : Int) * X ≥ (0 : Int)) →
  (W + (-10 : Int) * U ≥ (0 : Int)) →
  (U + (-10 : Int) * Q ≥ (0 : Int)) →
  (¬Q ≥ (1 : Int)) →
  (L ≥ (1 : Int)) →
  (A1 ≥ (1 : Int)) →
  (X ≥ (1 : Int)) →
  (¬I ≤ (9999 : Int)) →
  (¬I ≤ (99 : Int)) →
  (¬I ≤ (999 : Int)) →
  (¬I ≤ (9 : Int)) →
  (H = (-4 : Int) + D) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 J G I H E F) →
  (H = (-4 : Int) + D) →
  (G = (-1 : Int) + B) →
  (¬E = (0 : Int)) →
  ((10000 : Int) * C + (-1 : Int) * I ≥ (-9999 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * J ≥ (-9 : Int)) →
  (J + (-10 : Int) * A ≥ (0 : Int)) →
  (J + (-10 : Int) * K ≥ (0 : Int)) →
  (I + (-10000 : Int) * C ≥ (0 : Int)) →
  (¬K ≥ (1 : Int)) →
  (J ≥ (1 : Int)) →
  (¬I ≤ (9999 : Int)) →
  (¬I ≤ (99 : Int)) →
  (¬I ≤ (999 : Int)) →
  (¬I ≤ (9 : Int)) →
  (L = M) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 I G C D O P) →
  (D = (-3 : Int) + F) →
  (G = (-2 : Int) + B) →
  (Q = R) →
  (¬O = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * I ≥ (-9 : Int)) →
  (I + (-10 : Int) * H ≥ (0 : Int)) →
  (I + (-10 : Int) * N ≥ (0 : Int)) →
  (I + (-10 : Int) * M ≥ (0 : Int)) →
  (I + (-10 : Int) * L ≥ (0 : Int)) →
  (I + (-10 : Int) * J ≥ (0 : Int)) →
  (M + (-10 : Int) * K ≥ (0 : Int)) →
  (J + (-10 : Int) * A ≥ (0 : Int)) →
  (I ≥ (1 : Int)) →
  (N ≥ (1 : Int)) →
  (¬K ≥ (1 : Int)) →
  (C ≤ (9999 : Int)) →
  (¬C ≤ (99 : Int)) →
  (¬C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (E = (0 : Int)) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 : Int),
  (r0 K G C D H1 I1) →
  (E = (0 : Int)) →
  (D = (-3 : Int) + F) →
  (J1 = K1) →
  (¬H1 = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * Y ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * X ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * U ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * R ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * Q ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * B1 ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * B1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * G1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * F1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * E1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * D1 + (-1 : Int) * E1 ≥ (-9 : Int)) →
  ((10 : Int) * C1 + (-1 : Int) * K ≥ (-9 : Int)) →
  (V + (-10 : Int) * T ≥ (0 : Int)) →
  (T + (-10 : Int) * P ≥ (0 : Int)) →
  (S + (-10 : Int) * Q ≥ (0 : Int)) →
  (P + (-10 : Int) * A ≥ (0 : Int)) →
  (O + (-10 : Int) * M ≥ (0 : Int)) →
  (M + (-10 : Int) * H ≥ (0 : Int)) →
  (L + (-10 : Int) * I ≥ (0 : Int)) →
  (K + (-10 : Int) * Y ≥ (0 : Int)) →
  (K + (-10 : Int) * V ≥ (0 : Int)) →
  (K + (-10 : Int) * U ≥ (0 : Int)) →
  (K + (-10 : Int) * S ≥ (0 : Int)) →
  (K + (-10 : Int) * R ≥ (0 : Int)) →
  (K + (-10 : Int) * O ≥ (0 : Int)) →
  (K + (-10 : Int) * N ≥ (0 : Int)) →
  (K + (-10 : Int) * L ≥ (0 : Int)) →
  (K + (-10 : Int) * J ≥ (0 : Int)) →
  (K + (-10 : Int) * Z ≥ (0 : Int)) →
  (K + (-10 : Int) * B1 ≥ (0 : Int)) →
  (K + (-10 : Int) * G1 ≥ (0 : Int)) →
  (K + (-10 : Int) * F1 ≥ (0 : Int)) →
  (K + (-10 : Int) * E1 ≥ (0 : Int)) →
  (K + (-10 : Int) * C1 ≥ (0 : Int)) →
  (A1 + (-10 : Int) * W ≥ (0 : Int)) →
  (Z + (-10 : Int) * X ≥ (0 : Int)) →
  (F1 + (-10 : Int) * D1 ≥ (0 : Int)) →
  (C1 + (-10 : Int) * A1 ≥ (0 : Int)) →
  (W ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (G1 ≥ (1 : Int)) →
  (D1 ≥ (1 : Int)) →
  (C ≤ (9999 : Int)) →
  (¬C ≤ (99 : Int)) →
  (¬C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (G = (-4 : Int) + B) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 : Int),
  (r0 J G C D Z A1) →
  (E = (0 : Int)) →
  (D = (-3 : Int) + F) →
  (B1 = C1) →
  (¬Z = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * Q ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * P ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * T ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * W ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * J ≥ (-9 : Int)) →
  (N + (-10 : Int) * L ≥ (0 : Int)) →
  (L + (-10 : Int) * A ≥ (0 : Int)) →
  (K + (-10 : Int) * H ≥ (0 : Int)) →
  (J + (-10 : Int) * Q ≥ (0 : Int)) →
  (J + (-10 : Int) * N ≥ (0 : Int)) →
  (J + (-10 : Int) * M ≥ (0 : Int)) →
  (J + (-10 : Int) * K ≥ (0 : Int)) →
  (J + (-10 : Int) * I ≥ (0 : Int)) →
  (J + (-10 : Int) * R ≥ (0 : Int)) →
  (J + (-10 : Int) * T ≥ (0 : Int)) →
  (J + (-10 : Int) * Y ≥ (0 : Int)) →
  (J + (-10 : Int) * X ≥ (0 : Int)) →
  (J + (-10 : Int) * W ≥ (0 : Int)) →
  (J + (-10 : Int) * U ≥ (0 : Int)) →
  (S + (-10 : Int) * O ≥ (0 : Int)) →
  (R + (-10 : Int) * P ≥ (0 : Int)) →
  (X + (-10 : Int) * V ≥ (0 : Int)) →
  (U + (-10 : Int) * S ≥ (0 : Int)) →
  (¬O ≥ (1 : Int)) →
  (J ≥ (1 : Int)) →
  (Y ≥ (1 : Int)) →
  (V ≥ (1 : Int)) →
  (C ≤ (9999 : Int)) →
  (¬C ≤ (99 : Int)) →
  (¬C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (G = (-3 : Int) + B) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 H G C D J K) →
  (L = M) →
  (¬J = (0 : Int)) →
  (G = (-1 : Int) + B) →
  (E = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * H ≥ (-9 : Int)) →
  (H + (-10 : Int) * A ≥ (0 : Int)) →
  (H + (-10 : Int) * I ≥ (0 : Int)) →
  (¬I ≥ (1 : Int)) →
  (H ≥ (1 : Int)) →
  (C ≤ (9999 : Int)) →
  (¬C ≤ (99 : Int)) →
  (¬C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (D = (-3 : Int) + F) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 I G C D O P) →
  (D = (-1 : Int) + F) →
  (G = (-2 : Int) + B) →
  (Q = R) →
  (¬O = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * I ≥ (-9 : Int)) →
  (I + (-10 : Int) * H ≥ (0 : Int)) →
  (I + (-10 : Int) * N ≥ (0 : Int)) →
  (I + (-10 : Int) * M ≥ (0 : Int)) →
  (I + (-10 : Int) * L ≥ (0 : Int)) →
  (I + (-10 : Int) * J ≥ (0 : Int)) →
  (M + (-10 : Int) * K ≥ (0 : Int)) →
  (J + (-10 : Int) * A ≥ (0 : Int)) →
  (I ≥ (1 : Int)) →
  (N ≥ (1 : Int)) →
  (¬K ≥ (1 : Int)) →
  (C ≤ (99 : Int)) →
  (¬C ≤ (9 : Int)) →
  (E = (0 : Int)) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 : Int),
  (r0 K G C D H1 I1) →
  (E = (0 : Int)) →
  (D = (-1 : Int) + F) →
  (J1 = K1) →
  (¬H1 = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * Y ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * X ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * U ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * R ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * Q ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * B1 ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * B1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * G1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * F1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * E1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * D1 + (-1 : Int) * E1 ≥ (-9 : Int)) →
  ((10 : Int) * C1 + (-1 : Int) * K ≥ (-9 : Int)) →
  (V + (-10 : Int) * T ≥ (0 : Int)) →
  (T + (-10 : Int) * P ≥ (0 : Int)) →
  (S + (-10 : Int) * Q ≥ (0 : Int)) →
  (P + (-10 : Int) * A ≥ (0 : Int)) →
  (O + (-10 : Int) * M ≥ (0 : Int)) →
  (M + (-10 : Int) * H ≥ (0 : Int)) →
  (L + (-10 : Int) * I ≥ (0 : Int)) →
  (K + (-10 : Int) * Y ≥ (0 : Int)) →
  (K + (-10 : Int) * V ≥ (0 : Int)) →
  (K + (-10 : Int) * U ≥ (0 : Int)) →
  (K + (-10 : Int) * S ≥ (0 : Int)) →
  (K + (-10 : Int) * R ≥ (0 : Int)) →
  (K + (-10 : Int) * O ≥ (0 : Int)) →
  (K + (-10 : Int) * N ≥ (0 : Int)) →
  (K + (-10 : Int) * L ≥ (0 : Int)) →
  (K + (-10 : Int) * J ≥ (0 : Int)) →
  (K + (-10 : Int) * Z ≥ (0 : Int)) →
  (K + (-10 : Int) * B1 ≥ (0 : Int)) →
  (K + (-10 : Int) * G1 ≥ (0 : Int)) →
  (K + (-10 : Int) * F1 ≥ (0 : Int)) →
  (K + (-10 : Int) * E1 ≥ (0 : Int)) →
  (K + (-10 : Int) * C1 ≥ (0 : Int)) →
  (A1 + (-10 : Int) * W ≥ (0 : Int)) →
  (Z + (-10 : Int) * X ≥ (0 : Int)) →
  (F1 + (-10 : Int) * D1 ≥ (0 : Int)) →
  (C1 + (-10 : Int) * A1 ≥ (0 : Int)) →
  (W ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (G1 ≥ (1 : Int)) →
  (D1 ≥ (1 : Int)) →
  (C ≤ (99 : Int)) →
  (¬C ≤ (9 : Int)) →
  (G = (-4 : Int) + B) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 : Int),
  (r0 J G C D Z A1) →
  (E = (0 : Int)) →
  (D = (-1 : Int) + F) →
  (B1 = C1) →
  (¬Z = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * Q ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * P ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * T ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * W ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * J ≥ (-9 : Int)) →
  (N + (-10 : Int) * L ≥ (0 : Int)) →
  (L + (-10 : Int) * A ≥ (0 : Int)) →
  (K + (-10 : Int) * H ≥ (0 : Int)) →
  (J + (-10 : Int) * Q ≥ (0 : Int)) →
  (J + (-10 : Int) * N ≥ (0 : Int)) →
  (J + (-10 : Int) * M ≥ (0 : Int)) →
  (J + (-10 : Int) * K ≥ (0 : Int)) →
  (J + (-10 : Int) * I ≥ (0 : Int)) →
  (J + (-10 : Int) * R ≥ (0 : Int)) →
  (J + (-10 : Int) * T ≥ (0 : Int)) →
  (J + (-10 : Int) * Y ≥ (0 : Int)) →
  (J + (-10 : Int) * X ≥ (0 : Int)) →
  (J + (-10 : Int) * W ≥ (0 : Int)) →
  (J + (-10 : Int) * U ≥ (0 : Int)) →
  (S + (-10 : Int) * O ≥ (0 : Int)) →
  (R + (-10 : Int) * P ≥ (0 : Int)) →
  (X + (-10 : Int) * V ≥ (0 : Int)) →
  (U + (-10 : Int) * S ≥ (0 : Int)) →
  (¬O ≥ (1 : Int)) →
  (J ≥ (1 : Int)) →
  (Y ≥ (1 : Int)) →
  (V ≥ (1 : Int)) →
  (C ≤ (99 : Int)) →
  (¬C ≤ (9 : Int)) →
  (G = (-3 : Int) + B) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 H G C D J K) →
  (L = M) →
  (¬J = (0 : Int)) →
  (G = (-1 : Int) + B) →
  (E = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * H ≥ (-9 : Int)) →
  (H + (-10 : Int) * A ≥ (0 : Int)) →
  (H + (-10 : Int) * I ≥ (0 : Int)) →
  (¬I ≥ (1 : Int)) →
  (H ≥ (1 : Int)) →
  (C ≤ (99 : Int)) →
  (¬C ≤ (9 : Int)) →
  (D = (-1 : Int) + F) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 H G C D E F) →
  (G = (-1 : Int) + B) →
  (E = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * H ≥ (-9 : Int)) →
  (H + (-10 : Int) * A ≥ (0 : Int)) →
  (H + (-10 : Int) * I ≥ (0 : Int)) →
  (¬I ≥ (1 : Int)) →
  (H ≥ (1 : Int)) →
  (J = K) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  (r0 J G C D E F) →
  (E = (0 : Int)) →
  (Z = A1) →
  ((10 : Int) * O + (-1 : Int) * P ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * Q ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * W ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * T ≥ (-9 : Int)) →
  (N + (-10 : Int) * L ≥ (0 : Int)) →
  (L + (-10 : Int) * A ≥ (0 : Int)) →
  (K + (-10 : Int) * H ≥ (0 : Int)) →
  (J + (-10 : Int) * N ≥ (0 : Int)) →
  (J + (-10 : Int) * M ≥ (0 : Int)) →
  (J + (-10 : Int) * K ≥ (0 : Int)) →
  (J + (-10 : Int) * I ≥ (0 : Int)) →
  (J + (-10 : Int) * Q ≥ (0 : Int)) →
  (J + (-10 : Int) * R ≥ (0 : Int)) →
  (J + (-10 : Int) * Y ≥ (0 : Int)) →
  (J + (-10 : Int) * X ≥ (0 : Int)) →
  (J + (-10 : Int) * W ≥ (0 : Int)) →
  (J + (-10 : Int) * U ≥ (0 : Int)) →
  (J + (-10 : Int) * T ≥ (0 : Int)) →
  (R + (-10 : Int) * P ≥ (0 : Int)) →
  (X + (-10 : Int) * V ≥ (0 : Int)) →
  (U + (-10 : Int) * S ≥ (0 : Int)) →
  (S + (-10 : Int) * O ≥ (0 : Int)) →
  (¬O ≥ (1 : Int)) →
  (J ≥ (1 : Int)) →
  (Y ≥ (1 : Int)) →
  (V ≥ (1 : Int)) →
  (G = (-3 : Int) + B) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 : Int),
  (r0 K G C D E F) →
  (E = (0 : Int)) →
  (H1 = I1) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * X ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * U ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * R ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * Q ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * Y ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * G1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * F1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * E1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * D1 + (-1 : Int) * E1 ≥ (-9 : Int)) →
  ((10 : Int) * C1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * B1 + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * B1 ≥ (-9 : Int)) →
  (V + (-10 : Int) * T ≥ (0 : Int)) →
  (T + (-10 : Int) * P ≥ (0 : Int)) →
  (S + (-10 : Int) * Q ≥ (0 : Int)) →
  (P + (-10 : Int) * A ≥ (0 : Int)) →
  (O + (-10 : Int) * M ≥ (0 : Int)) →
  (M + (-10 : Int) * H ≥ (0 : Int)) →
  (L + (-10 : Int) * I ≥ (0 : Int)) →
  (K + (-10 : Int) * V ≥ (0 : Int)) →
  (K + (-10 : Int) * U ≥ (0 : Int)) →
  (K + (-10 : Int) * S ≥ (0 : Int)) →
  (K + (-10 : Int) * R ≥ (0 : Int)) →
  (K + (-10 : Int) * O ≥ (0 : Int)) →
  (K + (-10 : Int) * N ≥ (0 : Int)) →
  (K + (-10 : Int) * L ≥ (0 : Int)) →
  (K + (-10 : Int) * J ≥ (0 : Int)) →
  (K + (-10 : Int) * Y ≥ (0 : Int)) →
  (K + (-10 : Int) * Z ≥ (0 : Int)) →
  (K + (-10 : Int) * G1 ≥ (0 : Int)) →
  (K + (-10 : Int) * F1 ≥ (0 : Int)) →
  (K + (-10 : Int) * E1 ≥ (0 : Int)) →
  (K + (-10 : Int) * C1 ≥ (0 : Int)) →
  (K + (-10 : Int) * B1 ≥ (0 : Int)) →
  (Z + (-10 : Int) * X ≥ (0 : Int)) →
  (F1 + (-10 : Int) * D1 ≥ (0 : Int)) →
  (C1 + (-10 : Int) * A1 ≥ (0 : Int)) →
  (A1 + (-10 : Int) * W ≥ (0 : Int)) →
  (W ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (G1 ≥ (1 : Int)) →
  (D1 ≥ (1 : Int)) →
  (G = (-4 : Int) + B) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r0 I G C D E F) →
  (G = (-2 : Int) + B) →
  (O = P) →
  ((10 : Int) * A + (-1 : Int) * H ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * H + (-1 : Int) * I ≥ (-9 : Int)) →
  (M + (-10 : Int) * K ≥ (0 : Int)) →
  (J + (-10 : Int) * A ≥ (0 : Int)) →
  (I + (-10 : Int) * N ≥ (0 : Int)) →
  (I + (-10 : Int) * M ≥ (0 : Int)) →
  (I + (-10 : Int) * L ≥ (0 : Int)) →
  (I + (-10 : Int) * J ≥ (0 : Int)) →
  (I + (-10 : Int) * H ≥ (0 : Int)) →
  (N ≥ (1 : Int)) →
  (¬K ≥ (1 : Int)) →
  (I ≥ (1 : Int)) →
  (E = (0 : Int)) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G : Int),
  (F = (-1 : Int)) →
  (E = (1 : Int)) →
  (D = (1 : Int)) →
  (B = (1 : Int)) →
  ((10 : Int) * A + (-1 : Int) * G ≥ (-9 : Int)) →
  (G + (-10 : Int) * A ≥ (0 : Int)) →
  (G = C) →
  r0 A B C D E F) ∧
  (∀ (A B C D E F G H : Int),
  (r0 C A E F D B) →
  (D = (0 : Int)) →
  (¬A = B) →
  (¬C ≥ (1 : Int)) →
  (G = H) →
  False))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«009-horn_000»
