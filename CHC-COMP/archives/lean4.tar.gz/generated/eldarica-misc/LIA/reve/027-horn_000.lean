import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«027-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027-horn_000.smt2":180:1-180:12 (check-sat, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027-horn_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027-horn_000.smt2":18:1-34:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027-horn_000.smt2":35:1-45:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027-horn_000.smt2":46:1-55:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027-horn_000.smt2":56:1-72:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027-horn_000.smt2":73:1-91:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027-horn_000.smt2":92:1-111:2 (clause 7, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027-horn_000.smt2":112:1-128:2 (clause 8, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027-horn_000.smt2":129:1-146:2 (clause 9, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027-horn_000.smt2":147:1-157:2 (clause 10, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027-horn_000.smt2":158:1-168:2 (clause 11, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027-horn_000.smt2":169:1-178:2 (clause 12, command 16)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  (∀ (A B C D E : Int),
  (D = A) →
  (C = (0 : Int)) →
  (¬D ≥ (1 : Int)) →
  (E = B) →
  r2 A B C) ∧
  ((∀ (A B C D E F G H I : Int),
  (r2 A D E) →
  (H = I) →
  (F = G) →
  (E = (-1 : Int) + C) →
  (A ≥ (1 : Int)) →
  (D ≥ (1 : Int)) →
  (¬F ≥ (1 : Int)) →
  (D = (1 : Int) + B) →
  r2 A B C) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 A D C) →
  (E = F) →
  (D = (1 : Int) + B) →
  (¬A ≥ (1 : Int)) →
  (¬E ≥ (1 : Int)) →
  (D ≥ (1 : Int)) →
  (G = H) →
  r2 A B C) ∧
  ((∀ (A B C D E F : Int),
  (F = (0 : Int)) →
  (C = (0 : Int)) →
  (B = E) →
  (A ≥ (1 : Int)) →
  (A = D) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A G H D E F) →
  (K = L) →
  (I = J) →
  (H = (-1 : Int) + C) →
  (¬E ≥ (1 : Int)) →
  (G ≥ (1 : Int)) →
  (I ≥ (1 : Int)) →
  (G = (1 : Int) + B) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 A G H D I F) →
  (G = (1 : Int) + B) →
  (L = M) →
  (J = K) →
  (I = (1 : Int) + E) →
  (¬D ≥ (1 : Int)) →
  (G ≥ (1 : Int)) →
  (J ≥ (1 : Int)) →
  (I ≥ (1 : Int)) →
  (H = (-1 : Int) + C) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r0 A G H D I J) →
  (I = (1 : Int) + E) →
  (H = (-1 : Int) + C) →
  (M = N) →
  (K = L) →
  (J = (-1 : Int) + F) →
  (D ≥ (1 : Int)) →
  (G ≥ (1 : Int)) →
  (I ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (G = (1 : Int) + B) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 A B C D G F) →
  (H = I) →
  (G = (1 : Int) + E) →
  (¬B ≥ (1 : Int)) →
  (¬D ≥ (1 : Int)) →
  (H ≥ (1 : Int)) →
  (G ≥ (1 : Int)) →
  (J = K) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D G H) →
  (K = L) →
  (I = J) →
  (H = (-1 : Int) + F) →
  (¬B ≥ (1 : Int)) →
  (D ≥ (1 : Int)) →
  (G ≥ (1 : Int)) →
  (I ≥ (1 : Int)) →
  (G = (1 : Int) + E) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G : Int),
  (r2 C B A) →
  (F = G) →
  (D = E) →
  (¬B ≥ (1 : Int)) →
  (¬D ≥ (1 : Int)) →
  (¬A = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 E C A F D B) →
  (I = J) →
  (G = H) →
  (¬C ≥ (1 : Int)) →
  (¬D ≥ (1 : Int)) →
  (G ≥ (1 : Int)) →
  (¬A = B) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  False)))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«027-horn_000»
