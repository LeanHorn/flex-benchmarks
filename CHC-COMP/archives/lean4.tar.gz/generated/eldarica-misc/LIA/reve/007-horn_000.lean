import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«007-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/007-horn_000.smt2":68:1-68:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/007-horn_000.smt2":6:1-16:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/007-horn_000.smt2":17:1-33:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/007-horn_000.smt2":34:1-44:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/007-horn_000.smt2":45:1-54:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/007-horn_000.smt2":55:1-66:2 (clause 5, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D E J I H) →
  (K = L) →
  (I = (-2 : Int) + F) →
  (I ≤ (9 : Int)) →
  (¬B ≤ (9 : Int)) →
  ((2 : Int) * I = (-4 : Int) + G) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r0 A I K D E L J H) →
  ((2 : Int) * I = (-4 : Int) + B) →
  (M = N) →
  (J = (-2 : Int) + F) →
  (I = (-2 : Int) + C) →
  (J ≤ (9 : Int)) →
  (I ≤ (9 : Int)) →
  ((2 : Int) * J = (-4 : Int) + G) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A I J D E F G H) →
  (K = L) →
  (I = (-2 : Int) + C) →
  (I ≤ (9 : Int)) →
  (¬G ≤ (9 : Int)) →
  ((2 : Int) * I = (-4 : Int) + B) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (F = (0 : Int)) →
  (C = (0 : Int)) →
  (B = (1 : Int)) →
  (A = E) →
  (G = (1 : Int)) →
  r0 A B C D E F G H) ∧
  (∀ (A B C D E F G H I J : Int),
  let a!1 := ¬(2 : Int) * A + (-2 : Int) * B = (0 : Int);
  r0 C A D E F G B H → I = J → ¬B ≤ (9 : Int) → ¬A ≤ (9 : Int) → ¬(2 : Int) * A + (-2 : Int) * B = (0 : Int) → False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«007-horn_000»
