import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«027b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027b-horn_000.smt2":188:1-188:12 (check-sat, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027b-horn_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027b-horn_000.smt2":18:1-34:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027b-horn_000.smt2":35:1-45:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027b-horn_000.smt2":46:1-63:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027b-horn_000.smt2":64:1-80:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027b-horn_000.smt2":81:1-99:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027b-horn_000.smt2":100:1-119:2 (clause 7, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027b-horn_000.smt2":120:1-136:2 (clause 8, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027b-horn_000.smt2":137:1-154:2 (clause 9, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027b-horn_000.smt2":155:1-165:2 (clause 10, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027b-horn_000.smt2":166:1-176:2 (clause 11, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/027b-horn_000.smt2":177:1-186:2 (clause 12, command 16)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  (∀ (A B C D E : Int),
  (D = A) →
  (C = (0 : Int)) →
  (¬D ≥ (1 : Int)) →
  (E = B) →
  r2 A B C) ∧
  ((∀ (A B C D E F G H I : Int),
  (r2 A D E) →
  (H = I) →
  (F = G) →
  (E = (-1 : Int) + C) →
  (A ≥ (1 : Int)) →
  (D ≥ (1 : Int)) →
  (¬F ≥ (1 : Int)) →
  (D = (1 : Int) + B) →
  r2 A B C) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 A D C) →
  (E = F) →
  (D = (1 : Int) + B) →
  (¬A ≥ (1 : Int)) →
  (¬E ≥ (1 : Int)) →
  (D ≥ (1 : Int)) →
  (G = H) →
  r2 A B C) ∧
  ((∀ (A B C D E F v_6 v_7 v_8 v_9 : Int),
  (F = (0 : Int)) →
  (C = (0 : Int)) →
  (B = E) →
  (A ≥ (1 : Int)) →
  (A = D) →
  (v_6 = A) →
  (v_7 = B) →
  (v_8 = D) →
  (v_9 = E) →
  r0 A B C D E F v_6 v_7 v_8 v_9) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A K L D E F G H I J) →
  (L = (-1 : Int) + C) →
  (K = (1 : Int) + B) →
  (H = J) →
  (¬E ≥ (1 : Int)) →
  (G ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (G = I) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 A K L D M F G H I J) →
  (G = I) →
  (M = (1 : Int) + E) →
  (L = (-1 : Int) + C) →
  (K = (1 : Int) + B) →
  (¬D ≥ (1 : Int)) →
  (G ≥ (1 : Int)) →
  (M ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (H = J) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r0 A K L D M N G H I J) →
  (H = J) →
  (N = (-1 : Int) + F) →
  (M = (1 : Int) + E) →
  (L = (-1 : Int) + C) →
  (K = (1 : Int) + B) →
  (D ≥ (1 : Int)) →
  (G ≥ (1 : Int)) →
  (M ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (G = I) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 A B C D K F G H I J) →
  (H = J) →
  (G = I) →
  (¬B ≥ (1 : Int)) →
  (¬D ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (G ≥ (1 : Int)) →
  (K = (1 : Int) + E) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A B C D K L G H I J) →
  (L = (-1 : Int) + F) →
  (K = (1 : Int) + E) →
  (H = J) →
  (¬B ≥ (1 : Int)) →
  (D ≥ (1 : Int)) →
  (G ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (G = I) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G : Int),
  (r2 C B A) →
  (F = G) →
  (D = E) →
  (¬B ≥ (1 : Int)) →
  (¬D ≥ (1 : Int)) →
  (¬A = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 E C A F D B G H I J) →
  (H = J) →
  (G = I) →
  (¬C ≥ (1 : Int)) →
  (¬D ≥ (1 : Int)) →
  (G ≥ (1 : Int)) →
  (¬A = B) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  False)))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«027b-horn_000»
