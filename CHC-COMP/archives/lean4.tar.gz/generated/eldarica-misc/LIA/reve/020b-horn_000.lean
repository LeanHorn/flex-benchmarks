import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«020b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/020b-horn_000.smt2":73:1-73:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/020b-horn_000.smt2":6:1-17:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/020b-horn_000.smt2":18:1-34:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/020b-horn_000.smt2":35:1-49:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/020b-horn_000.smt2":50:1-59:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/020b-horn_000.smt2":60:1-71:2 (clause 5, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J : Int),
  let a!1 := ¬(2 : Int) * A + (-1 : Int) * B ≥ (1 : Int);
  r0 A B C D I J G H →
    I = (1 : Int) + E →
      G = H → ¬(2 : Int) * A + (-1 : Int) * B ≥ (1 : Int) → I ≥ (1 : Int) → J = (-2 : Int) + F → r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A I J D K L G H) →
  (K = (1 : Int) + E) →
  (J = (-1 : Int) + C) →
  (I = (-1 : Int) + B) →
  (G = H) →
  ((2 : Int) * A + (-1 : Int) * I ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (L = (-2 : Int) + F) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A I J D E F G H) →
  (I = (-1 : Int) + B) →
  (G = H) →
  ((2 : Int) * A + (-1 : Int) * I ≥ (1 : Int)) →
  (¬E ≥ (1 : Int)) →
  (J = (-1 : Int) + C) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E v_5 v_6 v_7 : Int),
  (C = (0 : Int)) →
  (B = (0 : Int)) →
  (A = D) →
  (E = (0 : Int)) →
  (v_5 = D) →
  (v_6 = A) →
  (v_7 = D) →
  r0 A B C D v_5 E v_6 v_7) ∧
  (∀ (A B C D E F G H : Int),
  let a!1 := ¬(2 : Int) * C + (-1 : Int) * D ≥ (1 : Int);
  r0 C D A F E B G H → ¬A = B → ¬(2 : Int) * C + (-1 : Int) * D ≥ (1 : Int) → ¬E ≥ (1 : Int) → G = H → False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«020b-horn_000»
