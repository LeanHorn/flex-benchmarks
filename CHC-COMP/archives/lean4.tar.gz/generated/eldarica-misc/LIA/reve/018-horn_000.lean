import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«018-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":325:1-325:12 (check-sat, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":10:1-26:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":27:1-45:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":46:1-63:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":64:1-73:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":74:1-90:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":91:1-109:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":110:1-127:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":128:1-137:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":138:1-154:2 (clause 9, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":155:1-173:2 (clause 10, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":174:1-191:2 (clause 11, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":192:1-201:2 (clause 12, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":202:1-218:2 (clause 13, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":219:1-237:2 (clause 14, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":238:1-255:2 (clause 15, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":256:1-265:2 (clause 16, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":266:1-277:2 (clause 17, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":278:1-289:2 (clause 18, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":290:1-301:2 (clause 19, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":302:1-313:2 (clause 20, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018-horn_000.smt2":314:1-323:2 (clause 21, command 27)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J : Int),
  (r2 A B C D G H) →
  (H = (-2 : Int) + F) →
  (G = (-1 : Int) + E) →
  (D + (-1 : Int) * G ≥ (1 : Int)) →
  (¬A ≥ B) →
  (¬J ≤ (0 : Int)) →
  (I ≤ (0 : Int)) →
  (J = I) →
  r2 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r2 A G H D I J) →
  (J = (-2 : Int) + F) →
  (I = (-1 : Int) + E) →
  (H = (-2 : Int) + C) →
  (G = (-1 : Int) + B) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (A ≥ G) →
  (¬L ≤ (0 : Int)) →
  (K ≤ (0 : Int)) →
  (L = K) →
  r2 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  let a!1 := ¬D + (-1 : Int) * E ≥ (1 : Int);
  r2 A G H D E F →
    H = (-2 : Int) + C →
      G = (-1 : Int) + B →
        ¬D + (-1 : Int) * E ≥ (1 : Int) → A ≥ G → ¬J ≤ (0 : Int) → I ≤ (0 : Int) → J = I → r2 A B C D E F) ∧
  ((∀ (A B C D E F G : Int),
  (E = (1 : Int)) →
  (D = (1 : Int)) →
  (C = (0 : Int)) →
  (B = (1 : Int)) →
  (A = G) →
  (G ≤ (0 : Int)) →
  (¬A ≤ (0 : Int)) →
  (F = (2 : Int)) →
  r2 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r4 A B C D G H) →
  (H = (-2 : Int) + F) →
  (G = (-1 : Int) + E) →
  (D + (-1 : Int) * G ≥ (1 : Int)) →
  (¬A ≥ B) →
  (¬J ≤ (0 : Int)) →
  (¬I ≤ (0 : Int)) →
  (J = I) →
  r4 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r4 A G H D I J) →
  (J = (-2 : Int) + F) →
  (I = (-1 : Int) + E) →
  (H = (-2 : Int) + C) →
  (G = (-1 : Int) + B) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (A ≥ G) →
  (¬L ≤ (0 : Int)) →
  (¬K ≤ (0 : Int)) →
  (L = K) →
  r4 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  let a!1 := ¬D + (-1 : Int) * E ≥ (1 : Int);
  r4 A G H D E F →
    H = (-2 : Int) + C →
      G = (-1 : Int) + B →
        ¬D + (-1 : Int) * E ≥ (1 : Int) → A ≥ G → ¬J ≤ (0 : Int) → ¬I ≤ (0 : Int) → J = I → r4 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (E = (1 : Int)) →
  (C = (0 : Int)) →
  (B = (1 : Int)) →
  (A = D) →
  (¬D ≤ (0 : Int)) →
  (¬A ≤ (0 : Int)) →
  (F = (2 : Int)) →
  r4 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B C D G H) →
  (H = (-2 : Int) + F) →
  (G = (-1 : Int) + E) →
  (D + (-1 : Int) * G ≥ (1 : Int)) →
  (¬A ≥ B) →
  (J ≤ (0 : Int)) →
  (I ≤ (0 : Int)) →
  (J = I) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A G H D I J) →
  (J = (-2 : Int) + F) →
  (I = (-1 : Int) + E) →
  (H = (-2 : Int) + C) →
  (G = (-1 : Int) + B) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (A ≥ G) →
  (L ≤ (0 : Int)) →
  (K ≤ (0 : Int)) →
  (L = K) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  let a!1 := ¬D + (-1 : Int) * E ≥ (1 : Int);
  r0 A G H D E F →
    H = (-2 : Int) + C →
      G = (-1 : Int) + B →
        ¬D + (-1 : Int) * E ≥ (1 : Int) → A ≥ G → J ≤ (0 : Int) → I ≤ (0 : Int) → J = I → r0 A B C D E F) ∧
  ((∀ (A B C D E F G H : Int),
  (F = (2 : Int)) →
  (E = (1 : Int)) →
  (D = (1 : Int)) →
  (C = (0 : Int)) →
  (B = (1 : Int)) →
  (A = (1 : Int)) →
  (H ≤ (0 : Int)) →
  (G ≤ (0 : Int)) →
  (H = G) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r1 A B C D G H) →
  (H = (-2 : Int) + F) →
  (G = (-1 : Int) + E) →
  (D + (-1 : Int) * G ≥ (1 : Int)) →
  (¬A ≥ B) →
  (J ≤ (0 : Int)) →
  (¬I ≤ (0 : Int)) →
  (J = I) →
  r1 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A G H D I J) →
  (J = (-2 : Int) + F) →
  (I = (-1 : Int) + E) →
  (H = (-2 : Int) + C) →
  (G = (-1 : Int) + B) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (A ≥ G) →
  (L ≤ (0 : Int)) →
  (¬K ≤ (0 : Int)) →
  (L = K) →
  r1 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  let a!1 := ¬D + (-1 : Int) * E ≥ (1 : Int);
  r1 A G H D E F →
    H = (-2 : Int) + C →
      G = (-1 : Int) + B →
        ¬D + (-1 : Int) * E ≥ (1 : Int) → A ≥ G → J ≤ (0 : Int) → ¬I ≤ (0 : Int) → J = I → r1 A B C D E F) ∧
  ((∀ (A B C D E F G : Int),
  (F = (2 : Int)) →
  (E = (1 : Int)) →
  (C = (0 : Int)) →
  (B = (1 : Int)) →
  (A = (1 : Int)) →
  (G ≤ (0 : Int)) →
  (¬D ≤ (0 : Int)) →
  (G = D) →
  r1 A B C D E F) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬E + (-1 : Int) * F ≥ (1 : Int);
  r2 C D A E F B → ¬A = B → ¬E + (-1 : Int) * F ≥ (1 : Int) → ¬C ≥ D → ¬H ≤ (0 : Int) → G ≤ (0 : Int) → H = G → r3) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬E + (-1 : Int) * F ≥ (1 : Int);
  r4 C D A E F B → ¬A = B → ¬E + (-1 : Int) * F ≥ (1 : Int) → ¬C ≥ D → ¬H ≤ (0 : Int) → ¬G ≤ (0 : Int) → H = G → r3) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬E + (-1 : Int) * F ≥ (1 : Int);
  r0 C D A E F B → ¬A = B → ¬E + (-1 : Int) * F ≥ (1 : Int) → ¬C ≥ D → H ≤ (0 : Int) → G ≤ (0 : Int) → H = G → r3) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬E + (-1 : Int) * F ≥ (1 : Int);
  r1 C D A E F B → ¬A = B → ¬E + (-1 : Int) * F ≥ (1 : Int) → ¬C ≥ D → H ≤ (0 : Int) → ¬G ≤ (0 : Int) → H = G → r3) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r3) →
  False))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«018-horn_000»
