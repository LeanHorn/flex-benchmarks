import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«026b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/026b-horn_000.smt2":61:1-61:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/026b-horn_000.smt2":6:1-16:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/026b-horn_000.smt2":17:1-27:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/026b-horn_000.smt2":28:1-38:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/026b-horn_000.smt2":39:1-48:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/026b-horn_000.smt2":49:1-59:2 (clause 5, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  (∀ (A B C D E : Int),
  (r0 A E C D) →
  (C = D) →
  (E ≤ (9 : Int)) →
  (D ≤ (10 : Int)) →
  (¬A ≤ (10 : Int)) →
  (E = (-1 : Int) + B) →
  r0 A B C D) ∧
  ((∀ (A B C D E F : Int),
  (r0 E F C D) →
  (E = (-1 : Int) + A) →
  (C = D) →
  (F ≤ (9 : Int)) →
  (E ≤ (10 : Int)) →
  (D ≤ (10 : Int)) →
  (F = (-1 : Int) + B) →
  r0 A B C D) ∧
  ((∀ (A B C D E : Int),
  (r0 E B C D) →
  (C = D) →
  (E ≤ (10 : Int)) →
  (D ≤ (10 : Int)) →
  (¬B ≤ (9 : Int)) →
  (E = (-1 : Int) + A) →
  r0 A B C D) ∧
  ((∀ (A B v_2 v_3 : Int),
  (B ≤ (10 : Int)) →
  (A = B) →
  (v_2 = A) →
  (v_3 = B) →
  r0 A B v_2 v_3) ∧
  (∀ (A B C D : Int),
  (r0 A B C D) →
  (¬A = (1 : Int) + B) →
  (D ≤ (10 : Int)) →
  (¬B ≤ (9 : Int)) →
  (¬A ≤ (10 : Int)) →
  (C = D) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«026b-horn_000»
