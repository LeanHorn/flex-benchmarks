import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«009b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":1246:1-1246:12 (check-sat, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":6:1-16:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":17:1-34:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":35:1-54:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":55:1-73:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":74:1-90:2 (clause 5, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":91:1-112:2 (clause 6, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":113:1-168:2 (clause 7, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":169:1-240:2 (clause 8, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":241:1-273:2 (clause 9, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":274:1-297:2 (clause 10, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":298:1-355:2 (clause 11, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":356:1-429:2 (clause 12, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":430:1-464:2 (clause 13, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":465:1-501:2 (clause 14, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":502:1-577:2 (clause 15, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":578:1-637:2 (clause 16, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":638:1-663:2 (clause 17, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":664:1-699:2 (clause 18, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":700:1-774:2 (clause 19, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":775:1-833:2 (clause 20, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":834:1-858:2 (clause 21, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":859:1-892:2 (clause 22, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":893:1-965:2 (clause 23, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":966:1-1022:2 (clause 24, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":1023:1-1045:2 (clause 25, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":1046:1-1064:2 (clause 26, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":1065:1-1117:2 (clause 27, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":1118:1-1186:2 (clause 28, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":1187:1-1216:2 (clause 29, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":1217:1-1233:2 (clause 30, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/009b-horn_000.smt2":1234:1-1244:2 (clause 31, command 33)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I v_9 : Int),
  (r0 A B C D H I F G) →
  (F = G) →
  (E = (0 : Int)) →
  (¬A ≥ (1 : Int)) →
  (C ≤ (9 : Int)) →
  (¬H = (0 : Int)) →
  (v_9 = D) →
  r0 A B C D E v_9 F G) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B C D I J G H) →
  (G = H) →
  (E = (0 : Int)) →
  (D = (-2 : Int) + F) →
  (¬A ≥ (1 : Int)) →
  (¬C ≤ (99 : Int)) →
  (C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (¬I = (0 : Int)) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B J I E F G H) →
  (G = H) →
  (¬E = (0 : Int)) →
  ((10000 : Int) * C + (-1 : Int) * J ≥ (-9999 : Int)) →
  (J + (-10000 : Int) * C ≥ (0 : Int)) →
  (¬A ≥ (1 : Int)) →
  (¬J ≤ (9999 : Int)) →
  (¬J ≤ (99 : Int)) →
  (¬J ≤ (999 : Int)) →
  (¬J ≤ (9 : Int)) →
  (I = (-4 : Int) + D) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B C D I J G H) →
  (G = H) →
  (E = (0 : Int)) →
  (D = (-3 : Int) + F) →
  (¬A ≥ (1 : Int)) →
  (C ≤ (9999 : Int)) →
  (¬C ≤ (99 : Int)) →
  (¬C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (¬I = (0 : Int)) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B C D I J G H) →
  (G = H) →
  (E = (0 : Int)) →
  (D = (-1 : Int) + F) →
  (¬A ≥ (1 : Int)) →
  (C ≤ (99 : Int)) →
  (¬C ≤ (9 : Int)) →
  (¬I = (0 : Int)) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L v_12 : Int),
  (r0 I H C D K L F G) →
  (H = (-1 : Int) + B) →
  (F = G) →
  (E = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * I ≥ (-9 : Int)) →
  (I + (-10 : Int) * A ≥ (0 : Int)) →
  (I + (-10 : Int) * J ≥ (0 : Int)) →
  (¬J ≥ (1 : Int)) →
  (I ≥ (1 : Int)) →
  (C ≤ (9 : Int)) →
  (¬K = (0 : Int)) →
  (v_12 = D) →
  r0 A B C D E v_12 F G) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 v_28 : Int),
  (r0 K H C D A1 B1 F G) →
  (F = G) →
  (E = (0 : Int)) →
  (¬A1 = (0 : Int)) →
  ((10 : Int) * P + (-1 : Int) * Q ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * A + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * R ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * X ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * U ≥ (-9 : Int)) →
  (O + (-10 : Int) * M ≥ (0 : Int)) →
  (M + (-10 : Int) * A ≥ (0 : Int)) →
  (L + (-10 : Int) * I ≥ (0 : Int)) →
  (K + (-10 : Int) * O ≥ (0 : Int)) →
  (K + (-10 : Int) * N ≥ (0 : Int)) →
  (K + (-10 : Int) * L ≥ (0 : Int)) →
  (K + (-10 : Int) * J ≥ (0 : Int)) →
  (K + (-10 : Int) * R ≥ (0 : Int)) →
  (K + (-10 : Int) * S ≥ (0 : Int)) →
  (K + (-10 : Int) * Z ≥ (0 : Int)) →
  (K + (-10 : Int) * Y ≥ (0 : Int)) →
  (K + (-10 : Int) * X ≥ (0 : Int)) →
  (K + (-10 : Int) * V ≥ (0 : Int)) →
  (K + (-10 : Int) * U ≥ (0 : Int)) →
  (S + (-10 : Int) * Q ≥ (0 : Int)) →
  (Y + (-10 : Int) * W ≥ (0 : Int)) →
  (V + (-10 : Int) * T ≥ (0 : Int)) →
  (T + (-10 : Int) * P ≥ (0 : Int)) →
  (¬P ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (Z ≥ (1 : Int)) →
  (W ≥ (1 : Int)) →
  (C ≤ (9 : Int)) →
  (H = (-3 : Int) + B) →
  (v_28 = D) →
  r0 A B C D E v_28 F G) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 v_36 : Int),
  (r0 L H C D I1 J1 F G) →
  (F = G) →
  (E = (0 : Int)) →
  (¬I1 = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * Y ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * V ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * S ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * R ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * Z ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * H1 + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * G1 + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * F1 + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * E1 + (-1 : Int) * F1 ≥ (-9 : Int)) →
  ((10 : Int) * D1 + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * C1 + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * B1 + (-1 : Int) * C1 ≥ (-9 : Int)) →
  (W + (-10 : Int) * U ≥ (0 : Int)) →
  (U + (-10 : Int) * Q ≥ (0 : Int)) →
  (T + (-10 : Int) * R ≥ (0 : Int)) →
  (Q + (-10 : Int) * A ≥ (0 : Int)) →
  (P + (-10 : Int) * N ≥ (0 : Int)) →
  (N + (-10 : Int) * I ≥ (0 : Int)) →
  (M + (-10 : Int) * J ≥ (0 : Int)) →
  (L + (-10 : Int) * W ≥ (0 : Int)) →
  (L + (-10 : Int) * V ≥ (0 : Int)) →
  (L + (-10 : Int) * T ≥ (0 : Int)) →
  (L + (-10 : Int) * S ≥ (0 : Int)) →
  (L + (-10 : Int) * P ≥ (0 : Int)) →
  (L + (-10 : Int) * O ≥ (0 : Int)) →
  (L + (-10 : Int) * M ≥ (0 : Int)) →
  (L + (-10 : Int) * K ≥ (0 : Int)) →
  (L + (-10 : Int) * Z ≥ (0 : Int)) →
  (L + (-10 : Int) * A1 ≥ (0 : Int)) →
  (L + (-10 : Int) * H1 ≥ (0 : Int)) →
  (L + (-10 : Int) * G1 ≥ (0 : Int)) →
  (L + (-10 : Int) * F1 ≥ (0 : Int)) →
  (L + (-10 : Int) * D1 ≥ (0 : Int)) →
  (L + (-10 : Int) * C1 ≥ (0 : Int)) →
  (A1 + (-10 : Int) * Y ≥ (0 : Int)) →
  (G1 + (-10 : Int) * E1 ≥ (0 : Int)) →
  (D1 + (-10 : Int) * B1 ≥ (0 : Int)) →
  (B1 + (-10 : Int) * X ≥ (0 : Int)) →
  (X ≥ (1 : Int)) →
  (L ≥ (1 : Int)) →
  (H1 ≥ (1 : Int)) →
  (E1 ≥ (1 : Int)) →
  (C ≤ (9 : Int)) →
  (H = (-4 : Int) + B) →
  (v_36 = D) →
  r0 A B C D E v_36 F G) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q v_17 : Int),
  (r0 J H C D P Q F G) →
  (F = G) →
  (H = (-2 : Int) + B) →
  (¬P = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * I ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * I + (-1 : Int) * J ≥ (-9 : Int)) →
  (N + (-10 : Int) * L ≥ (0 : Int)) →
  (K + (-10 : Int) * A ≥ (0 : Int)) →
  (J + (-10 : Int) * O ≥ (0 : Int)) →
  (J + (-10 : Int) * N ≥ (0 : Int)) →
  (J + (-10 : Int) * M ≥ (0 : Int)) →
  (J + (-10 : Int) * K ≥ (0 : Int)) →
  (J + (-10 : Int) * I ≥ (0 : Int)) →
  (O ≥ (1 : Int)) →
  (¬L ≥ (1 : Int)) →
  (J ≥ (1 : Int)) →
  (C ≤ (9 : Int)) →
  (E = (0 : Int)) →
  (v_17 = D) →
  r0 A B C D E v_17 F G) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 J I C D L M G H) →
  (¬L = (0 : Int)) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (E = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * J ≥ (-9 : Int)) →
  (J + (-10 : Int) * A ≥ (0 : Int)) →
  (J + (-10 : Int) * K ≥ (0 : Int)) →
  (¬K ≥ (1 : Int)) →
  (J ≥ (1 : Int)) →
  (¬C ≤ (99 : Int)) →
  (C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (D = (-2 : Int) + F) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 : Int),
  (r0 L I C D B1 C1 G H) →
  (G = H) →
  (E = (0 : Int)) →
  (D = (-2 : Int) + F) →
  (¬B1 = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * R ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * S ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * Y ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * V ≥ (-9 : Int)) →
  (P + (-10 : Int) * N ≥ (0 : Int)) →
  (N + (-10 : Int) * A ≥ (0 : Int)) →
  (M + (-10 : Int) * J ≥ (0 : Int)) →
  (L + (-10 : Int) * P ≥ (0 : Int)) →
  (L + (-10 : Int) * O ≥ (0 : Int)) →
  (L + (-10 : Int) * M ≥ (0 : Int)) →
  (L + (-10 : Int) * K ≥ (0 : Int)) →
  (L + (-10 : Int) * S ≥ (0 : Int)) →
  (L + (-10 : Int) * T ≥ (0 : Int)) →
  (L + (-10 : Int) * A1 ≥ (0 : Int)) →
  (L + (-10 : Int) * Z ≥ (0 : Int)) →
  (L + (-10 : Int) * Y ≥ (0 : Int)) →
  (L + (-10 : Int) * W ≥ (0 : Int)) →
  (L + (-10 : Int) * V ≥ (0 : Int)) →
  (T + (-10 : Int) * R ≥ (0 : Int)) →
  (Z + (-10 : Int) * X ≥ (0 : Int)) →
  (W + (-10 : Int) * U ≥ (0 : Int)) →
  (U + (-10 : Int) * Q ≥ (0 : Int)) →
  (¬Q ≥ (1 : Int)) →
  (L ≥ (1 : Int)) →
  (A1 ≥ (1 : Int)) →
  (X ≥ (1 : Int)) →
  (¬C ≤ (99 : Int)) →
  (C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (I = (-3 : Int) + B) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 : Int),
  (r0 M I C D J1 K1 G H) →
  (G = H) →
  (E = (0 : Int)) →
  (D = (-2 : Int) + F) →
  (¬J1 = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * Z ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * W ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * T ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * S ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * P ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * A1 ≥ (-9 : Int)) →
  ((10 : Int) * B1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * I1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * H1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * G1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * F1 + (-1 : Int) * G1 ≥ (-9 : Int)) →
  ((10 : Int) * E1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * D1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * C1 + (-1 : Int) * D1 ≥ (-9 : Int)) →
  (X + (-10 : Int) * V ≥ (0 : Int)) →
  (V + (-10 : Int) * R ≥ (0 : Int)) →
  (U + (-10 : Int) * S ≥ (0 : Int)) →
  (R + (-10 : Int) * A ≥ (0 : Int)) →
  (Q + (-10 : Int) * O ≥ (0 : Int)) →
  (O + (-10 : Int) * J ≥ (0 : Int)) →
  (N + (-10 : Int) * K ≥ (0 : Int)) →
  (M + (-10 : Int) * X ≥ (0 : Int)) →
  (M + (-10 : Int) * W ≥ (0 : Int)) →
  (M + (-10 : Int) * U ≥ (0 : Int)) →
  (M + (-10 : Int) * T ≥ (0 : Int)) →
  (M + (-10 : Int) * Q ≥ (0 : Int)) →
  (M + (-10 : Int) * P ≥ (0 : Int)) →
  (M + (-10 : Int) * N ≥ (0 : Int)) →
  (M + (-10 : Int) * L ≥ (0 : Int)) →
  (M + (-10 : Int) * A1 ≥ (0 : Int)) →
  (M + (-10 : Int) * B1 ≥ (0 : Int)) →
  (M + (-10 : Int) * I1 ≥ (0 : Int)) →
  (M + (-10 : Int) * H1 ≥ (0 : Int)) →
  (M + (-10 : Int) * G1 ≥ (0 : Int)) →
  (M + (-10 : Int) * E1 ≥ (0 : Int)) →
  (M + (-10 : Int) * D1 ≥ (0 : Int)) →
  (B1 + (-10 : Int) * Z ≥ (0 : Int)) →
  (H1 + (-10 : Int) * F1 ≥ (0 : Int)) →
  (E1 + (-10 : Int) * C1 ≥ (0 : Int)) →
  (C1 + (-10 : Int) * Y ≥ (0 : Int)) →
  (Y ≥ (1 : Int)) →
  (M ≥ (1 : Int)) →
  (I1 ≥ (1 : Int)) →
  (F1 ≥ (1 : Int)) →
  (¬C ≤ (99 : Int)) →
  (C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (I = (-4 : Int) + B) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 K I C D Q R G H) →
  (D = (-2 : Int) + F) →
  (G = H) →
  (I = (-2 : Int) + B) →
  (¬Q = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  (O + (-10 : Int) * M ≥ (0 : Int)) →
  (L + (-10 : Int) * A ≥ (0 : Int)) →
  (K + (-10 : Int) * P ≥ (0 : Int)) →
  (K + (-10 : Int) * O ≥ (0 : Int)) →
  (K + (-10 : Int) * N ≥ (0 : Int)) →
  (K + (-10 : Int) * L ≥ (0 : Int)) →
  (K + (-10 : Int) * J ≥ (0 : Int)) →
  (P ≥ (1 : Int)) →
  (¬M ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (¬C ≤ (99 : Int)) →
  (C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (E = (0 : Int)) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 M I K J E F G H) →
  (G = H) →
  (I = (-2 : Int) + B) →
  (J = (-4 : Int) + D) →
  ((10000 : Int) * C + (-1 : Int) * K ≥ (-9999 : Int)) →
  ((10 : Int) * A + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * P ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  (Q + (-10 : Int) * O ≥ (0 : Int)) →
  (N + (-10 : Int) * A ≥ (0 : Int)) →
  (M + (-10 : Int) * R ≥ (0 : Int)) →
  (M + (-10 : Int) * Q ≥ (0 : Int)) →
  (M + (-10 : Int) * P ≥ (0 : Int)) →
  (M + (-10 : Int) * N ≥ (0 : Int)) →
  (M + (-10 : Int) * L ≥ (0 : Int)) →
  (K + (-10000 : Int) * C ≥ (0 : Int)) →
  (R ≥ (1 : Int)) →
  (¬O ≥ (1 : Int)) →
  (M ≥ (1 : Int)) →
  (¬K ≤ (9999 : Int)) →
  (¬K ≤ (99 : Int)) →
  (¬K ≤ (999 : Int)) →
  (¬K ≤ (9 : Int)) →
  (¬E = (0 : Int)) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 : Int),
  (r0 O I K J E F G H) →
  (G = H) →
  (¬E = (0 : Int)) →
  (J = (-4 : Int) + D) →
  ((10000 : Int) * C + (-1 : Int) * K ≥ (-9999 : Int)) →
  ((10 : Int) * A + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * Y ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * V ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * U ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * R ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * B1 ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * B1 + (-1 : Int) * C1 ≥ (-9 : Int)) →
  ((10 : Int) * K1 + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * J1 + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * I1 + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * H1 + (-1 : Int) * I1 ≥ (-9 : Int)) →
  ((10 : Int) * G1 + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * F1 + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * E1 + (-1 : Int) * F1 ≥ (-9 : Int)) →
  ((10 : Int) * D1 + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * C1 + (-1 : Int) * O ≥ (-9 : Int)) →
  (X + (-10 : Int) * T ≥ (0 : Int)) →
  (W + (-10 : Int) * U ≥ (0 : Int)) →
  (T + (-10 : Int) * A ≥ (0 : Int)) →
  (S + (-10 : Int) * Q ≥ (0 : Int)) →
  (Q + (-10 : Int) * L ≥ (0 : Int)) →
  (P + (-10 : Int) * M ≥ (0 : Int)) →
  (O + (-10 : Int) * Y ≥ (0 : Int)) →
  (O + (-10 : Int) * W ≥ (0 : Int)) →
  (O + (-10 : Int) * V ≥ (0 : Int)) →
  (O + (-10 : Int) * S ≥ (0 : Int)) →
  (O + (-10 : Int) * R ≥ (0 : Int)) →
  (O + (-10 : Int) * P ≥ (0 : Int)) →
  (O + (-10 : Int) * N ≥ (0 : Int)) →
  (O + (-10 : Int) * Z ≥ (0 : Int)) →
  (O + (-10 : Int) * K1 ≥ (0 : Int)) →
  (O + (-10 : Int) * J1 ≥ (0 : Int)) →
  (O + (-10 : Int) * I1 ≥ (0 : Int)) →
  (O + (-10 : Int) * G1 ≥ (0 : Int)) →
  (O + (-10 : Int) * F1 ≥ (0 : Int)) →
  (O + (-10 : Int) * D1 ≥ (0 : Int)) →
  (O + (-10 : Int) * C1 ≥ (0 : Int)) →
  (K + (-10000 : Int) * C ≥ (0 : Int)) →
  (Z + (-10 : Int) * X ≥ (0 : Int)) →
  (J1 + (-10 : Int) * H1 ≥ (0 : Int)) →
  (G1 + (-10 : Int) * E1 ≥ (0 : Int)) →
  (E1 + (-10 : Int) * A1 ≥ (0 : Int)) →
  (D1 + (-10 : Int) * B1 ≥ (0 : Int)) →
  (O ≥ (1 : Int)) →
  (A1 ≥ (1 : Int)) →
  (K1 ≥ (1 : Int)) →
  (H1 ≥ (1 : Int)) →
  (¬K ≤ (9999 : Int)) →
  (¬K ≤ (99 : Int)) →
  (¬K ≤ (999 : Int)) →
  (¬K ≤ (9 : Int)) →
  (I = (-4 : Int) + B) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 : Int),
  (r0 N I K J E F G H) →
  (I = (-3 : Int) + B) →
  (G = H) →
  (¬E = (0 : Int)) →
  ((10000 : Int) * C + (-1 : Int) * K ≥ (-9999 : Int)) →
  ((10 : Int) * A + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * Q ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * T ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * U ≥ (-9 : Int)) →
  ((10 : Int) * C1 + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * B1 + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * A1 ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * X ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * N ≥ (-9 : Int)) →
  (P + (-10 : Int) * A ≥ (0 : Int)) →
  (O + (-10 : Int) * L ≥ (0 : Int)) →
  (N + (-10 : Int) * Q ≥ (0 : Int)) →
  (N + (-10 : Int) * O ≥ (0 : Int)) →
  (N + (-10 : Int) * M ≥ (0 : Int)) →
  (N + (-10 : Int) * R ≥ (0 : Int)) →
  (N + (-10 : Int) * C1 ≥ (0 : Int)) →
  (N + (-10 : Int) * B1 ≥ (0 : Int)) →
  (N + (-10 : Int) * A1 ≥ (0 : Int)) →
  (N + (-10 : Int) * Y ≥ (0 : Int)) →
  (N + (-10 : Int) * X ≥ (0 : Int)) →
  (N + (-10 : Int) * V ≥ (0 : Int)) →
  (N + (-10 : Int) * U ≥ (0 : Int)) →
  (K + (-10000 : Int) * C ≥ (0 : Int)) →
  (R + (-10 : Int) * P ≥ (0 : Int)) →
  (B1 + (-10 : Int) * Z ≥ (0 : Int)) →
  (Y + (-10 : Int) * W ≥ (0 : Int)) →
  (W + (-10 : Int) * S ≥ (0 : Int)) →
  (V + (-10 : Int) * T ≥ (0 : Int)) →
  (N ≥ (1 : Int)) →
  (¬S ≥ (1 : Int)) →
  (C1 ≥ (1 : Int)) →
  (Z ≥ (1 : Int)) →
  (¬K ≤ (9999 : Int)) →
  (¬K ≤ (99 : Int)) →
  (¬K ≤ (999 : Int)) →
  (¬K ≤ (9 : Int)) →
  (J = (-4 : Int) + D) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 L I K J E F G H) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (¬E = (0 : Int)) →
  ((10000 : Int) * C + (-1 : Int) * K ≥ (-9999 : Int)) →
  ((10 : Int) * A + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * L ≥ (-9 : Int)) →
  (L + (-10 : Int) * A ≥ (0 : Int)) →
  (L + (-10 : Int) * M ≥ (0 : Int)) →
  (K + (-10000 : Int) * C ≥ (0 : Int)) →
  (¬M ≥ (1 : Int)) →
  (L ≥ (1 : Int)) →
  (¬K ≤ (9999 : Int)) →
  (¬K ≤ (99 : Int)) →
  (¬K ≤ (999 : Int)) →
  (¬K ≤ (9 : Int)) →
  (J = (-4 : Int) + D) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 K I C D Q R G H) →
  (D = (-3 : Int) + F) →
  (G = H) →
  (I = (-2 : Int) + B) →
  (¬Q = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  (O + (-10 : Int) * M ≥ (0 : Int)) →
  (L + (-10 : Int) * A ≥ (0 : Int)) →
  (K + (-10 : Int) * P ≥ (0 : Int)) →
  (K + (-10 : Int) * O ≥ (0 : Int)) →
  (K + (-10 : Int) * N ≥ (0 : Int)) →
  (K + (-10 : Int) * L ≥ (0 : Int)) →
  (K + (-10 : Int) * J ≥ (0 : Int)) →
  (P ≥ (1 : Int)) →
  (¬M ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (C ≤ (9999 : Int)) →
  (¬C ≤ (99 : Int)) →
  (¬C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (E = (0 : Int)) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 : Int),
  (r0 M I C D J1 K1 G H) →
  (G = H) →
  (E = (0 : Int)) →
  (D = (-3 : Int) + F) →
  (¬J1 = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * Z ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * W ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * T ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * S ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * P ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * A1 ≥ (-9 : Int)) →
  ((10 : Int) * B1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * I1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * H1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * G1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * F1 + (-1 : Int) * G1 ≥ (-9 : Int)) →
  ((10 : Int) * E1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * D1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * C1 + (-1 : Int) * D1 ≥ (-9 : Int)) →
  (X + (-10 : Int) * V ≥ (0 : Int)) →
  (V + (-10 : Int) * R ≥ (0 : Int)) →
  (U + (-10 : Int) * S ≥ (0 : Int)) →
  (R + (-10 : Int) * A ≥ (0 : Int)) →
  (Q + (-10 : Int) * O ≥ (0 : Int)) →
  (O + (-10 : Int) * J ≥ (0 : Int)) →
  (N + (-10 : Int) * K ≥ (0 : Int)) →
  (M + (-10 : Int) * X ≥ (0 : Int)) →
  (M + (-10 : Int) * W ≥ (0 : Int)) →
  (M + (-10 : Int) * U ≥ (0 : Int)) →
  (M + (-10 : Int) * T ≥ (0 : Int)) →
  (M + (-10 : Int) * Q ≥ (0 : Int)) →
  (M + (-10 : Int) * P ≥ (0 : Int)) →
  (M + (-10 : Int) * N ≥ (0 : Int)) →
  (M + (-10 : Int) * L ≥ (0 : Int)) →
  (M + (-10 : Int) * A1 ≥ (0 : Int)) →
  (M + (-10 : Int) * B1 ≥ (0 : Int)) →
  (M + (-10 : Int) * I1 ≥ (0 : Int)) →
  (M + (-10 : Int) * H1 ≥ (0 : Int)) →
  (M + (-10 : Int) * G1 ≥ (0 : Int)) →
  (M + (-10 : Int) * E1 ≥ (0 : Int)) →
  (M + (-10 : Int) * D1 ≥ (0 : Int)) →
  (B1 + (-10 : Int) * Z ≥ (0 : Int)) →
  (H1 + (-10 : Int) * F1 ≥ (0 : Int)) →
  (E1 + (-10 : Int) * C1 ≥ (0 : Int)) →
  (C1 + (-10 : Int) * Y ≥ (0 : Int)) →
  (Y ≥ (1 : Int)) →
  (M ≥ (1 : Int)) →
  (I1 ≥ (1 : Int)) →
  (F1 ≥ (1 : Int)) →
  (C ≤ (9999 : Int)) →
  (¬C ≤ (99 : Int)) →
  (¬C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (I = (-4 : Int) + B) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 : Int),
  (r0 L I C D B1 C1 G H) →
  (G = H) →
  (E = (0 : Int)) →
  (D = (-3 : Int) + F) →
  (¬B1 = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * R ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * S ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * Y ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * V ≥ (-9 : Int)) →
  (P + (-10 : Int) * N ≥ (0 : Int)) →
  (N + (-10 : Int) * A ≥ (0 : Int)) →
  (M + (-10 : Int) * J ≥ (0 : Int)) →
  (L + (-10 : Int) * P ≥ (0 : Int)) →
  (L + (-10 : Int) * O ≥ (0 : Int)) →
  (L + (-10 : Int) * M ≥ (0 : Int)) →
  (L + (-10 : Int) * K ≥ (0 : Int)) →
  (L + (-10 : Int) * S ≥ (0 : Int)) →
  (L + (-10 : Int) * T ≥ (0 : Int)) →
  (L + (-10 : Int) * A1 ≥ (0 : Int)) →
  (L + (-10 : Int) * Z ≥ (0 : Int)) →
  (L + (-10 : Int) * Y ≥ (0 : Int)) →
  (L + (-10 : Int) * W ≥ (0 : Int)) →
  (L + (-10 : Int) * V ≥ (0 : Int)) →
  (T + (-10 : Int) * R ≥ (0 : Int)) →
  (Z + (-10 : Int) * X ≥ (0 : Int)) →
  (W + (-10 : Int) * U ≥ (0 : Int)) →
  (U + (-10 : Int) * Q ≥ (0 : Int)) →
  (¬Q ≥ (1 : Int)) →
  (L ≥ (1 : Int)) →
  (A1 ≥ (1 : Int)) →
  (X ≥ (1 : Int)) →
  (C ≤ (9999 : Int)) →
  (¬C ≤ (99 : Int)) →
  (¬C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (I = (-3 : Int) + B) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 J I C D L M G H) →
  (¬L = (0 : Int)) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (E = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * J ≥ (-9 : Int)) →
  (J + (-10 : Int) * A ≥ (0 : Int)) →
  (J + (-10 : Int) * K ≥ (0 : Int)) →
  (¬K ≥ (1 : Int)) →
  (J ≥ (1 : Int)) →
  (C ≤ (9999 : Int)) →
  (¬C ≤ (99 : Int)) →
  (¬C ≤ (999 : Int)) →
  (¬C ≤ (9 : Int)) →
  (D = (-3 : Int) + F) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r0 K I C D Q R G H) →
  (D = (-1 : Int) + F) →
  (G = H) →
  (I = (-2 : Int) + B) →
  (¬Q = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  (O + (-10 : Int) * M ≥ (0 : Int)) →
  (L + (-10 : Int) * A ≥ (0 : Int)) →
  (K + (-10 : Int) * P ≥ (0 : Int)) →
  (K + (-10 : Int) * O ≥ (0 : Int)) →
  (K + (-10 : Int) * N ≥ (0 : Int)) →
  (K + (-10 : Int) * L ≥ (0 : Int)) →
  (K + (-10 : Int) * J ≥ (0 : Int)) →
  (P ≥ (1 : Int)) →
  (¬M ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (C ≤ (99 : Int)) →
  (¬C ≤ (9 : Int)) →
  (E = (0 : Int)) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 : Int),
  (r0 M I C D J1 K1 G H) →
  (G = H) →
  (E = (0 : Int)) →
  (D = (-1 : Int) + F) →
  (¬J1 = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * Z ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * W ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * T ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * S ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * P ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * A1 ≥ (-9 : Int)) →
  ((10 : Int) * B1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * I1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * H1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * G1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * F1 + (-1 : Int) * G1 ≥ (-9 : Int)) →
  ((10 : Int) * E1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * D1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * C1 + (-1 : Int) * D1 ≥ (-9 : Int)) →
  (X + (-10 : Int) * V ≥ (0 : Int)) →
  (V + (-10 : Int) * R ≥ (0 : Int)) →
  (U + (-10 : Int) * S ≥ (0 : Int)) →
  (R + (-10 : Int) * A ≥ (0 : Int)) →
  (Q + (-10 : Int) * O ≥ (0 : Int)) →
  (O + (-10 : Int) * J ≥ (0 : Int)) →
  (N + (-10 : Int) * K ≥ (0 : Int)) →
  (M + (-10 : Int) * X ≥ (0 : Int)) →
  (M + (-10 : Int) * W ≥ (0 : Int)) →
  (M + (-10 : Int) * U ≥ (0 : Int)) →
  (M + (-10 : Int) * T ≥ (0 : Int)) →
  (M + (-10 : Int) * Q ≥ (0 : Int)) →
  (M + (-10 : Int) * P ≥ (0 : Int)) →
  (M + (-10 : Int) * N ≥ (0 : Int)) →
  (M + (-10 : Int) * L ≥ (0 : Int)) →
  (M + (-10 : Int) * A1 ≥ (0 : Int)) →
  (M + (-10 : Int) * B1 ≥ (0 : Int)) →
  (M + (-10 : Int) * I1 ≥ (0 : Int)) →
  (M + (-10 : Int) * H1 ≥ (0 : Int)) →
  (M + (-10 : Int) * G1 ≥ (0 : Int)) →
  (M + (-10 : Int) * E1 ≥ (0 : Int)) →
  (M + (-10 : Int) * D1 ≥ (0 : Int)) →
  (B1 + (-10 : Int) * Z ≥ (0 : Int)) →
  (H1 + (-10 : Int) * F1 ≥ (0 : Int)) →
  (E1 + (-10 : Int) * C1 ≥ (0 : Int)) →
  (C1 + (-10 : Int) * Y ≥ (0 : Int)) →
  (Y ≥ (1 : Int)) →
  (M ≥ (1 : Int)) →
  (I1 ≥ (1 : Int)) →
  (F1 ≥ (1 : Int)) →
  (C ≤ (99 : Int)) →
  (¬C ≤ (9 : Int)) →
  (I = (-4 : Int) + B) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 : Int),
  (r0 L I C D B1 C1 G H) →
  (G = H) →
  (E = (0 : Int)) →
  (D = (-1 : Int) + F) →
  (¬B1 = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * R ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * S ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * Y ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * V ≥ (-9 : Int)) →
  (P + (-10 : Int) * N ≥ (0 : Int)) →
  (N + (-10 : Int) * A ≥ (0 : Int)) →
  (M + (-10 : Int) * J ≥ (0 : Int)) →
  (L + (-10 : Int) * P ≥ (0 : Int)) →
  (L + (-10 : Int) * O ≥ (0 : Int)) →
  (L + (-10 : Int) * M ≥ (0 : Int)) →
  (L + (-10 : Int) * K ≥ (0 : Int)) →
  (L + (-10 : Int) * S ≥ (0 : Int)) →
  (L + (-10 : Int) * T ≥ (0 : Int)) →
  (L + (-10 : Int) * A1 ≥ (0 : Int)) →
  (L + (-10 : Int) * Z ≥ (0 : Int)) →
  (L + (-10 : Int) * Y ≥ (0 : Int)) →
  (L + (-10 : Int) * W ≥ (0 : Int)) →
  (L + (-10 : Int) * V ≥ (0 : Int)) →
  (T + (-10 : Int) * R ≥ (0 : Int)) →
  (Z + (-10 : Int) * X ≥ (0 : Int)) →
  (W + (-10 : Int) * U ≥ (0 : Int)) →
  (U + (-10 : Int) * Q ≥ (0 : Int)) →
  (¬Q ≥ (1 : Int)) →
  (L ≥ (1 : Int)) →
  (A1 ≥ (1 : Int)) →
  (X ≥ (1 : Int)) →
  (C ≤ (99 : Int)) →
  (¬C ≤ (9 : Int)) →
  (I = (-3 : Int) + B) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r0 J I C D L M G H) →
  (¬L = (0 : Int)) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (E = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * J ≥ (-9 : Int)) →
  (J + (-10 : Int) * A ≥ (0 : Int)) →
  (J + (-10 : Int) * K ≥ (0 : Int)) →
  (¬K ≥ (1 : Int)) →
  (J ≥ (1 : Int)) →
  (C ≤ (99 : Int)) →
  (¬C ≤ (9 : Int)) →
  (D = (-1 : Int) + F) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 J I C D E F G H) →
  (G = H) →
  (E = (0 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * J ≥ (-9 : Int)) →
  (J + (-10 : Int) * A ≥ (0 : Int)) →
  (J + (-10 : Int) * K ≥ (0 : Int)) →
  (¬K ≥ (1 : Int)) →
  (J ≥ (1 : Int)) →
  (I = (-1 : Int) + B) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  (r0 L I C D E F G H) →
  (G = H) →
  (E = (0 : Int)) →
  ((10 : Int) * O + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * O ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * R ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * S ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * Y ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * V ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * L ≥ (-9 : Int)) →
  (N + (-10 : Int) * A ≥ (0 : Int)) →
  (M + (-10 : Int) * J ≥ (0 : Int)) →
  (L + (-10 : Int) * O ≥ (0 : Int)) →
  (L + (-10 : Int) * M ≥ (0 : Int)) →
  (L + (-10 : Int) * K ≥ (0 : Int)) →
  (L + (-10 : Int) * P ≥ (0 : Int)) →
  (L + (-10 : Int) * A1 ≥ (0 : Int)) →
  (L + (-10 : Int) * Z ≥ (0 : Int)) →
  (L + (-10 : Int) * Y ≥ (0 : Int)) →
  (L + (-10 : Int) * W ≥ (0 : Int)) →
  (L + (-10 : Int) * V ≥ (0 : Int)) →
  (L + (-10 : Int) * T ≥ (0 : Int)) →
  (L + (-10 : Int) * S ≥ (0 : Int)) →
  (P + (-10 : Int) * N ≥ (0 : Int)) →
  (Z + (-10 : Int) * X ≥ (0 : Int)) →
  (W + (-10 : Int) * U ≥ (0 : Int)) →
  (U + (-10 : Int) * Q ≥ (0 : Int)) →
  (T + (-10 : Int) * R ≥ (0 : Int)) →
  (L ≥ (1 : Int)) →
  (¬Q ≥ (1 : Int)) →
  (A1 ≥ (1 : Int)) →
  (X ≥ (1 : Int)) →
  (I = (-3 : Int) + B) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 : Int),
  (r0 M I C D E F G H) →
  (E = (0 : Int)) →
  (I = (-4 : Int) + B) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * W + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * V + (-1 : Int) * W ≥ (-9 : Int)) →
  ((10 : Int) * U + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * T + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * S + (-1 : Int) * T ≥ (-9 : Int)) →
  ((10 : Int) * R + (-1 : Int) * S ≥ (-9 : Int)) →
  ((10 : Int) * Q + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * P ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * K + (-1 : Int) * L ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * Y + (-1 : Int) * Z ≥ (-9 : Int)) →
  ((10 : Int) * X + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * Z + (-1 : Int) * A1 ≥ (-9 : Int)) →
  ((10 : Int) * I1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * H1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * G1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * F1 + (-1 : Int) * G1 ≥ (-9 : Int)) →
  ((10 : Int) * E1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * D1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * C1 + (-1 : Int) * D1 ≥ (-9 : Int)) →
  ((10 : Int) * B1 + (-1 : Int) * M ≥ (-9 : Int)) →
  ((10 : Int) * A1 + (-1 : Int) * M ≥ (-9 : Int)) →
  (V + (-10 : Int) * R ≥ (0 : Int)) →
  (U + (-10 : Int) * S ≥ (0 : Int)) →
  (R + (-10 : Int) * A ≥ (0 : Int)) →
  (Q + (-10 : Int) * O ≥ (0 : Int)) →
  (O + (-10 : Int) * J ≥ (0 : Int)) →
  (N + (-10 : Int) * K ≥ (0 : Int)) →
  (M + (-10 : Int) * W ≥ (0 : Int)) →
  (M + (-10 : Int) * U ≥ (0 : Int)) →
  (M + (-10 : Int) * T ≥ (0 : Int)) →
  (M + (-10 : Int) * Q ≥ (0 : Int)) →
  (M + (-10 : Int) * P ≥ (0 : Int)) →
  (M + (-10 : Int) * N ≥ (0 : Int)) →
  (M + (-10 : Int) * L ≥ (0 : Int)) →
  (M + (-10 : Int) * X ≥ (0 : Int)) →
  (M + (-10 : Int) * I1 ≥ (0 : Int)) →
  (M + (-10 : Int) * H1 ≥ (0 : Int)) →
  (M + (-10 : Int) * G1 ≥ (0 : Int)) →
  (M + (-10 : Int) * E1 ≥ (0 : Int)) →
  (M + (-10 : Int) * D1 ≥ (0 : Int)) →
  (M + (-10 : Int) * B1 ≥ (0 : Int)) →
  (M + (-10 : Int) * A1 ≥ (0 : Int)) →
  (X + (-10 : Int) * V ≥ (0 : Int)) →
  (H1 + (-10 : Int) * F1 ≥ (0 : Int)) →
  (E1 + (-10 : Int) * C1 ≥ (0 : Int)) →
  (C1 + (-10 : Int) * Y ≥ (0 : Int)) →
  (B1 + (-10 : Int) * Z ≥ (0 : Int)) →
  (M ≥ (1 : Int)) →
  (Y ≥ (1 : Int)) →
  (I1 ≥ (1 : Int)) →
  (F1 ≥ (1 : Int)) →
  (G = H) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r0 K I C D E F G H) →
  (G = H) →
  (I = (-2 : Int) + B) →
  ((10 : Int) * A + (-1 : Int) * J ≥ (-9 : Int)) →
  ((10 : Int) * P + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * O + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * N + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * M + (-1 : Int) * N ≥ (-9 : Int)) →
  ((10 : Int) * L + (-1 : Int) * K ≥ (-9 : Int)) →
  ((10 : Int) * J + (-1 : Int) * K ≥ (-9 : Int)) →
  (O + (-10 : Int) * M ≥ (0 : Int)) →
  (L + (-10 : Int) * A ≥ (0 : Int)) →
  (K + (-10 : Int) * P ≥ (0 : Int)) →
  (K + (-10 : Int) * O ≥ (0 : Int)) →
  (K + (-10 : Int) * N ≥ (0 : Int)) →
  (K + (-10 : Int) * L ≥ (0 : Int)) →
  (K + (-10 : Int) * J ≥ (0 : Int)) →
  (P ≥ (1 : Int)) →
  (¬M ≥ (1 : Int)) →
  (K ≥ (1 : Int)) →
  (E = (0 : Int)) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G v_7 : Int),
  (F = (-1 : Int)) →
  (E = (1 : Int)) →
  (D = (1 : Int)) →
  (B = (1 : Int)) →
  ((10 : Int) * A + (-1 : Int) * G ≥ (-9 : Int)) →
  (G + (-10 : Int) * A ≥ (0 : Int)) →
  (G = C) →
  (v_7 = C) →
  r0 A B C D E F G v_7) ∧
  (∀ (A B C D E F G H : Int),
  (r0 C A E F D B G H) →
  (D = (0 : Int)) →
  (¬A = B) →
  (¬C ≥ (1 : Int)) →
  (G = H) →
  False))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«009b-horn_000»
