import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«011-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":553:1-553:12 (check-sat, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":9:1-19:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":20:1-30:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":31:1-40:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":41:1-50:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":51:1-61:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":62:1-72:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":73:1-82:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":83:1-92:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":93:1-109:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":110:1-126:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":127:1-143:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":144:1-160:2 (clause 12, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":161:1-178:2 (clause 13, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":179:1-196:2 (clause 14, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":197:1-214:2 (clause 15, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":215:1-232:2 (clause 16, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":233:1-249:2 (clause 17, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":250:1-266:2 (clause 18, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":267:1-281:2 (clause 19, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":282:1-296:2 (clause 20, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":297:1-313:2 (clause 21, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":314:1-330:2 (clause 22, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":331:1-345:2 (clause 23, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":346:1-355:2 (clause 24, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":356:1-370:2 (clause 25, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":371:1-387:2 (clause 26, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":388:1-402:2 (clause 27, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":403:1-419:2 (clause 28, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":420:1-436:2 (clause 29, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":437:1-454:2 (clause 30, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":455:1-472:2 (clause 31, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":473:1-490:2 (clause 32, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":491:1-507:2 (clause 33, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":508:1-524:2 (clause 34, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":525:1-541:2 (clause 35, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/011-horn_000.smt2":542:1-551:2 (clause 36, command 41)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Prop),
  (∀ (A B C D : Int),
  (r3 D C) →
  (A = (2 : Int) + D) →
  (A ≥ (2 : Int)) →
  (C ≤ (-3 : Int)) →
  (B = (0 : Int)) →
  r3 A B) ∧
  ((∀ (A B C D : Int),
  (r3 D C) →
  (C = (-2 : Int) + B) →
  (A ≥ (2 : Int)) →
  (¬C ≤ (-3 : Int)) →
  (A = (2 : Int) + D) →
  r3 A B) ∧
  ((∀ (A v_1 : Int),
  (¬A ≤ (-1 : Int)) →
  (¬A ≥ (2 : Int)) →
  (v_1 = A) →
  r3 A v_1) ∧
  ((∀ (A B : Int),
  (¬A ≥ (2 : Int)) →
  (A ≤ (-1 : Int)) →
  (B = (0 : Int)) →
  r3 A B) ∧
  ((∀ (A B C D : Int),
  (r0 D C) →
  (A = (1 : Int) + D) →
  (A ≥ (1 : Int)) →
  (C ≤ (-2 : Int)) →
  (B = (0 : Int)) →
  r0 A B) ∧
  ((∀ (A B C D : Int),
  (r0 D C) →
  (C = (-1 : Int) + B) →
  (A ≥ (1 : Int)) →
  (¬C ≤ (-2 : Int)) →
  (A = (1 : Int) + D) →
  r0 A B) ∧
  ((∀ (A v_1 : Int),
  (¬A ≤ (-1 : Int)) →
  (¬A ≥ (1 : Int)) →
  (v_1 = A) →
  r0 A v_1) ∧
  ((∀ (A B : Int),
  (¬A ≥ (1 : Int)) →
  (A ≤ (-1 : Int)) →
  (B = (0 : Int)) →
  r0 A B) ∧
  ((∀ (A B C D E F : Int),
  (r0 F E) →
  (A = (1 : Int) + F) →
  (D = (0 : Int)) →
  (A ≥ (1 : Int)) →
  (¬C ≥ (2 : Int)) →
  (C ≤ (-1 : Int)) →
  (E ≤ (-2 : Int)) →
  (B = (0 : Int)) →
  r1 A B C D) ∧
  ((∀ (A B C D E F : Int),
  (r0 F E) →
  (D = (0 : Int)) →
  (E = (-1 : Int) + B) →
  (A ≥ (1 : Int)) →
  (¬C ≥ (2 : Int)) →
  (C ≤ (-1 : Int)) →
  (¬E ≤ (-2 : Int)) →
  (A = (1 : Int) + F) →
  r1 A B C D) ∧
  ((∀ (A B C D E v_5 : Int),
  (r0 E D) →
  (B = (0 : Int)) →
  (A ≥ (1 : Int)) →
  (¬C ≥ (2 : Int)) →
  (¬C ≤ (-1 : Int)) →
  (D ≤ (-2 : Int)) →
  (A = (1 : Int) + E) →
  (v_5 = C) →
  r1 A B C v_5) ∧
  ((∀ (A B C D E v_5 : Int),
  (r0 E D) →
  (D = (-1 : Int) + B) →
  (A ≥ (1 : Int)) →
  (¬C ≥ (2 : Int)) →
  (¬C ≤ (-1 : Int)) →
  (¬D ≤ (-2 : Int)) →
  (A = (1 : Int) + E) →
  (v_5 = C) →
  r1 A B C v_5) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 G F H E) →
  (A = (1 : Int) + G) →
  (C = (2 : Int) + H) →
  (E = (-2 : Int) + D) →
  (A ≥ (1 : Int)) →
  (C ≥ (2 : Int)) →
  (F ≤ (-2 : Int)) →
  (¬E ≤ (-3 : Int)) →
  (B = (0 : Int)) →
  r1 A B C D) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 G E H F) →
  (C = (2 : Int) + H) →
  (F = (-2 : Int) + D) →
  (E = (-1 : Int) + B) →
  (A ≥ (1 : Int)) →
  (C ≥ (2 : Int)) →
  (¬F ≤ (-3 : Int)) →
  (¬E ≤ (-2 : Int)) →
  (A = (1 : Int) + G) →
  r1 A B C D) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 G E H F) →
  (A = (1 : Int) + G) →
  (D = (0 : Int)) →
  (C = (2 : Int) + H) →
  (A ≥ (1 : Int)) →
  (C ≥ (2 : Int)) →
  (F ≤ (-3 : Int)) →
  (E ≤ (-2 : Int)) →
  (B = (0 : Int)) →
  r1 A B C D) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 G E H F) →
  (D = (0 : Int)) →
  (C = (2 : Int) + H) →
  (E = (-1 : Int) + B) →
  (A ≥ (1 : Int)) →
  (C ≥ (2 : Int)) →
  (F ≤ (-3 : Int)) →
  (¬E ≤ (-2 : Int)) →
  (A = (1 : Int) + G) →
  r1 A B C D) ∧
  ((∀ (A B C D E v_5 : Int),
  (r3 E D) →
  (B = (2 : Int) + E) →
  (¬A ≥ (1 : Int)) →
  (B ≥ (2 : Int)) →
  (¬A ≤ (-1 : Int)) →
  (D ≤ (-3 : Int)) →
  (C = (0 : Int)) →
  (v_5 = A) →
  r1 A v_5 B C) ∧
  ((∀ (A B C D E v_5 : Int),
  (r3 E D) →
  (D = (-2 : Int) + C) →
  (¬A ≥ (1 : Int)) →
  (B ≥ (2 : Int)) →
  (¬A ≤ (-1 : Int)) →
  (¬D ≤ (-3 : Int)) →
  (B = (2 : Int) + E) →
  (v_5 = A) →
  r1 A v_5 B C) ∧
  ((∀ (A B v_2 v_3 : Int),
  (¬A ≥ (1 : Int)) →
  (¬B ≤ (-1 : Int)) →
  (¬A ≤ (-1 : Int)) →
  (¬B ≥ (2 : Int)) →
  (v_2 = A) →
  (v_3 = B) →
  r1 A v_2 B v_3) ∧
  ((∀ (A B C v_3 : Int),
  (¬A ≥ (1 : Int)) →
  (¬B ≥ (2 : Int)) →
  (¬A ≤ (-1 : Int)) →
  (B ≤ (-1 : Int)) →
  (C = (0 : Int)) →
  (v_3 = A) →
  r1 A v_3 B C) ∧
  ((∀ (A B C D E F : Int),
  (r3 F E) →
  (D = (0 : Int)) →
  (C = (2 : Int) + F) →
  (¬A ≥ (1 : Int)) →
  (C ≥ (2 : Int)) →
  (A ≤ (-1 : Int)) →
  (E ≤ (-3 : Int)) →
  (B = (0 : Int)) →
  r1 A B C D) ∧
  ((∀ (A B C D E F : Int),
  (r3 F E) →
  (C = (2 : Int) + F) →
  (E = (-2 : Int) + D) →
  (¬A ≥ (1 : Int)) →
  (C ≥ (2 : Int)) →
  (A ≤ (-1 : Int)) →
  (¬E ≤ (-3 : Int)) →
  (B = (0 : Int)) →
  r1 A B C D) ∧
  ((∀ (A B C v_3 : Int),
  (¬A ≥ (1 : Int)) →
  (¬C ≥ (2 : Int)) →
  (A ≤ (-1 : Int)) →
  (¬C ≤ (-1 : Int)) →
  (B = (0 : Int)) →
  (v_3 = C) →
  r1 A B C v_3) ∧
  ((∀ (A B C D : Int),
  (D = (0 : Int)) →
  (¬A ≥ (1 : Int)) →
  (¬C ≥ (2 : Int)) →
  (A ≤ (-1 : Int)) →
  (C ≤ (-1 : Int)) →
  (B = (0 : Int)) →
  r1 A B C D) ∧
  ((∀ (A B : Int),
  (¬A = (0 : Int)) →
  (¬B ≥ (1 : Int)) →
  (¬A ≥ (2 : Int)) →
  (B ≤ (-1 : Int)) →
  (¬A ≤ (-1 : Int)) →
  (B = A) →
  r2) ∧
  ((∀ (A B C D : Int),
  (r3 C A) →
  (¬A = (-2 : Int)) →
  (D = B) →
  (B ≥ (2 : Int)) →
  (¬D ≥ (1 : Int)) →
  (¬A ≤ (-3 : Int)) →
  (D ≤ (-1 : Int)) →
  (B = (2 : Int) + C) →
  r2) ∧
  ((∀ (A B : Int),
  (A = B) →
  (¬B ≥ (2 : Int)) →
  (¬A ≥ (1 : Int)) →
  (B ≤ (-1 : Int)) →
  (¬A ≤ (-1 : Int)) →
  (¬A = (0 : Int)) →
  r2) ∧
  ((∀ (A B C D : Int),
  (r3 D B) →
  (A = C) →
  (C = (2 : Int) + D) →
  (¬A ≥ (1 : Int)) →
  (C ≥ (2 : Int)) →
  (¬B ≤ (-3 : Int)) →
  (¬A ≤ (-1 : Int)) →
  (¬A = (2 : Int) + B) →
  r2) ∧
  ((∀ (A B C D : Int),
  (r3 D B) →
  (A = C) →
  (C = (2 : Int) + D) →
  (¬A ≥ (1 : Int)) →
  (C ≥ (2 : Int)) →
  (B ≤ (-3 : Int)) →
  (¬A ≤ (-1 : Int)) →
  (¬A = (0 : Int)) →
  r2) ∧
  ((∀ (A B C D E F : Int),
  (r1 D A F B) →
  (C = (1 : Int) + D) →
  (C = E) →
  (E = (2 : Int) + F) →
  (C ≥ (1 : Int)) →
  (E ≥ (2 : Int)) →
  (B ≤ (-3 : Int)) →
  (¬A ≤ (-2 : Int)) →
  (¬A = (-1 : Int)) →
  r2) ∧
  ((∀ (A B C D E F : Int),
  (r1 D A F B) →
  (C = (1 : Int) + D) →
  (C = E) →
  (E = (2 : Int) + F) →
  (C ≥ (1 : Int)) →
  (E ≥ (2 : Int)) →
  (¬B ≤ (-3 : Int)) →
  (¬A ≤ (-2 : Int)) →
  (¬A = (1 : Int) + B) →
  r2) ∧
  ((∀ (A B C D E F : Int),
  (r1 D B F A) →
  (C = (1 : Int) + D) →
  (C = E) →
  (E = (2 : Int) + F) →
  (C ≥ (1 : Int)) →
  (E ≥ (2 : Int)) →
  (B ≤ (-2 : Int)) →
  (¬A ≤ (-3 : Int)) →
  (¬A = (-2 : Int)) →
  r2) ∧
  ((∀ (A B C D : Int),
  (r0 D A) →
  (C = (1 : Int) + D) →
  (C = B) →
  (¬B ≥ (2 : Int)) →
  (C ≥ (1 : Int)) →
  (¬B ≤ (-1 : Int)) →
  (¬A ≤ (-2 : Int)) →
  (¬A = (-1 : Int) + B) →
  r2) ∧
  ((∀ (A B C D : Int),
  (r0 D B) →
  (C = (1 : Int) + D) →
  (C = A) →
  (¬A ≥ (2 : Int)) →
  (C ≥ (1 : Int)) →
  (B ≤ (-2 : Int)) →
  (¬A ≤ (-1 : Int)) →
  (¬A = (0 : Int)) →
  r2) ∧
  ((∀ (A B C D : Int),
  (r0 C A) →
  (B = D) →
  (¬A = (-1 : Int)) →
  (B ≥ (1 : Int)) →
  (¬D ≥ (2 : Int)) →
  (¬A ≤ (-2 : Int)) →
  (D ≤ (-1 : Int)) →
  (B = (1 : Int) + C) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  False)))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«011-horn_000»
