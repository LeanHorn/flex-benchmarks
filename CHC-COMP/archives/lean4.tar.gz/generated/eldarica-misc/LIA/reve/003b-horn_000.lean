import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«003b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/003b-horn_000.smt2":96:1-96:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/003b-horn_000.smt2":6:1-23:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/003b-horn_000.smt2":24:1-43:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/003b-horn_000.smt2":44:1-61:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/003b-horn_000.smt2":62:1-82:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/003b-horn_000.smt2":83:1-94:2 (clause 5, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q : Int),
  let a!1 := ¬A + (-1 : Int) * C ≥ (1 : Int);
  r0 A B C D E F G O P Q K L M N →
    P = (-5 : Int) + I →
      O = (-1 : Int) + H →
        L = N →
          K = M →
            F + (-1 : Int) * O ≥ (1 : Int) → ¬A + (-1 : Int) * C ≥ (1 : Int) → Q + P = J → r0 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B O T P F G Q R S K L M N) →
  ((5 : Int) * O + B = D) →
  (S + R = J) →
  (R = (-5 : Int) + I) →
  (Q = (-1 : Int) + H) →
  (O = (-1 : Int) + C) →
  (L = N) →
  (K = M) →
  (A + (-1 : Int) * O ≥ (1 : Int)) →
  (F + (-1 : Int) * Q ≥ (1 : Int)) →
  (P + (5 : Int) * O + B = E) →
  r0 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  let a!1 := ¬F + (-1 : Int) * H ≥ (1 : Int);
  r0 A B O Q P F G H I J K L M N →
    (5 : Int) * O + B = D →
      O = (-1 : Int) + C →
        L = N →
          K = M →
            ¬F + (-1 : Int) * H ≥ (1 : Int) →
              A + (-1 : Int) * O ≥ (1 : Int) → P + (5 : Int) * O + B = E → r0 A B C D E F G H I J K L M N) ∧
  ((∀ (A B C D E F G H I v_9 v_10 v_11 v_12 v_13 : Int),
  (H = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (B = G) →
  (A = F) →
  (I = (0 : Int)) →
  (v_9 = G) →
  (v_10 = A) →
  (v_11 = B) →
  (v_12 = F) →
  (v_13 = G) →
  r0 A B C D E F G H v_9 I v_10 v_11 v_12 v_13) ∧
  (∀ (A B C D E F G H I J K L M N : Int),
  let a!1 := ¬E + (-1 : Int) * F ≥ (1 : Int);
  let a!2 := ¬C + (-1 : Int) * D ≥ (1 : Int);
  r0 C G D H A E I F J B K L M N →
    K = M → ¬A = B → ¬E + (-1 : Int) * F ≥ (1 : Int) → ¬C + (-1 : Int) * D ≥ (1 : Int) → L = N → False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«003b-horn_000»
