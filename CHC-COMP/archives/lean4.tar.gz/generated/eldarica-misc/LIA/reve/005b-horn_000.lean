import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«005b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005b-horn_000.smt2":141:1-141:12 (check-sat, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005b-horn_000.smt2":7:1-17:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005b-horn_000.smt2":18:1-34:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005b-horn_000.smt2":35:1-45:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005b-horn_000.smt2":46:1-63:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005b-horn_000.smt2":64:1-83:2 (clause 5, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005b-horn_000.smt2":84:1-101:2 (clause 6, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005b-horn_000.smt2":102:1-112:2 (clause 7, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005b-horn_000.smt2":113:1-122:2 (clause 8, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/005b-horn_000.smt2":123:1-139:2 (clause 9, command 12)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J : Int),
  (r1 A B C D I J G H) →
  (I = (-1 : Int) + E) →
  (G = H) →
  (D ≥ I) →
  (¬A ≥ B) →
  ((5 : Int) * J = F) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A I J D K L G H) →
  ((5 : Int) * J = C) →
  (K = (-1 : Int) + E) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (A ≥ I) →
  (D ≥ K) →
  ((5 : Int) * L = F) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r1 A I J D E F G H) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (¬D ≥ E) →
  (A ≥ I) →
  ((5 : Int) * J = C) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r1 K L O M N P G H) →
  (r0 A I J D E F G H) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (¬D ≥ E) →
  (A ≥ I) →
  (¬M ≥ N) →
  (¬K ≥ L) →
  (J + I = C) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r1 M N Q O P R G H) →
  (r0 A I J D K L G H) →
  (J + I = C) →
  (G = H) →
  (K = (-1 : Int) + E) →
  (I = (-1 : Int) + B) →
  (A ≥ I) →
  (D ≥ K) →
  (¬O ≥ P) →
  (¬M ≥ N) →
  (L + K = F) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r1 K L O M N P G H) →
  (r0 A B C D I J G H) →
  (I = (-1 : Int) + E) →
  (G = H) →
  (D ≥ I) →
  (¬A ≥ B) →
  (¬M ≥ N) →
  (¬K ≥ L) →
  (J + I = F) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r1 A I C D J F G H) →
  (E = (1 : Int)) →
  (B = (0 : Int)) →
  (¬D ≥ J) →
  (¬A ≥ I) →
  (G = H) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F v_6 v_7 : Int),
  (E = (1 : Int)) →
  (C = (1 : Int)) →
  (B = (1 : Int)) →
  (A = D) →
  (F = (1 : Int)) →
  (v_6 = A) →
  (v_7 = D) →
  r1 A B C D E F v_6 v_7) ∧
  (∀ (A B C D E F G H I J K L M N : Int),
  (r1 I J M K L N G H) →
  (r0 E F A C D B G H) →
  (G = H) →
  (¬C ≥ D) →
  (¬K ≥ L) →
  (¬I ≥ J) →
  (¬E ≥ F) →
  (¬A = B) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«005b-horn_000»
