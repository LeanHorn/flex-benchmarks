import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«006b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":228:1-228:12 (check-sat, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":8:1-18:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":19:1-35:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":36:1-46:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":47:1-64:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":65:1-84:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":85:1-102:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":103:1-123:2 (clause 7, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":124:1-146:2 (clause 8, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":147:1-167:2 (clause 9, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":168:1-185:2 (clause 10, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":186:1-196:2 (clause 11, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":197:1-206:2 (clause 12, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/006b-horn_000.smt2":207:1-226:2 (clause 13, command 17)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J : Int),
  (r1 A B C D I J G H) →
  (I = (-1 : Int) + E) →
  (G = H) →
  (D ≥ I) →
  (¬A ≥ B) →
  (J = F) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A I J D K L G H) →
  (K = (-1 : Int) + E) →
  (J = C) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (A ≥ I) →
  (D ≥ K) →
  (L = F) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r1 A I J D E F G H) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (¬D ≥ E) →
  (A ≥ I) →
  (J = C) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r1 K L O M N P G H) →
  (r0 A I J D E F G H) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (¬D ≥ E) →
  (A ≥ I) →
  (¬M ≥ N) →
  (¬K ≥ L) →
  (J + I = C) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R : Int),
  (r1 M N Q O P R G H) →
  (r0 A I J D K L G H) →
  (J + I = C) →
  (G = H) →
  (K = (-1 : Int) + E) →
  (I = (-1 : Int) + B) →
  (A ≥ I) →
  (D ≥ K) →
  (¬O ≥ P) →
  (¬M ≥ N) →
  (L + K = F) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r1 K L O M N P G H) →
  (r0 A B C D I J G H) →
  (I = (-1 : Int) + E) →
  (G = H) →
  (D ≥ I) →
  (¬A ≥ B) →
  (¬M ≥ N) →
  (¬K ≥ L) →
  (J + I = F) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V : Int),
  (r1 Q R U S T V G H) →
  (r0 M N O K L P G H) →
  (r2 A B C D I J G H) →
  (I = (-1 : Int) + E) →
  (G = H) →
  (D ≥ I) →
  (¬A ≥ B) →
  (¬K ≥ L) →
  (¬S ≥ T) →
  (¬Q ≥ R) →
  (¬M ≥ N) →
  ((2 : Int) * J = F) →
  r2 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X : Int),
  (r1 S T W U V X G H) →
  (r0 O P Q M N R G H) →
  (r2 A I J D K L G H) →
  ((2 : Int) * J = C) →
  (G = H) →
  (K = (-1 : Int) + E) →
  (I = (-1 : Int) + B) →
  (A ≥ I) →
  (D ≥ K) →
  (¬M ≥ N) →
  (¬U ≥ V) →
  (¬S ≥ T) →
  (¬O ≥ P) →
  ((2 : Int) * L = F) →
  r2 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V : Int),
  (r1 Q R U S T V G H) →
  (r0 M N O K L P G H) →
  (r2 A I J D E F G H) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (¬D ≥ E) →
  (A ≥ I) →
  (¬K ≥ L) →
  (¬S ≥ T) →
  (¬Q ≥ R) →
  (¬M ≥ N) →
  ((2 : Int) * J = C) →
  r2 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r1 K L O M N P G H) →
  (r0 A J C D I F G H) →
  (E = (1 : Int)) →
  (G = H) →
  (¬D ≥ I) →
  (¬A ≥ J) →
  (¬M ≥ N) →
  (¬K ≥ L) →
  (B = (1 : Int)) →
  r2 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r1 A I C D J F G H) →
  (E = (1 : Int)) →
  (B = (0 : Int)) →
  (¬D ≥ J) →
  (¬A ≥ I) →
  (G = H) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F v_6 v_7 : Int),
  (E = (1 : Int)) →
  (C = (1 : Int)) →
  (B = (1 : Int)) →
  (A = D) →
  (F = (1 : Int)) →
  (v_6 = A) →
  (v_7 = D) →
  r1 A B C D E F v_6 v_7) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r1 O P S Q R T G H) →
  (r0 K L M I J N G H) →
  (r2 C D A E F B G H) →
  (G = H) →
  (¬C ≥ D) →
  (¬E ≥ F) →
  (¬I ≥ J) →
  (¬Q ≥ R) →
  (¬O ≥ P) →
  (¬K ≥ L) →
  (¬A = B) →
  False))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«006b-horn_000»
