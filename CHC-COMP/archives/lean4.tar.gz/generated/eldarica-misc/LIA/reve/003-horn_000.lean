import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«003-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/003-horn_000.smt2":85:1-85:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/003-horn_000.smt2":6:1-23:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/003-horn_000.smt2":24:1-43:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/003-horn_000.smt2":44:1-61:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/003-horn_000.smt2":62:1-71:2 (clause 4, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/003-horn_000.smt2":72:1-83:2 (clause 5, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q : Int),
  let a!1 := ¬A + (-1 : Int) * C ≥ (1 : Int);
  r0 A B C D E F G K L M →
    P = Q →
      N = O →
        L = (-5 : Int) + I →
          K = (-1 : Int) + H →
            F + (-1 : Int) * K ≥ (1 : Int) → ¬A + (-1 : Int) * C ≥ (1 : Int) → M + L = J → r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r0 A B K P L F G M N O) →
  ((5 : Int) * K + B = D) →
  (O + N = J) →
  (S = T) →
  (Q = R) →
  (N = (-5 : Int) + I) →
  (M = (-1 : Int) + H) →
  (K = (-1 : Int) + C) →
  (A + (-1 : Int) * K ≥ (1 : Int)) →
  (F + (-1 : Int) * M ≥ (1 : Int)) →
  (L + (5 : Int) * K + B = E) →
  r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  let a!1 := ¬F + (-1 : Int) * H ≥ (1 : Int);
  r0 A B K M L F G H I J →
    (5 : Int) * K + B = D →
      P = Q →
        N = O →
          K = (-1 : Int) + C →
            ¬F + (-1 : Int) * H ≥ (1 : Int) →
              A + (-1 : Int) * K ≥ (1 : Int) → L + (5 : Int) * K + B = E → r0 A B C D E F G H I J) ∧
  ((∀ (A B C D E F G H I v_9 : Int),
  (H = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (B = G) →
  (A = F) →
  (I = (0 : Int)) →
  (v_9 = G) →
  r0 A B C D E F G H v_9 I) ∧
  (∀ (A B C D E F G H I J K L M N : Int),
  let a!1 := ¬E + (-1 : Int) * F ≥ (1 : Int);
  let a!2 := ¬C + (-1 : Int) * D ≥ (1 : Int);
  r0 C G D H A E I F J B →
    K = L → ¬A = B → ¬E + (-1 : Int) * F ≥ (1 : Int) → ¬C + (-1 : Int) * D ≥ (1 : Int) → M = N → False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«003-horn_000»
