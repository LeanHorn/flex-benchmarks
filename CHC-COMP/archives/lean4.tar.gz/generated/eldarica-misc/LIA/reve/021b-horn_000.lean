import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«021b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/021b-horn_000.smt2":155:1-155:12 (check-sat, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/021b-horn_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/021b-horn_000.smt2":19:1-30:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/021b-horn_000.smt2":31:1-40:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/021b-horn_000.smt2":41:1-52:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/021b-horn_000.smt2":53:1-64:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/021b-horn_000.smt2":65:1-76:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/021b-horn_000.smt2":77:1-88:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/021b-horn_000.smt2":89:1-98:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/021b-horn_000.smt2":99:1-115:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/021b-horn_000.smt2":116:1-131:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/021b-horn_000.smt2":132:1-143:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/021b-horn_000.smt2":144:1-153:2 (clause 12, command 17)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Prop),
  (∀ (A B : Int),
  (A ≥ (101 : Int)) →
  (A = (10 : Int) + B) →
  r0 A B) ∧
  ((∀ (A B C D : Int),
  (r0 C B) →
  (r0 D C) →
  (¬A ≥ (101 : Int)) →
  (A = (-11 : Int) + D) →
  r0 A B) ∧
  ((∀ (A B C D : Int),
  (A = (10 : Int) + B) →
  (A ≥ (101 : Int)) →
  (¬C ≤ (100 : Int)) →
  (C = (10 : Int) + D) →
  r1 A B C D) ∧
  ((∀ (A B C D E F : Int),
  (r3 F E) →
  (r3 E D) →
  (A = (10 : Int) + B) →
  (A ≥ (101 : Int)) →
  (C ≤ (100 : Int)) →
  (C = (-11 : Int) + F) →
  r1 A B C D) ∧
  ((∀ (A B C D E F : Int),
  (r0 F E) →
  (r0 E B) →
  (A = (-11 : Int) + F) →
  (¬A ≥ (101 : Int)) →
  (¬C ≤ (100 : Int)) →
  (C = (10 : Int) + D) →
  r1 A B C D) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 E B F D) →
  (r1 G E H F) →
  (A = (-11 : Int) + G) →
  (¬A ≥ (101 : Int)) →
  (C ≤ (100 : Int)) →
  (C = (-11 : Int) + H) →
  r1 A B C D) ∧
  ((∀ (A B C D : Int),
  (r3 C B) →
  (r3 D C) →
  (A ≤ (100 : Int)) →
  (A = (-11 : Int) + D) →
  r3 A B) ∧
  ((∀ (A B : Int),
  (¬A ≤ (100 : Int)) →
  (A = (10 : Int) + B) →
  r3 A B) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 F C H D) →
  (r1 C A D B) →
  (E = (-11 : Int) + F) →
  (E = G) →
  (¬A = B) →
  (¬E ≥ (101 : Int)) →
  (G ≤ (100 : Int)) →
  (G = (-11 : Int) + H) →
  r2) ∧
  ((∀ (A B C D E : Int),
  (r0 E C) →
  (r0 C A) →
  (D = B) →
  (¬A = (-10 : Int) + B) →
  (¬D ≥ (101 : Int)) →
  (¬B ≤ (100 : Int)) →
  (D = (-11 : Int) + E) →
  r2) ∧
  ((∀ (A B C D E : Int),
  (r3 E C) →
  (r3 C B) →
  (¬A = (10 : Int) + B) →
  (A = D) →
  (A ≥ (101 : Int)) →
  (D ≤ (100 : Int)) →
  (D = (-11 : Int) + E) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  False)))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«021b-horn_000»
