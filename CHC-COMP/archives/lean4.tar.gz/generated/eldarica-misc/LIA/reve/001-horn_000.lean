import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«001-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":842:1-842:12 (check-sat, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":19:1-30:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":31:1-42:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":43:1-53:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":54:1-63:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":64:1-80:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":81:1-90:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":91:1-107:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":108:1-118:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":119:1-137:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":138:1-156:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":157:1-174:2 (clause 12, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":175:1-193:2 (clause 13, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":194:1-211:2 (clause 14, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":212:1-230:2 (clause 15, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":231:1-249:2 (clause 16, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":250:1-267:2 (clause 17, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":268:1-286:2 (clause 18, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":287:1-304:2 (clause 19, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":305:1-323:2 (clause 20, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":324:1-343:2 (clause 21, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":344:1-361:2 (clause 22, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":362:1-381:2 (clause 23, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":382:1-399:2 (clause 24, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":400:1-410:2 (clause 25, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":411:1-422:2 (clause 26, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":423:1-432:2 (clause 27, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":433:1-444:2 (clause 28, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":445:1-454:2 (clause 29, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":455:1-474:2 (clause 30, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":475:1-497:2 (clause 31, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":498:1-517:2 (clause 32, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":518:1-540:2 (clause 33, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":541:1-562:2 (clause 34, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":563:1-582:2 (clause 35, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":583:1-604:2 (clause 36, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":605:1-624:2 (clause 37, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":625:1-646:2 (clause 38, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":647:1-668:2 (clause 39, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":669:1-688:2 (clause 40, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":689:1-710:2 (clause 41, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":711:1-730:2 (clause 42, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":731:1-752:2 (clause 43, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":753:1-774:2 (clause 44, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":775:1-792:2 (clause 45, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":793:1-811:2 (clause 46, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":812:1-830:2 (clause 47, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/001-horn_000.smt2":831:1-840:2 (clause 48, command 53)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C : Int),
  (A = (0 : Int)) →
  (B = (-1 : Int) + C) →
  r2 A B C) ∧
  ((∀ (A B C D E F : Int),
  (r2 A F E) →
  (r2 D E C) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + D) →
  (¬A ≥ (1 : Int)) →
  (B = (1 : Int) + F) →
  r2 A B C) ∧
  ((∀ (A B C D E F : Int),
  (r2 A F E) →
  (r2 D E C) →
  (B = (1 : Int) + F) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + D) →
  (¬B = (0 : Int)) →
  r2 A B C) ∧
  ((∀ (A B C D E : Int),
  (r2 D E C) →
  (B = (0 : Int)) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + D) →
  (A ≥ (1 : Int)) →
  (E = (1 : Int)) →
  r2 A B C) ∧
  ((∀ (A B C D E F : Int),
  (D = (0 : Int)) →
  (B = (-1 : Int) + C) →
  (A = (0 : Int)) →
  (¬D ≥ (1 : Int)) →
  (E = (-1 : Int) + F) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I : Int),
  (r0 D I H) →
  (r0 G H F) →
  (A = (0 : Int)) →
  (E = (1 : Int) + I) →
  (¬D = (0 : Int)) →
  (D = (1 : Int) + G) →
  (¬D ≥ (1 : Int)) →
  (B = (-1 : Int) + C) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (E = (-1 : Int) + F) →
  (D = (0 : Int)) →
  (B = (-1 : Int) + C) →
  (A = (0 : Int)) →
  (¬E = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I : Int),
  (r0 D I H) →
  (r0 G H F) →
  (A = (0 : Int)) →
  (¬E = (0 : Int)) →
  (E = (1 : Int) + I) →
  (¬D = (0 : Int)) →
  (D = (1 : Int) + G) →
  (B = (-1 : Int) + C) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 G H F) →
  (H = (1 : Int)) →
  (E = (0 : Int)) →
  (D = (1 : Int) + G) →
  (B = (-1 : Int) + C) →
  (D ≥ (1 : Int)) →
  (A = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 A I H J K F) →
  (r2 G H C) →
  (B = (1 : Int) + I) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + G) →
  (K = (1 : Int)) →
  (E = (0 : Int)) →
  (D ≥ (1 : Int)) →
  (¬A ≥ (1 : Int)) →
  (D = (1 : Int) + J) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A K I D L J) →
  (r3 G I C H J F) →
  (A = (1 : Int) + G) →
  (¬E = (0 : Int)) →
  (E = (1 : Int) + L) →
  (¬D = (0 : Int)) →
  (D = (1 : Int) + H) →
  (B = (1 : Int) + K) →
  (¬A ≥ (1 : Int)) →
  (¬A = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I : Int),
  (r2 A I H) →
  (r2 G H C) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + G) →
  (¬E = (0 : Int)) →
  (E = (-1 : Int) + F) →
  (D = (0 : Int)) →
  (¬A ≥ (1 : Int)) →
  (B = (1 : Int) + I) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A K I D L J) →
  (r3 G I C H J F) →
  (A = (1 : Int) + G) →
  (E = (1 : Int) + L) →
  (¬D = (0 : Int)) →
  (D = (1 : Int) + H) →
  (B = (1 : Int) + K) →
  (¬A ≥ (1 : Int)) →
  (¬D ≥ (1 : Int)) →
  (¬A = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I : Int),
  (r2 A I H) →
  (r2 G H C) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + G) →
  (E = (-1 : Int) + F) →
  (D = (0 : Int)) →
  (¬A ≥ (1 : Int)) →
  (¬D ≥ (1 : Int)) →
  (B = (1 : Int) + I) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 A I H J K F) →
  (r2 G H C) →
  (¬B = (0 : Int)) →
  (B = (1 : Int) + I) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + G) →
  (K = (1 : Int)) →
  (E = (0 : Int)) →
  (D ≥ (1 : Int)) →
  (D = (1 : Int) + J) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A K I D L J) →
  (r3 G I C H J F) →
  (A = (1 : Int) + G) →
  (¬E = (0 : Int)) →
  (E = (1 : Int) + L) →
  (¬D = (0 : Int)) →
  (D = (1 : Int) + H) →
  (¬B = (0 : Int)) →
  (B = (1 : Int) + K) →
  (¬A = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I : Int),
  (r2 A I H) →
  (r2 G H C) →
  (B = (1 : Int) + I) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + G) →
  (¬E = (0 : Int)) →
  (E = (-1 : Int) + F) →
  (D = (0 : Int)) →
  (¬B = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A K I D L J) →
  (r3 G I C H J F) →
  (A = (1 : Int) + G) →
  (E = (1 : Int) + L) →
  (¬D = (0 : Int)) →
  (D = (1 : Int) + H) →
  (¬B = (0 : Int)) →
  (B = (1 : Int) + K) →
  (¬D ≥ (1 : Int)) →
  (¬A = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I : Int),
  (r2 A I H) →
  (r2 G H C) →
  (B = (1 : Int) + I) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + G) →
  (E = (-1 : Int) + F) →
  (D = (0 : Int)) →
  (¬D ≥ (1 : Int)) →
  (¬B = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 G H C I J F) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + G) →
  (J = (1 : Int)) →
  (H = (1 : Int)) →
  (E = (0 : Int)) →
  (D = (1 : Int) + I) →
  (A ≥ (1 : Int)) →
  (D ≥ (1 : Int)) →
  (B = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 I J C D K H) →
  (r0 G H F) →
  (D = (1 : Int) + G) →
  (B = (0 : Int)) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + I) →
  (J = (1 : Int)) →
  (¬E = (0 : Int)) →
  (E = (1 : Int) + K) →
  (A ≥ (1 : Int)) →
  (¬D = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 G H C) →
  (A = (1 : Int) + G) →
  (H = (1 : Int)) →
  (¬E = (0 : Int)) →
  (E = (-1 : Int) + F) →
  (D = (0 : Int)) →
  (B = (0 : Int)) →
  (A ≥ (1 : Int)) →
  (¬A = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 I J C D K H) →
  (r0 G H F) →
  (D = (1 : Int) + G) →
  (B = (0 : Int)) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + I) →
  (J = (1 : Int)) →
  (E = (1 : Int) + K) →
  (¬D ≥ (1 : Int)) →
  (A ≥ (1 : Int)) →
  (¬D = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 G H C) →
  (A = (1 : Int) + G) →
  (H = (1 : Int)) →
  (E = (-1 : Int) + F) →
  (D = (0 : Int)) →
  (B = (0 : Int)) →
  (A ≥ (1 : Int)) →
  (¬D ≥ (1 : Int)) →
  (¬A = (0 : Int)) →
  r3 A B C D E F) ∧
  ((∀ (A B C D E : Int),
  (r0 D E C) →
  (B = (0 : Int)) →
  (A = (1 : Int) + D) →
  (A ≥ (1 : Int)) →
  (E = (1 : Int)) →
  r0 A B C) ∧
  ((∀ (A B C D E F : Int),
  (r0 A F E) →
  (r0 D E C) →
  (B = (1 : Int) + F) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + D) →
  (¬B = (0 : Int)) →
  r0 A B C) ∧
  ((∀ (A B C : Int),
  (B = (-1 : Int) + C) →
  (A = (0 : Int)) →
  (¬B = (0 : Int)) →
  r0 A B C) ∧
  ((∀ (A B C D E F : Int),
  (r0 A F E) →
  (r0 D E C) →
  (¬A = (0 : Int)) →
  (A = (1 : Int) + D) →
  (¬A ≥ (1 : Int)) →
  (B = (1 : Int) + F) →
  r0 A B C) ∧
  ((∀ (A B C : Int),
  (A = (0 : Int)) →
  (¬A ≥ (1 : Int)) →
  (B = (-1 : Int) + C) →
  r0 A B C) ∧
  ((∀ (A B C D E F G : Int),
  (r2 D E A) →
  (G = B) →
  (F = (0 : Int)) →
  (E = (1 : Int)) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (C = F) →
  (¬A = (1 : Int) + B) →
  (¬F ≥ (1 : Int)) →
  (C ≥ (1 : Int)) →
  (G = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 G H A C J E) →
  (r0 D E B) →
  (C = (1 : Int) + D) →
  (¬A = B) →
  (K = (0 : Int)) →
  (K = I) →
  (I = (1 : Int) + J) →
  (H = (1 : Int)) →
  (¬F = (0 : Int)) →
  (F = (1 : Int) + G) →
  (F = C) →
  (¬C ≥ (1 : Int)) →
  (F ≥ (1 : Int)) →
  (¬C = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D E F G : Int),
  (r2 D E A) →
  (G = B) →
  (F = (0 : Int)) →
  (E = (1 : Int)) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (C = F) →
  (¬B = (0 : Int)) →
  (¬A = (1 : Int) + B) →
  (C ≥ (1 : Int)) →
  (G = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 G H A C J E) →
  (r0 D E B) →
  (C = (1 : Int) + D) →
  (¬A = B) →
  (K = (0 : Int)) →
  (K = I) →
  (¬I = (0 : Int)) →
  (I = (1 : Int) + J) →
  (H = (1 : Int)) →
  (¬F = (0 : Int)) →
  (F = (1 : Int) + G) →
  (F = C) →
  (F ≥ (1 : Int)) →
  (¬C = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 D E A G H B) →
  (C = (1 : Int) + D) →
  (C = F) →
  (¬A = B) →
  (J = (0 : Int)) →
  (J = I) →
  (I = (0 : Int)) →
  (H = (1 : Int)) →
  (F = (1 : Int) + G) →
  (E = (1 : Int)) →
  (C ≥ (1 : Int)) →
  (F ≥ (1 : Int)) →
  (¬C = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 C G E) →
  (r2 D E A) →
  (H = (0 : Int)) →
  (¬F = (0 : Int)) →
  (F = (1 : Int) + G) →
  (F = B) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (C = H) →
  (¬H ≥ (1 : Int)) →
  (¬A = (1 : Int) + B) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 C J G E L H) →
  (r3 D G A F H B) →
  (¬E = (0 : Int)) →
  (E = (1 : Int) + F) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (C = E) →
  (K = (1 : Int) + L) →
  (¬I = (0 : Int)) →
  (I = (1 : Int) + J) →
  (I = K) →
  (¬E ≥ (1 : Int)) →
  (¬A = B) →
  r1) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 C G E) →
  (r2 D E A) →
  (H = (0 : Int)) →
  (¬F = (0 : Int)) →
  (F = (1 : Int) + G) →
  (F = B) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (C = H) →
  (¬B = (0 : Int)) →
  (¬A = (1 : Int) + B) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 C J G E L H) →
  (r3 D G A F H B) →
  (¬E = (0 : Int)) →
  (E = (1 : Int) + F) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (C = E) →
  (¬K = (0 : Int)) →
  (K = (1 : Int) + L) →
  (¬I = (0 : Int)) →
  (I = (1 : Int) + J) →
  (I = K) →
  (¬A = B) →
  r1) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 C G E I J B) →
  (r2 D E A) →
  (C = (1 : Int) + D) →
  (C = H) →
  (¬A = B) →
  (K = (0 : Int)) →
  (J = (1 : Int)) →
  (H = (1 : Int) + I) →
  (¬F = (0 : Int)) →
  (F = (1 : Int) + G) →
  (F = K) →
  (H ≥ (1 : Int)) →
  (¬C = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 C G E) →
  (r2 D E A) →
  (H = (0 : Int)) →
  (F = (1 : Int) + G) →
  (F = B) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (C = H) →
  (¬H ≥ (1 : Int)) →
  (¬C ≥ (1 : Int)) →
  (¬A = (1 : Int) + B) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 C J G E L H) →
  (r3 D G A F H B) →
  (¬E = (0 : Int)) →
  (E = (1 : Int) + F) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (C = E) →
  (K = (1 : Int) + L) →
  (I = (1 : Int) + J) →
  (I = K) →
  (¬E ≥ (1 : Int)) →
  (¬C ≥ (1 : Int)) →
  (¬A = B) →
  r1) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 C G E) →
  (r2 D E A) →
  (H = (0 : Int)) →
  (F = (1 : Int) + G) →
  (F = B) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (C = H) →
  (¬B = (0 : Int)) →
  (¬C ≥ (1 : Int)) →
  (¬A = (1 : Int) + B) →
  r1) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 C J G E L H) →
  (r3 D G A F H B) →
  (¬E = (0 : Int)) →
  (E = (1 : Int) + F) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (C = E) →
  (¬K = (0 : Int)) →
  (K = (1 : Int) + L) →
  (I = (1 : Int) + J) →
  (I = K) →
  (¬C ≥ (1 : Int)) →
  (¬A = B) →
  r1) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 C G E I J B) →
  (r2 D E A) →
  (C = (1 : Int) + D) →
  (C = H) →
  (¬A = B) →
  (K = (0 : Int)) →
  (J = (1 : Int)) →
  (H = (1 : Int) + I) →
  (F = (1 : Int) + G) →
  (F = K) →
  (¬C ≥ (1 : Int)) →
  (H ≥ (1 : Int)) →
  (¬C = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D E F G : Int),
  (r0 D E B) →
  (G = C) →
  (F = (0 : Int)) →
  (E = (1 : Int)) →
  (C = (1 : Int) + D) →
  (¬A = (-1 : Int) + B) →
  (A = F) →
  (C ≥ (1 : Int)) →
  (G = (0 : Int)) →
  r1) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 C G E) →
  (r0 D E B) →
  (A = F) →
  (H = (0 : Int)) →
  (H = C) →
  (¬F = (0 : Int)) →
  (F = (1 : Int) + G) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (¬A = (-1 : Int) + B) →
  r1) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 C G E) →
  (r0 D E B) →
  (A = F) →
  (H = (0 : Int)) →
  (H = C) →
  (F = (1 : Int) + G) →
  (¬C = (0 : Int)) →
  (C = (1 : Int) + D) →
  (¬C ≥ (1 : Int)) →
  (¬A = (-1 : Int) + B) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  False)))))))))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«001-horn_000»
