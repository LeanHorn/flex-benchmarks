import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«018b-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":349:1-349:12 (check-sat, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":10:1-26:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":27:1-45:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":46:1-63:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":64:1-81:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":82:1-98:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":99:1-117:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":118:1-135:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":136:1-153:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":154:1-170:2 (clause 9, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":171:1-189:2 (clause 10, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":190:1-207:2 (clause 11, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":208:1-217:2 (clause 12, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":218:1-234:2 (clause 13, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":235:1-253:2 (clause 14, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":254:1-271:2 (clause 15, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":272:1-289:2 (clause 16, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":290:1-301:2 (clause 17, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":302:1-313:2 (clause 18, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":314:1-325:2 (clause 19, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":326:1-337:2 (clause 20, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/018b-horn_000.smt2":338:1-347:2 (clause 21, command 27)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J : Int),
  (r3 A B C D I J G H) →
  (I = (-1 : Int) + E) →
  (G = H) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (¬A ≥ B) →
  (H ≤ (0 : Int)) →
  (¬G ≤ (0 : Int)) →
  (J = (-2 : Int) + F) →
  r3 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 A I J D K L G H) →
  (K = (-1 : Int) + E) →
  (J = (-2 : Int) + C) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (D + (-1 : Int) * K ≥ (1 : Int)) →
  (A ≥ I) →
  (H ≤ (0 : Int)) →
  (¬G ≤ (0 : Int)) →
  (L = (-2 : Int) + F) →
  r3 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  let a!1 := ¬D + (-1 : Int) * E ≥ (1 : Int);
  r3 A I J D E F G H →
    I = (-1 : Int) + B →
      G = H →
        ¬D + (-1 : Int) * E ≥ (1 : Int) → A ≥ I → H ≤ (0 : Int) → ¬G ≤ (0 : Int) → J = (-2 : Int) + C → r3 A B C D E F G H) ∧
  ((∀ (A B C D E F G v_7 : Int),
  (E = (1 : Int)) →
  (D = (1 : Int)) →
  (C = (0 : Int)) →
  (B = (1 : Int)) →
  (A = G) →
  (G ≤ (0 : Int)) →
  (¬A ≤ (0 : Int)) →
  (F = (2 : Int)) →
  (v_7 = A) →
  r3 A B C D E F v_7 G) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r4 A B C D I J G H) →
  (I = (-1 : Int) + E) →
  (G = H) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (¬A ≥ B) →
  (¬H ≤ (0 : Int)) →
  (¬G ≤ (0 : Int)) →
  (J = (-2 : Int) + F) →
  r4 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r4 A I J D K L G H) →
  (K = (-1 : Int) + E) →
  (J = (-2 : Int) + C) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (D + (-1 : Int) * K ≥ (1 : Int)) →
  (A ≥ I) →
  (¬H ≤ (0 : Int)) →
  (¬G ≤ (0 : Int)) →
  (L = (-2 : Int) + F) →
  r4 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  let a!1 := ¬D + (-1 : Int) * E ≥ (1 : Int);
  r4 A I J D E F G H →
    I = (-1 : Int) + B →
      G = H →
        ¬D + (-1 : Int) * E ≥ (1 : Int) →
          A ≥ I → ¬H ≤ (0 : Int) → ¬G ≤ (0 : Int) → J = (-2 : Int) + C → r4 A B C D E F G H) ∧
  ((∀ (A B C D E F v_6 v_7 : Int),
  (E = (1 : Int)) →
  (C = (0 : Int)) →
  (B = (1 : Int)) →
  (A = D) →
  (¬D ≤ (0 : Int)) →
  (¬A ≤ (0 : Int)) →
  (F = (2 : Int)) →
  (v_6 = A) →
  (v_7 = D) →
  r4 A B C D E F v_6 v_7) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r1 A B C D I J G H) →
  (I = (-1 : Int) + E) →
  (G = H) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (¬A ≥ B) →
  (H ≤ (0 : Int)) →
  (G ≤ (0 : Int)) →
  (J = (-2 : Int) + F) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r1 A I J D K L G H) →
  (K = (-1 : Int) + E) →
  (J = (-2 : Int) + C) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (D + (-1 : Int) * K ≥ (1 : Int)) →
  (A ≥ I) →
  (H ≤ (0 : Int)) →
  (G ≤ (0 : Int)) →
  (L = (-2 : Int) + F) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  let a!1 := ¬D + (-1 : Int) * E ≥ (1 : Int);
  r1 A I J D E F G H →
    I = (-1 : Int) + B →
      G = H →
        ¬D + (-1 : Int) * E ≥ (1 : Int) → A ≥ I → H ≤ (0 : Int) → G ≤ (0 : Int) → J = (-2 : Int) + C → r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H : Int),
  (F = (2 : Int)) →
  (E = (1 : Int)) →
  (D = (1 : Int)) →
  (C = (0 : Int)) →
  (B = (1 : Int)) →
  (A = (1 : Int)) →
  (H ≤ (0 : Int)) →
  (G ≤ (0 : Int)) →
  (G = H) →
  r1 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 A B C D I J G H) →
  (I = (-1 : Int) + E) →
  (G = H) →
  (D + (-1 : Int) * I ≥ (1 : Int)) →
  (¬A ≥ B) →
  (¬H ≤ (0 : Int)) →
  (G ≤ (0 : Int)) →
  (J = (-2 : Int) + F) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 A I J D K L G H) →
  (K = (-1 : Int) + E) →
  (J = (-2 : Int) + C) →
  (I = (-1 : Int) + B) →
  (G = H) →
  (D + (-1 : Int) * K ≥ (1 : Int)) →
  (A ≥ I) →
  (¬H ≤ (0 : Int)) →
  (G ≤ (0 : Int)) →
  (L = (-2 : Int) + F) →
  r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G H I J : Int),
  let a!1 := ¬D + (-1 : Int) * E ≥ (1 : Int);
  r0 A I J D E F G H →
    I = (-1 : Int) + B →
      G = H →
        ¬D + (-1 : Int) * E ≥ (1 : Int) → A ≥ I → ¬H ≤ (0 : Int) → G ≤ (0 : Int) → J = (-2 : Int) + C → r0 A B C D E F G H) ∧
  ((∀ (A B C D E F G v_7 : Int),
  (F = (2 : Int)) →
  (E = (1 : Int)) →
  (C = (0 : Int)) →
  (B = (1 : Int)) →
  (A = (1 : Int)) →
  (G ≤ (0 : Int)) →
  (¬D ≤ (0 : Int)) →
  (G = D) →
  (v_7 = D) →
  r0 A B C D E F G v_7) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬E + (-1 : Int) * F ≥ (1 : Int);
  r3 C D A E F B G H → ¬A = B → ¬E + (-1 : Int) * F ≥ (1 : Int) → ¬C ≥ D → H ≤ (0 : Int) → ¬G ≤ (0 : Int) → G = H → r2) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬E + (-1 : Int) * F ≥ (1 : Int);
  r4 C D A E F B G H → ¬A = B → ¬E + (-1 : Int) * F ≥ (1 : Int) → ¬C ≥ D → ¬H ≤ (0 : Int) → ¬G ≤ (0 : Int) → G = H → r2) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬E + (-1 : Int) * F ≥ (1 : Int);
  r1 C D A E F B G H → ¬A = B → ¬E + (-1 : Int) * F ≥ (1 : Int) → ¬C ≥ D → H ≤ (0 : Int) → G ≤ (0 : Int) → G = H → r2) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ¬E + (-1 : Int) * F ≥ (1 : Int);
  r0 C D A E F B G H → ¬A = B → ¬E + (-1 : Int) * F ≥ (1 : Int) → ¬C ≥ D → ¬H ≤ (0 : Int) → G ≤ (0 : Int) → G = H → r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  False))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«018b-horn_000»
