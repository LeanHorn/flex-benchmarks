import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«015-horn_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":216:1-216:12 (check-sat, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":9:1-19:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":20:1-30:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":31:1-40:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":41:1-56:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":57:1-73:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":74:1-84:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":85:1-94:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":95:1-105:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":106:1-115:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":116:1-126:2 (clause 10, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":127:1-137:2 (clause 11, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":138:1-148:2 (clause 12, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":149:1-165:2 (clause 13, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":166:1-182:2 (clause 14, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":183:1-193:2 (clause 15, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":194:1-204:2 (clause 16, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/LIA/reve/015-horn_000.smt2":205:1-214:2 (clause 17, command 22)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Prop),
  (∀ (A B C D v_4 : Int),
  (r3 D C) →
  (¬C ≥ (0 : Int)) →
  (¬B ≤ (1 : Int)) →
  (A ≤ (1 : Int)) →
  (B = (1 : Int) + D) →
  (v_4 = A) →
  r1 A v_4 B C) ∧
  ((∀ (A B C D E v_5 : Int),
  (r3 E D) →
  (B = (1 : Int) + E) →
  (D ≥ (0 : Int)) →
  (A ≤ (1 : Int)) →
  (¬B ≤ (1 : Int)) →
  (B + D = C) →
  (v_5 = A) →
  r1 A v_5 B C) ∧
  ((∀ (A B v_2 v_3 : Int),
  (A ≤ (1 : Int)) →
  (B ≤ (1 : Int)) →
  (v_2 = A) →
  (v_3 = B) →
  r1 A v_2 B v_3) ∧
  ((∀ (A B C D E F G : Int),
  (r1 F E G D) →
  (A = (1 : Int) + F) →
  (C = (1 : Int) + G) →
  (¬D ≥ (0 : Int)) →
  (¬A ≤ (1 : Int)) →
  (¬C ≤ (1 : Int)) →
  (A + E = B) →
  r1 A B C D) ∧
  ((∀ (A B C D E F G H : Int),
  (r1 G E H F) →
  (C + F = D) →
  (A = (1 : Int) + G) →
  (C = (1 : Int) + H) →
  (F ≥ (0 : Int)) →
  (¬A ≤ (1 : Int)) →
  (¬C ≤ (1 : Int)) →
  (A + E = B) →
  r1 A B C D) ∧
  ((∀ (A B C D E v_5 : Int),
  (r0 E D) →
  (A = (1 : Int) + E) →
  (¬A ≤ (1 : Int)) →
  (C ≤ (1 : Int)) →
  (A + D = B) →
  (v_5 = C) →
  r1 A B C v_5) ∧
  ((∀ (A v_1 : Int),
  (A ≤ (1 : Int)) →
  (v_1 = A) →
  r0 A v_1) ∧
  ((∀ (A B C D : Int),
  (r0 D C) →
  (A = (1 : Int) + D) →
  (¬A ≤ (1 : Int)) →
  (A + C = B) →
  r0 A B) ∧
  ((∀ (A v_1 : Int),
  (A ≤ (1 : Int)) →
  (v_1 = A) →
  r3 A v_1) ∧
  ((∀ (A B C D : Int),
  (r3 D C) →
  (A = (1 : Int) + D) →
  (C ≥ (0 : Int)) →
  (¬A ≤ (1 : Int)) →
  (A + C = B) →
  r3 A B) ∧
  ((∀ (A B C : Int),
  (r3 C B) →
  (¬B ≥ (0 : Int)) →
  (¬A ≤ (1 : Int)) →
  (A = (1 : Int) + C) →
  r3 A B) ∧
  ((∀ (A B C D : Int),
  (r0 D B) →
  (A = (1 : Int) + D) →
  (A = C) →
  (C ≤ (1 : Int)) →
  (¬A ≤ (1 : Int)) →
  (¬A + B = C) →
  r2) ∧
  ((∀ (A B C D E F : Int),
  (r1 E B F D) →
  (A = (1 : Int) + E) →
  (A = C) →
  (C = (1 : Int) + F) →
  (D ≥ (0 : Int)) →
  (¬A ≤ (1 : Int)) →
  (¬C ≤ (1 : Int)) →
  (¬A + B = C + D) →
  r2) ∧
  ((∀ (A B C D E F : Int),
  (r1 D B F C) →
  (A = (1 : Int) + D) →
  (A = E) →
  (E = (1 : Int) + F) →
  (¬C ≥ (0 : Int)) →
  (¬A ≤ (1 : Int)) →
  (¬E ≤ (1 : Int)) →
  (¬A + B = C) →
  r2) ∧
  ((∀ (A B C D : Int),
  (r3 D C) →
  (¬A = B + C) →
  (A = B) →
  (C ≥ (0 : Int)) →
  (¬B ≤ (1 : Int)) →
  (A ≤ (1 : Int)) →
  (B = (1 : Int) + D) →
  r2) ∧
  ((∀ (A B C D : Int),
  (r3 D B) →
  (A = C) →
  (¬A = B) →
  (¬B ≥ (0 : Int)) →
  (¬C ≤ (1 : Int)) →
  (A ≤ (1 : Int)) →
  (C = (1 : Int) + D) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  False))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«LIA».«reve».«015-horn_000»
