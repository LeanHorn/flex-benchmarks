import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«BV».«qarmc».«qrsolv_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":6434:1-6434:12 (check-sat, command 175)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":82:1-141:2 (clause 1, command 79)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":142:1-218:2 (clause 2, command 80)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":219:1-229:2 (clause 3, command 81)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":230:1-240:2 (clause 4, command 82)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":241:1-251:2 (clause 5, command 83)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":252:1-295:2 (clause 6, command 84)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":296:1-306:2 (clause 7, command 85)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":307:1-317:2 (clause 8, command 86)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":318:1-361:2 (clause 9, command 87)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":362:1-405:2 (clause 10, command 88)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":406:1-482:2 (clause 11, command 89)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":483:1-559:2 (clause 12, command 90)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":560:1-636:2 (clause 13, command 91)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":637:1-713:2 (clause 14, command 92)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":714:1-790:2 (clause 15, command 93)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":791:1-867:2 (clause 16, command 94)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":868:1-944:2 (clause 17, command 95)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":945:1-1021:2 (clause 18, command 96)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":1022:1-1098:2 (clause 19, command 97)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":1099:1-1175:2 (clause 20, command 98)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":1176:1-1252:2 (clause 21, command 99)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":1253:1-1329:2 (clause 22, command 100)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":1330:1-1406:2 (clause 23, command 101)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":1407:1-1483:2 (clause 24, command 102)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":1484:1-1560:2 (clause 25, command 103)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":1561:1-1637:2 (clause 26, command 104)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":1638:1-1714:2 (clause 27, command 105)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":1715:1-1791:2 (clause 28, command 106)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":1792:1-1868:2 (clause 29, command 107)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":1869:1-1945:2 (clause 30, command 108)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":1946:1-2022:2 (clause 31, command 109)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":2023:1-2099:2 (clause 32, command 110)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":2100:1-2176:2 (clause 33, command 111)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":2177:1-2253:2 (clause 34, command 112)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":2254:1-2330:2 (clause 35, command 113)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":2331:1-2407:2 (clause 36, command 114)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":2408:1-2484:2 (clause 37, command 115)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":2485:1-2561:2 (clause 38, command 116)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":2562:1-2638:2 (clause 39, command 117)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":2639:1-2715:2 (clause 40, command 118)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":2716:1-2792:2 (clause 41, command 119)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":2793:1-2869:2 (clause 42, command 120)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":2870:1-2946:2 (clause 43, command 121)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":2947:1-3023:2 (clause 44, command 122)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":3024:1-3100:2 (clause 45, command 123)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":3101:1-3177:2 (clause 46, command 124)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":3178:1-3254:2 (clause 47, command 125)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":3255:1-3331:2 (clause 48, command 126)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":3332:1-3408:2 (clause 49, command 127)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":3409:1-3485:2 (clause 50, command 128)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":3486:1-3562:2 (clause 51, command 129)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":3563:1-3639:2 (clause 52, command 130)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":3640:1-3716:2 (clause 53, command 131)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":3717:1-3793:2 (clause 54, command 132)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":3794:1-3870:2 (clause 55, command 133)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":3871:1-3947:2 (clause 56, command 134)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":3948:1-4024:2 (clause 57, command 135)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":4025:1-4101:2 (clause 58, command 136)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":4102:1-4178:2 (clause 59, command 137)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":4179:1-4255:2 (clause 60, command 138)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":4256:1-4332:2 (clause 61, command 139)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":4333:1-4409:2 (clause 62, command 140)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":4410:1-4486:2 (clause 63, command 141)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":4487:1-4563:2 (clause 64, command 142)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":4564:1-4640:2 (clause 65, command 143)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":4641:1-4717:2 (clause 66, command 144)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":4718:1-4794:2 (clause 67, command 145)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":4795:1-4871:2 (clause 68, command 146)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":4872:1-4948:2 (clause 69, command 147)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":4949:1-5025:2 (clause 70, command 148)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5026:1-5102:2 (clause 71, command 149)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5103:1-5179:2 (clause 72, command 150)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5180:1-5256:2 (clause 73, command 151)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5257:1-5333:2 (clause 74, command 152)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5334:1-5410:2 (clause 75, command 153)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5411:1-5487:2 (clause 76, command 154)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5488:1-5564:2 (clause 77, command 155)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5565:1-5641:2 (clause 78, command 156)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5642:1-5718:2 (clause 79, command 157)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5719:1-5762:2 (clause 80, command 158)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5763:1-5806:2 (clause 81, command 159)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5807:1-5850:2 (clause 82, command 160)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5851:1-5894:2 (clause 83, command 161)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5895:1-5938:2 (clause 84, command 162)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5939:1-5982:2 (clause 85, command 163)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":5983:1-6026:2 (clause 86, command 164)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":6027:1-6070:2 (clause 87, command 165)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":6071:1-6114:2 (clause 88, command 166)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":6115:1-6158:2 (clause 89, command 167)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":6159:1-6202:2 (clause 90, command 168)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":6203:1-6246:2 (clause 91, command 169)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":6247:1-6290:2 (clause 92, command 170)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":6291:1-6334:2 (clause 93, command 171)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":6335:1-6378:2 (clause 94, command 172)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":6379:1-6422:2 (clause 95, command 173)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/qrsolv_000.smt2":6423:1-6432:2 (clause 96, command 174)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r28 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r29 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r30 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r31 : Prop),
  ∃ (r32 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r33 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r34 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r35 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r36 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r37 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r38 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r39 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r40 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r41 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r42 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r43 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r44 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r45 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r46 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r47 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r48 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r49 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r50 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r51 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r52 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r53 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r54 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r55 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r56 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r57 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r58 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r59 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r60 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r61 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r62 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r63 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r64 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r65 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r66 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r67 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r68 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r69 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r70 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r71 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r72 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r73 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r74 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r75 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r76 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int →
                                    Int →
                                      Int →
                                        Int →
                                          Int →
                                            Int →
                                              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (((((((∀ (A B C D E F G H I J K L M N O P Q v_17 v_18 v_19 v_20 v_21 v_22 v_23 v_24 v_25 v_26 v_27 v_28 v_29 v_30 v_31 v_32 v_33 : Int),
  (True) →
  (v_17 = A) →
  (v_18 = B) →
  (v_19 = C) →
  (v_20 = D) →
  (v_21 = E) →
  (v_22 = F) →
  (v_23 = G) →
  (v_24 = H) →
  (v_25 = I) →
  (v_26 = J) →
  (v_27 = K) →
  (v_28 = L) →
  (v_29 = M) →
  (v_30 = N) →
  (v_31 = O) →
  (v_32 = P) →
  (v_33 = Q) →
  r49 A B C D E F G H I J K L M N O P Q v_17 v_18 v_19 v_20 v_21 v_22 v_23 v_24 v_25 v_26 v_27 v_28 v_29 v_30 v_31 v_32
    v_33) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 : Int),
  (r49 A C E G I K M O Q S U W Y A1 C1 E1 G1 I1 J1 K1 L1 M1 N1 R P1 Q1 T V X Z B1 D1 F1 H1) →
  (L = P) →
  (J = (1 : Int)) →
  (H = P) →
  (F = (1 : Int)) →
  (D = P) →
  (B = (1 : Int)) →
  (O1 = (1 : Int)) →
  (J1 = P) →
  (N = (1 : Int)) →
  r8 A C E G I K M O Q S U W Y A1 C1 E1 G1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r8 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r11 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r11 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r35 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r35 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r40 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r23 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r40 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r40 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r37 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r37 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (A1 + (-1 : Int) * F1 ≥ (1 : Int)) →
  r50 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 : Int),
  (r50 A C E G I K M O Q S U V W X Y Z A1 B1 C1 D1 E1 F1 R H1 T J1 B D F H J L N P) →
  (H1 = G1) →
  (I1 = (0 : Int)) →
  r47 A C E G I K M O Q S U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r47 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r64 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r64 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r12 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r12 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r71 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r56 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r71 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r71 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r58 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r58 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (A1 + (-1 : Int) * E1 ≥ (0 : Int)) →
  r62 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r62 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r25 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P))))) ∧
  (((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r58 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (A1 + (-1 : Int) * E1 ≤ (-1 : Int)) →
  r48 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r48 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r39 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r39 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r14 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r25 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * J ≥ (0 : Int)) →
  r22 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r22 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r27 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r25 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * J ≤ (-1 : Int)) →
  r16 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r27 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * L ≤ (0 : Int)) →
  r63 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r63 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r54 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r27 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * L ≥ (1 : Int)) →
  r41 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r54 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * B ≥ (0 : Int)) →
  r0 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r0 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r42 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r54 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * B ≤ (-1 : Int)) →
  r13 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r42 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * D ≤ (0 : Int)) →
  r34 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r34 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r75 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r42 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * D ≥ (1 : Int)) →
  r29 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r75 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (F1 + (-1 : Int) * F ≥ (0 : Int)) →
  r36 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)))))) ∧
  ((((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r36 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r45 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r75 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (F1 + (-1 : Int) * F ≤ (-1 : Int)) →
  r15 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r45 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (F1 + (-1 : Int) * H ≤ (0 : Int)) →
  r19 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 : Int),
  (r19 A C E G I K M O Q S U V W X Y Z A1 B1 C1 D1 E1 F1 R H1 T J1 B D F H J L N P) →
  (R = (-1 : Int) + G1) →
  r56 A C E G I K M O Q S U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 B D F H J L N P))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r45 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (F1 + (-1 : Int) * H ≥ (1 : Int)) →
  r44 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r14 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r20 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r20 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (F1 + (-1 : Int) * N ≥ (0 : Int)) →
  r60 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r60 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r21 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r20 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (F1 + (-1 : Int) * N ≤ (-1 : Int)) →
  r70 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r21 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (F1 + (-1 : Int) * P ≤ (0 : Int)) →
  r66 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 : Int),
  (r66 A C E G I K M O Q R T V W X Y Z A1 B1 C1 D1 E1 F1 S H1 I1 U B D F H J L N P) →
  (H1 = G1) →
  r28 A C E G I K M O Q R T V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r21 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (F1 + (-1 : Int) * P ≥ (1 : Int)) →
  r61 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r28 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r9 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r9 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r30 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r30 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r55 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r68 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r55 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P))))) ∧
  (((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r55 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r18 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r18 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (A1 + (-1 : Int) * E1 ≥ (0 : Int)) →
  r67 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r67 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r1 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r18 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (A1 + (-1 : Int) * E1 ≤ (-1 : Int)) →
  r76 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r76 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r33 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r33 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r59 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r1 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * B ≥ (0 : Int)) →
  r3 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r3 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r6 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r1 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * B ≤ (-1 : Int)) →
  r7 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r6 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * D ≤ (0 : Int)) →
  r57 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r57 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r73 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r6 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * D ≥ (1 : Int)) →
  r74 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r73 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (F1 + (-1 : Int) * F ≥ (0 : Int)) →
  r65 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r65 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r51 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r73 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (F1 + (-1 : Int) * F ≤ (-1 : Int)) →
  r4 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r51 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (F1 + (-1 : Int) * H ≤ (0 : Int)) →
  r5 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P))))))) ∧
  ((((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r5 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r17 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r51 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (F1 + (-1 : Int) * H ≥ (1 : Int)) →
  r2 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r17 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * J ≥ (0 : Int)) →
  r43 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r43 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r46 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r17 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * J ≤ (-1 : Int)) →
  r32 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r46 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * L ≤ (0 : Int)) →
  r24 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r24 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r53 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r46 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * L ≥ (1 : Int)) →
  r72 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r53 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * J ≥ (0 : Int)) →
  r69 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r69 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r10 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r53 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * J ≤ (-1 : Int)) →
  r26 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r10 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * L ≤ (0 : Int)) →
  r52 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 : Int),
  (r52 A C E G I K M O Q S T U V W X Y Z A1 B1 C1 D1 E1 R G1 H1 I1 B D F H J L N P) →
  (R = (-1 : Int) + F1) →
  r68 A C E G I K M O Q S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r10 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (E1 + (-1 : Int) * L ≥ (1 : Int)) →
  r38 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 : Int),
  (r59 A C E G I K M O Q S T U V W X Y Z A1 B1 C1 D1 E1 F1 R H1 I1 B D F H J L N P) →
  (R = (-1 : Int) + G1) →
  r23 A C E G I K M O Q S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 B D F H J L N P) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r16 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31))))) ∧
  (((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r41 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r13 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r29 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r15 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r44 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r70 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r61 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r7 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r74 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r4 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r2 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r32 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r72 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r26 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r38 A C E G I K M O Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 B D F H J L N P) →
  (True) →
  r31) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r31) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«BV».«qarmc».«qrsolv_000»
