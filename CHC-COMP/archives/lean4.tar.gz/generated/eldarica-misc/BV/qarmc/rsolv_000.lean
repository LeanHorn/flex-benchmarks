import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«eldarica-misc».«BV».«qarmc».«rsolv_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1180:1-1180:12 (check-sat, command 174)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":81:1-134:2 (clause 1, command 78)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":135:1-145:2 (clause 2, command 79)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":146:1-156:2 (clause 3, command 80)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":157:1-167:2 (clause 4, command 81)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":168:1-178:2 (clause 5, command 82)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":179:1-189:2 (clause 6, command 83)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":190:1-200:2 (clause 7, command 84)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":201:1-211:2 (clause 8, command 85)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":212:1-222:2 (clause 9, command 86)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":223:1-233:2 (clause 10, command 87)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":234:1-244:2 (clause 11, command 88)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":245:1-255:2 (clause 12, command 89)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":256:1-266:2 (clause 13, command 90)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":267:1-277:2 (clause 14, command 91)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":278:1-288:2 (clause 15, command 92)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":289:1-299:2 (clause 16, command 93)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":300:1-310:2 (clause 17, command 94)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":311:1-321:2 (clause 18, command 95)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":322:1-332:2 (clause 19, command 96)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":333:1-343:2 (clause 20, command 97)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":344:1-354:2 (clause 21, command 98)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":355:1-365:2 (clause 22, command 99)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":366:1-376:2 (clause 23, command 100)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":377:1-387:2 (clause 24, command 101)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":388:1-398:2 (clause 25, command 102)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":399:1-409:2 (clause 26, command 103)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":410:1-420:2 (clause 27, command 104)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":421:1-431:2 (clause 28, command 105)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":432:1-442:2 (clause 29, command 106)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":443:1-453:2 (clause 30, command 107)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":454:1-464:2 (clause 31, command 108)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":465:1-475:2 (clause 32, command 109)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":476:1-486:2 (clause 33, command 110)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":487:1-497:2 (clause 34, command 111)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":498:1-508:2 (clause 35, command 112)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":509:1-519:2 (clause 36, command 113)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":520:1-530:2 (clause 37, command 114)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":531:1-541:2 (clause 38, command 115)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":542:1-552:2 (clause 39, command 116)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":553:1-563:2 (clause 40, command 117)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":564:1-574:2 (clause 41, command 118)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":575:1-585:2 (clause 42, command 119)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":586:1-596:2 (clause 43, command 120)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":597:1-607:2 (clause 44, command 121)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":608:1-618:2 (clause 45, command 122)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":619:1-629:2 (clause 46, command 123)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":630:1-640:2 (clause 47, command 124)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":641:1-651:2 (clause 48, command 125)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":652:1-662:2 (clause 49, command 126)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":663:1-673:2 (clause 50, command 127)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":674:1-684:2 (clause 51, command 128)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":685:1-695:2 (clause 52, command 129)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":696:1-706:2 (clause 53, command 130)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":707:1-717:2 (clause 54, command 131)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":718:1-728:2 (clause 55, command 132)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":729:1-739:2 (clause 56, command 133)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":740:1-750:2 (clause 57, command 134)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":751:1-761:2 (clause 58, command 135)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":762:1-772:2 (clause 59, command 136)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":773:1-783:2 (clause 60, command 137)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":784:1-794:2 (clause 61, command 138)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":795:1-805:2 (clause 62, command 139)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":806:1-816:2 (clause 63, command 140)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":817:1-827:2 (clause 64, command 141)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":828:1-838:2 (clause 65, command 142)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":839:1-849:2 (clause 66, command 143)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":850:1-860:2 (clause 67, command 144)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":861:1-871:2 (clause 68, command 145)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":872:1-882:2 (clause 69, command 146)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":883:1-893:2 (clause 70, command 147)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":894:1-904:2 (clause 71, command 148)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":905:1-915:2 (clause 72, command 149)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":916:1-926:2 (clause 73, command 150)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":927:1-937:2 (clause 74, command 151)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":938:1-948:2 (clause 75, command 152)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":949:1-959:2 (clause 76, command 153)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":960:1-970:2 (clause 77, command 154)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":971:1-981:2 (clause 78, command 155)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":982:1-992:2 (clause 79, command 156)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":993:1-1003:2 (clause 80, command 157)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1004:1-1014:2 (clause 81, command 158)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1015:1-1025:2 (clause 82, command 159)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1026:1-1036:2 (clause 83, command 160)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1037:1-1047:2 (clause 84, command 161)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1048:1-1058:2 (clause 85, command 162)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1059:1-1069:2 (clause 86, command 163)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1070:1-1080:2 (clause 87, command 164)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1081:1-1091:2 (clause 88, command 165)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1092:1-1102:2 (clause 89, command 166)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1103:1-1113:2 (clause 90, command 167)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1114:1-1124:2 (clause 91, command 168)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1125:1-1135:2 (clause 92, command 169)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1136:1-1146:2 (clause 93, command 170)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1147:1-1157:2 (clause 94, command 171)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1158:1-1168:2 (clause 95, command 172)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/eldarica-misc/BV/qarmc/rsolv_000.smt2":1169:1-1178:2 (clause 96, command 173)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r10 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r11 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r12 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r13 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r16 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r18 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r19 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r20 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r22 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r23 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r24 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r25 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r26 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r27 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r28 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r29 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r30 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r31 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r32 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r33 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r34 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r35 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r36 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r37 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r38 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r39 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r40 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r41 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r42 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r43 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r44 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r45 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r46 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r47 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r48 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r49 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r50 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r51 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r52 : Prop),
  ∃ (r53 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r54 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r55 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r56 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r57 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r58 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r59 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r60 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r61 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r62 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r63 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r64 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r65 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r66 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r67 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r68 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r69 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r70 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r71 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r72 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r73 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r74 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r75 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int →
                Int →
                  Int →
                    Int →
                      Int →
                        Int →
                          Int →
                            Int →
                              Int →
                                Int →
                                  Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (((((((∀ (A B C D E F G H I J K L M N O v_15 v_16 v_17 v_18 v_19 v_20 v_21 v_22 v_23 v_24 v_25 v_26 v_27 v_28 v_29 : Int),
  (True) →
  (v_15 = A) →
  (v_16 = B) →
  (v_17 = C) →
  (v_18 = D) →
  (v_19 = E) →
  (v_20 = F) →
  (v_21 = G) →
  (v_22 = H) →
  (v_23 = I) →
  (v_24 = J) →
  (v_25 = K) →
  (v_26 = L) →
  (v_27 = M) →
  (v_28 = N) →
  (v_29 = O) →
  r3 A B C D E F G H I J K L M N O v_15 v_16 v_17 v_18 v_19 v_20 v_21 v_22 v_23 v_24 v_25 v_26 v_27 v_28 v_29) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r3 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r70 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r70 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U ≥ (11 : Int)) →
  r11 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 : Int),
  (r11 A C E G I K M O Q S U W Y Z A1 B1 C1 D1 E1 F1 G1 H1 J L N P R T V X) →
  (D = H) →
  (B = (1 : Int)) →
  (L1 = H) →
  (K1 = (1 : Int)) →
  (J1 = H) →
  (I1 = (1 : Int)) →
  (C1 = H) →
  (F = (1 : Int)) →
  r75 A C E G I K M O Q S U W Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 B D F H))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r75 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r21 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r21 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * F ≥ (0 : Int)) →
  r64 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r64 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r66 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r21 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * F ≤ (-1 : Int)) →
  r0 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r66 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * H ≤ (0 : Int)) →
  r23 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r23 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r56 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r66 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * H ≥ (1 : Int)) →
  r38 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r56 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * B ≥ (0 : Int)) →
  r4 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r4 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r37 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r56 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * B ≤ (-1 : Int)) →
  r58 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r37 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * D ≤ (0 : Int)) →
  r1 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r1 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r59 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H))))) ∧
  (((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r37 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * D ≥ (1 : Int)) →
  r16 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r59 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * B ≥ (0 : Int)) →
  r25 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r25 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r43 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r59 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * B ≤ (-1 : Int)) →
  r49 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r43 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * D ≤ (0 : Int)) →
  r35 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 : Int),
  (r35 A C E G I K L M N O P Q R S T U V W X J Z A1 B1 C1 D1 E1 B D F H) →
  (V = (1 : Int) + Y) →
  r14 A C E G I K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r43 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * D ≥ (1 : Int)) →
  r65 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r14 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r15 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r15 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r9 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r9 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r45 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r68 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r45 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r45 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r67 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r67 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X ≥ (1 : Int)) →
  r24 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r24 A C E G I K M N O P Q R S T U V W X Y Z J L C1 D1 E1 F1 B D F H) →
  (Z = (-1 : Int) + A1) →
  (B1 = (0 : Int)) →
  r13 A C E G I K M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r13 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r28 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r28 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r72 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)))))) ∧
  ((((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r72 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r26 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r57 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r26 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r26 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r10 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r10 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * Y ≥ (0 : Int)) →
  r18 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r18 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r5 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r10 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (U + (-1 : Int) * Y ≤ (-1 : Int)) →
  r27 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r27 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r12 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r12 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r61 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r5 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (Y + (-1 : Int) * B ≥ (0 : Int)) →
  r63 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r63 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r71 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r5 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (Y + (-1 : Int) * B ≤ (-1 : Int)) →
  r29 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r71 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (Y + (-1 : Int) * D ≤ (0 : Int)) →
  r40 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r40 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r50 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r71 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (Y + (-1 : Int) * D ≥ (1 : Int)) →
  r42 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r50 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * A1 ≥ (0 : Int)) →
  r39 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r39 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r60 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H))))) ∧
  (((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r50 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * A1 ≤ (-1 : Int)) →
  r48 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r60 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * B1 ≤ (0 : Int)) →
  r73 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r73 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r41 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r60 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * B1 ≥ (1 : Int)) →
  r55 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r41 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (Y + (-1 : Int) * C1 ≥ (0 : Int)) →
  r17 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r17 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r74 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r41 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (Y + (-1 : Int) * C1 ≤ (-1 : Int)) →
  r30 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r74 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (Y + (-1 : Int) * D1 ≤ (0 : Int)) →
  r62 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 : Int),
  (r62 A C E G I K M N O P Q R S T U V W X Y Z J L C1 D1 E1 F1 B D F H) →
  (J = (-1 : Int) + A1) →
  r57 A C E G I K M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r74 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (Y + (-1 : Int) * D1 ≥ (1 : Int)) →
  r32 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r61 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r51 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r51 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * F ≥ (0 : Int)) →
  r19 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r19 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r44 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r51 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * F ≤ (-1 : Int)) →
  r69 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r44 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * H ≤ (0 : Int)) →
  r22 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r22 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r46 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H))))))) ∧
  ((((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r44 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * H ≥ (1 : Int)) →
  r20 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r46 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * B ≥ (0 : Int)) →
  r31 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r31 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r33 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r46 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * B ≤ (-1 : Int)) →
  r34 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r33 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * D ≤ (0 : Int)) →
  r54 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r54 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r2 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r33 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * D ≥ (1 : Int)) →
  r36 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r2 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * B ≥ (0 : Int)) →
  r7 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r7 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r6 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r2 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * B ≤ (-1 : Int)) →
  r47 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r6 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * D ≤ (0 : Int)) →
  r8 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 : Int),
  (r8 A C E G I K L M N O P Q R S T U V W X J Z A1 B1 C1 D1 E1 B D F H) →
  (J = (1 : Int) + Y) →
  r68 A C E G I K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 B D F H))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r6 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (X + (-1 : Int) * D ≥ (1 : Int)) →
  r53 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r0 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r38 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r58 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52))))) ∧
  (((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r16 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r49 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r65 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r29 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r42 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r48 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r55 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r30 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52)))) ∧
  ((((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r32 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r69 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r20 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r34 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52))) ∧
  (((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r36 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52) ∧
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r47 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52)) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 : Int),
  (r53 A C E G I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 B D F H) →
  (True) →
  r52) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r52) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«eldarica-misc».«BV».«qarmc».«rsolv_000»
