import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«bcopy2_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":271:1-271:12 (check-sat, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":16:1-29:2 (clause 1, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":30:1-40:2 (clause 2, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":41:1-55:2 (clause 3, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":56:1-72:2 (clause 4, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":73:1-86:2 (clause 5, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":87:1-99:2 (clause 6, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":100:1-114:2 (clause 7, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":115:1-131:2 (clause 8, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":132:1-145:2 (clause 9, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":146:1-158:2 (clause 10, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":159:1-173:2 (clause 11, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":174:1-185:2 (clause 12, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":186:1-201:2 (clause 13, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":202:1-217:2 (clause 14, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":218:1-234:2 (clause 15, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":235:1-246:2 (clause 16, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":247:1-257:2 (clause 17, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy2_000.smt2":258:1-269:2 (clause 18, command 30)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Prop),
  ∃ (r8 : Int → Int → Prop),
  ∃ (r9 : Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Prop),
  (∀ (A B C D E F G : Int),
  (r8 A C) →
  (r2 F E C B) →
  (r9 B C) →
  (r4 E B C) →
  ((0 : Int) = G) →
  (D = (1 : Int) + B) →
  (¬((0 : Int) = G) = (B ≥ C)) →
  r8 A C) ∧
  ((∀ (A B C : Int),
  (r9 A B) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (A ≥ B)) →
  r8 A B) ∧
  ((∀ (A B C D E F G H : Int),
  (r8 B D) →
  (r2 G F D C) →
  (r9 C D) →
  (r4 F C D) →
  (r4 A B D) →
  ((0 : Int) = H) →
  (E = (1 : Int) + C) →
  (¬((0 : Int) = H) = (C ≥ D)) →
  r4 A B D) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  r8 H B →
    r3 A H B →
      ((0 : Int) = E) = (B ≤ (0 : Int)) → ¬((0 : Int) = D) = (B ≤ C) → ¬(0 : Int) = F → G = (0 : Int) → ¬a!1 → r4 A H B) ∧
  ((∀ (A B C D E F G : Int),
  (r4 E B C) →
  (r2 F E C B) →
  (r9 B C) →
  (r7 A C) →
  ((0 : Int) = G) →
  (D = (1 : Int) + B) →
  (¬((0 : Int) = G) = (B ≥ C)) →
  r7 A C) ∧
  ((∀ (A B C D E : Int),
  (r4 D B C) →
  (r1 A C B) →
  (r9 B C) →
  ((0 : Int) = E) →
  (¬((0 : Int) = E) = (B ≥ C)) →
  r7 A C) ∧
  ((∀ (A B C D E F G H : Int),
  (r4 F C D) →
  (r2 G F D C) →
  (r9 C D) →
  (r5 A B D) →
  (r7 B D) →
  ((0 : Int) = H) →
  (E = (1 : Int) + C) →
  (¬((0 : Int) = H) = (C ≥ D)) →
  r5 A B D) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  r7 H B →
    r3 A H C →
      ((0 : Int) = E) = (B ≤ (0 : Int)) → ¬((0 : Int) = D) = (B ≤ C) → ¬(0 : Int) = F → G = (0 : Int) → ¬a!1 → r5 A H B) ∧
  ((∀ (A B C D E F : Int),
  (r4 E C D) →
  (r1 B D C) →
  (r9 C D) →
  (r5 A B D) →
  ((0 : Int) = F) →
  (¬((0 : Int) = F) = (C ≥ D)) →
  r6 A B D C) ∧
  ((∀ (A B C D E F : Int),
  (r4 D A B) →
  (r2 E D B A) →
  (r9 A B) →
  ((0 : Int) = F) →
  (C = (1 : Int) + A) →
  (¬((0 : Int) = F) = (A ≥ B)) →
  r9 C B) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  ((0 : Int) = D) = (A ≤ (0 : Int)) → ¬((0 : Int) = C) = (A ≤ B) → ¬(0 : Int) = E → F = (0 : Int) → ¬a!1 → r9 F A) ∧
  ((∀ (A B C D : Int),
  (r4 C A B) →
  (r9 A B) →
  ((0 : Int) = D) →
  (¬((0 : Int) = D) = (A ≥ B)) →
  r10 C B A) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  r8 A B → ((0 : Int) = E) = (B ≤ (0 : Int)) → ¬((0 : Int) = D) = (B ≤ C) → ¬(0 : Int) = F → G = (0 : Int) → ¬a!1 → r0 A B) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  r7 A B → ((0 : Int) = E) = (B ≤ (0 : Int)) → ¬((0 : Int) = D) = (B ≤ C) → ¬(0 : Int) = F → G = (0 : Int) → ¬a!1 → r0 A C) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r0 C B →
    ((0 : Int) = F) = (B ≤ C) →
      ¬((0 : Int) = E) = ((0 : Int) ≤ C) → ¬(0 : Int) = G → D = (1 : Int) → A = (0 : Int) → ¬a!1 → r3 A C B) ∧
  ((∀ (A B C D E v_5 : Int),
  (r6 E B C v_5) →
  (r10 D C B) →
  (v_5 = B) →
  (A = (1 : Int)) →
  r2 A D C B) ∧
  ((∀ (A B C v_3 : Int),
  (r10 C B A) →
  (v_3 = A) →
  r1 A B v_3) ∧
  (∀ (A B C D E : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  r0 B A → ((0 : Int) = D) = (A ≤ B) → ¬((0 : Int) = C) = ((0 : Int) ≤ B) → (0 : Int) = E → ¬a!1 → False)))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«bcopy2_000»
