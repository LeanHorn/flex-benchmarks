import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«repeat4_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/repeat4_000.smt2":74:1-74:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/repeat4_000.smt2":8:1-18:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/repeat4_000.smt2":19:1-29:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/repeat4_000.smt2":30:1-41:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/repeat4_000.smt2":42:1-51:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/repeat4_000.smt2":52:1-61:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/repeat4_000.smt2":62:1-72:2 (clause 6, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  (∀ (A B C D E : Int),
  (r0 A B) →
  ((0 : Int) = D) →
  (E = (-1 : Int) + C) →
  (¬((0 : Int) = D) = (C = (0 : Int))) →
  r0 A B) ∧
  ((∀ (A B : Int),
  (r2 A B) →
  (True) →
  r0 A B) ∧
  ((∀ (A B C D E F : Int),
  (r0 F E) →
  (r1 E D) →
  ((0 : Int) = C) →
  (A = F) →
  (D = (-1 : Int) + B) →
  (¬((0 : Int) = C) = (B = (0 : Int))) →
  r1 A B) ∧
  ((∀ (A B C : Int),
  (¬(0 : Int) = C) →
  (A = (0 : Int)) →
  (¬((0 : Int) = C) = (B = (0 : Int))) →
  r1 A B) ∧
  ((∀ (A B : Int),
  (A = (1 : Int) + B) →
  r2 A B) ∧
  (∀ (A B C : Int),
  (r1 B A) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (B = A)) →
  False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«repeat4_000»
