import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«a-copy-print_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":545:1-545:12 (check-sat, command 70)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":32:1-43:2 (clause 1, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":44:1-54:2 (clause 2, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":55:1-65:2 (clause 3, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":66:1-78:2 (clause 4, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":79:1-89:2 (clause 5, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":90:1-103:2 (clause 6, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":104:1-117:2 (clause 7, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":118:1-129:2 (clause 8, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":130:1-142:2 (clause 9, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":143:1-153:2 (clause 10, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":154:1-165:2 (clause 11, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":166:1-178:2 (clause 12, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":179:1-192:2 (clause 13, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":193:1-205:2 (clause 14, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":206:1-219:2 (clause 15, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":220:1-232:2 (clause 16, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":233:1-246:2 (clause 17, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":247:1-259:2 (clause 18, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":260:1-271:2 (clause 19, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":272:1-285:2 (clause 20, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":286:1-298:2 (clause 21, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":299:1-311:2 (clause 22, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":312:1-323:2 (clause 23, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":324:1-335:2 (clause 24, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":336:1-347:2 (clause 25, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":348:1-358:2 (clause 26, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":359:1-371:2 (clause 27, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":372:1-386:2 (clause 28, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":387:1-400:2 (clause 29, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":401:1-411:2 (clause 30, command 58)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":412:1-424:2 (clause 31, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":425:1-435:2 (clause 32, command 60)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":436:1-446:2 (clause 33, command 61)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":447:1-457:2 (clause 34, command 62)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":458:1-469:2 (clause 35, command 63)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":470:1-481:2 (clause 36, command 64)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":482:1-498:2 (clause 37, command 65)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":499:1-508:2 (clause 38, command 66)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":509:1-521:2 (clause 39, command 67)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":522:1-531:2 (clause 40, command 68)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-copy-print_000.smt2":532:1-543:2 (clause 41, command 69)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  ∃ (r3 : Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Prop),
  ∃ (r23 : Int → Int → Prop),
  ∃ (r24 : Int → Int → Int → Prop),
  ∃ (r25 : Int → Int → Int → Int → Prop),
  ∃ (r26 : Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H : Int),
  (r20 H F C B) →
  (r16 F E D C B) →
  ((0 : Int) = G) →
  (A = H) →
  (¬((0 : Int) = G) = (B = F)) →
  r1 A F E D C B) ∧
  ((∀ (A B C D E F G : Int),
  (r16 F E D C B) →
  (¬(0 : Int) = G) →
  (A = D) →
  (¬((0 : Int) = G) = (B = F)) →
  r1 A F E D C B) ∧
  ((∀ (A B C D E F : Int),
  (r16 E D C B A) →
  ((0 : Int) = F) →
  (¬((0 : Int) = F) = (A = E)) →
  r14 E B A) ∧
  ((∀ (A B C D E v_5 : Int),
  (r14 A C B) →
  (r2 D C B) →
  (r25 E B C v_5) →
  (v_5 = B) →
  r8 A C B) ∧
  ((∀ (A B C v_3 : Int),
  (r2 C B A) →
  (v_3 = A) →
  r8 A B v_3) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r14 D C B) →
  (r2 E C B) →
  (r25 F B C v_6) →
  (r25 A D C B) →
  (v_6 = B) →
  r20 A D C B) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r1 B A F E D C) →
  (r12 A E D C) →
  (r2 E D C) →
  (r25 F C D v_6) →
  (v_6 = C) →
  r5 B A E D C) ∧
  ((∀ (A B C v_3 : Int),
  (r24 A B v_3) →
  (r3 B) →
  (v_3 = B) →
  (C = (0 : Int)) →
  r18 A B) ∧
  ((∀ (A B C D E F G v_7 : Int),
  (r24 A C v_7) →
  (r13 G D C B) →
  (r9 D C B) →
  (v_7 = C) →
  ((0 : Int) = E) →
  (F = (1 : Int) + D) →
  (¬((0 : Int) = E) = (D ≥ C)) →
  r24 A C B) ∧
  ((∀ (A B C D : Int),
  (r9 C B A) →
  ((0 : Int) = D) →
  (¬((0 : Int) = D) = (C ≥ B)) →
  r24 C B A) ∧
  ((∀ (A B C v_3 : Int),
  (r4 A B v_3) →
  (r3 B) →
  (v_3 = B) →
  (C = (0 : Int)) →
  r23 A B) ∧
  ((∀ (A B C D E F G v_7 : Int),
  (r13 G D C B) →
  (r4 A C v_7) →
  (r9 D C B) →
  (v_7 = C) →
  ((0 : Int) = E) →
  (F = (1 : Int) + D) →
  (¬((0 : Int) = E) = (D ≥ C)) →
  r12 A G C D) ∧
  ((∀ (A B C D E F G H v_8 v_9 : Int),
  (r24 D C v_8) →
  (r13 A D C B) →
  (r9 E C B) →
  (r13 H E C B) →
  (v_8 = C) →
  ((0 : Int) = F) →
  (G = (1 : Int) + E) →
  (¬((0 : Int) = F) = (E ≥ C)) →
  (v_9 = C) →
  r13 A D C v_9) ∧
  ((∀ (A B C D v_4 v_5 : Int),
  (r24 C B v_4) →
  (r11 A C B) →
  (r3 B) →
  (v_4 = B) →
  (D = (0 : Int)) →
  (v_5 = B) →
  r13 A C B v_5) ∧
  ((∀ (A B C D E F G H v_8 v_9 : Int),
  (r13 G D C B) →
  (r5 A H G C D) →
  (r4 H C v_8) →
  (r9 D C B) →
  (v_8 = C) →
  ((0 : Int) = E) →
  (F = (1 : Int) + D) →
  (¬((0 : Int) = E) = (D ≥ C)) →
  (v_9 = C) →
  r19 A H C v_9) ∧
  ((∀ (A B C D v_4 v_5 : Int),
  (r4 C B v_4) →
  (r17 A C B) →
  (r3 B) →
  (v_4 = B) →
  (D = (0 : Int)) →
  (v_5 = B) →
  r19 A C B v_5) ∧
  ((∀ (A B C D E F G : Int),
  (r13 G E C B) →
  (r8 D C E) →
  (r19 A D C B) →
  (r9 E C B) →
  ((0 : Int) = F) →
  (¬((0 : Int) = F) = (E ≥ C)) →
  r25 A D C E) ∧
  ((∀ (A B C D E F G v_7 : Int),
  (r13 G D C B) →
  (r9 D C B) →
  (r0 A D C B) →
  ((0 : Int) = E) →
  (F = (1 : Int) + D) →
  (¬((0 : Int) = E) = (D ≥ C)) →
  (v_7 = C) →
  r0 A F C v_7) ∧
  ((∀ (A B C D v_4 v_5 : Int),
  (r6 A B v_4) →
  (r3 B) →
  (v_4 = B) →
  (C = (0 : Int)) →
  (D = (0 : Int)) →
  (v_5 = B) →
  r0 A D B v_5) ∧
  ((∀ (A B C D E F G H v_8 : Int),
  (r13 H E D C) →
  (r9 E D C) →
  (r26 B A G D v_8) →
  (r0 A E D C) →
  (v_8 = D) →
  ((0 : Int) = F) →
  (G = (1 : Int) + E) →
  (¬((0 : Int) = F) = (E ≥ D)) →
  r26 B A E D C) ∧
  ((∀ (A B C D E F : Int),
  (r19 B A D C) →
  (r9 E D C) →
  (r0 A E D C) →
  (¬(0 : Int) = F) →
  (¬((0 : Int) = F) = (E ≥ D)) →
  r26 B A E D C) ∧
  ((∀ (A B C D E F : Int),
  (r13 F D C B) →
  (r8 A C D) →
  (r9 D C B) →
  ((0 : Int) = E) →
  (¬((0 : Int) = E) = (D ≥ C)) →
  r4 A C B) ∧
  ((∀ (A B C D E : Int),
  (r9 D C B) →
  (r0 A D C B) →
  (¬(0 : Int) = E) →
  (¬((0 : Int) = E) = (D ≥ C)) →
  r4 A C B) ∧
  ((∀ (A B C D E : Int),
  (r13 E C B A) →
  (r9 C B A) →
  ((0 : Int) = D) →
  (¬((0 : Int) = D) = (C ≥ B)) →
  r2 E B C) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r13 F C B A) →
  (r9 C B A) →
  ((0 : Int) = D) →
  (E = (1 : Int) + C) →
  (¬((0 : Int) = D) = (C ≥ B)) →
  (v_6 = B) →
  r9 E B v_6) ∧
  ((∀ (A B v_2 : Int),
  (r3 A) →
  (B = (0 : Int)) →
  (v_2 = A) →
  r9 B A v_2) ∧
  ((∀ (A B C D E v_5 v_6 v_7 : Int),
  (r26 A E D B v_5) →
  (r3 B) →
  (r6 E B v_6) →
  (v_5 = B) →
  (v_6 = B) →
  (C = (0 : Int)) →
  (D = (0 : Int)) →
  (v_7 = B) →
  r15 A E B v_7) ∧
  ((∀ (A B C D E F G H I v_9 v_10 : Int),
  (r6 D C v_9) →
  (r22 I H) →
  (r7 E C B) →
  (r15 H E C B) →
  (r15 A D C B) →
  (v_9 = C) →
  ((0 : Int) = F) →
  (G = (1 : Int) + E) →
  (¬((0 : Int) = F) = (E ≥ C)) →
  (v_10 = C) →
  r15 A D C v_10) ∧
  ((∀ (A B C D E F G H v_8 : Int),
  (r6 A C v_8) →
  (r22 H G) →
  (r7 D C B) →
  (r15 G D C B) →
  (v_8 = C) →
  ((0 : Int) = E) →
  (F = (1 : Int) + D) →
  (¬((0 : Int) = E) = (D ≥ C)) →
  r6 A C B) ∧
  ((∀ (A B C D : Int),
  (r7 C B A) →
  ((0 : Int) = D) →
  (¬((0 : Int) = D) = (C ≥ B)) →
  r6 C B A) ∧
  ((∀ (A B C D E F G v_7 : Int),
  (r15 F C B A) →
  (r22 G F) →
  (r7 C B A) →
  ((0 : Int) = D) →
  (E = (1 : Int) + C) →
  (¬((0 : Int) = D) = (C ≥ B)) →
  (v_7 = B) →
  r7 E B v_7) ∧
  ((∀ (A B C v_3 : Int),
  (r3 A) →
  (B = (0 : Int)) →
  (C = (0 : Int)) →
  (v_3 = A) →
  r7 B A v_3) ∧
  ((∀ (A B C : Int),
  (r18 A B) →
  (¬(0 : Int) = C) →
  (((0 : Int) = C) = (B ≤ (0 : Int))) →
  r10 A B) ∧
  ((∀ (A B C : Int),
  (r23 A B) →
  (¬(0 : Int) = C) →
  (((0 : Int) = C) = (B ≤ (0 : Int))) →
  r10 A B) ∧
  ((∀ (A B C D : Int),
  (r18 D B) →
  (r21 A D B) →
  (¬(0 : Int) = C) →
  (((0 : Int) = C) = (B ≤ (0 : Int))) →
  r11 A D B) ∧
  ((∀ (A B C D : Int),
  (r23 D B) →
  (r21 A D B) →
  (¬(0 : Int) = C) →
  (((0 : Int) = C) = (B ≤ (0 : Int))) →
  r17 A D B) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r10 C B →
    ((0 : Int) = F) = (B ≤ C) →
      ¬((0 : Int) = E) = ((0 : Int) ≤ C) → ¬(0 : Int) = G → D = (1 : Int) → A = (0 : Int) → ¬a!1 → r21 A C B) ∧
  ((∀ (A B : Int),
  (A = (1 : Int)) →
  r22 A B) ∧
  ((∀ (A B C D E v_5 : Int),
  (r25 E B C v_5) →
  (r12 A D C B) →
  (r2 D C B) →
  (v_5 = B) →
  r16 A E D C B) ∧
  ((∀ (A B : Int),
  (¬(0 : Int) = B) →
  (((0 : Int) = B) = (A ≤ (0 : Int))) →
  r3 A) ∧
  (∀ (A B C D E : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  r10 B A → ((0 : Int) = D) = (A ≤ B) → ¬((0 : Int) = C) = ((0 : Int) ≤ B) → (0 : Int) = E → ¬a!1 → False))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«a-copy-print_000»
