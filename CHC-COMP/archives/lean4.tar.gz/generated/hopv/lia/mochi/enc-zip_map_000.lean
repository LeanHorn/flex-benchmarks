import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«enc-zip_map_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map_000.smt2":72:1-72:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map_000.smt2":7:1-17:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map_000.smt2":18:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map_000.smt2":28:1-44:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map_000.smt2":45:1-58:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map_000.smt2":59:1-70:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  (∀ (A B C D E : Int),
  (r1 E D) →
  ((0 : Int) = C) →
  (A = (1 : Int) + E) →
  (D = (-1 : Int) + B) →
  (¬((0 : Int) = C) = (B = (0 : Int))) →
  r1 A B) ∧
  ((∀ (A B C : Int),
  (¬(0 : Int) = C) →
  (A = (0 : Int)) →
  (¬((0 : Int) = C) = (B = (0 : Int))) →
  r1 A B) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 H G F) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  ((0 : Int) = E) →
  ((0 : Int) = D) →
  (A = (1 : Int) + H) →
  (F = (-1 : Int) + B) →
  (G = (-1 : Int) + C) →
  (¬((0 : Int) = E) = (C = (0 : Int))) →
  r0 A C B) ∧
  ((∀ (A B C D E : Int),
  (¬((0 : Int) = D) = (C = (0 : Int))) →
  (¬(0 : Int) = E) →
  (¬(0 : Int) = D) →
  (A = (0 : Int)) →
  (¬((0 : Int) = E) = (B = (0 : Int))) →
  r0 A C B) ∧
  (∀ (A B C D v_4 : Int),
  (r0 B A v_4) →
  (r1 C B) →
  (v_4 = A) →
  ((0 : Int) = D) →
  (¬((0 : Int) = D) = (C ≥ A)) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«enc-zip_map_000»
