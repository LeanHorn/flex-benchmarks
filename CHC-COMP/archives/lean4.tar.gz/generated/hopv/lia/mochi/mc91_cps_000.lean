import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«mc91_cps_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_cps_000.smt2":115:1-115:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_cps_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_cps_000.smt2":20:1-30:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_cps_000.smt2":31:1-41:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_cps_000.smt2":42:1-52:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_cps_000.smt2":53:1-64:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_cps_000.smt2":65:1-76:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_cps_000.smt2":77:1-87:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_cps_000.smt2":88:1-99:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_cps_000.smt2":100:1-113:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  (∀ (A : Int),
  (True) →
  r1 A) ∧
  ((∀ (A B : Int),
  (r2 B A) →
  (True) →
  r1 B) ∧
  ((∀ (A B C : Int),
  (r1 A) →
  ((0 : Int) = B) →
  (C = (11 : Int) + A) →
  (((0 : Int) = B) = (A ≤ (100 : Int))) →
  r1 C) ∧
  ((∀ (A B : Int),
  (r4 A B) →
  (True) →
  r0 A B) ∧
  ((∀ (A B C : Int),
  (r2 C B) →
  (r4 A C) →
  (True) →
  r3 A B) ∧
  ((∀ (A B C : Int),
  (r3 A B) →
  (r1 B) →
  ((0 : Int) = C) →
  (((0 : Int) = C) = (B ≤ (100 : Int))) →
  r4 A B) ∧
  ((∀ (A B C : Int),
  (r1 A) →
  (¬(0 : Int) = B) →
  (C = (-10 : Int) + A) →
  (((0 : Int) = B) = (A ≤ (100 : Int))) →
  r4 C A) ∧
  ((∀ (A B C D : Int),
  (r4 A D) →
  (r1 B) →
  ((0 : Int) = C) →
  (D = (11 : Int) + B) →
  (((0 : Int) = C) = (B ≤ (100 : Int))) →
  r2 A B) ∧
  (∀ (A B C D : Int),
  (r0 B A) →
  (¬((0 : Int) = D) = (B = (91 : Int))) →
  (¬(0 : Int) = C) →
  ((0 : Int) = D) →
  (¬((0 : Int) = C) = (A ≤ (101 : Int))) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«mc91_cps_000»
