import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«enc-zip_map2_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map2_000.smt2":134:1-134:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map2_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map2_000.smt2":19:1-34:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map2_000.smt2":35:1-45:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map2_000.smt2":46:1-55:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map2_000.smt2":56:1-73:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map2_000.smt2":74:1-88:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map2_000.smt2":89:1-100:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map2_000.smt2":101:1-111:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map2_000.smt2":112:1-122:2 (clause 9, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_map2_000.smt2":123:1-132:2 (clause 10, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Prop),
  ∃ (r3 : Int → Int → Prop),
  (∀ (A v_1 : Int),
  (True) →
  (v_1 = A) →
  r0 A v_1) ∧
  ((∀ (A B C D E F : Int),
  (r0 B A) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  ((0 : Int) = C) →
  ((0 : Int) = D) →
  (E = (-1 : Int) + A) →
  (F = (-1 : Int) + B) →
  (¬((0 : Int) = C) = (A = (0 : Int))) →
  r0 F E) ∧
  ((∀ (A B C D E : Int),
  (r3 E D) →
  ((0 : Int) = C) →
  (A = (1 : Int) + E) →
  (D = (-1 : Int) + B) →
  (¬((0 : Int) = C) = (B = (0 : Int))) →
  r3 A B) ∧
  ((∀ (A B C : Int),
  (¬(0 : Int) = C) →
  (A = B) →
  (¬((0 : Int) = C) = (B = (0 : Int))) →
  r3 A B) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 C B) →
  (r1 H G F) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  ((0 : Int) = E) →
  ((0 : Int) = D) →
  (A = (1 : Int) + H) →
  (F = (-1 : Int) + B) →
  (G = (-1 : Int) + C) →
  (¬((0 : Int) = E) = (C = (0 : Int))) →
  r1 A C B) ∧
  ((∀ (A B C D E : Int),
  (r0 C B) →
  (¬((0 : Int) = E) = (B = (0 : Int))) →
  (¬(0 : Int) = D) →
  (¬(0 : Int) = E) →
  (A = B) →
  (¬((0 : Int) = D) = (C = (0 : Int))) →
  r1 A C B) ∧
  ((∀ (A B C D v_4 : Int),
  (r1 B A v_4) →
  (r3 C B) →
  (v_4 = A) →
  ((0 : Int) = D) →
  (¬((0 : Int) = D) = (C = A)) →
  r2) ∧
  ((∀ (A B C D : Int),
  (r0 B A) →
  (¬((0 : Int) = D) = (A = (0 : Int))) →
  ((0 : Int) = C) →
  (¬(0 : Int) = D) →
  (¬((0 : Int) = C) = (B = (0 : Int))) →
  r2) ∧
  ((∀ (A B C D : Int),
  (r0 B A) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  ((0 : Int) = C) →
  (¬(0 : Int) = D) →
  (¬((0 : Int) = C) = (A = (0 : Int))) →
  r2) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r2) →
  False)))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«enc-zip_map2_000»
