import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«max_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/max_000.smt2":64:1-64:12 (check-sat, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/max_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/max_000.smt2":18:1-27:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/max_000.smt2":28:1-38:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/max_000.smt2":39:1-50:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/max_000.smt2":51:1-62:2 (clause 5, command 9)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (¬(0 : Int) = D) →
  (A = B) →
  (¬((0 : Int) = D) = (B ≥ C)) →
  r0 A C B) ∧
  ((∀ (A B C D : Int),
  ((0 : Int) = D) →
  (A = C) →
  (¬((0 : Int) = D) = (B ≥ C)) →
  r0 A C B) ∧
  ((∀ (A B C : Int),
  (r0 B A C) →
  (True) →
  r1 B A C) ∧
  ((∀ (A B C D E F : Int),
  (r1 E C B) →
  (r1 F D E) →
  (A = F) →
  r2 A D C B) ∧
  (∀ (A B C D E F : Int),
  (r2 F C B A) →
  (r0 D F A) →
  ((0 : Int) = E) →
  (¬((0 : Int) = E) = (D = F)) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«max_000»
