import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«enc-zip_unzip_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_unzip_000.smt2":138:1-138:12 (check-sat, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_unzip_000.smt2":11:1-20:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_unzip_000.smt2":21:1-31:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_unzip_000.smt2":32:1-43:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_unzip_000.smt2":44:1-54:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_unzip_000.smt2":55:1-65:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_unzip_000.smt2":66:1-77:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_unzip_000.smt2":78:1-88:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_unzip_000.smt2":89:1-104:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_unzip_000.smt2":105:1-115:2 (clause 9, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_unzip_000.smt2":116:1-126:2 (clause 10, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_unzip_000.smt2":127:1-136:2 (clause 11, command 18)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  ∃ (r5 : Prop),
  (∀ (A : Int),
  (True) →
  r2 A) ∧
  ((∀ (A B C : Int),
  (r2 A) →
  ((0 : Int) = B) →
  (C = (-1 : Int) + A) →
  (¬((0 : Int) = B) = (A = (0 : Int))) →
  r2 C) ∧
  ((∀ (A B C D : Int),
  (r0 A C) →
  (r2 B) →
  ((0 : Int) = D) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  r4 A C B) ∧
  ((∀ (A B C D : Int),
  (r2 A) →
  (¬(0 : Int) = D) →
  (B = (0 : Int)) →
  (C = (0 : Int)) →
  (¬((0 : Int) = D) = (A = (0 : Int))) →
  r4 C B A) ∧
  ((∀ (A B C D : Int),
  (r3 B A) →
  (D = (1 : Int) + B) →
  (C = (1 : Int) + A) →
  r0 D C) ∧
  ((∀ (A B C D E : Int),
  (r2 B) →
  (r4 A D E) →
  ((0 : Int) = C) →
  (E = (-1 : Int) + B) →
  (¬((0 : Int) = C) = (B = (0 : Int))) →
  r3 A D) ∧
  ((∀ (A B C : Int),
  (r4 A C B) →
  (True) →
  r1 A C) ∧
  ((∀ (A B C D E F : Int),
  (r1 B A) →
  (¬((0 : Int) = C) = (A = (0 : Int))) →
  ((0 : Int) = D) →
  ((0 : Int) = C) →
  (E = (-1 : Int) + A) →
  (F = (-1 : Int) + B) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  r1 F E) ∧
  ((∀ (A B C D : Int),
  (r1 B A) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  (¬(0 : Int) = C) →
  ((0 : Int) = D) →
  (¬((0 : Int) = C) = (A = (0 : Int))) →
  r5) ∧
  ((∀ (A B C D : Int),
  (r1 B A) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  ((0 : Int) = C) →
  (¬(0 : Int) = D) →
  (¬((0 : Int) = C) = (A = (0 : Int))) →
  r5) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r5) →
  False))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«enc-zip_unzip_000»
