import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«mult_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mult_000.smt2":50:1-50:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mult_000.smt2":6:1-22:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mult_000.smt2":23:1-37:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mult_000.smt2":38:1-48:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  (∀ (A B C D E F G H : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∨ ¬(0 : Int) = E);
  r0 H G B →
    ¬((0 : Int) = E) = (C ≤ (0 : Int)) →
      ¬((0 : Int) = D) = (B ≤ (0 : Int)) → (0 : Int) = F → G = (-1 : Int) + C → A = B + H → ¬a!1 → r0 A C B) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∨ ¬(0 : Int) = E);
  ¬((0 : Int) = E) = (C ≤ (0 : Int)) →
    ¬((0 : Int) = D) = (B ≤ (0 : Int)) → ¬(0 : Int) = F → A = (0 : Int) → ¬a!1 → r0 A C B) ∧
  (∀ (A B C v_3 : Int),
  (r0 B A v_3) →
  (v_3 = A) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (A ≤ B)) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«mult_000»
