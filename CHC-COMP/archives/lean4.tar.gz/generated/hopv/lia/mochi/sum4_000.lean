import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«sum4_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum4_000.smt2":39:1-39:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum4_000.smt2":6:1-16:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum4_000.smt2":17:1-26:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum4_000.smt2":27:1-37:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  (∀ (A B C D E : Int),
  (r0 E D) →
  ((0 : Int) = C) →
  (D = (-1 : Int) + B) →
  (A = B + E) →
  (¬((0 : Int) = C) = (B ≤ (0 : Int))) →
  r0 A B) ∧
  ((∀ (A B C : Int),
  (¬(0 : Int) = C) →
  (A = (0 : Int)) →
  (¬((0 : Int) = C) = (B ≤ (0 : Int))) →
  r0 A B) ∧
  (∀ (A B C D E : Int),
  (r0 D A) →
  ((0 : Int) = E) →
  (C = (-6 : Int) + B) →
  (B = (4 : Int) * A) →
  (¬((0 : Int) = E) = (C ≤ D)) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«sum4_000»
