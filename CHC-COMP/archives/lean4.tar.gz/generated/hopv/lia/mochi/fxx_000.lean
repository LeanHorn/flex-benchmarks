import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«fxx_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/fxx_000.smt2":33:1-33:12 (check-sat, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/fxx_000.smt2":6:1-15:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/fxx_000.smt2":16:1-31:2 (clause 2, command 4)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  (∀ (A v_1 : Int),
  (True) →
  (v_1 = A) →
  r0 A v_1) ∧
  (∀ (A B C D E F : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  r0 B A →
    ¬((0 : Int) = D) = (B ≤ (0 : Int)) →
      ((0 : Int) = C) = (A ≤ (0 : Int)) → ¬((0 : Int) = F) = ((0 : Int) = E) → (0 : Int) = F → ¬a!1 → False)

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«fxx_000»
