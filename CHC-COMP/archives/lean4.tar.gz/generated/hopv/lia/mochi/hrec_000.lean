import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«hrec_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hrec_000.smt2":88:1-88:12 (check-sat, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hrec_000.smt2":8:1-19:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hrec_000.smt2":20:1-31:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hrec_000.smt2":32:1-42:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hrec_000.smt2":43:1-54:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hrec_000.smt2":55:1-65:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hrec_000.smt2":66:1-75:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hrec_000.smt2":76:1-86:2 (clause 7, command 11)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  (∀ (A B C D E : Int),
  (r0 A B) →
  (r0 E C) →
  ((0 : Int) = D) →
  (¬((0 : Int) = D) = (C ≥ (0 : Int))) →
  r0 A B) ∧
  ((∀ (A B C D E : Int),
  (r0 E B) →
  (r1 A D) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (B ≥ (0 : Int))) →
  r0 A D) ∧
  ((∀ (A B : Int),
  (r2 A B) →
  (True) →
  r0 A B) ∧
  ((∀ (A B C D E : Int),
  (r0 D B) →
  (r1 E D) →
  ((0 : Int) = C) →
  (A = E) →
  (¬((0 : Int) = C) = (B ≥ (0 : Int))) →
  r1 A B) ∧
  ((∀ (A B C D : Int),
  (r0 D B) →
  (¬(0 : Int) = C) →
  (A = D) →
  (¬((0 : Int) = C) = (B ≥ (0 : Int))) →
  r1 A B) ∧
  ((∀ (A B : Int),
  (A = (1 : Int) + B) →
  r2 A B) ∧
  (∀ (A B C : Int),
  (r1 B A) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (B ≥ (0 : Int))) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«hrec_000»
