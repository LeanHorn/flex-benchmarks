import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«enc-zip3_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip3_000.smt2":49:1-49:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip3_000.smt2":6:1-22:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip3_000.smt2":23:1-36:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip3_000.smt2":37:1-47:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  (∀ (A B C D E F G H : Int),
  (r0 H G F) →
  (¬((0 : Int) = E) = (C = (0 : Int))) →
  ((0 : Int) = D) →
  ((0 : Int) = E) →
  (A = (1 : Int) + H) →
  (G = (-1 : Int) + C) →
  (F = (-1 : Int) + B) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  r0 A C B) ∧
  ((∀ (A B C D E : Int),
  (¬((0 : Int) = D) = (C = (0 : Int))) →
  (¬(0 : Int) = E) →
  (¬(0 : Int) = D) →
  (A = (0 : Int)) →
  (¬((0 : Int) = E) = (B = (0 : Int))) →
  r0 A C B) ∧
  (∀ (A B C v_3 : Int),
  (r0 B A v_3) →
  (v_3 = A) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (B = A)) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«enc-zip3_000»
