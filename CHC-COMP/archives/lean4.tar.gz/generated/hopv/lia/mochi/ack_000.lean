import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«ack_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/ack_000.smt2":69:1-69:12 (check-sat, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/ack_000.smt2":6:1-23:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/ack_000.smt2":24:1-40:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/ack_000.smt2":41:1-50:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/ack_000.smt2":51:1-67:2 (clause 4, command 6)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  (∀ (A B C D E F G H I : Int),
  (r0 E H I) →
  (r0 H G B) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  ((0 : Int) = F) →
  ((0 : Int) = D) →
  (I = (-1 : Int) + B) →
  (G = (-1 : Int) + C) →
  (A = E) →
  (¬((0 : Int) = F) = (C = (0 : Int))) →
  r0 A C B) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 G F E) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  (¬(0 : Int) = H) →
  ((0 : Int) = D) →
  (F = (1 : Int)) →
  (E = (-1 : Int) + B) →
  (A = G) →
  (¬((0 : Int) = H) = (C = (0 : Int))) →
  r0 A C B) ∧
  ((∀ (A B C D : Int),
  (¬(0 : Int) = D) →
  (A = (1 : Int) + C) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  r0 A C B) ∧
  (∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  r0 F B A →
    ¬a!1 →
      ¬((0 : Int) = D) = (B ≥ (0 : Int)) →
        ¬((0 : Int) = C) = (A ≥ (0 : Int)) → (0 : Int) = G → ¬(0 : Int) = E → ¬((0 : Int) = G) = (F ≥ B) → False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«ack_000»
