import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«enc-zip_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_000.smt2":111:1-111:12 (check-sat, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_000.smt2":18:1-35:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_000.smt2":36:1-50:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_000.smt2":51:1-66:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_000.smt2":67:1-77:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_000.smt2":78:1-88:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_000.smt2":89:1-99:2 (clause 7, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-zip_000.smt2":100:1-109:2 (clause 8, command 12)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  (∀ (A v_1 : Int),
  (True) →
  (v_1 = A) →
  r0 A v_1) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 C B) →
  (r2 H G F) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  ((0 : Int) = E) →
  ((0 : Int) = D) →
  (G = (-1 : Int) + C) →
  (F = (-1 : Int) + B) →
  (A = (1 : Int) + H) →
  (¬((0 : Int) = E) = (C = (0 : Int))) →
  r2 A C B) ∧
  ((∀ (A B C D E : Int),
  (r0 C B) →
  (¬((0 : Int) = E) = (C = (0 : Int))) →
  (¬(0 : Int) = D) →
  (¬(0 : Int) = E) →
  (A = (0 : Int)) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  r2 A C B) ∧
  ((∀ (A B C D E F : Int),
  (r0 B A) →
  (¬((0 : Int) = C) = (A = (0 : Int))) →
  ((0 : Int) = D) →
  ((0 : Int) = C) →
  (E = (-1 : Int) + A) →
  (F = (-1 : Int) + B) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  r0 F E) ∧
  ((∀ (A B C D : Int),
  (r0 B A) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  (¬(0 : Int) = C) →
  ((0 : Int) = D) →
  (¬((0 : Int) = C) = (A = (0 : Int))) →
  r1) ∧
  ((∀ (A B C D : Int),
  (r0 B A) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  ((0 : Int) = C) →
  (¬(0 : Int) = D) →
  (¬((0 : Int) = C) = (A = (0 : Int))) →
  r1) ∧
  ((∀ (A B C v_3 : Int),
  (r2 B A v_3) →
  (v_3 = A) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (B = A)) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  False)))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«enc-zip_000»
