import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«inc4_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":273:1-273:12 (check-sat, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":19:1-30:2 (clause 1, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":31:1-41:2 (clause 2, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":42:1-52:2 (clause 3, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":53:1-65:2 (clause 4, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":66:1-76:2 (clause 5, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":77:1-90:2 (clause 6, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":91:1-104:2 (clause 7, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":105:1-116:2 (clause 8, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":117:1-129:2 (clause 9, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":130:1-143:2 (clause 10, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":144:1-156:2 (clause 11, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":157:1-170:2 (clause 12, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":171:1-183:2 (clause 13, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":184:1-194:2 (clause 14, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":195:1-206:2 (clause 15, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":207:1-217:2 (clause 16, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":218:1-229:2 (clause 17, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":230:1-246:2 (clause 18, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":247:1-259:2 (clause 19, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc4_000.smt2":260:1-271:2 (clause 20, command 35)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H v_8 : Int),
  (r1 H B C v_8) →
  (r13 F E D C B) →
  (v_8 = B) →
  ((0 : Int) = G) →
  (A = H) →
  (¬((0 : Int) = G) = (B = F)) →
  r8 A F E D C B) ∧
  ((∀ (A B C D E F G : Int),
  (r13 F E D C B) →
  (¬(0 : Int) = G) →
  (A = D) →
  (¬((0 : Int) = G) = (B = F)) →
  r8 A F E D C B) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r13 E D C B A) →
  ((0 : Int) = F) →
  (¬((0 : Int) = F) = (A = E)) →
  (v_6 = A) →
  r9 A B v_6) ∧
  ((∀ (A B C D E v_5 : Int),
  (r9 A C B) →
  (r6 D C B) →
  (r11 E B C v_5) →
  (v_5 = B) →
  r7 A C B) ∧
  ((∀ (A B C v_3 : Int),
  (r6 C B A) →
  (v_3 = A) →
  r7 A B v_3) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r9 D C B) →
  (r6 E C B) →
  (r11 F B C v_6) →
  (r11 A D C B) →
  (v_6 = B) →
  r1 A D C B) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r8 B A F E D C) →
  (r12 A E D C) →
  (r6 E D C) →
  (r11 F C D v_6) →
  (v_6 = C) →
  r2 B A E D C) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  r0 A B → ((0 : Int) = E) = (B ≤ (0 : Int)) → ¬((0 : Int) = D) = (C = (0 : Int)) → ¬(0 : Int) = F → ¬a!1 → r3 A B) ∧
  ((∀ (A B C D E F G : Int),
  (r0 A C) →
  (r4 F B C) →
  (r5 B C) →
  ((0 : Int) = D) →
  (G = (1 : Int) + F) →
  (E = (1 : Int) + B) →
  (¬((0 : Int) = D) = (B ≥ C)) →
  r12 A G C B) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 H C) →
  (r2 A H G C B) →
  (r4 F B C) →
  (r5 B C) →
  ((0 : Int) = D) →
  (G = (1 : Int) + F) →
  (E = (1 : Int) + B) →
  (¬((0 : Int) = D) = (B ≥ C)) →
  r4 A H C) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  r0 G B →
    r10 A G B → ((0 : Int) = E) = (B ≤ (0 : Int)) → ¬((0 : Int) = D) = (C = (0 : Int)) → ¬(0 : Int) = F → ¬a!1 → r4 A G B) ∧
  ((∀ (A B C D E F G : Int),
  (r4 A B D) →
  (r7 B D C) →
  (r4 F C D) →
  (r5 C D) →
  ((0 : Int) = E) →
  (G = (1 : Int) + F) →
  (¬((0 : Int) = E) = (C ≥ D)) →
  r11 A B D C) ∧
  ((∀ (A B C D E F : Int),
  (r4 E B C) →
  (r7 A C B) →
  (r5 B C) →
  ((0 : Int) = D) →
  (F = (1 : Int) + E) →
  (¬((0 : Int) = D) = (B ≥ C)) →
  r0 A C) ∧
  ((∀ (A B C : Int),
  (r5 A B) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (A ≥ B)) →
  r0 A B) ∧
  ((∀ (A B C D E F : Int),
  (r4 E A B) →
  (r5 A B) →
  ((0 : Int) = C) →
  (F = (1 : Int) + E) →
  (D = (1 : Int) + A) →
  (¬((0 : Int) = C) = (A ≥ B)) →
  r5 D B) ∧
  ((∀ (A B C D E : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  ((0 : Int) = D) = (A ≤ (0 : Int)) → ¬((0 : Int) = C) = (B = (0 : Int)) → ¬(0 : Int) = E → ¬a!1 → r5 B A) ∧
  ((∀ (A B C D E : Int),
  (r4 D A B) →
  (r5 A B) →
  ((0 : Int) = C) →
  (E = (1 : Int) + D) →
  (¬((0 : Int) = C) = (A ≥ B)) →
  r6 E B A) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r3 C B →
    ((0 : Int) = F) = (B ≤ C) →
      ¬((0 : Int) = E) = ((0 : Int) ≤ C) → ¬(0 : Int) = G → D = (1 : Int) → A = (0 : Int) → ¬a!1 → r10 A C B) ∧
  ((∀ (A B C D E v_5 : Int),
  (r11 E B C v_5) →
  (r12 A D C B) →
  (r6 D C B) →
  (v_5 = B) →
  r13 A E D C B) ∧
  (∀ (A B C D E : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  r3 B A → ((0 : Int) = D) = (A ≤ B) → ¬((0 : Int) = C) = ((0 : Int) ≤ B) → (0 : Int) = E → ¬a!1 → False)))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«inc4_000»
