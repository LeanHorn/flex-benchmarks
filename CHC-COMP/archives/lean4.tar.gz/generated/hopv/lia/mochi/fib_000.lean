import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«fib_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/fib_000.smt2":44:1-44:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/fib_000.smt2":6:1-21:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/fib_000.smt2":22:1-31:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/fib_000.smt2":32:1-42:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  (∀ (A B C D E F G : Int),
  (r0 E D) →
  (r0 G F) →
  ((0 : Int) = C) →
  (F = (-2 : Int) + B) →
  (D = (-1 : Int) + B) →
  (A = E + G) →
  (((0 : Int) = C) = ((2 : Int) ≤ B)) →
  r0 A B) ∧
  ((∀ (A B C : Int),
  (¬(0 : Int) = C) →
  (A = (1 : Int)) →
  (((0 : Int) = C) = ((2 : Int) ≤ B)) →
  r0 A B) ∧
  (∀ (A B C : Int),
  (r0 C A) →
  ((0 : Int) = B) →
  (¬((0 : Int) = B) = (A ≤ C)) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«fib_000»
