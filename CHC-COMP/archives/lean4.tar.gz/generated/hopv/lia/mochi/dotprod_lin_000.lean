import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«dotprod_lin_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":408:1-408:12 (check-sat, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":13:1-36:2 (clause 1, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":37:1-54:2 (clause 2, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":55:1-79:2 (clause 3, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":80:1-98:2 (clause 4, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":99:1-122:2 (clause 5, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":123:1-147:2 (clause 6, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":148:1-172:2 (clause 7, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":173:1-195:2 (clause 8, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":196:1-215:2 (clause 9, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":216:1-233:2 (clause 10, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":234:1-252:2 (clause 11, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":253:1-270:2 (clause 12, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":271:1-287:2 (clause 13, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":288:1-299:2 (clause 14, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":300:1-310:2 (clause 15, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":311:1-321:2 (clause 16, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":322:1-332:2 (clause 17, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":333:1-344:2 (clause 18, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":345:1-355:2 (clause 19, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":356:1-367:2 (clause 20, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":368:1-384:2 (clause 21, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":385:1-394:2 (clause 22, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/dotprod_lin_000.smt2":395:1-406:2 (clause 23, command 32)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P : Int),
  (r6 A B) →
  (r7 L K J B) →
  (r0 D C B) →
  (r3 G C B) →
  (r5 P C B) →
  (r5 I C B) →
  (r3 N C B) →
  ((0 : Int) = M) →
  (O = D + N) →
  (K = H + I) →
  (J = (1 : Int) + C) →
  (H = D + G) →
  (F = O + P) →
  (E = (1 : Int) + C) →
  (¬((0 : Int) = M) = (C ≥ B)) →
  r6 A B) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r6 A B) →
  (r0 D C B) →
  (r3 E C B) →
  (r5 G C B) →
  ((0 : Int) = J) →
  (I = F + G) →
  (H = (1 : Int) + C) →
  (F = D + E) →
  (¬((0 : Int) = J) = (C ≥ B)) →
  r6 A B) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  (r6 C B) →
  (r7 M L K B) →
  (r0 E D B) →
  (r3 A C B) →
  (r5 Q D B) →
  (r5 J D B) →
  (r3 O D B) →
  (r3 H D B) →
  ((0 : Int) = N) →
  (P = E + O) →
  (L = I + J) →
  (K = (1 : Int) + D) →
  (I = E + H) →
  (G = P + Q) →
  (F = (1 : Int) + D) →
  (¬((0 : Int) = N) = (D ≥ B)) →
  r3 A C B) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r6 C B) →
  (r0 E D B) →
  (r3 A C B) →
  (r5 H D B) →
  (r3 F D B) →
  ((0 : Int) = K) →
  (J = G + H) →
  (I = (1 : Int) + D) →
  (G = E + F) →
  (¬((0 : Int) = K) = (D ≥ B)) →
  r3 A C B) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  (r3 G C B) →
  (r7 L K J B) →
  (r0 D C B) →
  (r3 N C B) →
  (r5 P C B) →
  (r5 I C B) →
  (r4 A B) →
  ((0 : Int) = M) →
  (O = D + N) →
  (K = H + I) →
  (J = (1 : Int) + C) →
  (H = D + G) →
  (F = O + P) →
  (E = (1 : Int) + C) →
  (¬((0 : Int) = M) = (C ≥ B)) →
  r4 A B) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  (r3 H D B) →
  (r7 M L K B) →
  (r0 E D B) →
  (r3 O D B) →
  (r5 Q D B) →
  (r5 J D B) →
  (r5 A C B) →
  (r4 C B) →
  ((0 : Int) = N) →
  (P = E + O) →
  (L = I + J) →
  (K = (1 : Int) + D) →
  (I = E + H) →
  (G = P + Q) →
  (F = (1 : Int) + D) →
  (¬((0 : Int) = N) = (D ≥ B)) →
  r5 A C B) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  (r3 H C B) →
  (r7 M L K B) →
  (r7 G F E B) →
  (r0 D C B) →
  (r3 O C B) →
  (r5 Q C B) →
  (r5 J C B) →
  ((0 : Int) = N) →
  (A = G) →
  (P = D + O) →
  (L = I + J) →
  (K = (1 : Int) + C) →
  (I = D + H) →
  (F = P + Q) →
  (E = (1 : Int) + C) →
  (¬((0 : Int) = N) = (C ≥ B)) →
  r7 A D C B) ∧
  ((∀ (A B C D E F G H I J K L M N O : Int),
  (r3 F B A) →
  (r7 K J I A) →
  (r0 C B A) →
  (r3 M B A) →
  (r5 O B A) →
  (r5 H B A) →
  ((0 : Int) = L) →
  (N = C + M) →
  (J = G + H) →
  (I = (1 : Int) + B) →
  (G = C + F) →
  (E = N + O) →
  (D = (1 : Int) + B) →
  (¬((0 : Int) = L) = (B ≥ A)) →
  r0 E D A) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r3 D B A) →
  (r7 I H G A) →
  (r0 C B A) →
  (r3 K B A) →
  (r5 F B A) →
  ((0 : Int) = J) →
  (L = C + K) →
  (H = E + F) →
  (G = (1 : Int) + B) →
  (E = C + D) →
  (¬((0 : Int) = J) = (B ≥ A)) →
  r4 B A) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 E C B) →
  (r0 D C B) →
  (r4 A B) →
  (r5 G C B) →
  ((0 : Int) = J) →
  (I = F + G) →
  (H = (1 : Int) + C) →
  (F = D + E) →
  (¬((0 : Int) = J) = (C ≥ B)) →
  r4 A B) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r3 F D B) →
  (r0 E D B) →
  (r4 C B) →
  (r5 H D B) →
  (r5 A C B) →
  ((0 : Int) = K) →
  (J = G + H) →
  (I = (1 : Int) + D) →
  (G = E + F) →
  (¬((0 : Int) = K) = (D ≥ B)) →
  r5 A C B) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 D B A) →
  (r7 I H G A) →
  (r0 C B A) →
  (r5 F B A) →
  ((0 : Int) = J) →
  (H = E + F) →
  (G = (1 : Int) + B) →
  (E = C + D) →
  (¬((0 : Int) = J) = (B ≥ A)) →
  r6 B A) ∧
  ((∀ (A B C D E F G H I : Int),
  (r3 D B A) →
  (r0 C B A) →
  (r5 F B A) →
  ((0 : Int) = I) →
  (H = E + F) →
  (G = (1 : Int) + B) →
  (E = C + D) →
  (¬((0 : Int) = I) = (B ≥ A)) →
  r0 H G A) ∧
  ((∀ (A B C D E F : Int),
  (r3 D B A) →
  (r0 C B A) →
  ((0 : Int) = F) →
  (E = C + D) →
  (¬((0 : Int) = F) = (B ≥ A)) →
  r4 B A) ∧
  ((∀ (A B C D E : Int),
  (r0 D C B) →
  (¬(0 : Int) = E) →
  (A = D) →
  (¬((0 : Int) = E) = (C ≥ B)) →
  r7 A D C B) ∧
  ((∀ (A B C D : Int),
  (r0 C B A) →
  ((0 : Int) = D) →
  (¬((0 : Int) = D) = (B ≥ A)) →
  r6 B A) ∧
  ((∀ (A B C D : Int),
  (r6 A B) →
  (¬(0 : Int) = D) →
  (¬((0 : Int) = D) = (C = (0 : Int))) →
  r2 A B) ∧
  ((∀ (A B C D E : Int),
  (r6 E B) →
  (r1 A E B) →
  (¬(0 : Int) = D) →
  (¬((0 : Int) = D) = (C = (0 : Int))) →
  r3 A E B) ∧
  ((∀ (A B C D : Int),
  (r4 A B) →
  (¬(0 : Int) = D) →
  (¬((0 : Int) = D) = (C = (0 : Int))) →
  r2 A B) ∧
  ((∀ (A B C D E : Int),
  (r4 E B) →
  (r1 A E B) →
  (¬(0 : Int) = D) →
  (¬((0 : Int) = D) = (C = (0 : Int))) →
  r5 A E B) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r2 C B →
    ((0 : Int) = F) = (B ≤ C) →
      ¬((0 : Int) = E) = ((0 : Int) ≤ C) → ¬(0 : Int) = G → D = (1 : Int) → A = (0 : Int) → ¬a!1 → r1 A C B) ∧
  ((∀ (A B C v_3 : Int),
  (¬(0 : Int) = C) →
  (¬((0 : Int) = C) = (B = (0 : Int))) →
  (v_3 = B) →
  r0 B v_3 A) ∧
  (∀ (A B C D E : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  r2 B A → ((0 : Int) = D) = (A ≤ B) → ¬((0 : Int) = C) = ((0 : Int) ≤ B) → (0 : Int) = E → ¬a!1 → False))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«dotprod_lin_000»
