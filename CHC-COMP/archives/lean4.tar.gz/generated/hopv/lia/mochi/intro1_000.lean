import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«intro1_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/intro1_000.smt2":52:1-52:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/intro1_000.smt2":8:1-18:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/intro1_000.smt2":19:1-29:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/intro1_000.smt2":30:1-39:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/intro1_000.smt2":40:1-50:2 (clause 4, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  ∃ (r2 : Int → Prop),
  (∀ (A B : Int),
  (r1 A) →
  (B = (1 : Int) + A) →
  r0 B A) ∧
  ((∀ (A B C : Int),
  (r0 A B) →
  (¬(0 : Int) = C) →
  (((0 : Int) = C) = (B ≤ (0 : Int))) →
  r2 A) ∧
  ((∀ (A B : Int),
  (¬(0 : Int) = B) →
  (((0 : Int) = B) = (A ≤ (0 : Int))) →
  r1 A) ∧
  (∀ (A B : Int),
  (r2 A) →
  ((0 : Int) = B) →
  (((0 : Int) = B) = (A ≤ (0 : Int))) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«intro1_000»
