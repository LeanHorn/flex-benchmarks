import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«bsearch_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bsearch_000.smt2":144:1-144:12 (check-sat, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bsearch_000.smt2":11:1-20:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bsearch_000.smt2":21:1-32:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bsearch_000.smt2":33:1-51:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bsearch_000.smt2":52:1-72:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bsearch_000.smt2":73:1-87:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bsearch_000.smt2":88:1-97:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bsearch_000.smt2":98:1-113:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bsearch_000.smt2":114:1-130:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bsearch_000.smt2":131:1-142:2 (clause 9, command 16)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Prop),
  (∀ (A B : Int),
  (A = B) →
  r4 A B) ∧
  ((∀ (A B C D E : Int),
  (r4 C B) →
  (r2 B A) →
  (D = (0 : Int)) →
  (E = (-1 : Int) + C) →
  r0 E D B A) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 C B A E) →
  (r5 G D A) →
  (((0 : Int) = J) = (B ≤ C)) →
  (¬(0 : Int) = K) →
  ((0 : Int) = J) →
  (D = B + I) →
  (I = H / (2 : Int)) →
  (H = C + (-1 : Int) * B) →
  (F = (1 : Int) + D) →
  (((0 : Int) = K) = (E ≤ G)) →
  r0 C F A E) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r0 C B A E) →
  (r5 G D A) →
  (((0 : Int) = L) = (G ≤ E)) →
  (((0 : Int) = K) = (E ≤ G)) →
  ((0 : Int) = J) →
  (¬(0 : Int) = L) →
  ((0 : Int) = K) →
  (D = B + I) →
  (I = H / (2 : Int)) →
  (H = C + (-1 : Int) * B) →
  (F = (-1 : Int) + D) →
  (((0 : Int) = J) = (B ≤ C)) →
  r0 F B A E) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 C B A E) →
  ((0 : Int) = H) →
  (F = C + (-1 : Int) * B) →
  (D = B + G) →
  (G = F / (2 : Int)) →
  (((0 : Int) = H) = (B ≤ C)) →
  r1 D A) ∧
  ((∀ (A B : Int),
  (A = B) →
  r3 A B) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  r3 F B → r3 G A → ¬((0 : Int) = D) = (A = B) → ¬((0 : Int) = C) = ((0 : Int) ≤ A) → ¬(0 : Int) = E → ¬a!1 → r2 F G) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = F ∧ ¬(0 : Int) = E);
  r1 C B →
    ¬a!1 →
      ((0 : Int) = F) = (B ≤ C) →
        ¬(0 : Int) = G → D = (1 : Int) → A = (0 : Int) → ¬((0 : Int) = E) = ((0 : Int) ≤ C) → r5 A C B) ∧
  (∀ (A B C D E : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = D ∧ ¬(0 : Int) = C);
  r1 B A → ¬a!1 → ((0 : Int) = D) = (A ≤ B) → (0 : Int) = E → ¬((0 : Int) = C) = ((0 : Int) ≤ B) → False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«bsearch_000»
