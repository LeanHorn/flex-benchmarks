import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«a-init_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":271:1-271:12 (check-sat, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":16:1-26:2 (clause 1, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":27:1-38:2 (clause 2, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":39:1-50:2 (clause 3, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":51:1-62:2 (clause 4, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":63:1-74:2 (clause 5, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":75:1-85:2 (clause 6, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":86:1-96:2 (clause 7, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":97:1-107:2 (clause 8, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":108:1-122:2 (clause 9, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":123:1-138:2 (clause 10, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":139:1-155:2 (clause 11, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":156:1-173:2 (clause 12, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":174:1-190:2 (clause 13, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":191:1-206:2 (clause 14, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":207:1-225:2 (clause 15, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":226:1-247:2 (clause 16, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":248:1-259:2 (clause 17, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-init_000.smt2":260:1-269:2 (clause 18, command 30)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Prop),
  ∃ (r6 : Prop),
  ∃ (r7 : Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Prop),
  (∀ (A B C D E F : Int),
  (r10 A C E) →
  ((0 : Int) = F) →
  (E = (1 : Int) + B) →
  (D = (1 : Int)) →
  (¬((0 : Int) = F) = (B ≥ C)) →
  r0 A D B) ∧
  ((∀ (A B C D E F G : Int),
  (r10 E C F) →
  (r4 A E D B) →
  ((0 : Int) = G) →
  (F = (1 : Int) + B) →
  (D = (1 : Int)) →
  (¬((0 : Int) = G) = (B ≥ C)) →
  r2 A E C F) ∧
  ((∀ (A B C D E : Int),
  (r2 B A D C) →
  (r9 A D C) →
  (¬(0 : Int) = E) →
  (¬((0 : Int) = E) = (C ≥ D)) →
  r3 B A D C) ∧
  ((∀ (A B C D E F : Int),
  (r2 A B D C) →
  (r5 B C) →
  ((0 : Int) = F) →
  (E = (1 : Int)) →
  (¬((0 : Int) = F) = (C ≥ D)) →
  r7 A B C) ∧
  ((∀ (A B C D E F G : Int),
  (r9 A D C) →
  (r3 B A D F) →
  ((0 : Int) = G) →
  (F = (1 : Int) + C) →
  (E = (1 : Int)) →
  (¬((0 : Int) = G) = (C ≥ D)) →
  r3 B A D C) ∧
  ((∀ (A B C D : Int),
  (r9 A C B) →
  (¬(0 : Int) = D) →
  (¬((0 : Int) = D) = (B ≥ C)) →
  r10 A C B) ∧
  ((∀ (A B C D E F : Int),
  (r9 A C B) →
  ((0 : Int) = F) →
  (E = (1 : Int) + B) →
  (D = (1 : Int)) →
  (¬((0 : Int) = F) = (B ≥ C)) →
  r9 A C E) ∧
  ((∀ (A B C D E : Int),
  (r5 A B) →
  ((0 : Int) = E) →
  (D = (1 : Int)) →
  (¬((0 : Int) = E) = (B ≥ C)) →
  r10 A C B) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  r10 A C B → ¬((0 : Int) = E) = (B ≤ (0 : Int)) → ¬((0 : Int) = D) = (B ≥ (0 : Int)) → ¬(0 : Int) = F → ¬a!1 → r8 A C) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  r10 G C B →
    r1 A G C →
      ¬((0 : Int) = E) = (B ≤ (0 : Int)) → ¬((0 : Int) = D) = (B ≥ (0 : Int)) → ¬(0 : Int) = F → ¬a!1 → r2 A G C B) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r8 C B →
    ((0 : Int) = F) = (B ≤ C) →
      ¬((0 : Int) = E) = ((0 : Int) ≤ C) → ¬(0 : Int) = G → A = (0 : Int) → D = (1 : Int) → ¬a!1 → r1 A C B) ∧
  ((∀ (A B C D E F G H I : Int),
  let a!1 := ((0 : Int) = H) = (¬(0 : Int) = F ∧ ¬(0 : Int) = G);
  r7 I D B →
    r0 D C B →
      ¬((0 : Int) = G) = (D ≤ B) →
        ((0 : Int) = F) = (D ≤ E) → (0 : Int) = H → A = I → E = (-1 : Int) + B → ¬a!1 → r4 A D C B) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ((0 : Int) = H) = (¬(0 : Int) = F ∧ ¬(0 : Int) = G);
  r0 D C B →
    ¬((0 : Int) = G) = (D ≤ B) →
      ((0 : Int) = F) = (D ≤ E) → ¬(0 : Int) = H → A = C → E = (-1 : Int) + B → ¬a!1 → r4 A D C B) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r0 C B A → ¬((0 : Int) = F) = (C ≤ A) → ((0 : Int) = E) = (C ≤ D) → (0 : Int) = G → D = (-1 : Int) + A → ¬a!1 → r5 C A) ∧
  ((∀ (A B C D E F G H I : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  let a!2 := ((0 : Int) = I) = (¬(0 : Int) = G ∧ ¬(0 : Int) = H);
  ((0 : Int) = H) = (B ≤ C) →
    ¬((0 : Int) = G) = ((0 : Int) ≤ C) →
      ¬a!1 →
        ¬((0 : Int) = E) = (A ≤ (0 : Int)) →
          ¬((0 : Int) = D) = (A ≥ (0 : Int)) → ¬(0 : Int) = I → ¬(0 : Int) = F → ¬a!2 → r9 C B A) ∧
  ((∀ (A B C D E F G H I J K : Int),
  let a!1 := ((0 : Int) = I) = (¬(0 : Int) = G ∧ ¬(0 : Int) = H);
  let a!2 := ((0 : Int) = F) = (¬(0 : Int) = E ∧ ¬(0 : Int) = D);
  r3 J C B A →
    ¬((0 : Int) = E) = (A ≤ (0 : Int)) →
      ¬((0 : Int) = K) = (J ≥ (1 : Int)) →
        ¬a!1 →
          ((0 : Int) = H) = (B ≤ C) →
            ¬((0 : Int) = G) = ((0 : Int) ≤ C) →
              ¬a!2 → (0 : Int) = K → ¬(0 : Int) = I → ¬(0 : Int) = F → ¬((0 : Int) = D) = (A ≥ (0 : Int)) → r6) ∧
  ((∀ (A B C D E : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  r8 B A → ((0 : Int) = D) = (A ≤ B) → ¬((0 : Int) = C) = ((0 : Int) ≤ B) → (0 : Int) = E → ¬a!1 → r6) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r6) →
  False)))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«a-init_000»
