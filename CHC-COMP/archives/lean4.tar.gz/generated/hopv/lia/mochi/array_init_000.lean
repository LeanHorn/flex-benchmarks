import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«array_init_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/array_init_000.smt2":135:1-135:12 (check-sat, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/array_init_000.smt2":10:1-20:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/array_init_000.smt2":21:1-31:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/array_init_000.smt2":32:1-42:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/array_init_000.smt2":43:1-53:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/array_init_000.smt2":54:1-64:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/array_init_000.smt2":65:1-79:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/array_init_000.smt2":80:1-94:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/array_init_000.smt2":95:1-105:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/array_init_000.smt2":106:1-115:2 (clause 9, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/array_init_000.smt2":116:1-133:2 (clause 10, command 16)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  (∀ (A B C D E F G : Int),
  (r2 A E D B) →
  ((0 : Int) = G) →
  (F = (1 : Int) + B) →
  (D = (1 : Int)) →
  (¬((0 : Int) = G) = (B ≥ C)) →
  r0 A E C F) ∧
  ((∀ (A B C D E : Int),
  (r0 B A D C) →
  (¬(0 : Int) = E) →
  (¬((0 : Int) = E) = (C ≥ D)) →
  r1 B A D C) ∧
  ((∀ (A B C D E F : Int),
  (r0 A D C B) →
  ((0 : Int) = F) →
  (E = (1 : Int)) →
  (¬((0 : Int) = F) = (B ≥ C)) →
  r4 A D B) ∧
  ((∀ (A B C D E F G : Int),
  (r1 B A D F) →
  ((0 : Int) = G) →
  (F = (1 : Int) + C) →
  (E = (1 : Int)) →
  (¬((0 : Int) = G) = (C ≥ D)) →
  r1 B A D C) ∧
  ((∀ (A B C D : Int),
  (r3 A C B) →
  (D = (0 : Int)) →
  r0 A C B D) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  ¬((0 : Int) = D) = ((0 : Int) ≤ C) → ¬a!1 → ¬(0 : Int) = F → A = (0 : Int) → ((0 : Int) = E) = (B ≤ C) → r3 A C B) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  ¬((0 : Int) = D) = ((0 : Int) ≤ C) → ¬a!1 → (0 : Int) = F → A = (-1 : Int) → ((0 : Int) = E) = (B ≤ C) → r3 A C B) ∧
  ((∀ (A B C D E F : Int),
  (r4 F D B) →
  ((0 : Int) = E) →
  (A = F) →
  (¬((0 : Int) = E) = (D = B)) →
  r2 A D C B) ∧
  ((∀ (A B C D E : Int),
  (¬(0 : Int) = E) →
  (A = C) →
  (¬((0 : Int) = E) = (D = B)) →
  r2 A D C B) ∧
  (∀ (A B C D E F G H : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = D ∧ ¬(0 : Int) = C);
  r1 F B A H →
    ¬((0 : Int) = G) = (F ≥ (1 : Int)) →
      ¬a!1 →
        ((0 : Int) = D) = (A ≤ B) →
          (0 : Int) = G → ¬(0 : Int) = E → H = (0 : Int) → ¬((0 : Int) = C) = ((0 : Int) ≤ B) → False)))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«array_init_000»
