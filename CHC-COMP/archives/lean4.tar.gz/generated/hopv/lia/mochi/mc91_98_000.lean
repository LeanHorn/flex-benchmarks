import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«mc91_98_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_98_000.smt2":43:1-43:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_98_000.smt2":6:1-17:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_98_000.smt2":18:1-27:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/mc91_98_000.smt2":28:1-41:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  (∀ (A B C D E F : Int),
  (r0 E D) →
  (r0 F E) →
  ((0 : Int) = C) →
  (D = (11 : Int) + B) →
  (A = F) →
  (((0 : Int) = C) = (B ≤ (100 : Int))) →
  r0 A B) ∧
  ((∀ (A B C : Int),
  (¬(0 : Int) = C) →
  (A = (-10 : Int) + B) →
  (((0 : Int) = C) = (B ≤ (100 : Int))) →
  r0 A B) ∧
  (∀ (A B C D : Int),
  (r0 C A) →
  (¬((0 : Int) = B) = (A ≤ (98 : Int))) →
  ((0 : Int) = D) →
  (¬(0 : Int) = B) →
  (¬((0 : Int) = D) = (C = (91 : Int))) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«mc91_98_000»
