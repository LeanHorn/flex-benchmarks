import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«bcopy3_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy3_000.smt2":123:1-123:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy3_000.smt2":10:1-22:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy3_000.smt2":23:1-33:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy3_000.smt2":34:1-47:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy3_000.smt2":48:1-59:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy3_000.smt2":60:1-71:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy3_000.smt2":72:1-81:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy3_000.smt2":82:1-92:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy3_000.smt2":93:1-109:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy3_000.smt2":110:1-121:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  (∀ (A B C D E F : Int),
  (r3 A C) →
  (r4 B C) →
  (r2 E B C) →
  ((0 : Int) = F) →
  (D = (1 : Int) + B) →
  (¬((0 : Int) = F) = (B ≥ C)) →
  r3 A C) ∧
  ((∀ (A B C : Int),
  (r4 A B) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (A ≥ B)) →
  r3 A B) ∧
  ((∀ (A B C D E F G : Int),
  (r3 D C) →
  (r4 B C) →
  (r2 F B C) →
  (r2 A D C) →
  ((0 : Int) = G) →
  (E = (1 : Int) + B) →
  (¬((0 : Int) = G) = (B ≥ C)) →
  r2 A D C) ∧
  ((∀ (A B C D E F : Int),
  (r3 F B) →
  (r1 A F B) →
  (¬(0 : Int) = D) →
  (E = (0 : Int)) →
  (¬((0 : Int) = D) = (B ≤ C)) →
  r2 A F B) ∧
  ((∀ (A B C D E : Int),
  (r2 D A B) →
  (r4 A B) →
  ((0 : Int) = E) →
  (C = (1 : Int) + A) →
  (¬((0 : Int) = E) = (A ≥ B)) →
  r4 C B) ∧
  ((∀ (A B C D : Int),
  (¬(0 : Int) = C) →
  (D = (0 : Int)) →
  (¬((0 : Int) = C) = (A ≤ B)) →
  r4 D A) ∧
  ((∀ (A B C D E : Int),
  (r3 A B) →
  (¬(0 : Int) = D) →
  (E = (0 : Int)) →
  (¬((0 : Int) = D) = (B ≤ C)) →
  r0 A B) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r0 C B →
    ((0 : Int) = F) = (B ≤ C) →
      ¬((0 : Int) = E) = ((0 : Int) ≤ C) → ¬(0 : Int) = G → A = (0 : Int) → D = (1 : Int) → ¬a!1 → r1 A C B) ∧
  (∀ (A B C D E : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  r0 B A → ((0 : Int) = D) = (A ≤ B) → ¬((0 : Int) = C) = ((0 : Int) ≤ B) → (0 : Int) = E → ¬a!1 → False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«bcopy3_000»
