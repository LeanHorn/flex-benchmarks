import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«neg2_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/neg2_000.smt2":89:1-89:12 (check-sat, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/neg2_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/neg2_000.smt2":20:1-31:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/neg2_000.smt2":32:1-41:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/neg2_000.smt2":42:1-53:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/neg2_000.smt2":54:1-65:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/neg2_000.smt2":66:1-77:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/neg2_000.smt2":78:1-87:2 (clause 7, command 13)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Prop),
  ∃ (r2 : Int → Int → Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  (∀ (A B : Int),
  (A = (2 : Int) * B) →
  r0 A B) ∧
  ((∀ (A B C D : Int),
  (r0 C B) →
  (r2 A D) →
  (True) →
  r4 A D C) ∧
  ((∀ (A B : Int),
  (A = (-1 : Int) * B) →
  r2 A B) ∧
  ((∀ (A B C D v_4 : Int),
  (r4 C B v_4) →
  (r4 D C B) →
  (v_4 = B) →
  (A = D) →
  r3 A B) ∧
  ((∀ (A B C D E : Int),
  (r3 B E) →
  (r0 E A) →
  (¬((0 : Int) = D) = (B ≥ (0 : Int))) →
  (¬(0 : Int) = C) →
  ((0 : Int) = D) →
  (((0 : Int) = C) = (A ≤ (0 : Int))) →
  r1) ∧
  ((∀ (A B C D E : Int),
  (r3 B E) →
  (r0 E A) →
  (¬((0 : Int) = D) = (B ≤ (0 : Int))) →
  ((0 : Int) = C) →
  ((0 : Int) = D) →
  (((0 : Int) = C) = (A ≤ (0 : Int))) →
  r1) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r1) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«neg2_000»
