import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«bcopy_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy_000.smt2":162:1-162:12 (check-sat, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy_000.smt2":14:1-23:2 (clause 1, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy_000.smt2":24:1-35:2 (clause 2, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy_000.smt2":36:1-48:2 (clause 3, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy_000.smt2":49:1-60:2 (clause 4, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy_000.smt2":61:1-71:2 (clause 5, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy_000.smt2":72:1-81:2 (clause 6, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy_000.smt2":82:1-93:2 (clause 7, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy_000.smt2":94:1-110:2 (clause 8, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy_000.smt2":111:1-126:2 (clause 9, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy_000.smt2":127:1-138:2 (clause 10, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy_000.smt2":139:1-150:2 (clause 11, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy_000.smt2":151:1-160:2 (clause 12, command 22)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Prop),
  ∃ (r7 : Prop),
  ∃ (r8 : Int → Int → Int → Prop),
  (∀ (A B : Int),
  (A = B) →
  r6 A B) ∧
  ((∀ (A B C D : Int),
  (r6 C A) →
  (r3 B A) →
  (D = (0 : Int)) →
  r2 C D B A) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 C B A D) →
  (r5 G F B A) →
  (r8 F B D) →
  ((0 : Int) = H) →
  (E = (1 : Int) + B) →
  (¬((0 : Int) = H) = (B ≥ C)) →
  r2 C E A D) ∧
  ((∀ (A B C D E F : Int),
  (r2 C B A D) →
  (r8 E B D) →
  ((0 : Int) = F) →
  (¬((0 : Int) = F) = (B ≥ C)) →
  r0 E B A) ∧
  ((∀ (A B C D E : Int),
  (r2 C B A D) →
  ((0 : Int) = E) →
  (¬((0 : Int) = E) = (B ≥ C)) →
  r1 B D) ∧
  ((∀ (A B : Int),
  (A = B) →
  r4 A B) ∧
  ((∀ (A B C D E : Int),
  (r4 D B) →
  (r4 E A) →
  (¬(0 : Int) = C) →
  (¬((0 : Int) = C) = (A ≤ B)) →
  r3 D E) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = F ∧ ¬(0 : Int) = E);
  r1 C B →
    ¬a!1 →
      ((0 : Int) = F) = (B ≤ C) →
        ¬(0 : Int) = G → A = (0 : Int) → D = (1 : Int) → ¬((0 : Int) = E) = ((0 : Int) ≤ C) → r8 A C B) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = F ∧ ¬(0 : Int) = E);
  r0 D C B →
    ¬a!1 → ((0 : Int) = F) = (B ≤ C) → ¬(0 : Int) = G → A = (1 : Int) → ¬((0 : Int) = E) = ((0 : Int) ≤ C) → r5 A D C B) ∧
  ((∀ (A B C D E : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = D ∧ ¬(0 : Int) = C);
  r1 B A → ¬a!1 → ((0 : Int) = D) = (A ≤ B) → (0 : Int) = E → ¬((0 : Int) = C) = ((0 : Int) ≤ B) → r7) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = E ∧ ¬(0 : Int) = D);
  r0 C B A → ¬a!1 → ((0 : Int) = E) = (A ≤ B) → (0 : Int) = F → ¬((0 : Int) = D) = ((0 : Int) ≤ B) → r7) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r7) →
  False)))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«bcopy_000»
