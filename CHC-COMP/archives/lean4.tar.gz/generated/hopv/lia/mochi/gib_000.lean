import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«gib_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/gib_000.smt2":68:1-68:12 (check-sat, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/gib_000.smt2":6:1-23:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/gib_000.smt2":24:1-33:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/gib_000.smt2":34:1-47:2 (clause 3, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/gib_000.smt2":48:1-66:2 (clause 4, command 6)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J : Int),
  (r0 G F C B) →
  (r0 J I C B) →
  (¬((0 : Int) = E) = (D = (0 : Int))) →
  ((0 : Int) = H) →
  ((0 : Int) = E) →
  (I = (-1 : Int) + D) →
  (F = (-2 : Int) + D) →
  (A = J + G) →
  (¬((0 : Int) = H) = (D = (1 : Int))) →
  r0 A D C B) ∧
  ((∀ (A B C D E : Int),
  (¬(0 : Int) = E) →
  (A = B) →
  (¬((0 : Int) = E) = (D = (0 : Int))) →
  r0 A D C B) ∧
  ((∀ (A B C D E F : Int),
  (¬((0 : Int) = E) = (D = (0 : Int))) →
  (¬(0 : Int) = F) →
  ((0 : Int) = E) →
  (A = C) →
  (¬((0 : Int) = F) = (D = (1 : Int))) →
  r0 A D C B) ∧
  (∀ (A B C D E F G H I J : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  r0 I A H G →
    ¬a!1 →
      ¬((0 : Int) = E) = (C ≥ (0 : Int)) →
        ¬((0 : Int) = D) = (B ≥ (0 : Int)) →
          (0 : Int) = J → ¬(0 : Int) = F → H = (1 : Int) → G = (0 : Int) → ¬((0 : Int) = J) = (I ≥ (0 : Int)) → False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«gib_000»
