import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«sum_intro_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_intro_000.smt2":51:1-51:12 (check-sat, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_intro_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_intro_000.smt2":17:1-28:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_intro_000.smt2":29:1-38:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_intro_000.smt2":39:1-49:2 (clause 4, command 7)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  (∀ (A B C : Int),
  (A = B + C) →
  r1 A C B) ∧
  ((∀ (A B C D E F : Int),
  (r1 F E B) →
  (r0 E D) →
  ((0 : Int) = C) →
  (A = F) →
  (D = (-1 : Int) + B) →
  (¬((0 : Int) = C) = (B ≤ (0 : Int))) →
  r0 A B) ∧
  ((∀ (A B C : Int),
  (¬(0 : Int) = C) →
  (A = (0 : Int)) →
  (¬((0 : Int) = C) = (B ≤ (0 : Int))) →
  r0 A B) ∧
  (∀ (A B C : Int),
  (r0 C A) →
  ((0 : Int) = B) →
  (¬((0 : Int) = B) = (A ≤ C)) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«sum_intro_000»
