import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«sigma_sum_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sigma_sum_000.smt2":86:1-86:12 (check-sat, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sigma_sum_000.smt2":8:1-19:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sigma_sum_000.smt2":20:1-30:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sigma_sum_000.smt2":31:1-42:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sigma_sum_000.smt2":43:1-52:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sigma_sum_000.smt2":53:1-63:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sigma_sum_000.smt2":64:1-73:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sigma_sum_000.smt2":74:1-84:2 (clause 7, command 11)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  (∀ (A B C D E F : Int),
  (r2 A B) →
  (r2 E C) →
  ((0 : Int) = D) →
  (F = (-1 : Int) + C) →
  (¬((0 : Int) = D) = (C ≤ (0 : Int))) →
  r2 A B) ∧
  ((∀ (A B : Int),
  (r0 A B) →
  (True) →
  r2 A B) ∧
  ((∀ (A B C D E F : Int),
  (r2 E B) →
  (r1 C F) →
  ((0 : Int) = D) →
  (A = E + C) →
  (F = (-1 : Int) + B) →
  (¬((0 : Int) = D) = (B ≤ (0 : Int))) →
  r1 A B) ∧
  ((∀ (A B C : Int),
  (¬(0 : Int) = C) →
  (A = (0 : Int)) →
  (¬((0 : Int) = C) = (B ≤ (0 : Int))) →
  r1 A B) ∧
  ((∀ (A B C D E : Int),
  (r0 E D) →
  ((0 : Int) = C) →
  (A = B + E) →
  (D = (-1 : Int) + B) →
  (¬((0 : Int) = C) = (B ≤ (0 : Int))) →
  r0 A B) ∧
  ((∀ (A B C : Int),
  (¬(0 : Int) = C) →
  (A = (0 : Int)) →
  (¬((0 : Int) = C) = (B ≤ (0 : Int))) →
  r0 A B) ∧
  (∀ (A B C : Int),
  (r1 B A) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (B ≥ A)) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«sigma_sum_000»
