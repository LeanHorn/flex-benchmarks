import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«queen_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":687:1-687:12 (check-sat, command 68)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":28:1-38:2 (clause 1, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":39:1-48:2 (clause 2, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":49:1-60:2 (clause 3, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":61:1-72:2 (clause 4, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":73:1-83:2 (clause 5, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":84:1-94:2 (clause 6, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":95:1-107:2 (clause 7, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":108:1-120:2 (clause 8, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":121:1-141:2 (clause 9, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":142:1-163:2 (clause 10, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":164:1-177:2 (clause 11, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":178:1-199:2 (clause 12, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":200:1-219:2 (clause 13, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":220:1-231:2 (clause 14, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":232:1-244:2 (clause 15, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":245:1-256:2 (clause 16, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":257:1-266:2 (clause 17, command 41)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":267:1-295:2 (clause 18, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":296:1-307:2 (clause 19, command 43)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":308:1-337:2 (clause 20, command 44)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":338:1-348:2 (clause 21, command 45)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":349:1-376:2 (clause 22, command 46)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":377:1-387:2 (clause 23, command 47)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":388:1-400:2 (clause 24, command 48)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":401:1-421:2 (clause 25, command 49)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":422:1-442:2 (clause 26, command 50)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":443:1-455:2 (clause 27, command 51)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":456:1-474:2 (clause 28, command 52)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":475:1-485:2 (clause 29, command 53)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":486:1-506:2 (clause 30, command 54)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":507:1-518:2 (clause 31, command 55)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":519:1-540:2 (clause 32, command 56)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":541:1-560:2 (clause 33, command 57)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":561:1-575:2 (clause 34, command 58)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":576:1-585:2 (clause 35, command 59)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":586:1-597:2 (clause 36, command 60)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":598:1-617:2 (clause 37, command 61)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":618:1-627:2 (clause 38, command 62)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":628:1-637:2 (clause 39, command 63)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":638:1-647:2 (clause 40, command 64)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":648:1-657:2 (clause 41, command 65)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":658:1-667:2 (clause 42, command 66)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/queen_000.smt2":668:1-685:2 (clause 43, command 67)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Prop),
  ∃ (r8 : Int → Prop),
  ∃ (r9 : Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Prop),
  ∃ (r11 : Int → Int → Prop),
  ∃ (r12 : Int → Int → Int → Int → Prop),
  ∃ (r13 : Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Prop),
  ∃ (r16 : Int → Int → Int → Int → Prop),
  ∃ (r17 : Int → Int → Int → Int → Prop),
  ∃ (r18 : Int → Int → Int → Int → Prop),
  ∃ (r19 : Int → Int → Int → Prop),
  ∃ (r20 : Int → Int → Int → Int → Int → Prop),
  ∃ (r21 : Int → Int → Int → Prop),
  ∃ (r22 : Int → Int → Int → Prop),
  (∀ (A B C D E F G H : Int),
  (r18 H F C B) →
  ((0 : Int) = G) →
  (A = H) →
  (¬((0 : Int) = G) = (B = F)) →
  r2 A F E D C B) ∧
  ((∀ (A B C D E F G : Int),
  (¬(0 : Int) = G) →
  (A = D) →
  (¬((0 : Int) = G) = (B = F)) →
  r2 A F E D C B) ∧
  ((∀ (A B C D E v_5 : Int),
  (r16 A D C B) →
  (r16 E B C v_5) →
  (v_5 = B) →
  r18 A D C B) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r2 B A F E D C) →
  (r16 F C D v_6) →
  (v_6 = C) →
  r4 B A E D C) ∧
  ((∀ (A B C D E : Int),
  (r6 A E D C B) →
  (True) →
  r16 A E B C) ∧
  ((∀ (A B C D E : Int),
  (r4 B A E C D) →
  (True) →
  r20 B A E D C) ∧
  ((∀ (A B C D E F G v_7 : Int),
  (r1 C B) →
  (r17 G C v_7 B) →
  (r17 A D C B) →
  (v_7 = C) →
  ((0 : Int) = F) →
  (E = (1 : Int) + G) →
  (((0 : Int) = F) = (E ≤ B)) →
  r6 A D E C B) ∧
  ((∀ (A B C D E F G H v_8 : Int),
  (r1 C B) →
  (r17 H C v_8 B) →
  (r17 A D C B) →
  (v_8 = C) →
  (¬(0 : Int) = F) →
  (G = (0 : Int)) →
  (E = (1 : Int) + H) →
  (((0 : Int) = F) = (E ≤ B)) →
  r6 A D G C B) ∧
  ((∀ (A B C D E F G H I J v_10 : Int),
  (r20 A I D C B) →
  (r17 J C v_10 B) →
  (r1 C B) →
  (r19 F C B) →
  (v_10 = C) →
  (((0 : Int) = E) = (D ≤ B)) →
  (¬(0 : Int) = H) →
  (¬(0 : Int) = F) →
  ((0 : Int) = E) →
  (G = (1 : Int) + C) →
  (D = (1 : Int) + J) →
  (¬((0 : Int) = H) = (G = B)) →
  r9 A I B) ∧
  ((∀ (A B C D E F G H I J K v_11 : Int),
  (r20 A J D C B) →
  (r17 K C v_11 B) →
  (r7 I B) →
  (r1 C B) →
  (r19 F C B) →
  (v_11 = C) →
  (((0 : Int) = E) = (D ≤ B)) →
  (¬(0 : Int) = H) →
  (¬(0 : Int) = F) →
  ((0 : Int) = E) →
  (G = (1 : Int) + C) →
  (D = (1 : Int) + K) →
  (¬((0 : Int) = H) = (G = B)) →
  r17 A J C B) ∧
  ((∀ (A B C D E F G H v_8 : Int),
  (r20 A G D C B) →
  (r17 H C v_8 B) →
  (r19 F C B) →
  (r1 C B) →
  (v_8 = C) →
  ((0 : Int) = F) →
  ((0 : Int) = E) →
  (D = (1 : Int) + H) →
  (((0 : Int) = E) = (D ≤ B)) →
  r17 A G C B) ∧
  ((∀ (A B C D E F G H I J K v_11 : Int),
  (r20 A J D C B) →
  (r17 K C v_11 B) →
  (r19 F C B) →
  (r1 C B) →
  (v_11 = C) →
  (((0 : Int) = E) = (D ≤ B)) →
  ((0 : Int) = H) →
  (¬(0 : Int) = F) →
  ((0 : Int) = E) →
  (I = (1 : Int) + C) →
  (G = (1 : Int) + C) →
  (D = (1 : Int) + K) →
  (¬((0 : Int) = H) = (G = B)) →
  r17 A J I B) ∧
  ((∀ (A B C D E F G H I J v_10 : Int),
  (r20 A I H C B) →
  (r17 J C v_10 B) →
  (r1 C B) →
  (v_10 = C) →
  (((0 : Int) = E) = (D ≤ B)) →
  ((0 : Int) = F) →
  (¬(0 : Int) = E) →
  (H = (0 : Int)) →
  (G = (-1 : Int) + C) →
  (D = (1 : Int) + J) →
  (¬((0 : Int) = F) = (C = (0 : Int))) →
  r17 A I G B) ∧
  ((∀ (A B C D E : Int),
  (r14 A E D B) →
  (r8 B) →
  (C = (0 : Int)) →
  (D = (0 : Int)) →
  r17 A E C B) ∧
  ((∀ (A B C D E F G v_7 : Int),
  (r20 A F D C B) →
  (r17 G C v_7 B) →
  (r1 C B) →
  (v_7 = C) →
  ((0 : Int) = E) →
  (D = (1 : Int) + G) →
  (((0 : Int) = E) = (D ≤ B)) →
  r12 A F C B) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 F E B) →
  (r3 H G) →
  ((0 : Int) = D) →
  (G = (1 : Int)) →
  (E = (-1 : Int) + C) →
  (A = F) →
  (¬((0 : Int) = D) = (C = (0 : Int))) →
  r0 A C B) ∧
  ((∀ (A B C D : Int),
  (¬(0 : Int) = D) →
  (A = (1 : Int)) →
  (¬((0 : Int) = D) = (C = (0 : Int))) →
  r0 A C B) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  let a!1 := ((0 : Int) = R) = (¬(0 : Int) = P ∧ ¬(0 : Int) = Q);
  r0 K J B →
    r3 M L →
      r3 I H →
        r11 D B →
          r22 S D B →
            r22 A C B →
              r0 O N B →
                ¬a!1 →
                  ¬((0 : Int) = Q) = (D ≤ B) →
                    ¬((0 : Int) = P) = ((0 : Int) ≤ D) →
                      (0 : Int) = F →
                        ¬(0 : Int) = R →
                          E = (1 : Int) →
                            H = (1 : Int) →
                              G = (1 : Int) + D →
                                J = B + (-1 : Int) * S →
                                  N = (-1 : Int) + S → L = (1 : Int) → ¬((0 : Int) = F) = (D = B) → r22 A C B) ∧
  ((∀ (A B C D : Int),
  (r13 B) →
  (r9 A C B) →
  (D = (0 : Int)) →
  r22 A C B) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  let a!1 := ((0 : Int) = R) = (¬(0 : Int) = P ∧ ¬(0 : Int) = Q);
  r0 K J B →
    r3 M L →
      r3 I H →
        r21 G F B →
          r11 C B →
            r22 S C B →
              r0 O N B →
                ¬a!1 →
                  ¬((0 : Int) = Q) = (C ≤ B) →
                    ¬((0 : Int) = P) = ((0 : Int) ≤ C) →
                      (0 : Int) = E →
                        ¬(0 : Int) = R →
                          A = G →
                            D = (1 : Int) →
                              F = (1 : Int) + C →
                                H = (1 : Int) →
                                  J = B + (-1 : Int) * S →
                                    N = (-1 : Int) + S → L = (1 : Int) → ¬((0 : Int) = E) = (C = B) → r21 A C B) ∧
  ((∀ (A B C D : Int),
  (r11 C B) →
  (¬(0 : Int) = D) →
  (A = (1 : Int)) →
  (¬((0 : Int) = D) = (C = B)) →
  r21 A C B) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q : Int),
  let a!1 := ((0 : Int) = P) = (¬(0 : Int) = N ∧ ¬(0 : Int) = O);
  r0 I H A →
    r3 K J →
      r3 G F →
        r11 B A →
          r22 Q B A →
            r0 M L A →
              ¬a!1 →
                ¬((0 : Int) = O) = (B ≤ A) →
                  ¬((0 : Int) = N) = ((0 : Int) ≤ B) →
                    (0 : Int) = D →
                      ¬(0 : Int) = P →
                        C = (1 : Int) →
                          F = (1 : Int) →
                            E = (1 : Int) + B →
                              H = A + (-1 : Int) * Q →
                                L = (-1 : Int) + Q → J = (1 : Int) → ¬((0 : Int) = D) = (B = A) → r11 E A) ∧
  ((∀ (A B : Int),
  (r13 A) →
  (B = (0 : Int)) →
  r11 B A) ∧
  ((∀ (A B C D E F : Int),
  (r21 F E B) →
  (r3 D C) →
  (r13 B) →
  (C = (1 : Int)) →
  (A = D) →
  (E = (0 : Int)) →
  r7 A B) ∧
  ((∀ (A B C D E F G H I v_9 : Int),
  (r7 H A) →
  (r17 I B v_9 A) →
  (r1 B A) →
  (r19 E B A) →
  (v_9 = B) →
  (((0 : Int) = D) = (C ≤ A)) →
  (¬(0 : Int) = G) →
  (¬(0 : Int) = E) →
  ((0 : Int) = D) →
  (F = (1 : Int) + B) →
  (C = (1 : Int) + I) →
  (¬((0 : Int) = G) = (F = A)) →
  r1 B A) ∧
  ((∀ (A B C D E F G H I v_9 : Int),
  (r19 E B A) →
  (r17 I B v_9 A) →
  (r1 B A) →
  (v_9 = B) →
  (((0 : Int) = D) = (C ≤ A)) →
  ((0 : Int) = G) →
  (¬(0 : Int) = E) →
  ((0 : Int) = D) →
  (H = (1 : Int) + B) →
  (F = (1 : Int) + B) →
  (C = (1 : Int) + I) →
  (¬((0 : Int) = G) = (F = A)) →
  r1 H A) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r19 E B A) →
  (r17 F B v_6 A) →
  (r1 B A) →
  (v_6 = B) →
  ((0 : Int) = E) →
  ((0 : Int) = D) →
  (C = (1 : Int) + F) →
  (((0 : Int) = D) = (C ≤ A)) →
  r1 B A) ∧
  ((∀ (A B C D E F G H v_8 : Int),
  (r1 B A) →
  (r17 H B v_8 A) →
  (v_8 = B) →
  (((0 : Int) = D) = (C ≤ A)) →
  ((0 : Int) = E) →
  (¬(0 : Int) = D) →
  (G = (0 : Int)) →
  (F = (-1 : Int) + B) →
  (C = (1 : Int) + H) →
  (¬((0 : Int) = E) = (B = (0 : Int))) →
  r1 F A) ∧
  ((∀ (A B C : Int),
  (r8 A) →
  (B = (0 : Int)) →
  (C = (0 : Int)) →
  r1 B A) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r15 A D C B) →
  (r10 J I) →
  (r15 N F C B) →
  (¬((0 : Int) = H) = (N = E)) →
  (((0 : Int) = G) = (C ≤ F)) →
  ((0 : Int) = L) →
  ((0 : Int) = H) →
  (¬(0 : Int) = G) →
  (M = (1 : Int) + F) →
  (K = C + (-1 : Int) * F) →
  (I = E + (-1 : Int) * N) →
  (¬((0 : Int) = L) = (J = K)) →
  r15 A D C B) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r12 A D C B) →
  (r12 F C v_6 B) →
  (v_6 = C) →
  (E = (0 : Int)) →
  r15 A D C B) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  (r15 N E C B) →
  (r10 I H) →
  (r5 M L D C B) →
  (¬((0 : Int) = K) = (I = J)) →
  (¬((0 : Int) = G) = (N = D)) →
  (¬(0 : Int) = F) →
  ((0 : Int) = K) →
  ((0 : Int) = G) →
  (A = M) →
  (L = (1 : Int) + E) →
  (J = C + (-1 : Int) * E) →
  (H = D + (-1 : Int) * N) →
  (((0 : Int) = F) = (C ≤ E)) →
  r5 A E D C B) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r15 L E C B) →
  (r10 I H) →
  (¬((0 : Int) = G) = (L = D)) →
  (((0 : Int) = F) = (C ≤ E)) →
  (¬(0 : Int) = K) →
  ((0 : Int) = G) →
  (¬(0 : Int) = F) →
  (A = (0 : Int)) →
  (J = C + (-1 : Int) * E) →
  (H = D + (-1 : Int) * L) →
  (¬((0 : Int) = K) = (I = J)) →
  r5 A E D C B) ∧
  ((∀ (A B C D E F G H : Int),
  (r15 H E C B) →
  (((0 : Int) = F) = (C ≤ E)) →
  (¬(0 : Int) = G) →
  (¬(0 : Int) = F) →
  (A = (0 : Int)) →
  (¬((0 : Int) = G) = (H = D)) →
  r5 A E D C B) ∧
  ((∀ (A B C D E F : Int),
  ((0 : Int) = F) →
  (A = (1 : Int)) →
  (((0 : Int) = F) = (C ≤ E)) →
  r5 A E D C B) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r5 E D F C B) →
  (r12 F C v_6 B) →
  (v_6 = C) →
  (A = E) →
  (D = (0 : Int)) →
  r19 A C B) ∧
  ((∀ (A B C D E F G H v_8 : Int),
  (r19 E B A) →
  (r17 H B v_8 A) →
  (r1 B A) →
  (v_8 = B) →
  (((0 : Int) = D) = (C ≤ A)) →
  (¬(0 : Int) = G) →
  (¬(0 : Int) = E) →
  ((0 : Int) = D) →
  (F = (1 : Int) + B) →
  (C = (1 : Int) + H) →
  (¬((0 : Int) = G) = (F = A)) →
  r13 A) ∧
  ((∀ (A B C : Int),
  (¬(0 : Int) = C) →
  (A = (-1 : Int) * B) →
  (((0 : Int) = C) = ((0 : Int) ≤ B)) →
  r10 A B) ∧
  ((∀ (A B C : Int),
  ((0 : Int) = C) →
  (A = B) →
  (((0 : Int) = C) = ((0 : Int) ≤ B)) →
  r10 A B) ∧
  ((∀ (A B C D : Int),
  (A = C) →
  r14 A D C B) ∧
  ((∀ (A B : Int),
  (A = (1 : Int)) →
  r3 A B) ∧
  ((∀ (A B : Int),
  (¬(0 : Int) = B) →
  (((0 : Int) = B) = (A ≤ (0 : Int))) →
  r8 A) ∧
  (∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  r11 B A →
    r22 G B A →
      ¬((0 : Int) = E) = (B ≤ A) →
        ¬((0 : Int) = D) = ((0 : Int) ≤ B) → ¬((0 : Int) = C) = (B = A) → (0 : Int) = F → (0 : Int) = C → ¬a!1 → False))))))))))))))))))))))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«queen_000»
