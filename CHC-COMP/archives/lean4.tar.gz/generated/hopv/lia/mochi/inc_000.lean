import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«inc_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc_000.smt2":145:1-145:12 (check-sat, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc_000.smt2":20:1-40:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc_000.smt2":41:1-50:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc_000.smt2":51:1-61:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc_000.smt2":62:1-83:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc_000.smt2":84:1-105:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc_000.smt2":106:1-116:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc_000.smt2":117:1-126:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc_000.smt2":127:1-143:2 (clause 9, command 15)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Prop),
  (∀ (A B : Int),
  (B = (0 : Int)) →
  r1 B A) ∧
  ((∀ (A B C D E F G H I J : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r3 I B A →
    r1 B A →
      ¬((0 : Int) = E) = ((0 : Int) ≤ B) →
        ((0 : Int) = H) = (A ≤ B) →
          ¬a!1 →
            ¬(0 : Int) = H →
              ¬(0 : Int) = G → D = (1 : Int) + B → C = (1 : Int) → J = (1 : Int) + I → ((0 : Int) = F) = (A ≤ B) → r1 D A) ∧
  ((∀ (A B : Int),
  (A = (0 : Int)) →
  r2 A B) ∧
  ((∀ (A B C D : Int),
  (r2 A D) →
  (C = (0 : Int)) →
  r3 A D B) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  let a!1 := ((0 : Int) = I) = (¬(0 : Int) = G ∧ ¬(0 : Int) = H);
  r3 K C B →
    r4 A E L C →
      r1 C B →
        ¬((0 : Int) = G) = ((0 : Int) ≤ C) →
          ((0 : Int) = J) = (B ≤ C) →
            ¬a!1 →
              ¬(0 : Int) = J →
                ¬(0 : Int) = I →
                  F = (1 : Int) + C → D = (1 : Int) → L = (1 : Int) + K → ((0 : Int) = H) = (B ≤ C) → r3 A E B) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  let a!1 := ((0 : Int) = I) = (¬(0 : Int) = G ∧ ¬(0 : Int) = H);
  r3 A C B →
    r3 K D B →
      r1 D B →
        ¬((0 : Int) = G) = ((0 : Int) ≤ D) →
          ((0 : Int) = J) = (B ≤ D) →
            ¬a!1 →
              ¬(0 : Int) = J →
                ¬(0 : Int) = I →
                  F = (1 : Int) + D → E = (1 : Int) → L = (1 : Int) + K → ((0 : Int) = H) = (B ≤ D) → r0 A C) ∧
  ((∀ (A B C D E F : Int),
  (r0 F D) →
  ((0 : Int) = E) →
  (A = F) →
  (¬((0 : Int) = E) = (D = B)) →
  r4 A D C B) ∧
  ((∀ (A B C D E : Int),
  (¬(0 : Int) = E) →
  (A = C) →
  (¬((0 : Int) = E) = (D = B)) →
  r4 A D C B) ∧
  (∀ (A B C D E F : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  r1 B A →
    ¬((0 : Int) = C) = ((0 : Int) ≤ B) →
      ¬a!1 → ((0 : Int) = F) = (A ≤ B) → (0 : Int) = E → ¬(0 : Int) = F → ((0 : Int) = D) = (A ≤ B) → False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«inc_000»
