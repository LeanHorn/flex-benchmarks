import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«inc3_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":192:1-192:12 (check-sat, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":14:1-27:2 (clause 1, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":28:1-40:2 (clause 2, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":41:1-51:2 (clause 3, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":52:1-66:2 (clause 4, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":67:1-78:2 (clause 5, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":79:1-92:2 (clause 6, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":93:1-105:2 (clause 7, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":106:1-115:2 (clause 8, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":116:1-127:2 (clause 9, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":128:1-138:2 (clause 10, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":139:1-155:2 (clause 11, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":156:1-167:2 (clause 12, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":168:1-178:2 (clause 13, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/inc3_000.smt2":179:1-190:2 (clause 14, command 24)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Prop),
  (∀ (A B C D E F G H : Int),
  (r7 A C) →
  (r6 F E C B) →
  (r2 B C) →
  (r8 D B C) →
  ((0 : Int) = G) →
  (H = (1 : Int) + B) →
  (E = (1 : Int) + D) →
  (¬((0 : Int) = G) = (B ≥ C)) →
  r7 A C) ∧
  ((∀ (A B C D E F : Int),
  (r8 D B C) →
  (r0 A C B) →
  (r2 B C) →
  ((0 : Int) = F) →
  (E = (1 : Int) + D) →
  (¬((0 : Int) = F) = (B ≥ C)) →
  r7 A C) ∧
  ((∀ (A B C : Int),
  (r2 A B) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (A ≥ B)) →
  r7 A B) ∧
  ((∀ (A B C D E F G H I : Int),
  (r7 B D) →
  (r6 G F D C) →
  (r2 C D) →
  (r8 E C D) →
  (r8 A B D) →
  ((0 : Int) = H) →
  (I = (1 : Int) + C) →
  (F = (1 : Int) + E) →
  (¬((0 : Int) = H) = (C ≥ D)) →
  r8 A B D) ∧
  ((∀ (A B C D E : Int),
  (r7 D B) →
  (r4 A D B) →
  (¬(0 : Int) = C) →
  (E = (0 : Int)) →
  (((0 : Int) = C) = (B ≤ (0 : Int))) →
  r8 A D B) ∧
  ((∀ (A B C D E F G : Int),
  (r8 A B D) →
  (r0 B D C) →
  (r2 C D) →
  (r8 E C D) →
  ((0 : Int) = G) →
  (F = (1 : Int) + E) →
  (¬((0 : Int) = G) = (C ≥ D)) →
  r1 A B D C) ∧
  ((∀ (A B C D E F G : Int),
  (r8 C A B) →
  (r6 E D B A) →
  (r2 A B) →
  ((0 : Int) = F) →
  (G = (1 : Int) + A) →
  (D = (1 : Int) + C) →
  (¬((0 : Int) = F) = (A ≥ B)) →
  r2 G B) ∧
  ((∀ (A B C : Int),
  (¬(0 : Int) = B) →
  (C = (0 : Int)) →
  (((0 : Int) = B) = (A ≤ (0 : Int))) →
  r2 C A) ∧
  ((∀ (A B C D E : Int),
  (r8 C A B) →
  (r2 A B) →
  ((0 : Int) = E) →
  (D = (1 : Int) + C) →
  (¬((0 : Int) = E) = (A ≥ B)) →
  r3 D B A) ∧
  ((∀ (A B C D : Int),
  (r7 A B) →
  (¬(0 : Int) = C) →
  (D = (0 : Int)) →
  (((0 : Int) = C) = (B ≤ (0 : Int))) →
  r5 A B) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r5 C B →
    ((0 : Int) = F) = (B ≤ C) →
      ¬((0 : Int) = E) = ((0 : Int) ≤ C) → ¬(0 : Int) = G → D = (1 : Int) → A = (0 : Int) → ¬a!1 → r4 A C B) ∧
  ((∀ (A B C D E v_5 : Int),
  (r1 E B C v_5) →
  (r3 D C B) →
  (v_5 = B) →
  (A = (1 : Int)) →
  r6 A D C B) ∧
  ((∀ (A B C v_3 : Int),
  (r3 C B A) →
  (v_3 = A) →
  r0 A B v_3) ∧
  (∀ (A B C D E : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  r5 B A → ((0 : Int) = D) = (A ≤ B) → ¬((0 : Int) = C) = ((0 : Int) ≤ B) → (0 : Int) = E → ¬a!1 → False)))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«inc3_000»
