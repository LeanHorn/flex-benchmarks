import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«a-max_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-max_000.smt2":139:1-139:12 (check-sat, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-max_000.smt2":8:1-24:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-max_000.smt2":25:1-41:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-max_000.smt2":42:1-59:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-max_000.smt2":60:1-77:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-max_000.smt2":78:1-87:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-max_000.smt2":88:1-106:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-max_000.smt2":107:1-116:2 (clause 7, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/a-max_000.smt2":117:1-137:2 (clause 8, command 12)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I v_9 : Int),
  (r0 A D C B) →
  (r0 H C v_9 B) →
  (v_9 = C) →
  (¬((0 : Int) = F) = (C ≥ B)) →
  (¬(0 : Int) = G) →
  ((0 : Int) = F) →
  (I = (1 : Int) + C) →
  (((0 : Int) = G) = (H ≤ E)) →
  r0 A D I B) ∧
  ((∀ (A B C D E F G H I v_9 : Int),
  (r0 A D C B) →
  (r0 H C v_9 B) →
  (v_9 = C) →
  (¬((0 : Int) = F) = (C ≥ B)) →
  ((0 : Int) = G) →
  ((0 : Int) = F) →
  (I = (1 : Int) + C) →
  (((0 : Int) = G) = (H ≤ E)) →
  r0 A D I B) ∧
  ((∀ (A B C D E F G H I v_9 : Int),
  (r0 G C v_9 B) →
  (r2 I D H B) →
  (v_9 = C) →
  (¬((0 : Int) = E) = (C ≥ B)) →
  ((0 : Int) = F) →
  ((0 : Int) = E) →
  (A = I) →
  (H = (1 : Int) + C) →
  (((0 : Int) = F) = (G ≤ D)) →
  r2 A D C B) ∧
  ((∀ (A B C D E F G H I v_9 : Int),
  (r0 G C v_9 B) →
  (r2 I G H B) →
  (v_9 = C) →
  (¬((0 : Int) = E) = (C ≥ B)) →
  (¬(0 : Int) = F) →
  ((0 : Int) = E) →
  (A = I) →
  (H = (1 : Int) + C) →
  (((0 : Int) = F) = (G ≤ D)) →
  r2 A D C B) ∧
  ((∀ (A B C D E : Int),
  (¬(0 : Int) = E) →
  (A = D) →
  (¬((0 : Int) = E) = (C ≥ B)) →
  r2 A D C B) ∧
  ((∀ (A B C D E F G H I J : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  let a!2 := ((0 : Int) = H) = (¬(0 : Int) = D ∧ ¬(0 : Int) = G);
  r1 A I C →
    ¬a!1 →
      ¬((0 : Int) = F) = (B ≤ (0 : Int)) →
        ¬((0 : Int) = E) = (B ≥ (0 : Int)) →
          ((0 : Int) = D) = (C ≤ (0 : Int)) → ¬(0 : Int) = H → J = (-1 : Int) → ¬a!2 → r0 A I B C) ∧
  ((∀ (A B C : Int),
  (A = B + (-1 : Int) * C) →
  r1 A C B) ∧
  (∀ (A B C D E F G H I J : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = F ∧ ¬(0 : Int) = C);
  let a!2 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  r2 J I A B →
    ¬((0 : Int) = H) = (J ≥ B) →
      ¬a!1 →
        ¬a!2 →
          ¬((0 : Int) = E) = (A ≤ (0 : Int)) →
            ¬((0 : Int) = D) = (A ≥ (0 : Int)) →
              (0 : Int) = H → ¬(0 : Int) = G → I = (-1 : Int) → ((0 : Int) = C) = (B ≤ (0 : Int)) → False)))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«a-max_000»
