import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«file_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":246:1-246:12 (check-sat, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":14:1-24:2 (clause 1, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":25:1-34:2 (clause 2, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":35:1-47:2 (clause 3, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":48:1-61:2 (clause 4, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":62:1-76:2 (clause 5, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":77:1-88:2 (clause 6, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":89:1-99:2 (clause 7, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":100:1-109:2 (clause 8, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":110:1-126:2 (clause 9, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":127:1-136:2 (clause 10, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":137:1-146:2 (clause 11, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":147:1-158:2 (clause 12, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":159:1-169:2 (clause 13, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":170:1-180:2 (clause 14, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":181:1-191:2 (clause 15, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":192:1-208:2 (clause 16, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":209:1-218:2 (clause 17, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":219:1-228:2 (clause 18, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/file_000.smt2":229:1-244:2 (clause 19, command 29)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  ∃ (r5 : Int → Prop),
  ∃ (r6 : Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (r6 D C) →
  (A = D) →
  (¬(0 : Int) = B) →
  r4 A C B) ∧
  ((∀ (A B C : Int),
  (A = C) →
  ((0 : Int) = B) →
  r4 A C B) ∧
  ((∀ (A B C D E : Int),
  (r4 D C A) →
  (r8 C B A) →
  (r4 E D B) →
  (True) →
  r0 C A) ∧
  ((∀ (A B C D E F : Int),
  (r4 E C A) →
  (r1 D C A) →
  (r8 C B A) →
  (r4 F E B) →
  (True) →
  r0 D B) ∧
  ((∀ (A B C D E F G : Int),
  (r4 F C A) →
  (r1 E D B) →
  (r1 D C A) →
  (r8 C B A) →
  (r4 G F B) →
  (True) →
  r8 E B A) ∧
  ((∀ (A B C D E F : Int),
  (r7 C B A) →
  (r2 E C) →
  (¬(0 : Int) = D) →
  (F = (1 : Int)) →
  (((0 : Int) = D) = (A ≤ (0 : Int))) →
  r8 E F B) ∧
  ((∀ (A B C D E : Int),
  (r7 C B A) →
  ((0 : Int) = D) →
  (E = (0 : Int)) →
  (((0 : Int) = D) = (A ≤ (0 : Int))) →
  r8 C E B) ∧
  ((∀ (A B C D E F : Int),
  (¬(0 : Int) = F) →
  (A = B) →
  (B = (2 : Int)) →
  (E = (3 : Int)) →
  (D = (1 : Int)) →
  (¬((0 : Int) = F) = (C = D)) →
  r6 A C) ∧
  ((∀ (A B C D E F G : Int),
  (¬((0 : Int) = F) = (C = D)) →
  (¬(0 : Int) = G) →
  ((0 : Int) = F) →
  (B = (2 : Int)) →
  (A = C) →
  (E = (3 : Int)) →
  (D = (1 : Int)) →
  (¬((0 : Int) = G) = (C = E)) →
  r6 A C) ∧
  ((∀ (A B C D E F : Int),
  (¬(0 : Int) = F) →
  (A = C) →
  (E = (3 : Int)) →
  (D = (0 : Int)) →
  (C = (1 : Int)) →
  (¬((0 : Int) = F) = (B = D)) →
  r2 A B) ∧
  ((∀ (A B C D E F : Int),
  ((0 : Int) = F) →
  (A = E) →
  (E = (3 : Int)) →
  (D = (0 : Int)) →
  (C = (1 : Int)) →
  (¬((0 : Int) = F) = (B = D)) →
  r2 A B) ∧
  ((∀ (A B C D : Int),
  (r0 C B) →
  (r3 D C) →
  (A = D) →
  (¬(0 : Int) = B) →
  r1 A C B) ∧
  ((∀ (A B C : Int),
  (r0 C B) →
  (A = C) →
  ((0 : Int) = B) →
  r1 A C B) ∧
  ((∀ (A B : Int),
  (r0 B A) →
  (¬(0 : Int) = A) →
  r5 B) ∧
  ((∀ (A B C D E : Int),
  (r5 B) →
  (¬(0 : Int) = E) →
  (A = C) →
  (D = (3 : Int)) →
  (C = (1 : Int)) →
  (¬((0 : Int) = E) = (B = C)) →
  r3 A B) ∧
  ((∀ (A B C D E F : Int),
  (r5 B) →
  (¬((0 : Int) = E) = (B = C)) →
  (¬(0 : Int) = F) →
  ((0 : Int) = E) →
  (A = B) →
  (D = (3 : Int)) →
  (C = (1 : Int)) →
  (¬((0 : Int) = F) = (B = D)) →
  r3 A B) ∧
  ((∀ (A B C D E F : Int),
  (¬(0 : Int) = E) →
  (F = (1 : Int)) →
  (D = (0 : Int)) →
  (C = (1 : Int)) →
  (((0 : Int) = E) = (A ≤ (0 : Int))) →
  r7 C F B) ∧
  ((∀ (A B C D E F : Int),
  ((0 : Int) = E) →
  (F = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (1 : Int)) →
  (((0 : Int) = E) = (A ≤ (0 : Int))) →
  r7 D F B) ∧
  (∀ (A B C D E : Int),
  (r5 A) →
  (¬((0 : Int) = D) = (A = B)) →
  ((0 : Int) = E) →
  ((0 : Int) = D) →
  (C = (3 : Int)) →
  (B = (1 : Int)) →
  (¬((0 : Int) = E) = (A = C)) →
  False))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«file_000»
