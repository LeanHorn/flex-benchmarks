import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«hors_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hors_000.smt2":151:1-151:12 (check-sat, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hors_000.smt2":14:1-23:2 (clause 1, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hors_000.smt2":24:1-35:2 (clause 2, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hors_000.smt2":36:1-47:2 (clause 3, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hors_000.smt2":48:1-59:2 (clause 4, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hors_000.smt2":60:1-70:2 (clause 5, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hors_000.smt2":71:1-82:2 (clause 6, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hors_000.smt2":83:1-94:2 (clause 7, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hors_000.smt2":95:1-106:2 (clause 8, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hors_000.smt2":107:1-117:2 (clause 9, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hors_000.smt2":118:1-127:2 (clause 10, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hors_000.smt2":128:1-138:2 (clause 11, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/hors_000.smt2":139:1-149:2 (clause 12, command 22)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  ∃ (r5 : Int → Prop),
  ∃ (r6 : Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Prop),
  (∀ (A B : Int),
  (B = (0 : Int)) →
  r0 B A) ∧
  ((∀ (A B C D E F : Int),
  (r7 A D C) →
  (r6 B C) →
  ((0 : Int) = F) →
  (E = (-1 : Int) + C) →
  (¬((0 : Int) = F) = (C ≤ (0 : Int))) →
  r4 A D) ∧
  ((∀ (A B C D E : Int),
  (r4 E D) →
  (r1 A) →
  (¬(0 : Int) = B) →
  (C = (0 : Int)) →
  (D = (0 : Int)) →
  (¬((0 : Int) = B) = (A = (0 : Int))) →
  r5 C) ∧
  ((∀ (A B C D E : Int),
  (r5 A) →
  (r6 B C) →
  ((0 : Int) = E) →
  (D = (-1 : Int) + C) →
  (¬((0 : Int) = E) = (C ≤ (0 : Int))) →
  r6 A D) ∧
  ((∀ (A B : Int),
  (r0 B A) →
  (True) →
  r6 B A) ∧
  ((∀ (A B C D E F : Int),
  (r3 A F) →
  (r6 B C) →
  ((0 : Int) = E) →
  (D = (-1 : Int) + C) →
  (¬((0 : Int) = E) = (C ≤ (0 : Int))) →
  r7 A F D) ∧
  ((∀ (A B C D : Int),
  (r2 A D) →
  (r0 C B) →
  (True) →
  r7 A D B) ∧
  ((∀ (A B C D E : Int),
  (r7 A D C) →
  (r6 B C) →
  ((0 : Int) = E) →
  (¬((0 : Int) = E) = (C ≤ (0 : Int))) →
  r8 A D) ∧
  ((∀ (A B C D : Int),
  (r8 D C) →
  (C = (1 : Int)) →
  (A = D) →
  r3 A B) ∧
  ((∀ (A B : Int),
  (A = (1 : Int)) →
  r2 A B) ∧
  ((∀ (A B C D : Int),
  (r6 A B) →
  ((0 : Int) = D) →
  (C = (-1 : Int) + B) →
  (¬((0 : Int) = D) = (B ≤ (0 : Int))) →
  r1 A) ∧
  (∀ (A B : Int),
  (r1 A) →
  ((0 : Int) = B) →
  (¬((0 : Int) = B) = (A = (0 : Int))) →
  False)))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«hors_000»
