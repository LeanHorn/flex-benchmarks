import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«lock_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":170:1-170:12 (check-sat, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":14:1-23:2 (clause 1, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":24:1-35:2 (clause 2, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":36:1-46:2 (clause 3, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":47:1-57:2 (clause 4, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":58:1-68:2 (clause 5, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":69:1-80:2 (clause 6, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":81:1-91:2 (clause 7, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":92:1-102:2 (clause 8, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":103:1-113:2 (clause 9, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":114:1-124:2 (clause 10, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":125:1-136:2 (clause 11, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":137:1-147:2 (clause 12, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":148:1-158:2 (clause 13, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/lock_000.smt2":159:1-168:2 (clause 14, command 24)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  ∃ (r3 : Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  ∃ (r5 : Prop),
  ∃ (r6 : Int → Prop),
  ∃ (r7 : Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Prop),
  (∀ (A B : Int),
  (B = (0 : Int)) →
  r2 B A) ∧
  ((∀ (A B C D E : Int),
  (r2 C B) →
  (r0 E C) →
  (¬(0 : Int) = D) →
  (A = E) →
  (((0 : Int) = D) = (B ≤ (0 : Int))) →
  r7 A C B) ∧
  ((∀ (A B C : Int),
  (r2 B A) →
  (¬(0 : Int) = C) →
  (((0 : Int) = C) = (A ≤ (0 : Int))) →
  r3 B) ∧
  ((∀ (A B C D : Int),
  (r2 C B) →
  ((0 : Int) = D) →
  (A = C) →
  (((0 : Int) = D) = (B ≤ (0 : Int))) →
  r7 A C B) ∧
  ((∀ (A B C : Int),
  (r7 B C A) →
  (C = (0 : Int)) →
  r8 B A) ∧
  ((∀ (A B C D E : Int),
  (r8 C B) →
  (r1 E C) →
  (¬(0 : Int) = D) →
  (A = E) →
  (((0 : Int) = D) = (B ≤ (0 : Int))) →
  r4 A C B) ∧
  ((∀ (A B C : Int),
  (r8 B A) →
  (¬(0 : Int) = C) →
  (((0 : Int) = C) = (A ≤ (0 : Int))) →
  r6 B) ∧
  ((∀ (A B C D : Int),
  (r8 C B) →
  ((0 : Int) = D) →
  (A = C) →
  (((0 : Int) = D) = (B ≤ (0 : Int))) →
  r4 A C B) ∧
  ((∀ (A B C D : Int),
  (r3 B) →
  (¬(0 : Int) = D) →
  (A = (1 : Int)) →
  (C = (1 : Int)) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  r0 A B) ∧
  ((∀ (A B C D : Int),
  (r6 B) →
  (¬(0 : Int) = D) →
  (A = (0 : Int)) →
  (C = (1 : Int)) →
  (¬((0 : Int) = D) = (B = (1 : Int))) →
  r1 A B) ∧
  ((∀ (A B C D E : Int),
  (r4 C B A) →
  (r7 B E A) →
  ((0 : Int) = D) →
  (E = (0 : Int)) →
  (¬((0 : Int) = D) = (C = (0 : Int))) →
  r5) ∧
  ((∀ (A B : Int),
  (r3 A) →
  ((0 : Int) = B) →
  (¬((0 : Int) = B) = (A = (0 : Int))) →
  r5) ∧
  ((∀ (A B : Int),
  (r6 A) →
  ((0 : Int) = B) →
  (¬((0 : Int) = B) = (A = (1 : Int))) →
  r5) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r5) →
  False)))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«lock_000»
