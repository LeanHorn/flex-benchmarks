import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«sum_cps_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_cps_000.smt2":100:1-100:12 (check-sat, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_cps_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_cps_000.smt2":20:1-30:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_cps_000.smt2":31:1-41:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_cps_000.smt2":42:1-52:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_cps_000.smt2":53:1-64:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_cps_000.smt2":65:1-75:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_cps_000.smt2":76:1-87:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/sum_cps_000.smt2":88:1-98:2 (clause 8, command 14)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  ∃ (r3 : Int → Prop),
  ∃ (r4 : Int → Int → Prop),
  (∀ (A : Int),
  (True) →
  r3 A) ∧
  ((∀ (A B C : Int),
  (r3 A) →
  ((0 : Int) = B) →
  (C = (-1 : Int) + A) →
  (¬((0 : Int) = B) = (A ≤ (0 : Int))) →
  r3 C) ∧
  ((∀ (A B : Int),
  (r1 A B) →
  (True) →
  r4 A B) ∧
  ((∀ (A B C : Int),
  (r0 B A) →
  (C = B + A) →
  r2 C A) ∧
  ((∀ (A B C : Int),
  (r2 A B) →
  (r3 B) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (B ≤ (0 : Int))) →
  r1 A B) ∧
  ((∀ (A B C : Int),
  (r3 A) →
  (¬(0 : Int) = B) →
  (C = (0 : Int)) →
  (¬((0 : Int) = B) = (A ≤ (0 : Int))) →
  r1 C A) ∧
  ((∀ (A B C D : Int),
  (r1 A D) →
  (r3 B) →
  ((0 : Int) = C) →
  (D = (-1 : Int) + B) →
  (¬((0 : Int) = C) = (B ≤ (0 : Int))) →
  r0 A B) ∧
  (∀ (A B C : Int),
  (r4 B A) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (B ≥ A)) →
  False)))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«sum_cps_000»
