import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«enc-rev_append_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-rev_append_000.smt2":90:1-90:12 (check-sat, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-rev_append_000.smt2":8:1-18:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-rev_append_000.smt2":19:1-28:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-rev_append_000.smt2":29:1-40:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-rev_append_000.smt2":41:1-50:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-rev_append_000.smt2":51:1-67:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-rev_append_000.smt2":68:1-78:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/enc-rev_append_000.smt2":79:1-88:2 (clause 7, command 11)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  (∀ (A B C D E F : Int),
  (r1 F C E) →
  ((0 : Int) = D) →
  (E = (-1 : Int) + B) →
  (A = (1 : Int) + F) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  r1 A C B) ∧
  ((∀ (A B C D : Int),
  (¬(0 : Int) = D) →
  (A = C) →
  (¬((0 : Int) = D) = (B = (0 : Int))) →
  r1 A C B) ∧
  ((∀ (A B C D E F G : Int),
  (r1 D C G) →
  (r2 G F) →
  ((0 : Int) = E) →
  (A = D) →
  (F = (-1 : Int) + B) →
  (C = (1 : Int)) →
  (¬((0 : Int) = E) = (B = (0 : Int))) →
  r2 A B) ∧
  ((∀ (A B C : Int),
  (¬(0 : Int) = C) →
  (A = (0 : Int)) →
  (¬((0 : Int) = C) = (B = (0 : Int))) →
  r2 A B) ∧
  ((∀ (A B C D E F G H : Int),
  (r2 G A) →
  (r1 D B A) →
  (¬((0 : Int) = F) = (D = E)) →
  (¬(0 : Int) = H) →
  ((0 : Int) = F) →
  (E = A + B) →
  (C = (1 : Int)) →
  (¬((0 : Int) = H) = (G = A)) →
  r0) ∧
  ((∀ (A B C : Int),
  (r2 B A) →
  ((0 : Int) = C) →
  (¬((0 : Int) = C) = (B = A)) →
  r0) ∧
  (∀ (_CHC_COMP_UNUSED : Prop),
  (r0) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«enc-rev_append_000»
