import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«bcopy5_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":342:1-342:12 (check-sat, command 42)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":21:1-32:2 (clause 1, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":33:1-43:2 (clause 2, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":44:1-54:2 (clause 3, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":55:1-67:2 (clause 4, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":68:1-78:2 (clause 5, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":79:1-92:2 (clause 6, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":93:1-106:2 (clause 7, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":107:1-121:2 (clause 8, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":122:1-136:2 (clause 9, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":137:1-149:2 (clause 10, command 27)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":150:1-160:2 (clause 11, command 28)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":161:1-174:2 (clause 12, command 29)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":175:1-190:2 (clause 13, command 30)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":191:1-203:2 (clause 14, command 31)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":204:1-217:2 (clause 15, command 32)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":218:1-233:2 (clause 16, command 33)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":234:1-247:2 (clause 17, command 34)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":248:1-260:2 (clause 18, command 35)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":261:1-272:2 (clause 19, command 36)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":273:1-286:2 (clause 20, command 37)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":287:1-298:2 (clause 21, command 38)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":299:1-315:2 (clause 22, command 39)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":316:1-328:2 (clause 23, command 40)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy5_000.smt2":329:1-340:2 (clause 24, command 41)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  ∃ (r2 : Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r8 : Int → Int → Int → Prop),
  ∃ (r9 : Int → Int → Int → Prop),
  ∃ (r10 : Int → Int → Int → Prop),
  ∃ (r11 : Int → Int → Int → Int → Prop),
  ∃ (r12 : Int → Int → Prop),
  ∃ (r13 : Int → Int → Int → Int → Int → Prop),
  ∃ (r14 : Int → Int → Int → Int → Int → Prop),
  ∃ (r15 : Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H : Int),
  (r0 H F C B) →
  (r14 F E D C B) →
  ((0 : Int) = G) →
  (A = H) →
  (¬((0 : Int) = G) = (B = F)) →
  r7 A F E D C B) ∧
  ((∀ (A B C D E F G : Int),
  (r14 F E D C B) →
  (¬(0 : Int) = G) →
  (A = D) →
  (¬((0 : Int) = G) = (B = F)) →
  r7 A F E D C B) ∧
  ((∀ (A B C D E F : Int),
  (r14 E D C B A) →
  ((0 : Int) = F) →
  (¬((0 : Int) = F) = (A = E)) →
  r8 E B A) ∧
  ((∀ (A B C D E v_5 : Int),
  (r8 A C B) →
  (r3 D C B) →
  (r11 E B C v_5) →
  (v_5 = B) →
  r5 A C B) ∧
  ((∀ (A B C v_3 : Int),
  (r3 C B A) →
  (v_3 = A) →
  r5 A B v_3) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r8 D C B) →
  (r3 E C B) →
  (r11 F B C v_6) →
  (r11 A D C B) →
  (v_6 = B) →
  r0 A D C B) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r7 B A F E D C) →
  (r15 A E D C) →
  (r3 E D C) →
  (r11 F C D v_6) →
  (v_6 = C) →
  r13 B A E D C) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r12 A C → ¬((0 : Int) = F) = (C ≤ D) → ¬((0 : Int) = E) = (B = (0 : Int)) → ¬(0 : Int) = G → ¬a!1 → r6 A C) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r1 A C → ¬((0 : Int) = F) = (C ≤ D) → ¬((0 : Int) = E) = (B = (0 : Int)) → ¬(0 : Int) = G → ¬a!1 → r6 A D) ∧
  ((∀ (A B C D E F : Int),
  (r12 A C) →
  (r4 E B C) →
  (r2 B C) →
  ((0 : Int) = D) →
  (F = (1 : Int) + B) →
  (¬((0 : Int) = D) = (B ≥ C)) →
  r12 A C) ∧
  ((∀ (A B C D : Int),
  (r2 A B) →
  ((0 : Int) = C) →
  (D = (1 : Int) + A) →
  (¬((0 : Int) = C) = (A ≥ B)) →
  r12 A B) ∧
  ((∀ (A B C D E F G : Int),
  (r12 B D) →
  (r4 A B D) →
  (r2 C D) →
  (r4 F C D) →
  ((0 : Int) = E) →
  (G = (1 : Int) + C) →
  (¬((0 : Int) = E) = (C ≥ D)) →
  r4 A B D) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r12 H C → r9 A H C → ¬((0 : Int) = F) = (C ≤ D) → ¬((0 : Int) = E) = (B = (0 : Int)) → ¬(0 : Int) = G → ¬a!1 → r4 A H C) ∧
  ((∀ (A B C D E F : Int),
  (r4 E B C) →
  (r1 A C) →
  (r2 B C) →
  ((0 : Int) = D) →
  (F = (1 : Int) + B) →
  (¬((0 : Int) = D) = (B ≥ C)) →
  r15 A E C B) ∧
  ((∀ (A B C D E F G : Int),
  (r4 E B C) →
  (r13 A F E C B) →
  (r1 F C) →
  (r2 B C) →
  ((0 : Int) = D) →
  (G = (1 : Int) + B) →
  (¬((0 : Int) = D) = (B ≥ C)) →
  r10 A F C) ∧
  ((∀ (A B C D E F G H : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r1 H C → r9 A H D → ¬((0 : Int) = F) = (C ≤ D) → ¬((0 : Int) = E) = (B = (0 : Int)) → ¬(0 : Int) = G → ¬a!1 → r10 A H C) ∧
  ((∀ (A B C D E F G : Int),
  (r4 F C D) →
  (r5 B D C) →
  (r10 A B D) →
  (r2 C D) →
  ((0 : Int) = E) →
  (G = (1 : Int) + C) →
  (¬((0 : Int) = E) = (C ≥ D)) →
  r11 A B D C) ∧
  ((∀ (A B C D E F : Int),
  (r4 E B C) →
  (r5 A C B) →
  (r2 B C) →
  ((0 : Int) = D) →
  (F = (1 : Int) + B) →
  (¬((0 : Int) = D) = (B ≥ C)) →
  r1 A C) ∧
  ((∀ (A B C D E : Int),
  (r4 D A B) →
  (r2 A B) →
  ((0 : Int) = C) →
  (E = (1 : Int) + A) →
  (¬((0 : Int) = C) = (A ≥ B)) →
  r2 E B) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := ((0 : Int) = F) = (¬(0 : Int) = D ∧ ¬(0 : Int) = E);
  ¬((0 : Int) = E) = (B ≤ C) → ¬((0 : Int) = D) = (A = (0 : Int)) → ¬(0 : Int) = F → ¬a!1 → r2 A B) ∧
  ((∀ (A B C D E : Int),
  (r4 D A B) →
  (r2 A B) →
  ((0 : Int) = C) →
  (E = (1 : Int) + A) →
  (¬((0 : Int) = C) = (A ≥ B)) →
  r3 D B A) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = E ∧ ¬(0 : Int) = F);
  r6 C B →
    ((0 : Int) = F) = (B ≤ C) →
      ¬((0 : Int) = E) = ((0 : Int) ≤ C) → ¬(0 : Int) = G → D = (1 : Int) → A = (0 : Int) → ¬a!1 → r9 A C B) ∧
  ((∀ (A B C D E v_5 : Int),
  (r11 E B C v_5) →
  (r15 A D C B) →
  (r3 D C B) →
  (v_5 = B) →
  r14 A E D C B) ∧
  (∀ (A B C D E : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  r6 B A → ((0 : Int) = D) = (A ≤ B) → ¬((0 : Int) = C) = ((0 : Int) ≤ B) → (0 : Int) = E → ¬a!1 → False)))))))))))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«bcopy5_000»
