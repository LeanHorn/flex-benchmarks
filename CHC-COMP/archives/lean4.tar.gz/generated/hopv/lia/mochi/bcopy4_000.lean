import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«mochi».«bcopy4_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy4_000.smt2":123:1-123:12 (check-sat, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy4_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy4_000.smt2":20:1-31:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy4_000.smt2":32:1-52:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy4_000.smt2":53:1-63:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy4_000.smt2":64:1-83:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy4_000.smt2":84:1-94:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy4_000.smt2":95:1-104:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/mochi/bcopy4_000.smt2":105:1-121:2 (clause 8, command 14)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Prop),
  ∃ (r3 : Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  (∀ (A : Int),
  (True) →
  r2 A) ∧
  ((∀ (A B C D : Int),
  (r2 B) →
  (r4 A C B) →
  (D = (0 : Int)) →
  r1 A C B) ∧
  ((∀ (A B C D E F G H I J K : Int),
  let a!1 := ((0 : Int) = I) = (¬(0 : Int) = H ∧ ¬(0 : Int) = G);
  r1 A E D →
    r0 B D →
      r1 F B D →
        ¬((0 : Int) = J) = (B ≥ D) →
          ¬a!1 →
            ¬((0 : Int) = H) = (B ≤ D) →
              (0 : Int) = J →
                ¬(0 : Int) = I → C = (1 : Int) → K = (1 : Int) + B → ¬((0 : Int) = G) = ((0 : Int) ≤ B) → r1 A E D) ∧
  ((∀ (A B : Int),
  (r2 A) →
  (B = (0 : Int)) →
  r0 B A) ∧
  ((∀ (A B C D E F G H I : Int),
  let a!1 := ((0 : Int) = G) = (¬(0 : Int) = F ∧ ¬(0 : Int) = E);
  r1 D A C →
    r0 A C →
      ¬((0 : Int) = H) = (A ≥ C) →
        ¬a!1 →
          ¬((0 : Int) = F) = (A ≤ C) →
            (0 : Int) = H →
              ¬(0 : Int) = G → B = (1 : Int) → I = (1 : Int) + A → ¬((0 : Int) = E) = ((0 : Int) ≤ A) → r0 I C) ∧
  ((∀ (A B C : Int),
  (r3 A C) →
  (True) →
  r4 A C B) ∧
  ((∀ (A B : Int),
  (A = (0 : Int)) →
  r3 A B) ∧
  (∀ (A B C D E F : Int),
  let a!1 := ((0 : Int) = E) = (¬(0 : Int) = C ∧ ¬(0 : Int) = D);
  r0 A B →
    ¬((0 : Int) = D) = (A ≤ B) →
      ¬((0 : Int) = C) = ((0 : Int) ≤ A) → ¬((0 : Int) = F) = (A ≥ B) → (0 : Int) = E → (0 : Int) = F → ¬a!1 → False)))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«mochi».«bcopy4_000»
