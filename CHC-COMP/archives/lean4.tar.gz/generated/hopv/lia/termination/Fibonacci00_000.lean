import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«Fibonacci00_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci00_000.smt2":40:1-40:12 (check-sat, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci00_000.smt2":7:1-17:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci00_000.smt2":18:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci00_000.smt2":28:1-38:2 (clause 3, command 6)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  (∀ (A B C D : Int),
  (r0 A C B) →
  (D = (1 : Int)) →
  (¬(0 : Int) = B) →
  r1 D) ∧
  ((∀ (A B C : Int),
  (B = (0 : Int)) →
  (C = (0 : Int)) →
  r0 A C B) ∧
  (∀ (A : Int),
  (r1 A) →
  (True) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«Fibonacci00_000»
