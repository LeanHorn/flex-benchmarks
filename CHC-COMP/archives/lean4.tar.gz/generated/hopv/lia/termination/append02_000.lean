import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«append02_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/append02_000.smt2":148:1-148:12 (check-sat, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/append02_000.smt2":10:1-21:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/append02_000.smt2":22:1-32:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/append02_000.smt2":33:1-64:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/append02_000.smt2":65:1-75:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/append02_000.smt2":76:1-107:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/append02_000.smt2":108:1-125:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/append02_000.smt2":126:1-135:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/append02_000.smt2":136:1-146:2 (clause 8, command 14)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S : Int),
  (r4 A G F E D C B S) →
  (r0 O N M L K J I H) →
  ((0 : Int) = R) →
  (Q = (-1 : Int) + K) →
  (P = (1 : Int)) →
  (¬((0 : Int) = R) = (K ≤ (0 : Int))) →
  r0 A G F E D C B S) ∧
  ((∀ (A B C D E F v_6 v_7 v_8 : Int),
  (r3 F E D C B A) →
  (v_6 = C) →
  (v_7 = B) →
  (v_8 = A) →
  r0 F C B A E v_6 v_7 v_8) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  let a!1 := ((0 : Int) = A1) = (¬(0 : Int) = T ∧ ¬(0 : Int) = Z);
  r1 B A I H G F E D →
    ¬((0 : Int) = Z) = (Y ≥ (0 : Int)) →
      ((0 : Int) = T) = (N ≤ S) →
        ¬(0 : Int) = H →
          ¬(0 : Int) = A1 →
            C = (1 : Int) →
              P = G →
                O = (0 : Int) →
                  N = L + M →
                    M = (0 : Int) →
                      L = J + K →
                        K = I →
                          J = (0 : Int) →
                            Y = W + X →
                              X = (0 : Int) →
                                W = U + V →
                                  V = G →
                                    U = (0 : Int) → S = Q + R → R = (0 : Int) → Q = O + P → ¬a!1 → r4 B A I H G F E D) ∧
  ((∀ (A B C D E F G H I : Int),
  (r1 B A I H G F E D) →
  (C = (1 : Int)) →
  ((0 : Int) = H) →
  r4 B A I H G F E D) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  let a!1 := ((0 : Int) = Z) = (¬(0 : Int) = S ∧ ¬(0 : Int) = Y);
  r1 B A H G F E D C →
    ¬((0 : Int) = Y) = (X ≥ (0 : Int)) →
      ((0 : Int) = S) = (M ≤ R) →
        ¬(0 : Int) = G →
          (0 : Int) = Z →
            P = N + O →
              O = F →
                N = (0 : Int) →
                  M = K + L →
                    L = (0 : Int) →
                      K = I + J →
                        J = H →
                          I = (0 : Int) →
                            A1 = (1 : Int) →
                              X = V + W →
                                W = (0 : Int) →
                                  V = T + U → U = F → T = (0 : Int) → R = P + Q → Q = (0 : Int) → ¬a!1 → r2 A1) ∧
  ((∀ (A B C D E F G H I J K v_11 v_12 v_13 v_14 : Int),
  (r0 H G F E D C B A) →
  ((0 : Int) = K) →
  (J = (-1 : Int) + D) →
  (I = (1 : Int)) →
  (¬((0 : Int) = K) = (D ≤ (0 : Int))) →
  (v_11 = H) →
  (v_12 = H) →
  (v_13 = D) →
  (v_14 = I) →
  r1 H v_11 D I J v_12 v_13 v_14) ∧
  ((∀ (A B C D E F : Int),
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (F = (1 : Int)) →
  r3 A B F E D C) ∧
  (∀ (A : Int),
  (r2 A) →
  (True) →
  False)))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«append02_000»
