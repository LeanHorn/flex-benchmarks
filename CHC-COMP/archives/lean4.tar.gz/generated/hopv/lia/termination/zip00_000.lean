import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«zip00_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip00_000.smt2":40:1-40:12 (check-sat, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip00_000.smt2":7:1-17:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip00_000.smt2":18:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip00_000.smt2":28:1-38:2 (clause 3, command 6)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I : Int),
  (r1 H G F E D C B A) →
  (I = (1 : Int)) →
  (¬(0 : Int) = E) →
  r0 I) ∧
  ((∀ (A B C D E v_5 v_6 v_7 : Int),
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (E = (0 : Int)) →
  (v_5 = E) →
  (v_6 = D) →
  (v_7 = C) →
  r1 B E D C A v_5 v_6 v_7) ∧
  (∀ (A : Int),
  (r0 A) →
  (True) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«zip00_000»
