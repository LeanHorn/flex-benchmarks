import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«alias_partial00_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial00_000.smt2":75:1-75:12 (check-sat, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial00_000.smt2":9:1-19:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial00_000.smt2":20:1-30:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial00_000.smt2":31:1-41:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial00_000.smt2":42:1-52:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial00_000.smt2":53:1-62:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial00_000.smt2":63:1-73:2 (clause 6, command 11)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  (∀ (A B C D E F G H : Int),
  (r0 C B A F E D) →
  (¬(0 : Int) = G) →
  (H = (-1 : Int) + F) →
  (((0 : Int) = G) = (F ≤ (0 : Int))) →
  r0 C B A H E D) ∧
  ((∀ (A B C D E F G : Int),
  (r1 C B A) →
  (F = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (2 : Int)) →
  (G = (1 : Int)) →
  r0 D B A G F E) ∧
  ((∀ (A B C D E F G : Int),
  (r0 A C B F E D) →
  ((0 : Int) = G) →
  (((0 : Int) = G) = (F ≤ (0 : Int))) →
  r3 A C B) ∧
  ((∀ (A B C D : Int),
  (r3 A C B) →
  (D = (1 : Int)) →
  (¬(0 : Int) = B) →
  r2 D) ∧
  ((∀ (A B C : Int),
  (B = (0 : Int)) →
  (A = (0 : Int)) →
  (C = (1 : Int)) →
  r1 C B A) ∧
  (∀ (A : Int),
  (r2 A) →
  (True) →
  False)))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«alias_partial00_000»
