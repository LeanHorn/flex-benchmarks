import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«zip02_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip02_000.smt2":144:1-144:12 (check-sat, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip02_000.smt2":9:1-40:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip02_000.smt2":41:1-51:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip02_000.smt2":52:1-69:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip02_000.smt2":70:1-79:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip02_000.smt2":80:1-111:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip02_000.smt2":112:1-131:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip02_000.smt2":132:1-142:2 (clause 7, command 12)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  let a!1 := ((0 : Int) = A1) = (¬(0 : Int) = Z ∧ ¬(0 : Int) = T);
  r1 B A I H G F E D →
    ¬a!1 →
      ¬((0 : Int) = Z) = (Y ≥ (0 : Int)) →
        ¬(0 : Int) = H →
          ¬(0 : Int) = A1 →
            W = U + V →
              V = G →
                U = (0 : Int) →
                  S = Q + R →
                    R = (0 : Int) →
                      Q = O + P →
                        P = G →
                          O = (0 : Int) →
                            N = L + M →
                              M = (0 : Int) →
                                L = J + K →
                                  K = I →
                                    J = (0 : Int) →
                                      C = (1 : Int) →
                                        Y = W + X → X = (0 : Int) → ((0 : Int) = T) = (N ≤ S) → r3 B A I H G F E D) ∧
  ((∀ (A B C D E F G H I : Int),
  (r1 B A I H G F E D) →
  (C = (1 : Int)) →
  ((0 : Int) = H) →
  r3 B A I H G F E D) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r3 A G F E D C B U) →
  (r0 O N M L K J I H) →
  (¬((0 : Int) = S) = (K ≤ (0 : Int))) →
  ((0 : Int) = T) →
  ((0 : Int) = S) →
  (Q = (-1 : Int) + K) →
  (P = (1 : Int)) →
  (R = (-1 : Int) + O) →
  (¬((0 : Int) = T) = (O ≤ (0 : Int))) →
  r0 A G F E D C B U) ∧
  ((∀ (A B C D E v_5 v_6 v_7 : Int),
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (E = (0 : Int)) →
  (v_5 = E) →
  (v_6 = D) →
  (v_7 = C) →
  r0 B E D C A v_5 v_6 v_7) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  let a!1 := ((0 : Int) = Z) = (¬(0 : Int) = Y ∧ ¬(0 : Int) = S);
  r1 B A H G F E D C →
    ¬a!1 →
      ¬((0 : Int) = Y) = (X ≥ (0 : Int)) →
        ¬(0 : Int) = G →
          (0 : Int) = Z →
            W = (0 : Int) →
              V = T + U →
                U = F →
                  T = (0 : Int) →
                    R = P + Q →
                      Q = (0 : Int) →
                        P = N + O →
                          O = F →
                            N = (0 : Int) →
                              M = K + L →
                                L = (0 : Int) →
                                  K = I + J →
                                    J = H → I = (0 : Int) → A1 = (1 : Int) → X = V + W → ((0 : Int) = S) = (M ≤ R) → r2 A1) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r0 H G F E D C B A) →
  (¬((0 : Int) = L) = (D ≤ (0 : Int))) →
  ((0 : Int) = M) →
  ((0 : Int) = L) →
  (I = (1 : Int)) →
  (K = (-1 : Int) + H) →
  (J = (-1 : Int) + D) →
  (¬((0 : Int) = M) = (H ≤ (0 : Int))) →
  (v_13 = H) →
  (v_14 = D) →
  (v_15 = I) →
  r1 K H D I J v_13 v_14 v_15) ∧
  (∀ (A : Int),
  (r2 A) →
  (True) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«zip02_000»
