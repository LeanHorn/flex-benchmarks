import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«Ackermann03_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann03_000.smt2":80:1-80:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann03_000.smt2":8:1-39:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann03_000.smt2":40:1-57:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann03_000.smt2":58:1-67:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann03_000.smt2":68:1-78:2 (clause 4, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  let a!1 := ((0 : Int) = Z) = (¬(0 : Int) = S ∧ ¬(0 : Int) = Y);
  r0 H G F E D C B A →
    ¬((0 : Int) = Y) = (X ≥ (0 : Int)) →
      ((0 : Int) = S) = (M ≤ R) →
        (0 : Int) = Z →
          ¬(0 : Int) = E →
            A1 = (1 : Int) →
              X = V + W →
                W = H →
                  V = T + U →
                    U = (0 : Int) →
                      T = (0 : Int) →
                        R = P + Q →
                          Q = H →
                            P = N + O →
                              O = (0 : Int) →
                                N = (0 : Int) →
                                  M = K + L → L = G → K = I + J → J = (0 : Int) → I = (0 : Int) → ¬a!1 → r2 A1) ∧
  ((∀ (A B C D E F G H I v_9 v_10 v_11 : Int),
  let a!1 := ((0 : Int) = I) = (¬(0 : Int) = G ∧ ¬(0 : Int) = H);
  r1 F E D C B A →
    ((0 : Int) = H) = (E ≤ (0 : Int)) →
      ((0 : Int) = G) = (F ≤ (0 : Int)) →
        ¬(0 : Int) = I → ¬a!1 → v_9 = C → v_10 = B → v_11 = A → r0 F C B A E v_9 v_10 v_11) ∧
  ((∀ (A B C D E F : Int),
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (F = (1 : Int)) →
  r1 A B F E D C) ∧
  (∀ (A : Int),
  (r2 A) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«Ackermann03_000»
