import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«binomial05_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":432:1-432:12 (check-sat, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":13:1-33:2 (clause 1, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":34:1-62:2 (clause 2, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":63:1-80:2 (clause 3, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":81:1-102:2 (clause 4, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":103:1-170:2 (clause 5, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":171:1-182:2 (clause 6, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":183:1-248:2 (clause 7, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":249:1-259:2 (clause 8, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":260:1-325:2 (clause 9, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":326:1-356:2 (clause 10, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":357:1-367:2 (clause 11, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":368:1-386:2 (clause 12, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":387:1-409:2 (clause 13, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":410:1-419:2 (clause 14, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial05_000.smt2":420:1-430:2 (clause 15, command 24)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W : Int),
  let a!1 := ((0 : Int) = T) = (¬(0 : Int) = S ∨ ¬(0 : Int) = R);
  r6 A G F E D C B W →
    r0 O N M L K J I H →
      ¬((0 : Int) = S) = (O ≥ K) →
        ¬((0 : Int) = R) = (O ≤ (0 : Int)) →
          ¬((0 : Int) = Q) = (K = (0 : Int)) →
            (0 : Int) = T →
              (0 : Int) = Q → V = (-1 : Int) + O → U = (-1 : Int) + K → P = (1 : Int) → ¬a!1 → r0 A G F E D C B W) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q v_17 v_18 v_19 v_20 v_21 v_22 v_23 : Int),
  let a!1 := ((0 : Int) = N) = (¬(0 : Int) = M ∨ ¬(0 : Int) = L);
  r2 Q P H D I O v_17 v_18 v_19 →
    r0 H G F E D C B A →
      v_17 = H →
        v_18 = D →
          v_19 = I →
            ¬((0 : Int) = M) = (H ≥ D) →
              ¬((0 : Int) = L) = (H ≤ (0 : Int)) →
                ¬((0 : Int) = K) = (D = (0 : Int)) →
                  (0 : Int) = N →
                    (0 : Int) = K →
                      P = (-1 : Int) + H →
                        O = (-1 : Int) + D →
                          J = (-1 : Int) + D →
                            I = (1 : Int) →
                              ¬a!1 → v_20 = H → v_21 = H → v_22 = D → v_23 = I → r0 H v_20 D I J v_21 v_22 v_23) ∧
  ((∀ (A B C D E F G H I v_9 v_10 v_11 : Int),
  let a!1 := ((0 : Int) = I) = (¬(0 : Int) = G ∧ ¬(0 : Int) = H);
  r1 F E D C B A →
    ¬((0 : Int) = H) = (F ≥ (0 : Int)) →
      ¬((0 : Int) = G) = (E ≥ (0 : Int)) →
        ¬(0 : Int) = I → ¬a!1 → v_9 = C → v_10 = B → v_11 = A → r0 F C B A E v_9 v_10 v_11) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X : Int),
  let a!1 := ((0 : Int) = U) = (¬(0 : Int) = T ∨ ¬(0 : Int) = S);
  r6 G F E D C B A X →
    r3 H G F E D C B A X →
      r0 P O N M L K J I →
        ¬((0 : Int) = T) = (P ≥ L) →
          ¬((0 : Int) = S) = (P ≤ (0 : Int)) →
            ¬((0 : Int) = R) = (L = (0 : Int)) →
              (0 : Int) = U →
                (0 : Int) = R → W = (-1 : Int) + P → V = (-1 : Int) + L → Q = (1 : Int) → ¬a!1 → r4 H G F E D C B A X) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 U1 V1 W1 X1 Y1 Z1 A2 B2 C2 D2 E2 F2 G2 H2 : Int),
  let a!1 := ((0 : Int) = H2) = (¬(0 : Int) = G2 ∨ ¬(0 : Int) = C1);
  let a!2 := ((0 : Int) = G2) = (¬(0 : Int) = F2 ∧ ¬(0 : Int) = N1);
  let a!3 := ((0 : Int) = F2) = (¬(0 : Int) = Y1 ∧ ¬(0 : Int) = E2);
  let a!4 := ((0 : Int) = C1) = (¬(0 : Int) = V ∧ ¬(0 : Int) = B1);
  r5 C B J I H G F E →
    r4 K C B J I H G F E →
      ¬((0 : Int) = B1) = (A1 ≥ (0 : Int)) →
        ((0 : Int) = V) = (P ≤ U) →
          ¬((0 : Int) = N1) = (H1 ≥ M1) →
            ¬a!1 →
              ¬a!2 →
                ¬a!3 →
                  ¬((0 : Int) = E2) = (D2 ≥ (0 : Int)) →
                    ((0 : Int) = Y1) = (S1 ≤ X1) →
                      ¬(0 : Int) = I →
                        ¬(0 : Int) = H2 →
                          J1 = (0 : Int) →
                            I1 = (0 : Int) →
                              H1 = F1 + G1 →
                                G1 = B →
                                  F1 = D1 + E1 →
                                    E1 = (0 : Int) →
                                      D1 = (0 : Int) →
                                        A1 = Y + Z →
                                          Z = C →
                                            Y = W + X →
                                              X = (0 : Int) →
                                                W = (0 : Int) →
                                                  U = S + T →
                                                    T = C →
                                                      S = Q + R →
                                                        R = (0 : Int) →
                                                          Q = (0 : Int) →
                                                            P = N + O →
                                                              O = B →
                                                                N = L + M →
                                                                  M = (0 : Int) →
                                                                    L = (0 : Int) →
                                                                      D = (1 : Int) →
                                                                        A = K →
                                                                          K1 = I1 + J1 →
                                                                            S1 = Q1 + R1 →
                                                                              R1 = (-1 : Int) * B →
                                                                                Q1 = O1 + P1 →
                                                                                  P1 = J →
                                                                                    O1 = (0 : Int) →
                                                                                      M1 = K1 + L1 →
                                                                                        L1 = C →
                                                                                          D2 = B2 + C2 →
                                                                                            C2 = (-1 : Int) * C →
                                                                                              B2 = Z1 + A2 →
                                                                                                A2 = H →
                                                                                                  Z1 = (0 : Int) →
                                                                                                    X1 = V1 + W1 →
                                                                                                      W1 =
                                                                                                          (-1 : Int) * C →
                                                                                                        V1 = T1 + U1 →
                                                                                                          U1 = H →
                                                                                                            T1 =
                                                                                                                (0 :
                                                                                                                  Int) →
                                                                                                              ¬a!4 →
                                                                                                                r2 A C B J
                                                                                                                  I H G F
                                                                                                                  E) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r5 C B J I H G F E) →
  (r4 K C B J I H G F E) →
  (D = (1 : Int)) →
  (A = K) →
  ((0 : Int) = I) →
  r2 A C B J I H G F E) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 U1 V1 W1 X1 Y1 Z1 A2 B2 C2 D2 E2 F2 : Int),
  let a!1 := ((0 : Int) = F2) = (¬(0 : Int) = E2 ∨ ¬(0 : Int) = A1);
  let a!2 := ((0 : Int) = E2) = (¬(0 : Int) = D2 ∧ ¬(0 : Int) = L1);
  let a!3 := ((0 : Int) = D2) = (¬(0 : Int) = W1 ∧ ¬(0 : Int) = C2);
  let a!4 := ((0 : Int) = A1) = (¬(0 : Int) = T ∧ ¬(0 : Int) = Z);
  r5 B A I H G F E D →
    ¬((0 : Int) = Z) = (Y ≥ (0 : Int)) →
      ((0 : Int) = T) = (N ≤ S) →
        ¬((0 : Int) = L1) = (F1 ≥ K1) →
          ¬a!1 →
            ¬a!2 →
              ¬a!3 →
                ¬((0 : Int) = C2) = (B2 ≥ (0 : Int)) →
                  ((0 : Int) = W1) = (Q1 ≤ V1) →
                    ¬(0 : Int) = H →
                      ¬(0 : Int) = F2 →
                        H1 = (0 : Int) →
                          G1 = (0 : Int) →
                            F1 = D1 + E1 →
                              E1 = A →
                                D1 = B1 + C1 →
                                  C1 = (0 : Int) →
                                    B1 = (0 : Int) →
                                      Y = W + X →
                                        X = B →
                                          W = U + V →
                                            V = (0 : Int) →
                                              U = (0 : Int) →
                                                S = Q + R →
                                                  R = B →
                                                    Q = O + P →
                                                      P = (0 : Int) →
                                                        O = (0 : Int) →
                                                          N = L + M →
                                                            M = A →
                                                              L = J + K →
                                                                K = (0 : Int) →
                                                                  J = (0 : Int) →
                                                                    C = (1 : Int) →
                                                                      I1 = G1 + H1 →
                                                                        Q1 = O1 + P1 →
                                                                          P1 = (-1 : Int) * A →
                                                                            O1 = M1 + N1 →
                                                                              N1 = I →
                                                                                M1 = (0 : Int) →
                                                                                  K1 = I1 + J1 →
                                                                                    J1 = B →
                                                                                      B2 = Z1 + A2 →
                                                                                        A2 = (-1 : Int) * B →
                                                                                          Z1 = X1 + Y1 →
                                                                                            Y1 = G →
                                                                                              X1 = (0 : Int) →
                                                                                                V1 = T1 + U1 →
                                                                                                  U1 = (-1 : Int) * B →
                                                                                                    T1 = R1 + S1 →
                                                                                                      S1 = G →
                                                                                                        R1 = (0 : Int) →
                                                                                                          ¬a!4 →
                                                                                                            r6 B A I H G F
                                                                                                              E D) ∧
  ((∀ (A B C D E F G H I : Int),
  (r5 B A I H G F E D) →
  (C = (1 : Int)) →
  ((0 : Int) = H) →
  r6 B A I H G F E D) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 U1 V1 W1 X1 Y1 Z1 A2 B2 C2 D2 E2 F2 : Int),
  let a!1 := ((0 : Int) = E2) = (¬(0 : Int) = D2 ∨ ¬(0 : Int) = Z);
  let a!2 := ((0 : Int) = D2) = (¬(0 : Int) = C2 ∧ ¬(0 : Int) = K1);
  let a!3 := ((0 : Int) = C2) = (¬(0 : Int) = V1 ∧ ¬(0 : Int) = B2);
  let a!4 := ((0 : Int) = Z) = (¬(0 : Int) = S ∧ ¬(0 : Int) = Y);
  r5 B A H G F E D C →
    ¬((0 : Int) = Y) = (X ≥ (0 : Int)) →
      ((0 : Int) = S) = (M ≤ R) →
        ¬((0 : Int) = K1) = (E1 ≥ J1) →
          ¬a!1 →
            ¬a!2 →
              ¬a!3 →
                ¬((0 : Int) = B2) = (A2 ≥ (0 : Int)) →
                  ((0 : Int) = V1) = (P1 ≤ U1) →
                    ¬(0 : Int) = G →
                      (0 : Int) = E2 →
                        H1 = F1 + G1 →
                          G1 = (0 : Int) →
                            F1 = (0 : Int) →
                              E1 = C1 + D1 →
                                D1 = A →
                                  C1 = A1 + B1 →
                                    B1 = (0 : Int) →
                                      A1 = (0 : Int) →
                                        X = V + W →
                                          W = B →
                                            V = T + U →
                                              U = (0 : Int) →
                                                T = (0 : Int) →
                                                  R = P + Q →
                                                    Q = B →
                                                      P = N + O →
                                                        O = (0 : Int) →
                                                          N = (0 : Int) →
                                                            M = K + L →
                                                              L = A →
                                                                K = I + J →
                                                                  J = (0 : Int) →
                                                                    I = (0 : Int) →
                                                                      I1 = B →
                                                                        Q1 = (0 : Int) →
                                                                          P1 = N1 + O1 →
                                                                            O1 = (-1 : Int) * A →
                                                                              N1 = L1 + M1 →
                                                                                M1 = H →
                                                                                  L1 = (0 : Int) →
                                                                                    J1 = H1 + I1 →
                                                                                      F2 = (1 : Int) →
                                                                                        A2 = Y1 + Z1 →
                                                                                          Z1 = (-1 : Int) * B →
                                                                                            Y1 = W1 + X1 →
                                                                                              X1 = F →
                                                                                                W1 = (0 : Int) →
                                                                                                  U1 = S1 + T1 →
                                                                                                    T1 = (-1 : Int) * B →
                                                                                                      S1 = Q1 + R1 →
                                                                                                        R1 = F →
                                                                                                          ¬a!4 → r7 F2) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 v_22 v_23 v_24 v_25 : Int),
  let a!1 := ((0 : Int) = P) = (¬(0 : Int) = O ∨ ¬(0 : Int) = N);
  r2 S R I E J Q v_19 v_20 v_21 →
    r3 L I v_22 E J K v_23 v_24 v_25 →
      r0 I H G F E D C B →
        v_19 = I →
          v_20 = E →
            v_21 = J →
              v_22 = I →
                v_23 = I →
                  v_24 = E →
                    v_25 = J →
                      ¬((0 : Int) = O) = (I ≥ E) →
                        ¬((0 : Int) = N) = (I ≤ (0 : Int)) →
                          ¬((0 : Int) = M) = (E = (0 : Int)) →
                            (0 : Int) = P →
                              (0 : Int) = M →
                                A = S + L →
                                  R = (-1 : Int) + I →
                                    Q = (-1 : Int) + E → K = (-1 : Int) + E → J = (1 : Int) → ¬a!1 → r3 A I H G F E D C B) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 I H G F E D C B) →
  (¬(0 : Int) = K) →
  (J = (1 : Int)) →
  (A = (1 : Int)) →
  (¬((0 : Int) = K) = (E = (0 : Int))) →
  r3 A I H G F E D C B) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  let a!1 := ((0 : Int) = N) = (¬(0 : Int) = L ∨ ¬(0 : Int) = M);
  r0 I H G F E D C B →
    ¬((0 : Int) = M) = (I ≥ E) →
      ¬((0 : Int) = L) = (I ≤ (0 : Int)) →
        ¬((0 : Int) = K) = (E = (0 : Int)) →
          ¬(0 : Int) = N → (0 : Int) = K → J = (1 : Int) → A = (1 : Int) → ¬a!1 → r3 A I H G F E D C B) ∧
  ((∀ (A B C D E F G H I J K L M N O v_15 v_16 v_17 : Int),
  let a!1 := ((0 : Int) = M) = (¬(0 : Int) = K ∨ ¬(0 : Int) = L);
  r0 H G F E D C B A →
    ¬((0 : Int) = L) = (H ≥ D) →
      ¬((0 : Int) = K) = (H ≤ (0 : Int)) →
        ¬((0 : Int) = J) = (D = (0 : Int)) →
          (0 : Int) = M →
            (0 : Int) = J →
              O = (-1 : Int) + H →
                N = (-1 : Int) + D → I = (1 : Int) → ¬a!1 → v_15 = H → v_16 = D → v_17 = I → r5 O H D I N v_15 v_16 v_17) ∧
  ((∀ (A B C D E F : Int),
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (F = (1 : Int)) →
  r1 A B F E D C) ∧
  (∀ (A : Int),
  (r7 A) →
  (True) →
  False))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«binomial05_000»
