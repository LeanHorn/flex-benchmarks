import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«CE-1CFA00_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA00_000.smt2":296:1-296:12 (check-sat, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA00_000.smt2":11:1-21:2 (clause 1, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA00_000.smt2":22:1-70:2 (clause 2, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA00_000.smt2":71:1-122:2 (clause 3, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA00_000.smt2":123:1-163:2 (clause 4, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA00_000.smt2":164:1-174:2 (clause 5, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA00_000.smt2":175:1-227:2 (clause 6, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA00_000.smt2":228:1-272:2 (clause 7, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA00_000.smt2":273:1-283:2 (clause 8, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA00_000.smt2":284:1-294:2 (clause 9, command 16)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H : Int),
  (r4 H G F E D C B A) →
  (True) →
  r1 H G F E D C B A) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 : Int),
  (r1 A B M1 K P1 F O1 N1) →
  (E1 = (0 : Int)) →
  (D1 = (0 : Int)) →
  (C1 = (0 : Int)) →
  (B1 = (0 : Int)) →
  (A1 = (0 : Int)) →
  (Z = (0 : Int)) →
  (Y = (0 : Int)) →
  (X = (0 : Int)) →
  (W = (0 : Int)) →
  (V = (1 : Int)) →
  (U = (0 : Int)) →
  (T = (0 : Int)) →
  (S = (0 : Int)) →
  (R = (0 : Int)) →
  (Q = (0 : Int)) →
  (P = (0 : Int)) →
  (O = (0 : Int)) →
  (N = (0 : Int)) →
  (M = (0 : Int)) →
  (L = (0 : Int)) →
  (K = (0 : Int)) →
  (J = (0 : Int)) →
  (I = (0 : Int)) →
  (H = (0 : Int)) →
  (G = (0 : Int)) →
  (F = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (H1 = (0 : Int)) →
  (G1 = (0 : Int)) →
  (P1 = (0 : Int)) →
  (O1 = (0 : Int)) →
  (N1 = (0 : Int)) →
  (L1 = (0 : Int)) →
  (K1 = (0 : Int)) →
  (J1 = (0 : Int)) →
  (I1 = (0 : Int)) →
  (F1 = (0 : Int)) →
  r5 A B M1 L1 K1 G J1 I1 H1 G1 I F1 E1) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 : Int),
  (F1 = (0 : Int)) →
  (E1 = (0 : Int)) →
  (D1 = (0 : Int)) →
  (C1 = (0 : Int)) →
  (B1 = (0 : Int)) →
  (A1 = (0 : Int)) →
  (Z = (0 : Int)) →
  (Y = (0 : Int)) →
  (X = (1 : Int)) →
  (W = (0 : Int)) →
  (V = (0 : Int)) →
  (U = (0 : Int)) →
  (T = (0 : Int)) →
  (S = (0 : Int)) →
  (R = (0 : Int)) →
  (Q = (0 : Int)) →
  (P = (0 : Int)) →
  (O = (0 : Int)) →
  (N = (0 : Int)) →
  (M = (0 : Int)) →
  (L = (0 : Int)) →
  (K = (0 : Int)) →
  (J = (0 : Int)) →
  (I = (0 : Int)) →
  (H = (0 : Int)) →
  (G = (0 : Int)) →
  (F = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (B = (0 : Int)) →
  (A = (0 : Int)) →
  (I1 = (0 : Int)) →
  (H1 = (0 : Int)) →
  (Q1 = (0 : Int)) →
  (P1 = (0 : Int)) →
  (O1 = (0 : Int)) →
  (N1 = (0 : Int)) →
  (M1 = (0 : Int)) →
  (L1 = (0 : Int)) →
  (K1 = (0 : Int)) →
  (J1 = (0 : Int)) →
  (G1 = (0 : Int)) →
  r5 X W V U T A S R Q P C O N) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 : Int),
  (r1 A B H1 Y X J W V) →
  (W = (0 : Int)) →
  (V = (0 : Int)) →
  (U = (1 : Int)) →
  (T = (0 : Int)) →
  (S = (0 : Int)) →
  (R = (0 : Int)) →
  (Q = (0 : Int)) →
  (P = (0 : Int)) →
  (O = (0 : Int)) →
  (N = (0 : Int)) →
  (M = (0 : Int)) →
  (L = (0 : Int)) →
  (K = (0 : Int)) →
  (J = (0 : Int)) →
  (I = (0 : Int)) →
  (H = (0 : Int)) →
  (G = (0 : Int)) →
  (F = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (Z = (0 : Int)) →
  (Y = (0 : Int)) →
  (G1 = (0 : Int)) →
  (F1 = (0 : Int)) →
  (E1 = (0 : Int)) →
  (D1 = (0 : Int)) →
  (C1 = (0 : Int)) →
  (B1 = (0 : Int)) →
  (A1 = (0 : Int)) →
  (X = (0 : Int)) →
  r3 A B H1) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r5 M L K J I H G F E D C B A) →
  (True) →
  r2 M L K J I H G F E D C B A) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 : Int),
  (r2 B A P X W C V U T S E R Q) →
  (I1 = (0 : Int)) →
  (H1 = (0 : Int)) →
  (G1 = (0 : Int)) →
  (F1 = (0 : Int)) →
  (E1 = (0 : Int)) →
  (D1 = (0 : Int)) →
  (C1 = (0 : Int)) →
  (B1 = (0 : Int)) →
  (A1 = (1 : Int)) →
  (Z = (0 : Int)) →
  (Y = (0 : Int)) →
  (X = (0 : Int)) →
  (W = (0 : Int)) →
  (V = (0 : Int)) →
  (U = (0 : Int)) →
  (T = (0 : Int)) →
  (S = (0 : Int)) →
  (R = (0 : Int)) →
  (Q = (0 : Int)) →
  (O = (0 : Int)) →
  (N = (0 : Int)) →
  (M = (0 : Int)) →
  (L = (0 : Int)) →
  (K = (0 : Int)) →
  (J = (0 : Int)) →
  (I = (0 : Int)) →
  (H = (0 : Int)) →
  (G = (0 : Int)) →
  (F = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (L1 = (0 : Int)) →
  (K1 = (0 : Int)) →
  (T1 = (0 : Int)) →
  (S1 = (0 : Int)) →
  (R1 = (0 : Int)) →
  (Q1 = (0 : Int)) →
  (P1 = (0 : Int)) →
  (O1 = (0 : Int)) →
  (N1 = (0 : Int)) →
  (M1 = (0 : Int)) →
  (J1 = (0 : Int)) →
  r4 B A P O N D M L) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 : Int),
  (r2 B A D1 L1 K1 G J1 I1 H1 G1 I F1 E1) →
  (A1 = (0 : Int)) →
  (Z = (0 : Int)) →
  (Y = (0 : Int)) →
  (X = (0 : Int)) →
  (W = (0 : Int)) →
  (V = (0 : Int)) →
  (U = (1 : Int)) →
  (T = (0 : Int)) →
  (S = (0 : Int)) →
  (R = (0 : Int)) →
  (Q = (0 : Int)) →
  (P = (0 : Int)) →
  (O = (0 : Int)) →
  (N = (0 : Int)) →
  (M = (0 : Int)) →
  (L = (0 : Int)) →
  (K = (0 : Int)) →
  (J = (0 : Int)) →
  (I = (0 : Int)) →
  (H = (0 : Int)) →
  (G = (0 : Int)) →
  (F = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (C1 = (0 : Int)) →
  (L1 = (0 : Int)) →
  (K1 = (0 : Int)) →
  (J1 = (0 : Int)) →
  (I1 = (0 : Int)) →
  (H1 = (0 : Int)) →
  (G1 = (0 : Int)) →
  (F1 = (0 : Int)) →
  (E1 = (0 : Int)) →
  (B1 = (0 : Int)) →
  r4 B A D1 C1 B1 H A1 Z) ∧
  ((∀ (A B C D : Int),
  (r3 A C B) →
  (D = (1 : Int)) →
  (¬(0 : Int) = B) →
  r0 D) ∧
  (∀ (A : Int),
  (r0 A) →
  (True) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«CE-1CFA00_000»
