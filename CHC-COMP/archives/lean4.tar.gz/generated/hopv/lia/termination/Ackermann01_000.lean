import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«Ackermann01_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann01_000.smt2":71:1-71:12 (check-sat, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann01_000.smt2":7:1-38:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann01_000.smt2":39:1-58:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann01_000.smt2":59:1-69:2 (clause 3, command 6)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  let a!1 := ((0 : Int) = Z) = (¬(0 : Int) = S ∧ ¬(0 : Int) = Y);
  r0 H G F E D C B A →
    ¬((0 : Int) = Y) = (X ≥ (0 : Int)) →
      ((0 : Int) = S) = (M ≤ R) →
        (0 : Int) = Z →
          ¬(0 : Int) = E →
            A1 = (1 : Int) →
              X = V + W →
                W = H →
                  V = T + U →
                    U = (0 : Int) →
                      T = (0 : Int) →
                        R = P + Q →
                          Q = H →
                            P = N + O →
                              O = (0 : Int) →
                                N = (0 : Int) →
                                  M = K + L → L = G → K = I + J → J = (0 : Int) → I = (0 : Int) → ¬a!1 → r1 A1) ∧
  ((∀ (A B C D E F G H v_8 v_9 v_10 : Int),
  let a!1 := ((0 : Int) = H) = (¬(0 : Int) = F ∧ ¬(0 : Int) = G);
  ((0 : Int) = G) = (A ≤ (0 : Int)) →
    ((0 : Int) = F) = (B ≤ (0 : Int)) →
      ¬(0 : Int) = H →
        E = (0 : Int) → D = (0 : Int) → C = (0 : Int) → ¬a!1 → v_8 = E → v_9 = D → v_10 = C → r0 B E D C A v_8 v_9 v_10) ∧
  (∀ (A : Int),
  (r1 A) →
  (True) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«Ackermann01_000»
