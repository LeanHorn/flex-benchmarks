import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«zip01_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip01_000.smt2":61:1-61:12 (check-sat, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip01_000.smt2":7:1-38:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip01_000.smt2":39:1-48:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/zip01_000.smt2":49:1-59:2 (clause 3, command 6)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  let a!1 := ((0 : Int) = Z) = (¬(0 : Int) = Y ∧ ¬(0 : Int) = S);
  r1 H G F E D C B A →
    ¬a!1 →
      ¬((0 : Int) = Y) = (X ≥ (0 : Int)) →
        ¬(0 : Int) = E →
          (0 : Int) = Z →
            W = (0 : Int) →
              V = T + U →
                U = D →
                  T = (0 : Int) →
                    R = P + Q →
                      Q = (0 : Int) →
                        P = N + O →
                          O = D →
                            N = (0 : Int) →
                              M = K + L →
                                L = (0 : Int) →
                                  K = I + J →
                                    J = F → I = (0 : Int) → A1 = (1 : Int) → X = V + W → ((0 : Int) = S) = (M ≤ R) → r0 A1) ∧
  ((∀ (A B C D E v_5 v_6 v_7 : Int),
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (E = (0 : Int)) →
  (v_5 = E) →
  (v_6 = D) →
  (v_7 = C) →
  r1 B E D C A v_5 v_6 v_7) ∧
  (∀ (A : Int),
  (r0 A) →
  (True) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«zip01_000»
