import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«CE-0CFA05_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-0CFA05_000.smt2":80:1-80:12 (check-sat, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-0CFA05_000.smt2":7:1-17:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-0CFA05_000.smt2":18:1-67:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-0CFA05_000.smt2":68:1-78:2 (clause 3, command 6)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X : Int),
  (r0 W V U T S R Q P O N M L K J I H G F E D C B A) →
  (X = (1 : Int)) →
  (¬(0 : Int) = S) →
  r1 X) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 : Int),
  (G = (0 : Int)) →
  (F = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (B = (0 : Int)) →
  (A = (0 : Int)) →
  (K1 = (0 : Int)) →
  (J1 = (0 : Int)) →
  (I1 = (0 : Int)) →
  (H1 = (0 : Int)) →
  (G1 = (1 : Int)) →
  (F1 = (0 : Int)) →
  (E1 = (0 : Int)) →
  (D1 = (0 : Int)) →
  (C1 = (0 : Int)) →
  (B1 = (0 : Int)) →
  (A1 = (0 : Int)) →
  (Z = (0 : Int)) →
  (Y = (0 : Int)) →
  (X = (0 : Int)) →
  (W = (0 : Int)) →
  (V = (0 : Int)) →
  (U = (0 : Int)) →
  (T = (0 : Int)) →
  (S = (0 : Int)) →
  (R = (0 : Int)) →
  (Q = (0 : Int)) →
  (P = (0 : Int)) →
  (O = (0 : Int)) →
  (N = (0 : Int)) →
  (M = (0 : Int)) →
  (L = (0 : Int)) →
  (K = (0 : Int)) →
  (J = (0 : Int)) →
  (I = (0 : Int)) →
  (O1 = (0 : Int)) →
  (N1 = (0 : Int)) →
  (M1 = (0 : Int)) →
  (L1 = (0 : Int)) →
  (H = (0 : Int)) →
  r0 G1 F1 E1 D1 C1 B1 A1 Z Y A X W V U T S R Q B P O N M) ∧
  (∀ (A : Int),
  (r1 A) →
  (True) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«CE-0CFA05_000»
