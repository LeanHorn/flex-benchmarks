import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«binomial03_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial03_000.smt2":114:1-114:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial03_000.smt2":8:1-73:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial03_000.smt2":74:1-91:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial03_000.smt2":92:1-101:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial03_000.smt2":102:1-112:2 (clause 4, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 U1 V1 W1 X1 Y1 Z1 A2 B2 C2 D2 E2 F2 : Int),
  let a!1 := ((0 : Int) = G1) = (¬(0 : Int) = Z ∧ ¬(0 : Int) = F1);
  let a!2 := ((0 : Int) = N) = (¬(0 : Int) = G1 ∨ ¬(0 : Int) = M);
  let a!3 := ((0 : Int) = M) = (¬(0 : Int) = L ∧ ¬(0 : Int) = R1);
  let a!4 := ((0 : Int) = L) = (¬(0 : Int) = K ∧ ¬(0 : Int) = C2);
  r2 H G F E D C B A →
    ¬((0 : Int) = R1) = (L1 ≥ Q1) →
      ¬a!1 →
        ¬((0 : Int) = F1) = (E1 ≥ (0 : Int)) →
          ((0 : Int) = Z) = (T ≤ Y) →
            ¬a!2 →
              ¬a!3 →
                ¬a!4 →
                  ¬((0 : Int) = K) = (J ≥ (0 : Int)) →
                    (0 : Int) = N →
                      ¬(0 : Int) = E →
                        F2 = D2 + E2 →
                          E2 = D →
                            D2 = (0 : Int) →
                              B2 = Z1 + A2 →
                                A2 = (-1 : Int) * H →
                                  Z1 = X1 + Y1 →
                                    Y1 = D →
                                      X1 = (0 : Int) →
                                        W1 = U1 + V1 →
                                          V1 = (-1 : Int) * G →
                                            U1 = S1 + T1 →
                                              T1 = F →
                                                S1 = (0 : Int) →
                                                  Q1 = O1 + P1 →
                                                    P1 = H →
                                                      O1 = M1 + N1 →
                                                        N1 = (0 : Int) →
                                                          M1 = (0 : Int) →
                                                            L1 = J1 + K1 →
                                                              K1 = G →
                                                                J1 = H1 + I1 →
                                                                  I1 = (0 : Int) →
                                                                    H1 = (0 : Int) →
                                                                      E1 = C1 + D1 →
                                                                        D1 = H →
                                                                          C1 = A1 + B1 →
                                                                            B1 = (0 : Int) →
                                                                              A1 = (0 : Int) →
                                                                                Y = W + X →
                                                                                  X = H →
                                                                                    W = U + V →
                                                                                      V = (0 : Int) →
                                                                                        U = (0 : Int) →
                                                                                          T = R + S →
                                                                                            S = G →
                                                                                              R = P + Q →
                                                                                                Q = (0 : Int) →
                                                                                                  P = (0 : Int) →
                                                                                                    O = (1 : Int) →
                                                                                                      J = F2 + I →
                                                                                                        I =
                                                                                                            (-1 : Int) *
                                                                                                              H →
                                                                                                          ((0 : Int) =
                                                                                                                C2) =
                                                                                                              (W1 ≤ B2) →
                                                                                                            r1 O) ∧
  ((∀ (A B C D E F G H I v_9 v_10 v_11 : Int),
  let a!1 := ((0 : Int) = I) = (¬(0 : Int) = G ∧ ¬(0 : Int) = H);
  r0 F E D C B A →
    ¬((0 : Int) = H) = (F ≥ (0 : Int)) →
      ¬((0 : Int) = G) = (E ≥ (0 : Int)) →
        ¬(0 : Int) = I → ¬a!1 → v_9 = C → v_10 = B → v_11 = A → r2 F C B A E v_9 v_10 v_11) ∧
  ((∀ (A B C D E F : Int),
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (F = (1 : Int)) →
  r0 A B F E D C) ∧
  (∀ (A : Int),
  (r1 A) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«binomial03_000»
