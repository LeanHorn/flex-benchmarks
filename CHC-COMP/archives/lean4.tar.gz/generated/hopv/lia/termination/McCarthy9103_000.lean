import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«McCarthy9103_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":211:1-211:12 (check-sat, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":12:1-39:2 (clause 1, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":40:1-51:2 (clause 2, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":52:1-77:2 (clause 3, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":78:1-103:2 (clause 4, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":104:1-114:2 (clause 5, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":115:1-127:2 (clause 6, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":128:1-140:2 (clause 7, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":141:1-154:2 (clause 8, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":155:1-166:2 (clause 9, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":167:1-177:2 (clause 10, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":178:1-188:2 (clause 11, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":189:1-198:2 (clause 12, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/McCarthy9103_000.smt2":199:1-209:2 (clause 13, command 21)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R : Int),
  let a!1 := ((0 : Int) = O) = (¬(0 : Int) = J ∧ ¬(0 : Int) = N);
  r0 D C B →
    r1 P D C B →
      ((0 : Int) = J) = (F ≤ I) →
        ¬a!1 →
          ¬(0 : Int) = B →
            ¬(0 : Int) = O →
              M = K + L →
                L = (-1 : Int) * D →
                  K = (111 : Int) →
                    I = G + H →
                      H = (-1 : Int) * D →
                        G = (111 : Int) →
                          F = Q + R →
                            E = (1 : Int) →
                              A = P →
                                R = (-1 : Int) * C → Q = (111 : Int) → ¬((0 : Int) = N) = (M ≥ (0 : Int)) → r3 A D C B) ∧
  ((∀ (A B C D E F : Int),
  (r0 D C B) →
  (r1 F D C B) →
  (A = F) →
  (E = (1 : Int)) →
  ((0 : Int) = B) →
  r3 A D C B) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  let a!1 := ((0 : Int) = N) = (¬(0 : Int) = M ∧ ¬(0 : Int) = I);
  r0 C B A →
    ¬a!1 →
      ¬((0 : Int) = M) = (L ≥ (0 : Int)) →
        ¬(0 : Int) = A →
          ¬(0 : Int) = N →
            L = J + K →
              K = (-1 : Int) * C →
                J = (111 : Int) →
                  H = F + G →
                    G = (-1 : Int) * C →
                      F = (111 : Int) →
                        E = O + P →
                          D = (1 : Int) → P = (-1 : Int) * B → O = (111 : Int) → ((0 : Int) = I) = (E ≤ H) → r4 C B A) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  let a!1 := ((0 : Int) = M) = (¬(0 : Int) = H ∧ ¬(0 : Int) = L);
  r0 C B A →
    ((0 : Int) = H) = (D ≤ G) →
      ¬a!1 →
        ¬(0 : Int) = A →
          (0 : Int) = M →
            K = I + J →
              J = (-1 : Int) * C →
                I = (111 : Int) →
                  G = E + F →
                    F = (-1 : Int) * C →
                      E = (111 : Int) →
                        D = O + P →
                          P = (-1 : Int) * B → O = (111 : Int) → N = (1 : Int) → ¬((0 : Int) = L) = (K ≥ (0 : Int)) → r2 N) ∧
  ((∀ (A B C D : Int),
  (r0 C B A) →
  (D = (1 : Int)) →
  ((0 : Int) = A) →
  r4 C B A) ∧
  ((∀ (A B C D E F G H I : Int),
  (r3 I H C D) →
  (r6 H G C D) →
  (r5 C B E) →
  ((0 : Int) = F) →
  (D = (1 : Int)) →
  (A = I) →
  (G = (11 : Int) + C) →
  (((0 : Int) = F) = (C ≤ (100 : Int))) →
  r6 A C B E) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r4 A B J) →
  (r6 I H D E) →
  (r5 D C F) →
  ((0 : Int) = G) →
  (E = (1 : Int)) →
  (H = (11 : Int) + D) →
  (((0 : Int) = G) = (D ≤ (100 : Int))) →
  r5 A B J) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r4 B A K) →
  (r6 J I E F) →
  (r6 C B A K) →
  (r5 E D G) →
  ((0 : Int) = H) →
  (F = (1 : Int)) →
  (I = (11 : Int) + E) →
  (((0 : Int) = H) = (E ≤ (100 : Int))) →
  r1 C B A K) ∧
  ((∀ (A B C D E F G : Int),
  (r5 B A D) →
  (r6 G F B C) →
  ((0 : Int) = E) →
  (C = (1 : Int)) →
  (F = (11 : Int) + B) →
  (((0 : Int) = E) = (B ≤ (100 : Int))) →
  r0 G B C) ∧
  ((∀ (A B C D E F : Int),
  (r5 C B E) →
  (¬(0 : Int) = F) →
  (A = (-10 : Int) + C) →
  (D = (1 : Int)) →
  (((0 : Int) = F) = (C ≤ (100 : Int))) →
  r6 A C B E) ∧
  ((∀ (A B C D E F : Int),
  (r5 B A D) →
  ((0 : Int) = E) →
  (F = (11 : Int) + B) →
  (C = (1 : Int)) →
  (((0 : Int) = E) = (B ≤ (100 : Int))) →
  r5 F B C) ∧
  ((∀ (A B C : Int),
  (B = (0 : Int)) →
  (C = (0 : Int)) →
  r5 A C B) ∧
  (∀ (A : Int),
  (r2 A) →
  (True) →
  False))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«McCarthy9103_000»
