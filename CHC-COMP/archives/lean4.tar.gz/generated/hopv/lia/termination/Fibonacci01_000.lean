import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«Fibonacci01_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci01_000.smt2":55:1-55:12 (check-sat, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci01_000.smt2":7:1-32:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci01_000.smt2":33:1-42:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci01_000.smt2":43:1-53:2 (clause 3, command 6)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P : Int),
  let a!1 := ((0 : Int) = O) = (¬(0 : Int) = N ∧ ¬(0 : Int) = J);
  r0 A C B →
    ¬a!1 →
      ¬((0 : Int) = N) = (M ≥ (0 : Int)) →
        ¬(0 : Int) = B →
          (0 : Int) = O →
            L = A →
              K = (0 : Int) →
                I = G + H →
                  H = A →
                    G = (0 : Int) →
                      F = D + E → E = C → D = (0 : Int) → P = (1 : Int) → M = K + L → ((0 : Int) = J) = (F ≤ I) → r1 P) ∧
  ((∀ (A B C : Int),
  (B = (0 : Int)) →
  (C = (0 : Int)) →
  r0 A C B) ∧
  (∀ (A : Int),
  (r1 A) →
  (True) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«Fibonacci01_000»
