import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«Fibonacci02_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":216:1-216:12 (check-sat, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":12:1-39:2 (clause 1, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":40:1-51:2 (clause 2, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":52:1-77:2 (clause 3, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":78:1-103:2 (clause 4, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":104:1-114:2 (clause 5, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":115:1-132:2 (clause 6, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":133:1-145:2 (clause 7, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":146:1-159:2 (clause 8, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":160:1-171:2 (clause 9, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":172:1-182:2 (clause 10, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":183:1-193:2 (clause 11, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":194:1-203:2 (clause 12, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Fibonacci02_000.smt2":204:1-214:2 (clause 13, command 21)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R : Int),
  let a!1 := ((0 : Int) = O) = (¬(0 : Int) = J ∧ ¬(0 : Int) = N);
  r2 D C B →
    r6 P D C B →
      ((0 : Int) = J) = (F ≤ I) →
        ¬a!1 →
          ¬(0 : Int) = B →
            ¬(0 : Int) = O →
              M = K + L →
                L = D →
                  K = (0 : Int) →
                    I = G + H →
                      H = D →
                        G = (0 : Int) →
                          F = Q + R →
                            E = (1 : Int) →
                              A = P → R = C → Q = (0 : Int) → ¬((0 : Int) = N) = (M ≥ (0 : Int)) → r3 A D C B) ∧
  ((∀ (A B C D E F : Int),
  (r2 D C B) →
  (r6 F D C B) →
  (A = F) →
  (E = (1 : Int)) →
  ((0 : Int) = B) →
  r3 A D C B) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  let a!1 := ((0 : Int) = N) = (¬(0 : Int) = M ∧ ¬(0 : Int) = I);
  r2 C B A →
    ¬a!1 →
      ¬((0 : Int) = M) = (L ≥ (0 : Int)) →
        ¬(0 : Int) = A →
          ¬(0 : Int) = N →
            L = J + K →
              K = C →
                J = (0 : Int) →
                  H = F + G →
                    G = C →
                      F = (0 : Int) →
                        E = O + P → D = (1 : Int) → P = B → O = (0 : Int) → ((0 : Int) = I) = (E ≤ H) → r4 C B A) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  let a!1 := ((0 : Int) = M) = (¬(0 : Int) = H ∧ ¬(0 : Int) = L);
  r2 C B A →
    ((0 : Int) = H) = (D ≤ G) →
      ¬a!1 →
        ¬(0 : Int) = A →
          (0 : Int) = M →
            K = I + J →
              J = C →
                I = (0 : Int) →
                  G = E + F →
                    F = C →
                      E = (0 : Int) →
                        D = O + P → P = B → O = (0 : Int) → N = (1 : Int) → ¬((0 : Int) = L) = (K ≥ (0 : Int)) → r1 N) ∧
  ((∀ (A B C D : Int),
  (r2 C B A) →
  (D = (1 : Int)) →
  ((0 : Int) = A) →
  r4 C B A) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r3 J I C D) →
  (r5 H G C D) →
  (r0 C B E) →
  ((0 : Int) = F) →
  (D = (1 : Int)) →
  (A = H + J) →
  (I = (-2 : Int) + C) →
  (G = (-1 : Int) + C) →
  (((0 : Int) = F) = ((2 : Int) ≤ C)) →
  r5 A C B E) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r4 A B K) →
  (r5 I H D E) →
  (r0 D C F) →
  ((0 : Int) = G) →
  (E = (1 : Int)) →
  (J = (-2 : Int) + D) →
  (H = (-1 : Int) + D) →
  (((0 : Int) = G) = ((2 : Int) ≤ D)) →
  r0 A B K) ∧
  ((∀ (A B C D E F G H I J K L : Int),
  (r4 B A L) →
  (r5 J I E F) →
  (r5 C B A L) →
  (r0 E D G) →
  ((0 : Int) = H) →
  (F = (1 : Int)) →
  (K = (-2 : Int) + E) →
  (I = (-1 : Int) + E) →
  (((0 : Int) = H) = ((2 : Int) ≤ E)) →
  r6 C B A L) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 B A D) →
  (r5 G F B C) →
  ((0 : Int) = E) →
  (C = (1 : Int)) →
  (H = (-2 : Int) + B) →
  (F = (-1 : Int) + B) →
  (((0 : Int) = E) = ((2 : Int) ≤ B)) →
  r2 H B C) ∧
  ((∀ (A B C D E F : Int),
  (r0 C B E) →
  (¬(0 : Int) = F) →
  (A = (1 : Int)) →
  (D = (1 : Int)) →
  (((0 : Int) = F) = ((2 : Int) ≤ C)) →
  r5 A C B E) ∧
  ((∀ (A B C D E F : Int),
  (r0 B A D) →
  ((0 : Int) = E) →
  (F = (-1 : Int) + B) →
  (C = (1 : Int)) →
  (((0 : Int) = E) = ((2 : Int) ≤ B)) →
  r0 F B C) ∧
  ((∀ (A B C : Int),
  (B = (0 : Int)) →
  (C = (0 : Int)) →
  r0 A C B) ∧
  (∀ (A : Int),
  (r1 A) →
  (True) →
  False))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«Fibonacci02_000»
