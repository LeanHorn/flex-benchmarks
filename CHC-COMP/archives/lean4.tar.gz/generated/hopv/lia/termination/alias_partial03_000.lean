import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«alias_partial03_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial03_000.smt2":129:1-129:12 (check-sat, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial03_000.smt2":10:1-35:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial03_000.smt2":36:1-46:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial03_000.smt2":47:1-72:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial03_000.smt2":73:1-84:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial03_000.smt2":85:1-95:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial03_000.smt2":96:1-106:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial03_000.smt2":107:1-116:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial03_000.smt2":117:1-127:2 (clause 8, command 14)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  ∃ (r3 : Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P : Int),
  let a!1 := ((0 : Int) = N) = (¬(0 : Int) = M ∧ ¬(0 : Int) = I);
  r2 D C B →
    ¬a!1 →
      ¬((0 : Int) = M) = (L ≥ (0 : Int)) →
        ¬(0 : Int) = B →
          ¬(0 : Int) = N →
            L = J + K →
              K = D →
                J = (0 : Int) →
                  H = F + G →
                    G = D →
                      F = (0 : Int) →
                        E = O + P → A = (1 : Int) → P = C → O = (0 : Int) → ((0 : Int) = I) = (E ≤ H) → r0 D C B) ∧
  ((∀ (A B C D : Int),
  (r2 D C B) →
  (A = (1 : Int)) →
  ((0 : Int) = B) →
  r0 D C B) ∧
  ((∀ (A B C D E F G H I J K L M N O P : Int),
  let a!1 := ((0 : Int) = M) = (¬(0 : Int) = H ∧ ¬(0 : Int) = L);
  r2 C B A →
    ((0 : Int) = H) = (D ≤ G) →
      ¬a!1 →
        ¬(0 : Int) = A →
          (0 : Int) = M →
            K = I + J →
              J = C →
                I = (0 : Int) →
                  G = E + F →
                    F = C →
                      E = (0 : Int) →
                        D = O + P → P = B → O = (0 : Int) → N = (1 : Int) → ¬((0 : Int) = L) = (K ≥ (0 : Int)) → r3 N) ∧
  ((∀ (A B C D E F G H I : Int),
  (r0 B A I) →
  (r1 E D C) →
  (¬(0 : Int) = G) →
  (H = (-1 : Int) + E) →
  (F = (1 : Int)) →
  (((0 : Int) = G) = (E ≤ (0 : Int))) →
  r1 B A I) ∧
  ((∀ (A B C D E F : Int),
  (r4 C B A) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (F = (1 : Int)) →
  r1 F E D) ∧
  ((∀ (A B C D E F : Int),
  (r1 C B A) →
  (¬(0 : Int) = E) →
  (F = (-1 : Int) + C) →
  (D = (1 : Int)) →
  (((0 : Int) = E) = (C ≤ (0 : Int))) →
  r2 F C D) ∧
  ((∀ (A B C : Int),
  (B = (0 : Int)) →
  (A = (0 : Int)) →
  (C = (1 : Int)) →
  r4 C B A) ∧
  (∀ (A : Int),
  (r3 A) →
  (True) →
  False)))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«alias_partial03_000»
