import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«alias_partial01_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial01_000.smt2":52:1-52:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial01_000.smt2":8:1-18:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial01_000.smt2":19:1-29:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial01_000.smt2":30:1-39:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial01_000.smt2":40:1-50:2 (clause 4, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Prop),
  (∀ (A B C D : Int),
  (r0 C B A) →
  (D = (1 : Int)) →
  (¬(0 : Int) = A) →
  r2 D) ∧
  ((∀ (A B C D E F : Int),
  (r1 C B A) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (F = (1 : Int)) →
  r0 F E D) ∧
  ((∀ (A B C : Int),
  (B = (0 : Int)) →
  (A = (0 : Int)) →
  (C = (1 : Int)) →
  r1 C B A) ∧
  (∀ (A : Int),
  (r2 A) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«alias_partial01_000»
