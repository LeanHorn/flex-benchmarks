import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«Ackermann00_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann00_000.smt2":50:1-50:12 (check-sat, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann00_000.smt2":7:1-17:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann00_000.smt2":18:1-37:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann00_000.smt2":38:1-48:2 (clause 3, command 6)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  (∀ (A B C D E F G H I : Int),
  (r0 H G F E D C B A) →
  (I = (1 : Int)) →
  (¬(0 : Int) = E) →
  r1 I) ∧
  ((∀ (A B C D E F G H v_8 v_9 v_10 : Int),
  let a!1 := ((0 : Int) = H) = (¬(0 : Int) = F ∧ ¬(0 : Int) = G);
  ((0 : Int) = G) = (A ≤ (0 : Int)) →
    ((0 : Int) = F) = (B ≤ (0 : Int)) →
      ¬(0 : Int) = H →
        E = (0 : Int) → D = (0 : Int) → C = (0 : Int) → ¬a!1 → v_8 = E → v_9 = D → v_10 = C → r0 B E D C A v_8 v_9 v_10) ∧
  (∀ (A : Int),
  (r1 A) →
  (True) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«Ackermann00_000»
