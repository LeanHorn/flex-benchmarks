import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«CE-0CFA01_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-0CFA01_000.smt2":108:1-108:12 (check-sat, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-0CFA01_000.smt2":9:1-40:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-0CFA01_000.smt2":41:1-51:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-0CFA01_000.smt2":52:1-84:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-0CFA01_000.smt2":85:1-95:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-0CFA01_000.smt2":96:1-106:2 (clause 5, command 10)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W : Int),
  (M = (0 : Int)) →
  (L = (0 : Int)) →
  (K = (0 : Int)) →
  (J = (0 : Int)) →
  (I = (0 : Int)) →
  (H = (0 : Int)) →
  (G = (0 : Int)) →
  (F = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (B = (0 : Int)) →
  (A = (0 : Int)) →
  (S = (0 : Int)) →
  (R = (0 : Int)) →
  (Q = (0 : Int)) →
  (P = (0 : Int)) →
  (O = (0 : Int)) →
  (W = (1 : Int)) →
  (V = (0 : Int)) →
  (U = (0 : Int)) →
  (T = (0 : Int)) →
  (N = (0 : Int)) →
  r1 W V U T S A R Q P O B N M) ∧
  ((∀ (A B C D E F G H I J K L M : Int),
  (r1 M L K J I H G F E D C B A) →
  (True) →
  r3 M L K J I H G F E D C B A) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z : Int),
  (r3 A B Z V U C T S R Q D P O) →
  (P = (0 : Int)) →
  (O = (0 : Int)) →
  (N = (0 : Int)) →
  (M = (0 : Int)) →
  (L = (0 : Int)) →
  (K = (0 : Int)) →
  (J = (0 : Int)) →
  (I = (0 : Int)) →
  (H = (0 : Int)) →
  (G = (0 : Int)) →
  (F = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (V = (0 : Int)) →
  (U = (0 : Int)) →
  (T = (0 : Int)) →
  (S = (0 : Int)) →
  (R = (0 : Int)) →
  (Y = (1 : Int)) →
  (X = (0 : Int)) →
  (W = (0 : Int)) →
  (Q = (0 : Int)) →
  r0 A B Z) ∧
  ((∀ (A B C D : Int),
  (r0 A C B) →
  (D = (1 : Int)) →
  (¬(0 : Int) = B) →
  r2 D) ∧
  (∀ (A : Int),
  (r2 A) →
  (True) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«CE-0CFA01_000»
