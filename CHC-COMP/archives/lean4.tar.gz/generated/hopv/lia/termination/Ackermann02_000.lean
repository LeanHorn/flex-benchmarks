import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«Ackermann02_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":334:1-334:12 (check-sat, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":13:1-29:2 (clause 1, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":30:1-54:2 (clause 2, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":55:1-74:2 (clause 3, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":75:1-92:2 (clause 4, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":93:1-110:2 (clause 5, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":111:1-144:2 (clause 6, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":145:1-156:2 (clause 7, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":157:1-188:2 (clause 8, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":189:1-199:2 (clause 9, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":200:1-231:2 (clause 10, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":232:1-258:2 (clause 11, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":259:1-280:2 (clause 12, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":281:1-291:2 (clause 13, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":292:1-311:2 (clause 14, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":312:1-321:2 (clause 15, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann02_000.smt2":322:1-332:2 (clause 16, command 25)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r1 A G F E D C B T) →
  (r2 O N M L K J I H) →
  (¬((0 : Int) = Q) = (K = (0 : Int))) →
  ((0 : Int) = R) →
  ((0 : Int) = Q) →
  (S = (-1 : Int) + O) →
  (P = (1 : Int)) →
  (¬((0 : Int) = R) = (O = (0 : Int))) →
  r2 A G F E D C B T) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 v_17 v_18 v_19 v_20 : Int),
  (r6 M L H D I v_14 v_15 v_16 v_17) →
  (r2 H G F E D C B A) →
  (v_14 = D) →
  (v_15 = H) →
  (v_16 = D) →
  (v_17 = I) →
  (¬((0 : Int) = J) = (D = (0 : Int))) →
  ((0 : Int) = K) →
  ((0 : Int) = J) →
  (N = (-1 : Int) + D) →
  (L = (-1 : Int) + H) →
  (I = (1 : Int)) →
  (¬((0 : Int) = K) = (H = (0 : Int))) →
  (v_18 = H) →
  (v_19 = D) →
  (v_20 = I) →
  r2 M H D I N v_18 v_19 v_20) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r2 H G F E D C B A) →
  (¬((0 : Int) = J) = (D = (0 : Int))) →
  (¬(0 : Int) = K) →
  ((0 : Int) = J) →
  (M = (1 : Int)) →
  (L = (-1 : Int) + D) →
  (I = (1 : Int)) →
  (¬((0 : Int) = K) = (H = (0 : Int))) →
  (v_13 = H) →
  (v_14 = D) →
  (v_15 = I) →
  r2 M H D I L v_13 v_14 v_15) ∧
  ((∀ (A B C D E F G H I v_9 v_10 v_11 : Int),
  let a!1 := ((0 : Int) = I) = (¬(0 : Int) = G ∧ ¬(0 : Int) = H);
  r0 F E D C B A →
    ((0 : Int) = H) = (E ≤ (0 : Int)) →
      ((0 : Int) = G) = (F ≤ (0 : Int)) →
        ¬(0 : Int) = I → ¬a!1 → v_9 = C → v_10 = B → v_11 = A → r2 F C B A E v_9 v_10 v_11) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r1 G F E D C B A U) →
  (r5 H G F E D C B A U) →
  (r2 P O N M L K J I) →
  (¬((0 : Int) = R) = (L = (0 : Int))) →
  ((0 : Int) = S) →
  ((0 : Int) = R) →
  (T = (-1 : Int) + P) →
  (Q = (1 : Int)) →
  (¬((0 : Int) = S) = (P = (0 : Int))) →
  r3 H G F E D C B A U) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 : Int),
  let a!1 := ((0 : Int) = C1) = (¬(0 : Int) = V ∧ ¬(0 : Int) = B1);
  r7 C B J I H G F E →
    r3 K C B J I H G F E →
      ¬((0 : Int) = B1) = (A1 ≥ (0 : Int)) →
        ((0 : Int) = V) = (P ≤ U) →
          ¬(0 : Int) = I →
            ¬(0 : Int) = C1 →
              D = (1 : Int) →
                A = K →
                  Q = (0 : Int) →
                    P = N + O →
                      O = B →
                        N = L + M →
                          M = (0 : Int) →
                            L = (0 : Int) →
                              A1 = Y + Z →
                                Z = C →
                                  Y = W + X →
                                    X = (0 : Int) →
                                      W = (0 : Int) →
                                        U = S + T → T = C → S = Q + R → R = (0 : Int) → ¬a!1 → r6 A C B J I H G F E) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r7 C B J I H G F E) →
  (r3 K C B J I H G F E) →
  (D = (1 : Int)) →
  (A = K) →
  ((0 : Int) = I) →
  r6 A C B J I H G F E) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  let a!1 := ((0 : Int) = A1) = (¬(0 : Int) = T ∧ ¬(0 : Int) = Z);
  r7 B A I H G F E D →
    ¬((0 : Int) = Z) = (Y ≥ (0 : Int)) →
      ((0 : Int) = T) = (N ≤ S) →
        ¬(0 : Int) = H →
          ¬(0 : Int) = A1 →
            C = (1 : Int) →
              O = (0 : Int) →
                N = L + M →
                  M = A →
                    L = J + K →
                      K = (0 : Int) →
                        J = (0 : Int) →
                          Y = W + X →
                            X = B →
                              W = U + V →
                                V = (0 : Int) →
                                  U = (0 : Int) →
                                    S = Q + R → R = B → Q = O + P → P = (0 : Int) → ¬a!1 → r1 B A I H G F E D) ∧
  ((∀ (A B C D E F G H I : Int),
  (r7 B A I H G F E D) →
  (C = (1 : Int)) →
  ((0 : Int) = H) →
  r1 B A I H G F E D) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  let a!1 := ((0 : Int) = Z) = (¬(0 : Int) = S ∧ ¬(0 : Int) = Y);
  r7 B A H G F E D C →
    ¬((0 : Int) = Y) = (X ≥ (0 : Int)) →
      ((0 : Int) = S) = (M ≤ R) →
        ¬(0 : Int) = G →
          (0 : Int) = Z →
            O = (0 : Int) →
              N = (0 : Int) →
                M = K + L →
                  L = A →
                    K = I + J →
                      J = (0 : Int) →
                        I = (0 : Int) →
                          A1 = (1 : Int) →
                            X = V + W →
                              W = B →
                                V = T + U → U = (0 : Int) → T = (0 : Int) → R = P + Q → Q = B → P = N + O → ¬a!1 → r4 A1) ∧
  ((∀ (A B C D E F G H I J K L M N O P v_16 v_17 v_18 v_19 v_20 v_21 v_22 : Int),
  (r6 N M I E J v_16 v_17 v_18 v_19) →
  (r5 P N I E J O v_20 v_21 v_22) →
  (r2 I H G F E D C B) →
  (v_16 = E) →
  (v_17 = I) →
  (v_18 = E) →
  (v_19 = J) →
  (v_20 = I) →
  (v_21 = E) →
  (v_22 = J) →
  (¬((0 : Int) = K) = (E = (0 : Int))) →
  ((0 : Int) = L) →
  ((0 : Int) = K) →
  (A = P) →
  (O = (-1 : Int) + E) →
  (M = (-1 : Int) + I) →
  (J = (1 : Int)) →
  (¬((0 : Int) = L) = (I = (0 : Int))) →
  r5 A I H G F E D C B) ∧
  ((∀ (A B C D E F G H I J K L M N O v_15 v_16 v_17 : Int),
  (r2 I H G F E D C B) →
  (r5 O N I E J M v_15 v_16 v_17) →
  (v_15 = I) →
  (v_16 = E) →
  (v_17 = J) →
  (¬((0 : Int) = K) = (E = (0 : Int))) →
  (¬(0 : Int) = L) →
  ((0 : Int) = K) →
  (A = O) →
  (N = (1 : Int)) →
  (M = (-1 : Int) + E) →
  (J = (1 : Int)) →
  (¬((0 : Int) = L) = (I = (0 : Int))) →
  r5 A I H G F E D C B) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r2 I H G F E D C B) →
  (¬(0 : Int) = K) →
  (J = (1 : Int)) →
  (A = (1 : Int) + I) →
  (¬((0 : Int) = K) = (E = (0 : Int))) →
  r5 A I H G F E D C B) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 v_15 : Int),
  (r2 H G F E D C B A) →
  (¬((0 : Int) = J) = (D = (0 : Int))) →
  ((0 : Int) = K) →
  ((0 : Int) = J) →
  (L = (-1 : Int) + H) →
  (I = (1 : Int)) →
  (¬((0 : Int) = K) = (H = (0 : Int))) →
  (v_12 = D) →
  (v_13 = H) →
  (v_14 = D) →
  (v_15 = I) →
  r7 L H D I v_12 v_13 v_14 v_15) ∧
  ((∀ (A B C D E F : Int),
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (F = (1 : Int)) →
  r0 A B F E D C) ∧
  (∀ (A : Int),
  (r4 A) →
  (True) →
  False)))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«Ackermann02_000»
