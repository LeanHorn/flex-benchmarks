import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«binomial01_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial01_000.smt2":80:1-80:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial01_000.smt2":8:1-39:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial01_000.smt2":40:1-57:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial01_000.smt2":58:1-67:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial01_000.smt2":68:1-78:2 (clause 4, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  let a!1 := ((0 : Int) = Z) = (¬(0 : Int) = S ∧ ¬(0 : Int) = Y);
  r2 H G F E D C B A →
    ¬((0 : Int) = Y) = (X ≥ (0 : Int)) →
      ((0 : Int) = S) = (M ≤ R) →
        (0 : Int) = Z →
          ¬(0 : Int) = E →
            A1 = (1 : Int) →
              X = V + W →
                W = (-1 : Int) * H →
                  V = T + U →
                    U = D →
                      T = (0 : Int) →
                        R = P + Q →
                          Q = (-1 : Int) * H →
                            P = N + O →
                              O = D →
                                N = (0 : Int) →
                                  M = K + L → L = (-1 : Int) * G → K = I + J → J = F → I = (0 : Int) → ¬a!1 → r1 A1) ∧
  ((∀ (A B C D E F G H I v_9 v_10 v_11 : Int),
  let a!1 := ((0 : Int) = I) = (¬(0 : Int) = G ∧ ¬(0 : Int) = H);
  r0 F E D C B A →
    ¬((0 : Int) = H) = (F ≥ (0 : Int)) →
      ¬((0 : Int) = G) = (E ≥ (0 : Int)) →
        ¬(0 : Int) = I → ¬a!1 → v_9 = C → v_10 = B → v_11 = A → r2 F C B A E v_9 v_10 v_11) ∧
  ((∀ (A B C D E F : Int),
  (E = (0 : Int)) →
  (D = (1 : Int)) →
  (C = (0 : Int)) →
  (F = (0 : Int)) →
  r0 A B D C F E) ∧
  (∀ (A : Int),
  (r1 A) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«binomial01_000»
