import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«alias_partial02_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial02_000.smt2":67:1-67:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial02_000.smt2":8:1-33:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial02_000.smt2":34:1-44:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial02_000.smt2":45:1-54:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/alias_partial02_000.smt2":55:1-65:2 (clause 4, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P : Int),
  let a!1 := ((0 : Int) = O) = (¬(0 : Int) = N ∧ ¬(0 : Int) = J);
  r0 C B A →
    ¬a!1 →
      ¬((0 : Int) = N) = (M ≥ (0 : Int)) →
        ¬(0 : Int) = A →
          (0 : Int) = O →
            L = C →
              K = (0 : Int) →
                I = G + H →
                  H = C →
                    G = (0 : Int) →
                      F = D + E → E = B → D = (0 : Int) → P = (1 : Int) → M = K + L → ((0 : Int) = J) = (F ≤ I) → r2 P) ∧
  ((∀ (A B C D E F : Int),
  (r1 C B A) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (F = (1 : Int)) →
  r0 F E D) ∧
  ((∀ (A B C : Int),
  (B = (0 : Int)) →
  (A = (0 : Int)) →
  (C = (1 : Int)) →
  r1 C B A) ∧
  (∀ (A : Int),
  (r2 A) →
  (True) →
  False)))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«alias_partial02_000»
