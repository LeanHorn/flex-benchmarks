import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«binomial02_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":340:1-340:12 (check-sat, command 25)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":13:1-38:2 (clause 1, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":39:1-61:2 (clause 2, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":62:1-79:2 (clause 3, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":80:1-106:2 (clause 4, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":107:1-140:2 (clause 5, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":141:1-152:2 (clause 6, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":153:1-184:2 (clause 7, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":185:1-195:2 (clause 8, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":196:1-227:2 (clause 9, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":228:1-258:2 (clause 10, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":259:1-269:2 (clause 11, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":270:1-288:2 (clause 12, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":289:1-317:2 (clause 13, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":318:1-327:2 (clause 14, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/binomial02_000.smt2":328:1-338:2 (clause 15, command 24)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y v_25 v_26 v_27 : Int),
  let a!1 := ((0 : Int) = T) = (¬(0 : Int) = S ∨ ¬(0 : Int) = R);
  r6 A G F E D C B Y →
    r3 W V O K P U v_25 v_26 v_27 →
      r0 O N M L K J I H →
        v_25 = O →
          v_26 = K →
            v_27 = P →
              ¬((0 : Int) = S) = (O ≥ K) →
                ¬((0 : Int) = R) = (O ≤ (0 : Int)) →
                  ¬((0 : Int) = Q) = (K = (0 : Int)) →
                    (0 : Int) = T →
                      (0 : Int) = Q →
                        X = (-1 : Int) + K →
                          V = (-1 : Int) + O → U = (-1 : Int) + K → P = (1 : Int) → ¬a!1 → r0 A G F E D C B Y) ∧
  ((∀ (A B C D E F G H I J K L M N O v_15 v_16 v_17 : Int),
  let a!1 := ((0 : Int) = M) = (¬(0 : Int) = K ∨ ¬(0 : Int) = L);
  r0 H G F E D C B A →
    ¬((0 : Int) = L) = (H ≥ D) →
      ¬((0 : Int) = K) = (H ≤ (0 : Int)) →
        ¬((0 : Int) = J) = (D = (0 : Int)) →
          (0 : Int) = M →
            (0 : Int) = J →
              O = (-1 : Int) + H →
                N = (-1 : Int) + D → I = (1 : Int) → ¬a!1 → v_15 = H → v_16 = D → v_17 = I → r0 O H D I N v_15 v_16 v_17) ∧
  ((∀ (A B C D E F G H I v_9 v_10 v_11 : Int),
  let a!1 := ((0 : Int) = I) = (¬(0 : Int) = G ∧ ¬(0 : Int) = H);
  r1 F E D C B A →
    ¬((0 : Int) = H) = (F ≥ (0 : Int)) →
      ¬((0 : Int) = G) = (E ≥ (0 : Int)) →
        ¬(0 : Int) = I → ¬a!1 → v_9 = C → v_10 = B → v_11 = A → r0 F C B A E v_9 v_10 v_11) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z v_26 v_27 v_28 : Int),
  let a!1 := ((0 : Int) = U) = (¬(0 : Int) = T ∨ ¬(0 : Int) = S);
  r6 G F E D C B A Z →
    r3 X W P L Q V v_26 v_27 v_28 →
      r3 H G F E D C B A Z →
        r0 P O N M L K J I →
          v_26 = P →
            v_27 = L →
              v_28 = Q →
                ¬((0 : Int) = T) = (P ≥ L) →
                  ¬((0 : Int) = S) = (P ≤ (0 : Int)) →
                    ¬((0 : Int) = R) = (L = (0 : Int)) →
                      (0 : Int) = U →
                        (0 : Int) = R →
                          Y = (-1 : Int) + L →
                            W = (-1 : Int) + P → V = (-1 : Int) + L → Q = (1 : Int) → ¬a!1 → r4 H G F E D C B A Z) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 : Int),
  let a!1 := ((0 : Int) = C1) = (¬(0 : Int) = V ∧ ¬(0 : Int) = B1);
  r5 C B J I H G F E →
    r4 K C B J I H G F E →
      ¬((0 : Int) = B1) = (A1 ≥ (0 : Int)) →
        ((0 : Int) = V) = (P ≤ U) →
          ¬(0 : Int) = I →
            ¬(0 : Int) = C1 →
              A = K →
                D = (1 : Int) →
                  L = (0 : Int) →
                    A1 = Y + Z →
                      Z = (-1 : Int) * C →
                        Y = W + X →
                          X = H →
                            W = (0 : Int) →
                              U = S + T →
                                T = (-1 : Int) * C →
                                  S = Q + R →
                                    R = H →
                                      Q = (0 : Int) →
                                        P = N + O → O = (-1 : Int) * B → N = L + M → M = J → ¬a!1 → r2 A C B J I H G F E) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r5 C B J I H G F E) →
  (r4 K C B J I H G F E) →
  (D = (1 : Int)) →
  (A = K) →
  ((0 : Int) = I) →
  r2 A C B J I H G F E) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  let a!1 := ((0 : Int) = A1) = (¬(0 : Int) = T ∧ ¬(0 : Int) = Z);
  r5 B A I H G F E D →
    ¬((0 : Int) = Z) = (Y ≥ (0 : Int)) →
      ((0 : Int) = T) = (N ≤ S) →
        ¬(0 : Int) = H →
          ¬(0 : Int) = A1 →
            J = (0 : Int) →
              C = (1 : Int) →
                Y = W + X →
                  X = (-1 : Int) * B →
                    W = U + V →
                      V = G →
                        U = (0 : Int) →
                          S = Q + R →
                            R = (-1 : Int) * B →
                              Q = O + P →
                                P = G →
                                  O = (0 : Int) →
                                    N = L + M → M = (-1 : Int) * A → L = J + K → K = I → ¬a!1 → r6 B A I H G F E D) ∧
  ((∀ (A B C D E F G H I : Int),
  (r5 B A I H G F E D) →
  (C = (1 : Int)) →
  ((0 : Int) = H) →
  r6 B A I H G F E D) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 : Int),
  let a!1 := ((0 : Int) = Z) = (¬(0 : Int) = S ∧ ¬(0 : Int) = Y);
  r5 B A H G F E D C →
    ¬((0 : Int) = Y) = (X ≥ (0 : Int)) →
      ((0 : Int) = S) = (M ≤ R) →
        ¬(0 : Int) = G →
          (0 : Int) = Z →
            J = H →
              I = (0 : Int) →
                A1 = (1 : Int) →
                  X = V + W →
                    W = (-1 : Int) * B →
                      V = T + U →
                        U = F →
                          T = (0 : Int) →
                            R = P + Q →
                              Q = (-1 : Int) * B →
                                P = N + O →
                                  O = F → N = (0 : Int) → M = K + L → L = (-1 : Int) * A → K = I + J → ¬a!1 → r7 A1) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S v_19 v_20 v_21 v_22 v_23 v_24 v_25 : Int),
  let a!1 := ((0 : Int) = N) = (¬(0 : Int) = M ∨ ¬(0 : Int) = L);
  r2 S I v_19 E J R v_20 v_21 v_22 →
    r3 Q P I E J O v_23 v_24 v_25 →
      r0 I H G F E D C B →
        v_19 = I →
          v_20 = I →
            v_21 = E →
              v_22 = J →
                v_23 = I →
                  v_24 = E →
                    v_25 = J →
                      ¬((0 : Int) = M) = (I ≥ E) →
                        ¬((0 : Int) = L) = (I ≤ (0 : Int)) →
                          ¬((0 : Int) = K) = (E = (0 : Int)) →
                            (0 : Int) = N →
                              (0 : Int) = K →
                                A = Q + S →
                                  R = (-1 : Int) + E →
                                    P = (-1 : Int) + I → O = (-1 : Int) + E → J = (1 : Int) → ¬a!1 → r3 A I H G F E D C B) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r0 I H G F E D C B) →
  (¬(0 : Int) = K) →
  (J = (1 : Int)) →
  (A = (1 : Int)) →
  (¬((0 : Int) = K) = (E = (0 : Int))) →
  r3 A I H G F E D C B) ∧
  ((∀ (A B C D E F G H I J K L M N : Int),
  let a!1 := ((0 : Int) = N) = (¬(0 : Int) = M ∨ ¬(0 : Int) = L);
  r0 I H G F E D C B →
    ¬((0 : Int) = M) = (I ≥ E) →
      ¬((0 : Int) = L) = (I ≤ (0 : Int)) →
        ¬((0 : Int) = K) = (E = (0 : Int)) →
          ¬(0 : Int) = N → (0 : Int) = K → J = (1 : Int) → A = (1 : Int) → ¬a!1 → r3 A I H G F E D C B) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q v_17 v_18 v_19 v_20 v_21 v_22 v_23 : Int),
  let a!1 := ((0 : Int) = M) = (¬(0 : Int) = K ∨ ¬(0 : Int) = L);
  r0 H G F E D C B A →
    r3 P O H D I N v_17 v_18 v_19 →
      v_17 = H →
        v_18 = D →
          v_19 = I →
            ¬((0 : Int) = L) = (H ≥ D) →
              ¬((0 : Int) = K) = (H ≤ (0 : Int)) →
                ¬((0 : Int) = J) = (D = (0 : Int)) →
                  (0 : Int) = M →
                    (0 : Int) = J →
                      Q = (-1 : Int) + D →
                        O = (-1 : Int) + H →
                          N = (-1 : Int) + D →
                            I = (1 : Int) →
                              ¬a!1 → v_20 = H → v_21 = H → v_22 = D → v_23 = I → r5 H v_20 D I Q v_21 v_22 v_23) ∧
  ((∀ (A B C D E F : Int),
  (E = (1 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (F = (0 : Int)) →
  r1 A B E D C F) ∧
  (∀ (A : Int),
  (r7 A) →
  (True) →
  False))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«binomial02_000»
