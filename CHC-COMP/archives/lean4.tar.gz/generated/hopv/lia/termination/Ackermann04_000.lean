import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«Ackermann04_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":436:1-436:12 (check-sat, command 26)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":13:1-29:2 (clause 1, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":30:1-54:2 (clause 2, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":55:1-74:2 (clause 3, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":75:1-92:2 (clause 4, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":93:1-110:2 (clause 5, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":111:1-178:2 (clause 6, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":179:1-190:2 (clause 7, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":191:1-256:2 (clause 8, command 17)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":257:1-267:2 (clause 9, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":268:1-333:2 (clause 10, command 19)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":334:1-360:2 (clause 11, command 20)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":361:1-382:2 (clause 12, command 21)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":383:1-393:2 (clause 13, command 22)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":394:1-413:2 (clause 14, command 23)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":414:1-423:2 (clause 15, command 24)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/Ackermann04_000.smt2":424:1-434:2 (clause 16, command 25)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Prop),
  ∃ (r5 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r6 : Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r7 : Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S T : Int),
  (r1 A G F E D C B T) →
  (r2 O N M L K J I H) →
  (¬((0 : Int) = Q) = (K = (0 : Int))) →
  ((0 : Int) = R) →
  ((0 : Int) = Q) →
  (S = (-1 : Int) + O) →
  (P = (1 : Int)) →
  (¬((0 : Int) = R) = (O = (0 : Int))) →
  r2 A G F E D C B T) ∧
  ((∀ (A B C D E F G H I J K L M N v_14 v_15 v_16 v_17 v_18 v_19 v_20 : Int),
  (r6 M L H D I v_14 v_15 v_16 v_17) →
  (r2 H G F E D C B A) →
  (v_14 = D) →
  (v_15 = H) →
  (v_16 = D) →
  (v_17 = I) →
  (¬((0 : Int) = J) = (D = (0 : Int))) →
  ((0 : Int) = K) →
  ((0 : Int) = J) →
  (N = (-1 : Int) + D) →
  (L = (-1 : Int) + H) →
  (I = (1 : Int)) →
  (¬((0 : Int) = K) = (H = (0 : Int))) →
  (v_18 = H) →
  (v_19 = D) →
  (v_20 = I) →
  r2 M H D I N v_18 v_19 v_20) ∧
  ((∀ (A B C D E F G H I J K L M v_13 v_14 v_15 : Int),
  (r2 H G F E D C B A) →
  (¬((0 : Int) = L) = (D = (0 : Int))) →
  (¬(0 : Int) = M) →
  ((0 : Int) = L) →
  (K = (1 : Int)) →
  (J = (-1 : Int) + D) →
  (I = (1 : Int)) →
  (¬((0 : Int) = M) = (H = (0 : Int))) →
  (v_13 = H) →
  (v_14 = D) →
  (v_15 = I) →
  r2 K H D I J v_13 v_14 v_15) ∧
  ((∀ (A B C D E F G H I v_9 v_10 v_11 : Int),
  let a!1 := ((0 : Int) = I) = (¬(0 : Int) = G ∧ ¬(0 : Int) = H);
  r0 F E D C B A →
    ((0 : Int) = H) = (E ≤ (0 : Int)) →
      ((0 : Int) = G) = (F ≤ (0 : Int)) →
        ¬(0 : Int) = I → ¬a!1 → v_9 = C → v_10 = B → v_11 = A → r2 F C B A E v_9 v_10 v_11) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U : Int),
  (r1 G F E D C B A U) →
  (r5 H G F E D C B A U) →
  (r2 P O N M L K J I) →
  (¬((0 : Int) = R) = (L = (0 : Int))) →
  ((0 : Int) = S) →
  ((0 : Int) = R) →
  (T = (-1 : Int) + P) →
  (Q = (1 : Int)) →
  (¬((0 : Int) = S) = (P = (0 : Int))) →
  r3 H G F E D C B A U) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 U1 V1 W1 X1 Y1 Z1 A2 B2 C2 D2 E2 F2 G2 H2 : Int),
  let a!1 := ((0 : Int) = H2) = (¬(0 : Int) = G2 ∨ ¬(0 : Int) = C1);
  let a!2 := ((0 : Int) = G2) = (¬(0 : Int) = F2 ∧ ¬(0 : Int) = N1);
  let a!3 := ((0 : Int) = F2) = (¬(0 : Int) = Y1 ∧ ¬(0 : Int) = E2);
  let a!4 := ((0 : Int) = C1) = (¬(0 : Int) = V ∧ ¬(0 : Int) = B1);
  r7 C B J I H G F E →
    r3 K C B J I H G F E →
      ¬((0 : Int) = B1) = (A1 ≥ (0 : Int)) →
        ((0 : Int) = V) = (P ≤ U) →
          ¬((0 : Int) = N1) = (H1 ≥ M1) →
            ¬a!1 →
              ¬a!2 →
                ¬a!3 →
                  ¬((0 : Int) = E2) = (D2 ≥ (0 : Int)) →
                    ((0 : Int) = Y1) = (S1 ≤ X1) →
                      ¬(0 : Int) = I →
                        ¬(0 : Int) = H2 →
                          M1 = K1 + L1 →
                            L1 = (0 : Int) →
                              K1 = I1 + J1 →
                                J1 = H →
                                  I1 = (0 : Int) →
                                    H1 = F1 + G1 →
                                      G1 = (0 : Int) →
                                        F1 = D1 + E1 →
                                          E1 = J →
                                            D1 = (0 : Int) →
                                              A1 = Y + Z →
                                                Z = (0 : Int) →
                                                  Y = W + X →
                                                    X = H →
                                                      W = (0 : Int) →
                                                        U = S + T →
                                                          T = (0 : Int) →
                                                            S = Q + R →
                                                              R = H →
                                                                Q = (0 : Int) →
                                                                  P = N + O →
                                                                    O = (0 : Int) →
                                                                      N = L + M →
                                                                        M = J →
                                                                          L = (0 : Int) →
                                                                            D = (1 : Int) →
                                                                              A = K →
                                                                                V1 = T1 + U1 →
                                                                                  U1 = (0 : Int) →
                                                                                    T1 = (0 : Int) →
                                                                                      S1 = Q1 + R1 →
                                                                                        R1 = B →
                                                                                          Q1 = O1 + P1 →
                                                                                            P1 = (0 : Int) →
                                                                                              O1 = (0 : Int) →
                                                                                                D2 = B2 + C2 →
                                                                                                  C2 = C →
                                                                                                    B2 = Z1 + A2 →
                                                                                                      A2 = (0 : Int) →
                                                                                                        Z1 = (0 : Int) →
                                                                                                          X1 = V1 + W1 →
                                                                                                            W1 = C →
                                                                                                              ¬a!4 →
                                                                                                                r6 A C B J
                                                                                                                  I H G F
                                                                                                                  E) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r7 C B J I H G F E) →
  (r3 K C B J I H G F E) →
  (D = (1 : Int)) →
  (A = K) →
  ((0 : Int) = I) →
  r6 A C B J I H G F E) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 U1 V1 W1 X1 Y1 Z1 A2 B2 C2 D2 E2 F2 : Int),
  let a!1 := ((0 : Int) = F2) = (¬(0 : Int) = E2 ∨ ¬(0 : Int) = A1);
  let a!2 := ((0 : Int) = E2) = (¬(0 : Int) = D2 ∧ ¬(0 : Int) = L1);
  let a!3 := ((0 : Int) = D2) = (¬(0 : Int) = W1 ∧ ¬(0 : Int) = C2);
  let a!4 := ((0 : Int) = A1) = (¬(0 : Int) = T ∧ ¬(0 : Int) = Z);
  r7 B A I H G F E D →
    ¬((0 : Int) = Z) = (Y ≥ (0 : Int)) →
      ((0 : Int) = T) = (N ≤ S) →
        ¬((0 : Int) = L1) = (F1 ≥ K1) →
          ¬a!1 →
            ¬a!2 →
              ¬a!3 →
                ¬((0 : Int) = C2) = (B2 ≥ (0 : Int)) →
                  ((0 : Int) = W1) = (Q1 ≤ V1) →
                    ¬(0 : Int) = H →
                      ¬(0 : Int) = F2 →
                        K1 = I1 + J1 →
                          J1 = (0 : Int) →
                            I1 = G1 + H1 →
                              H1 = G →
                                G1 = (0 : Int) →
                                  F1 = D1 + E1 →
                                    E1 = (0 : Int) →
                                      D1 = B1 + C1 →
                                        C1 = I →
                                          B1 = (0 : Int) →
                                            Y = W + X →
                                              X = (0 : Int) →
                                                W = U + V →
                                                  V = G →
                                                    U = (0 : Int) →
                                                      S = Q + R →
                                                        R = (0 : Int) →
                                                          Q = O + P →
                                                            P = G →
                                                              O = (0 : Int) →
                                                                N = L + M →
                                                                  M = (0 : Int) →
                                                                    L = J + K →
                                                                      K = I →
                                                                        J = (0 : Int) →
                                                                          C = (1 : Int) →
                                                                            T1 = R1 + S1 →
                                                                              S1 = (0 : Int) →
                                                                                R1 = (0 : Int) →
                                                                                  Q1 = O1 + P1 →
                                                                                    P1 = A →
                                                                                      O1 = M1 + N1 →
                                                                                        N1 = (0 : Int) →
                                                                                          M1 = (0 : Int) →
                                                                                            B2 = Z1 + A2 →
                                                                                              A2 = B →
                                                                                                Z1 = X1 + Y1 →
                                                                                                  Y1 = (0 : Int) →
                                                                                                    X1 = (0 : Int) →
                                                                                                      V1 = T1 + U1 →
                                                                                                        U1 = B →
                                                                                                          ¬a!4 →
                                                                                                            r1 B A I H G F
                                                                                                              E D) ∧
  ((∀ (A B C D E F G H I : Int),
  (r7 B A I H G F E D) →
  (C = (1 : Int)) →
  ((0 : Int) = H) →
  r1 B A I H G F E D) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 U1 V1 W1 X1 Y1 Z1 A2 B2 C2 D2 E2 F2 : Int),
  let a!1 := ((0 : Int) = Z) = (¬(0 : Int) = S ∧ ¬(0 : Int) = Y);
  let a!2 := ((0 : Int) = E2) = (¬(0 : Int) = D2 ∨ ¬(0 : Int) = Z);
  let a!3 := ((0 : Int) = D2) = (¬(0 : Int) = C2 ∧ ¬(0 : Int) = K1);
  let a!4 := ((0 : Int) = C2) = (¬(0 : Int) = V1 ∧ ¬(0 : Int) = B2);
  r7 B A H G F E D C →
    ¬a!1 →
      ¬((0 : Int) = Y) = (X ≥ (0 : Int)) →
        ((0 : Int) = S) = (M ≤ R) →
          ¬a!2 →
            ¬a!3 →
              ¬a!4 →
                ¬((0 : Int) = B2) = (A2 ≥ (0 : Int)) →
                  ((0 : Int) = V1) = (P1 ≤ U1) →
                    ¬(0 : Int) = G →
                      (0 : Int) = E2 →
                        J1 = H1 + I1 →
                          I1 = (0 : Int) →
                            H1 = F1 + G1 →
                              G1 = F →
                                F1 = (0 : Int) →
                                  E1 = C1 + D1 →
                                    D1 = (0 : Int) →
                                      C1 = A1 + B1 →
                                        B1 = H →
                                          A1 = (0 : Int) →
                                            X = V + W →
                                              W = (0 : Int) →
                                                V = T + U →
                                                  U = F →
                                                    T = (0 : Int) →
                                                      R = P + Q →
                                                        Q = (0 : Int) →
                                                          P = N + O →
                                                            O = F →
                                                              N = (0 : Int) →
                                                                M = K + L →
                                                                  L = (0 : Int) →
                                                                    K = I + J →
                                                                      J = H →
                                                                        I = (0 : Int) →
                                                                          L1 = (0 : Int) →
                                                                            T1 = B →
                                                                              S1 = Q1 + R1 →
                                                                                R1 = (0 : Int) →
                                                                                  Q1 = (0 : Int) →
                                                                                    P1 = N1 + O1 →
                                                                                      O1 = A →
                                                                                        N1 = L1 + M1 →
                                                                                          M1 = (0 : Int) →
                                                                                            F2 = (1 : Int) →
                                                                                              A2 = Y1 + Z1 →
                                                                                                Z1 = B →
                                                                                                  Y1 = W1 + X1 →
                                                                                                    X1 = (0 : Int) →
                                                                                                      W1 = (0 : Int) →
                                                                                                        U1 = S1 + T1 →
                                                                                                          ¬((0 : Int) =
                                                                                                                  K1) =
                                                                                                                (E1 ≥
                                                                                                                  J1) →
                                                                                                            r4 F2) ∧
  ((∀ (A B C D E F G H I J K L M N O P v_16 v_17 v_18 v_19 v_20 v_21 v_22 : Int),
  (r6 O N I E J v_16 v_17 v_18 v_19) →
  (r5 K O I E J P v_20 v_21 v_22) →
  (r2 I H G F E D C B) →
  (v_16 = E) →
  (v_17 = I) →
  (v_18 = E) →
  (v_19 = J) →
  (v_20 = I) →
  (v_21 = E) →
  (v_22 = J) →
  (¬((0 : Int) = L) = (E = (0 : Int))) →
  ((0 : Int) = M) →
  ((0 : Int) = L) →
  (A = K) →
  (P = (-1 : Int) + E) →
  (N = (-1 : Int) + I) →
  (J = (1 : Int)) →
  (¬((0 : Int) = M) = (I = (0 : Int))) →
  r5 A I H G F E D C B) ∧
  ((∀ (A B C D E F G H I J K L M N O v_15 v_16 v_17 : Int),
  (r2 I H G F E D C B) →
  (r5 M L I E J K v_15 v_16 v_17) →
  (v_15 = I) →
  (v_16 = E) →
  (v_17 = J) →
  (¬((0 : Int) = N) = (E = (0 : Int))) →
  (¬(0 : Int) = O) →
  ((0 : Int) = N) →
  (A = M) →
  (L = (1 : Int)) →
  (K = (-1 : Int) + E) →
  (J = (1 : Int)) →
  (¬((0 : Int) = O) = (I = (0 : Int))) →
  r5 A I H G F E D C B) ∧
  ((∀ (A B C D E F G H I J K : Int),
  (r2 I H G F E D C B) →
  (¬(0 : Int) = K) →
  (J = (1 : Int)) →
  (A = (1 : Int) + I) →
  (¬((0 : Int) = K) = (E = (0 : Int))) →
  r5 A I H G F E D C B) ∧
  ((∀ (A B C D E F G H I J K L v_12 v_13 v_14 v_15 : Int),
  (r2 H G F E D C B A) →
  (¬((0 : Int) = J) = (D = (0 : Int))) →
  ((0 : Int) = K) →
  ((0 : Int) = J) →
  (L = (-1 : Int) + H) →
  (I = (1 : Int)) →
  (¬((0 : Int) = K) = (H = (0 : Int))) →
  (v_12 = D) →
  (v_13 = H) →
  (v_14 = D) →
  (v_15 = I) →
  r7 L H D I v_12 v_13 v_14 v_15) ∧
  ((∀ (A B C D E F : Int),
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (F = (1 : Int)) →
  r0 A B F E D C) ∧
  (∀ (A : Int),
  (r4 A) →
  (True) →
  False)))))))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«Ackermann04_000»
