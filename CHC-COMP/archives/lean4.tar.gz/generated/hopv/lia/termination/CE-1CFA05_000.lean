import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«hopv».«lia».«termination».«CE-1CFA05_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA05_000.smt2":139:1-139:12 (check-sat, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA05_000.smt2":7:1-17:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA05_000.smt2":18:1-126:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/hopv/lia/termination/CE-1CFA05_000.smt2":127:1-137:2 (clause 3, command 6)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int →
    Int →
      Int →
        Int →
          Int →
            Int →
              Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Prop),
  (∀ (A B C D E F G H I J K L M N O P Q R S T U V W X : Int),
  (r0 W V U T S R Q P O N M L K J I H G F E D C B A) →
  (X = (1 : Int)) →
  (¬(0 : Int) = S) →
  r1 X) ∧
  ((∀ (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z A1 B1 C1 D1 E1 F1 G1 H1 I1 J1 K1 L1 M1 N1 O1 P1 Q1 R1 S1 T1 U1 V1 W1 X1 Y1 Z1 A2 B2 C2 D2 E2 F2 G2 H2 I2 J2 K2 L2 M2 N2 O2 P2 Q2 R2 S2 T2 U2 V2 W2 X2 Y2 : Int),
  (A = (0 : Int)) →
  (H = (0 : Int)) →
  (G = (0 : Int)) →
  (F = (0 : Int)) →
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = (0 : Int)) →
  (X = (0 : Int)) →
  (W = (0 : Int)) →
  (V = (0 : Int)) →
  (U = (0 : Int)) →
  (T = (0 : Int)) →
  (S = (0 : Int)) →
  (R = (0 : Int)) →
  (Q = (0 : Int)) →
  (P = (0 : Int)) →
  (O = (0 : Int)) →
  (N = (0 : Int)) →
  (M = (0 : Int)) →
  (L = (0 : Int)) →
  (K = (0 : Int)) →
  (J = (0 : Int)) →
  (I = (0 : Int)) →
  (I2 = (0 : Int)) →
  (H2 = (0 : Int)) →
  (G2 = (0 : Int)) →
  (F2 = (0 : Int)) →
  (E2 = (0 : Int)) →
  (D2 = (0 : Int)) →
  (C2 = (0 : Int)) →
  (B2 = (0 : Int)) →
  (A2 = (0 : Int)) →
  (Z1 = (0 : Int)) →
  (Y1 = (0 : Int)) →
  (X1 = (0 : Int)) →
  (W1 = (0 : Int)) →
  (V1 = (0 : Int)) →
  (U1 = (0 : Int)) →
  (T1 = (0 : Int)) →
  (S1 = (0 : Int)) →
  (R1 = (0 : Int)) →
  (Q1 = (0 : Int)) →
  (P1 = (0 : Int)) →
  (O1 = (0 : Int)) →
  (N1 = (0 : Int)) →
  (M1 = (0 : Int)) →
  (L1 = (0 : Int)) →
  (K1 = (0 : Int)) →
  (J1 = (0 : Int)) →
  (I1 = (0 : Int)) →
  (H1 = (0 : Int)) →
  (G1 = (0 : Int)) →
  (F1 = (0 : Int)) →
  (E1 = (0 : Int)) →
  (D1 = (0 : Int)) →
  (C1 = (0 : Int)) →
  (B1 = (0 : Int)) →
  (A1 = (0 : Int)) →
  (Z = (0 : Int)) →
  (Y = (0 : Int)) →
  (Y2 = (0 : Int)) →
  (X2 = (0 : Int)) →
  (W2 = (0 : Int)) →
  (V2 = (0 : Int)) →
  (U2 = (0 : Int)) →
  (T2 = (0 : Int)) →
  (S2 = (1 : Int)) →
  (R2 = (0 : Int)) →
  (Q2 = (0 : Int)) →
  (P2 = (0 : Int)) →
  (O2 = (0 : Int)) →
  (N2 = (0 : Int)) →
  (M2 = (0 : Int)) →
  (L2 = (0 : Int)) →
  (K2 = (0 : Int)) →
  (J2 = (0 : Int)) →
  (B = (0 : Int)) →
  r0 S2 R2 Q2 P2 O2 N2 M2 L2 K2 A J2 I2 H2 G2 F2 E2 D2 C2 C B2 A2 Z1 Y1) ∧
  (∀ (A : Int),
  (r1 A) →
  (True) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«hopv».«lia».«termination».«CE-1CFA05_000»
