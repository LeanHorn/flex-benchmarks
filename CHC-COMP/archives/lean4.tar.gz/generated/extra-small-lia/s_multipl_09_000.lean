import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_09_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_09_000.smt2":85:1-85:12 (check-sat, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_09_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_09_000.smt2":18:1-28:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_09_000.smt2":29:1-39:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_09_000.smt2":40:1-50:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_09_000.smt2":51:1-61:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_09_000.smt2":62:1-72:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_09_000.smt2":73:1-83:2 (clause 7, command 11)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  (∀ (A B C : Int),
  (A = (0 : Int)) →
  (¬C ≤ (0 : Int)) →
  (B = (0 : Int)) →
  r1 A B C) ∧
  ((∀ (A B C D E : Int),
  (r1 A B E) →
  (C = (1 : Int) + A) →
  (¬E ≤ B) →
  (D = (1 : Int) + B) →
  r1 C D E) ∧
  ((∀ (A B C D E : Int),
  (r1 B A E) →
  (C = B) →
  (A ≥ E) →
  (D = (0 : Int)) →
  r0 C D E) ∧
  ((∀ (A B C D E : Int),
  (r0 A B E) →
  (C = (1 : Int) + A) →
  (¬E ≤ B) →
  (D = (1 : Int) + B) →
  r0 C D E) ∧
  ((∀ (A B C D E : Int),
  (r0 B A E) →
  (C = B) →
  (A ≥ E) →
  (D = (0 : Int)) →
  r2 C D E) ∧
  ((∀ (A B C D E : Int),
  (r2 A B E) →
  (C = (1 : Int) + A) →
  (¬E ≤ B) →
  (D = (1 : Int) + B) →
  r2 C D E) ∧
  (∀ (A B C : Int),
  (r2 B A C) →
  (¬(3 : Int) * C ≤ B) →
  (A ≥ C) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_09_000»
