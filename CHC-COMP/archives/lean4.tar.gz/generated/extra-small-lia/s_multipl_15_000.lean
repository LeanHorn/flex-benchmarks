import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_15_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_15_000.smt2":64:1-64:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_15_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_15_000.smt2":17:1-28:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_15_000.smt2":29:1-39:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_15_000.smt2":40:1-51:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_15_000.smt2":52:1-62:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  (∀ (A v_1 v_2 v_3 : Int),
  (A ≥ (0 : Int)) →
  (v_1 = A) →
  ((0 : Int) = v_2) →
  ((0 : Int) = v_3) →
  r0 A v_1 v_2 v_3) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := G = C ∧ F = (1 : Int) + B ∨ G = (1 : Int) + C ∧ F = B;
  r0 A E B C → ¬A ≤ (0 : Int) → G = C ∧ F = (1 : Int) + B ∨ G = (1 : Int) + C ∧ F = B → D = (-1 : Int) + A → r0 D E F G) ∧
  ((∀ (A B C D : Int),
  (r0 A B C D) →
  (A = (0 : Int)) →
  r1 B C D) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := F = C ∧ E = (-1 : Int) + B ∨ F = (-1 : Int) + C ∧ E = B;
  r1 A B C → ¬A ≤ (0 : Int) → F = C ∧ E = (-1 : Int) + B ∨ F = (-1 : Int) + C ∧ E = B → D = (-1 : Int) + A → r1 D E F) ∧
  (∀ (A B C : Int),
  (r1 A B C) →
  (¬B ≤ (0 : Int)) →
  (¬C ≤ (0 : Int)) →
  (A = (0 : Int)) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_15_000»
