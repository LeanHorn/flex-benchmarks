import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_11_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_11_000.smt2":62:1-62:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_11_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_11_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_11_000.smt2":28:1-38:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_11_000.smt2":39:1-49:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_11_000.smt2":50:1-60:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  (∀ (A B : Int),
  (¬B ≤ A) →
  r1 A B) ∧
  ((∀ (A B C D : Int),
  (r1 A B) →
  (C = (1000 : Int) + A) →
  (¬B ≤ A) →
  (D = B) →
  r1 C D) ∧
  ((∀ (A B v_2 : Int),
  (r1 A B) →
  (B ≤ A) →
  ((0 : Int) = v_2) →
  r0 v_2 A B) ∧
  ((∀ (A B C D E F : Int),
  (r0 A B C) →
  (F = (2 : Int) + C) →
  (E = B) →
  (¬B ≤ C) →
  (D = (1 : Int) + A) →
  r0 D E F) ∧
  (∀ (A B C : Int),
  (r0 C A B) →
  (¬C ≤ (500 : Int)) →
  (A ≤ B) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_11_000»
