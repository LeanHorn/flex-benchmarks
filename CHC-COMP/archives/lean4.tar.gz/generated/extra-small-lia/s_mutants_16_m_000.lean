import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_mutants_16_m_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_16_m_000.smt2":62:1-62:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_16_m_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_16_m_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_16_m_000.smt2":28:1-38:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_16_m_000.smt2":39:1-49:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_16_m_000.smt2":50:1-60:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  (∀ (A B C : Int),
  (A = (0 : Int)) →
  (¬(5 : Int) ≤ C) →
  (¬C ≤ (0 : Int)) →
  (B = (3 : Int) * C) →
  r0 A B C) ∧
  ((∀ (A B C D E : Int),
  (r0 A B E) →
  (C = (1 : Int) + A) →
  (¬(100 : Int) ≤ A) →
  (D = (1 : Int) + B) →
  r0 C D E) ∧
  ((∀ (A B C : Int),
  (r0 A B C) →
  ((100 : Int) ≤ A) →
  r1 A B C) ∧
  ((∀ (A B C D E : Int),
  (r1 A B E) →
  (C = (1 : Int) + A) →
  (¬(120 : Int) ≤ A) →
  (D = (1 : Int) + B) →
  r1 C D E) ∧
  (∀ (A B C : Int),
  (r1 B C A) →
  (¬C ≤ (132 : Int) ∨ ¬C ≥ (3 : Int)) →
  ((120 : Int) ≤ B) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_mutants_16_m_000»
