import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_18_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_18_000.smt2":66:1-66:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_18_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_18_000.smt2":17:1-29:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_18_000.smt2":30:1-40:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_18_000.smt2":41:1-53:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_18_000.smt2":54:1-64:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  (∀ (A v_1 v_2 : Int),
  (True) →
  ((0 : Int) = v_1) →
  ((0 : Int) = v_2) →
  r0 v_1 v_2 A) ∧
  ((∀ (A B C D E : Int),
  let a!1 := ¬(0 : Int) ≤ A ∧ C = B + E ∧ D = A + (-1 : Int) * E;
  let a!2 := A ≥ (0 : Int) ∧ C = B + (-1 : Int) * E ∧ D = A + E;
  r0 B A E → a!1 ∨ a!2 → r0 C D E) ∧
  ((∀ (A B C D : Int),
  (r0 B C A) →
  (¬C ≤ B) →
  (D = (-1 : Int) * A) →
  r1 B C D) ∧
  ((∀ (A B C D E : Int),
  let a!1 := ¬(0 : Int) ≤ B ∧ C = B + (-1 : Int) * E ∧ D = A + E;
  let a!2 := B ≥ (0 : Int) ∧ C = B + E ∧ D = A + (-1 : Int) * E;
  r1 A B E → a!1 ∨ a!2 → ¬A = B → r1 C D E) ∧
  (∀ (A B C : Int),
  (r1 C B A) →
  (C = B) →
  (¬C = (0 : Int)) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_18_000»
