import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«bouncy_three_counters_merged_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/bouncy_three_counters_merged_000.smt2":41:1-41:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/bouncy_three_counters_merged_000.smt2":6:1-15:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/bouncy_three_counters_merged_000.smt2":16:1-28:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/bouncy_three_counters_merged_000.smt2":29:1-39:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (B = (0 : Int)) →
  (A = C) →
  (A = B) →
  (D = A) →
  r0 A B C D) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 B C A D) →
  (E = B ∧ F = C ∧ G = (1 : Int) + A ∧ H = (1 : Int) + D ∨
    E = B ∧ F = (1 : Int) + C ∧ G = A ∧ H = (-1 : Int) + D ∨ E = (1 : Int) + B ∧ F = C ∧ G = A ∧ H = (1 : Int) + D) →
  r0 E F G H) ∧
  (∀ (A B C D : Int),
  (r0 D A B C) →
  (D = A) →
  (¬C = D) →
  (D = B) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«bouncy_three_counters_merged_000»
