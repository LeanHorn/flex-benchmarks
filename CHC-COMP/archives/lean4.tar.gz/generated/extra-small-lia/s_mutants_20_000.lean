import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_mutants_20_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_20_000.smt2":43:1-43:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_20_000.smt2":6:1-15:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_20_000.smt2":16:1-30:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_20_000.smt2":31:1-41:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E : Int),
  (B = (0 : Int)) →
  (B = C) →
  (A = (100 : Int)) →
  (E = (0 : Int) ∨ E = (1 : Int)) →
  (D = (0 : Int)) →
  r0 A B C D E) ∧
  ((∀ (A B C D E F G H I : Int),
  (r0 E A B D C) →
  (H = (1 : Int) + D) →
  (G = if C = (0 : Int) then B else (1 : Int) + B) →
  (F = if C = (0 : Int) then (1 : Int) + A else A) →
  (¬(2 : Int) * E ≤ D) →
  (I = if C = (0 : Int) then (1 : Int) else (0 : Int)) →
  r0 E F G H I) ∧
  (∀ (A B C D E : Int),
  (r0 B C D E A) →
  (E ≥ (2 : Int) * B) →
  (¬C + D = E) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_mutants_20_000»
