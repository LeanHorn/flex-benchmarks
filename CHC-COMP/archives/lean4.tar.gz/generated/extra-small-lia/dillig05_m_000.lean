import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«dillig05_m_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig05_m_000.smt2":66:1-66:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig05_m_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig05_m_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig05_m_000.smt2":28:1-42:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig05_m_000.smt2":43:1-53:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig05_m_000.smt2":54:1-64:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (C = (0 : Int)) →
  (B = (0 : Int)) →
  (A = (0 : Int)) →
  (D = (0 : Int)) →
  r0 A B C D) ∧
  ((∀ (A B C D : Int),
  (r0 A B C D) →
  (True) →
  r1 A B C D) ∧
  ((∀ (A B C D E F G H I : Int),
  (r1 A B C D) →
  (H = C + F) →
  (G = (1 : Int) + B) →
  (F = (1 : Int) + A) →
  (I = E ∨ I = (1 : Int) + E) →
  (E = D + G) →
  r1 F G H I) ∧
  ((∀ (A B C D : Int),
  (r1 A B C D) →
  (True) →
  r0 A B C D) ∧
  (∀ (A B C D : Int),
  (r0 A B D C) →
  (C ≤ (-1 : Int) + D) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«dillig05_m_000»
