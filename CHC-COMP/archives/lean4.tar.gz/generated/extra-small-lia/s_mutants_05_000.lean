import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_mutants_05_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_05_000.smt2":39:1-39:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_05_000.smt2":6:1-15:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_05_000.smt2":16:1-26:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_05_000.smt2":27:1-37:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  (∀ (A B : Int),
  (¬B ≤ A) →
  (A = (0 : Int)) →
  r0 A B) ∧
  ((∀ (A B C D : Int),
  (r0 A B) →
  (C = (1 : Int) + A) →
  (D = (2 : Int) + B) →
  r0 C D) ∧
  (∀ (A B : Int),
  (r0 A B) →
  (¬A ≤ (1000 : Int)) →
  (B ≤ (2000 : Int)) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_mutants_05_000»
