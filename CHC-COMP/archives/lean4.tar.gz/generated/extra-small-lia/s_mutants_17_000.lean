import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_mutants_17_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_17_000.smt2":39:1-39:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_17_000.smt2":6:1-15:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_17_000.smt2":16:1-26:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_17_000.smt2":27:1-37:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  (∀ (A B C : Int),
  (A = (0 : Int)) →
  (¬(5 : Int) ≤ C) →
  (¬C ≤ (0 : Int)) →
  (B = (3 : Int) * C) →
  r0 A B C) ∧
  ((∀ (A B C D E : Int),
  (r0 A B E) →
  (C = (1 : Int) + A) →
  (¬(1000 : Int) ≤ A) →
  (D = (1 : Int) + B) →
  r0 C D E) ∧
  (∀ (A B C : Int),
  (r0 A C B) →
  (¬C ≤ (1012 : Int) ∨ ¬C ≥ (3 : Int)) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_mutants_17_000»
