import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«dillig02_m_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig02_m_000.smt2":63:1-63:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig02_m_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig02_m_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig02_m_000.smt2":28:1-39:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig02_m_000.smt2":40:1-50:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig02_m_000.smt2":51:1-61:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E F : Int),
  (E = (0 : Int)) →
  (D = (0 : Int)) →
  (C = A + (-1 : Int) * B) →
  (B = (0 : Int)) →
  (A = (1 : Int)) →
  (F = (0 : Int)) →
  r0 A B C D E F) ∧
  ((∀ (A B C D E F : Int),
  (r0 A B C D E F) →
  (True) →
  r1 A B C D E F) ∧
  ((∀ (A B C D E F G H I J : Int),
  let a!1 := H = if G % (2 : Int) = (1 : Int) then (1 : Int) + C else C;
  r1 E F A C B D → I = (1 : Int) + B → a!1 → G = A + C + B + D → J = (2 : Int) + D → r1 E F G H I J) ∧
  ((∀ (A B C D E F : Int),
  (r1 A B C D E F) →
  (True) →
  r0 A B C D E F) ∧
  (∀ (A B C D E F : Int),
  (r0 A B C E F D) →
  (¬E = F) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«dillig02_m_000»
