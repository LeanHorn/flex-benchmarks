import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«dillig22_m_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig22_m_000.smt2":63:1-63:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig22_m_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig22_m_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig22_m_000.smt2":28:1-38:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig22_m_000.smt2":39:1-50:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig22_m_000.smt2":51:1-61:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (C = (0 : Int)) →
  (B = (0 : Int)) →
  (A = (0 : Int)) →
  (D = (0 : Int)) →
  r1 A B C D) ∧
  ((∀ (A B C D E : Int),
  (r1 B C D A) →
  (E = (14 : Int) + A) →
  r1 B C D E) ∧
  ((∀ (A B C D E : Int),
  (r1 B C D A) →
  (E = (2 : Int) + A) →
  r0 B C D E) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := D = if A % (2 : Int) = (0 : Int) then (1 : Int) + B else B;
  r0 B C A G → E = (1 : Int) + C → a!1 → ¬G ≤ C → F = D + E → r0 D E F G) ∧
  (∀ (A B C D : Int),
  (r0 D B A C) →
  (B = C) →
  (¬C = D) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«dillig22_m_000»
