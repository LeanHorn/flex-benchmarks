import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_13_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_13_000.smt2":86:1-86:12 (check-sat, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_13_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_13_000.smt2":18:1-29:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_13_000.smt2":30:1-40:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_13_000.smt2":41:1-51:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_13_000.smt2":52:1-62:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_13_000.smt2":63:1-73:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_13_000.smt2":74:1-84:2 (clause 7, command 11)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  (∀ (A v_1 v_2 v_3 : Int),
  (A ≥ (0 : Int)) →
  (v_1 = A) →
  ((0 : Int) = v_2) →
  ((0 : Int) = v_3) →
  r1 A v_1 v_2 v_3) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := G = C ∧ F = (1 : Int) + B ∨ G = (1 : Int) + C ∧ F = B;
  r1 A E B C → ¬A = (0 : Int) → G = C ∧ F = (1 : Int) + B ∨ G = (1 : Int) + C ∧ F = B → D = (-1 : Int) + A → r1 D E F G) ∧
  ((∀ (A B C D : Int),
  (r1 A B C D) →
  (A = (0 : Int)) →
  r0 B C D) ∧
  ((∀ (A B C D E : Int),
  (r0 B A E) →
  (C = (-1 : Int) + B) →
  (¬A = (0 : Int)) →
  (D = (-1 : Int) + A) →
  r0 C D E) ∧
  ((∀ (A B C : Int),
  (r0 A B C) →
  (B = (0 : Int)) →
  r2 A B C) ∧
  ((∀ (A B C D E : Int),
  (r2 B D A) →
  (¬A = (0 : Int)) →
  (E = (-1 : Int) + A) →
  (C = (-1 : Int) + B) →
  r2 C D E) ∧
  (∀ (A B C : Int),
  (r2 C A B) →
  (¬C = (0 : Int)) →
  (B = (0 : Int)) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_13_000»
