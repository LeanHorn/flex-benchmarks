import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«bouncy_two_counters_merged_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/bouncy_two_counters_merged_000.smt2":40:1-40:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/bouncy_two_counters_merged_000.smt2":6:1-15:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/bouncy_two_counters_merged_000.smt2":16:1-27:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/bouncy_two_counters_merged_000.smt2":28:1-38:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  (∀ (A B C : Int),
  (B = (0 : Int)) →
  (A = (0 : Int)) →
  (C = (0 : Int)) →
  r0 A B C) ∧
  ((∀ (A B C D E F : Int),
  (r0 B A C) →
  (D = B ∧ E = (1 : Int) + A ∧ F = (-1 : Int) + C ∨ D = (1 : Int) + B ∧ E = A ∧ F = (1 : Int) + C) →
  r0 D E F) ∧
  (∀ (A B C : Int),
  (r0 A B C) →
  (A = B) →
  (¬C = (0 : Int)) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«bouncy_two_counters_merged_000»
