import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«yz_plus_minus_2_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/yz_plus_minus_2_000.smt2":43:1-43:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/yz_plus_minus_2_000.smt2":6:1-15:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/yz_plus_minus_2_000.smt2":16:1-30:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/yz_plus_minus_2_000.smt2":31:1-41:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  (∀ (v_0 v_1 v_2 v_3 : Int),
  (True) →
  ((0 : Int) = v_0) →
  ((0 : Int) = v_1) →
  ((0 : Int) = v_2) →
  ((0 : Int) = v_3) →
  r0 v_0 v_1 v_2 v_3) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 A D B C) →
  (G = (-1 : Int) + C) →
  (F = (1 : Int) + B) →
  (E = A + C) →
  (¬(10000 : Int) ≤ A) →
  (H = (1 : Int) + D) →
  r0 E F G H) ∧
  (∀ (A B C D : Int),
  (r0 D A B C) →
  (¬D ≥ (0 : Int)) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«yz_plus_minus_2_000»
