import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_24_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_24_000.smt2":68:1-68:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_24_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_24_000.smt2":17:1-30:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_24_000.smt2":31:1-41:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_24_000.smt2":42:1-55:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_24_000.smt2":56:1-66:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  (∀ (A B C D v_4 : Int),
  (C = (0 : Int)) →
  (B = (0 : Int)) →
  (¬D ≤ (0 : Int)) →
  (D = (1 : Int) + (2 : Int) * A) →
  ((0 : Int) = v_4) →
  r0 B C v_4 D) ∧
  ((∀ (A B C D E F G : Int),
  (r0 A C B G) →
  (E = if B = (0 : Int) then (1 : Int) + C else C) →
  (D = (1 : Int) + A) →
  (¬G ≤ A) →
  (F = if B = (0 : Int) then (1 : Int) else (0 : Int)) →
  r0 D E F G) ∧
  ((∀ (A B C D E F v_6 : Int),
  (r0 A C B F) →
  (D = (0 : Int)) →
  (C ≥ F) →
  (E = C) →
  ((0 : Int) = v_6) →
  r1 D E v_6 F) ∧
  ((∀ (A B C D E F G : Int),
  (r1 A C B G) →
  (E = if B = (1 : Int) then (1 : Int) + C else C) →
  (D = (1 : Int) + A) →
  (¬G ≤ A) →
  (F = if B = (0 : Int) then (1 : Int) else (0 : Int)) →
  r1 D E F G) ∧
  (∀ (A B C D : Int),
  (r1 B D A C) →
  (B ≥ C) →
  (¬C = D) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_24_000»
