import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_14_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_14_000.smt2":111:1-111:12 (check-sat, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_14_000.smt2":9:1-18:2 (clause 1, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_14_000.smt2":19:1-32:2 (clause 2, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_14_000.smt2":33:1-43:2 (clause 3, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_14_000.smt2":44:1-54:2 (clause 4, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_14_000.smt2":55:1-65:2 (clause 5, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_14_000.smt2":66:1-76:2 (clause 6, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_14_000.smt2":77:1-87:2 (clause 7, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_14_000.smt2":88:1-98:2 (clause 8, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_14_000.smt2":99:1-109:2 (clause 9, command 14)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Prop),
  (∀ (A v_1 v_2 v_3 v_4 : Int),
  (A ≥ (0 : Int)) →
  (v_1 = A) →
  ((0 : Int) = v_2) →
  ((0 : Int) = v_3) →
  ((0 : Int) = v_4) →
  r0 A v_1 v_2 v_3 v_4) ∧
  ((∀ (A B C D E F G H I : Int),
  let a!1 := I = D ∧ G = B ∧ H = (1 : Int) + C ∨ I = D ∧ G = (1 : Int) + B ∧ H = C ∨ I = (1 : Int) + D ∧ G = B ∧ H = C;
  r0 A F B C D →
    ¬A = (0 : Int) →
      I = D ∧ G = B ∧ H = (1 : Int) + C ∨ I = D ∧ G = (1 : Int) + B ∧ H = C ∨ I = (1 : Int) + D ∧ G = B ∧ H = C →
        E = (-1 : Int) + A → r0 E F G H I) ∧
  ((∀ (A B C D E : Int),
  (r0 A B C D E) →
  (A = (0 : Int)) →
  r1 B C D E) ∧
  ((∀ (A B C D E F : Int),
  (r1 B A E F) →
  (C = (-1 : Int) + B) →
  (¬A = (0 : Int)) →
  (D = (-1 : Int) + A) →
  r1 C D E F) ∧
  ((∀ (A B C D : Int),
  (r1 A B C D) →
  (B = (0 : Int)) →
  r3 A B C D) ∧
  ((∀ (A B C D E F : Int),
  (r3 B D A F) →
  (C = (-1 : Int) + B) →
  (¬A = (0 : Int)) →
  (E = (-1 : Int) + A) →
  r3 C D E F) ∧
  ((∀ (A B C D : Int),
  (r3 A B C D) →
  (C = (0 : Int)) →
  r2 A B C D) ∧
  ((∀ (A B C D E F : Int),
  (r2 B D E A) →
  (¬A = (0 : Int)) →
  (F = (-1 : Int) + E) →
  (C = (-1 : Int) + B) →
  r2 C D E F) ∧
  (∀ (A B C D : Int),
  (r2 D A B C) →
  (¬D = (0 : Int)) →
  (C = (0 : Int)) →
  False))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_14_000»
