import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«dillig21_m_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig21_m_000.smt2":66:1-66:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig21_m_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig21_m_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig21_m_000.smt2":28:1-38:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig21_m_000.smt2":39:1-53:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig21_m_000.smt2":54:1-64:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  (∀ (v_0 v_1 : Int),
  (True) →
  ((10 : Int) = v_0) →
  ((20 : Int) = v_1) →
  r1 v_0 v_1) ∧
  ((∀ (A B C D : Int),
  (r1 A B) →
  (C = (2 : Int) * A) →
  (D = (2 : Int) * B) →
  r1 C D) ∧
  ((∀ (A B C D E : Int),
  (r1 A B) →
  (C = (0 : Int)) →
  (¬(10 : Int) ≤ E) →
  (¬E ≤ (0 : Int)) →
  (D = (0 : Int)) →
  r0 A B C D E) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r0 F G E A J) →
  (C = B % (2 : Int)) →
  (I = (1 : Int) + A) →
  (H = if D = (0 : Int) then E + F else E + G) →
  (¬J ≤ A) →
  (D = if C = (0 : Int) then (0 : Int) else (1 : Int)) →
  r0 F G H I J) ∧
  (∀ (A B C D E : Int),
  (r0 A B D C E) →
  (D ≤ E) →
  (C ≥ E) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«dillig21_m_000»
