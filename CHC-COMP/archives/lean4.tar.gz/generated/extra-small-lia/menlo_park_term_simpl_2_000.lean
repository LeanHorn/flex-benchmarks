import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«menlo_park_term_simpl_2_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/menlo_park_term_simpl_2_000.smt2":43:1-43:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/menlo_park_term_simpl_2_000.smt2":6:1-15:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/menlo_park_term_simpl_2_000.smt2":16:1-30:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/menlo_park_term_simpl_2_000.smt2":31:1-41:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (C = (1 : Int)) →
  (D ≥ A) →
  (¬B ≤ (1 : Int)) →
  (¬A ≤ (0 : Int)) →
  (B % (2 : Int) = (0 : Int)) →
  r0 A B C D) ∧
  ((∀ (A B C D E F G H : Int),
  (r0 A B C D) →
  (G = (-1 : Int) * C) →
  (F = B + (-1 : Int) * C) →
  (E = A + (-1 : Int) * B) →
  (¬A ≤ (0 : Int)) →
  (H = (-1 : Int) + D) →
  r0 E F G H) ∧
  (∀ (A B C D : Int),
  (r0 C A B D) →
  (¬C ≤ (0 : Int)) →
  (¬(0 : Int) ≤ D) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«menlo_park_term_simpl_2_000»
