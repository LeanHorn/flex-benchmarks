import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«dtuc_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dtuc_000.smt2":62:1-62:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dtuc_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dtuc_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dtuc_000.smt2":28:1-38:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dtuc_000.smt2":39:1-49:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dtuc_000.smt2":50:1-60:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (A = (0 : Int)) →
  (C = (0 : Int)) →
  r0 A B C D) ∧
  ((∀ (A B C D E F : Int),
  (r0 A D B F) →
  (C = (1 : Int) + A) →
  (¬F ≤ A) →
  (E = (1 : Int) + B) →
  r0 C D E F) ∧
  ((∀ (A B C D E : Int),
  (r0 B A D E) →
  (B = E) →
  (C = E) →
  r1 B C D E) ∧
  ((∀ (A B C D E F : Int),
  (r1 C B A F) →
  (D = (-1 : Int) + B) →
  (¬B ≤ (0 : Int)) →
  (E = (-1 : Int) + A) →
  r1 C D E F) ∧
  (∀ (A B C D : Int),
  (r1 A C D B) →
  (¬C ≤ (0 : Int)) →
  (D ≤ (0 : Int)) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«dtuc_000»
