import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«gj2007_m_3_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_3_000.smt2":135:1-135:12 (check-sat, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_3_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_3_000.smt2":20:1-30:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_3_000.smt2":31:1-41:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_3_000.smt2":42:1-53:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_3_000.smt2":54:1-64:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_3_000.smt2":65:1-76:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_3_000.smt2":77:1-87:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_3_000.smt2":88:1-99:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_3_000.smt2":100:1-110:2 (clause 9, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_3_000.smt2":111:1-122:2 (clause 10, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_3_000.smt2":123:1-133:2 (clause 11, command 17)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (B = D) →
  (A = (0 : Int)) →
  (¬D ≤ (0 : Int)) →
  (C = (0 : Int)) →
  r0 A B C D) ∧
  ((∀ (A B C D E F G : Int),
  (r0 A C B G) →
  (E = if G ≤ B then (1 : Int) + C else C) →
  (D = (1 : Int) + A) →
  (¬G ≤ A) →
  (F = (1 : Int) + B) →
  r0 D E F G) ∧
  ((∀ (A B C D : Int),
  (r0 A B C D) →
  (A ≥ D) →
  r4 A B C D) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := E = if (2 : Int) * G ≤ B then (1 : Int) + C else C;
  r4 A C B G → a!1 → D = (1 : Int) + A → ¬(2 : Int) * G ≤ A → F = (1 : Int) + B → r4 D E F G) ∧
  ((∀ (A B C D E : Int),
  (r4 B C D E) →
  (A ≥ (2 : Int) * E) →
  r2 B C D E) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := E = if (3 : Int) * G ≤ B then (1 : Int) + C else C;
  r2 A C B G → a!1 → D = (1 : Int) + A → ¬(3 : Int) * G ≤ A → F = (1 : Int) + B → r2 D E F G) ∧
  ((∀ (A B C D E : Int),
  (r2 B C D E) →
  (A ≥ (3 : Int) * E) →
  r3 B C D E) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := E = if (4 : Int) * G ≤ B then (1 : Int) + C else C;
  r3 A C B G → a!1 → D = (1 : Int) + A → ¬(4 : Int) * G ≤ A → F = (1 : Int) + B → r3 D E F G) ∧
  ((∀ (A B C D E : Int),
  (r3 B C D E) →
  (A ≥ (4 : Int) * E) →
  r1 B C D E) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := E = if (5 : Int) * G ≤ B then (1 : Int) + C else C;
  r1 A C B G → a!1 → D = (1 : Int) + A → ¬(5 : Int) * G ≤ A → F = (1 : Int) + B → r1 D E F G) ∧
  (∀ (A B C D : Int),
  (r1 B C A D) →
  (B ≥ (5 : Int) * D) →
  (¬C = D) →
  False))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«gj2007_m_3_000»
