import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_disj_ite_06_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_disj_ite_06_000.smt2":39:1-39:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_disj_ite_06_000.smt2":6:1-15:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_disj_ite_06_000.smt2":16:1-26:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_disj_ite_06_000.smt2":27:1-37:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  (∀ (A B : Int),
  (A = (0 : Int)) →
  (B = (50 : Int)) →
  r0 A B) ∧
  ((∀ (A B C D : Int),
  (r0 A B) →
  (C = (1 : Int) + A) →
  (¬(100 : Int) ≤ A) →
  (if C ≤ (50 : Int) then D = B else D = (1 : Int) + B) →
  r0 C D) ∧
  (∀ (A B : Int),
  (r0 B A) →
  (¬B ≤ (50 : Int)) →
  (¬A = B) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_disj_ite_06_000»
