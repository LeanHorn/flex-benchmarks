import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_17_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_17_000.smt2":63:1-63:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_17_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_17_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_17_000.smt2":28:1-39:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_17_000.smt2":40:1-50:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_17_000.smt2":51:1-61:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  (∀ (A : Int),
  (A = (3138 : Int)) →
  r0 A) ∧
  ((∀ (A B C : Int),
  (r0 A) →
  (C = (0 : Int)) →
  (B = A) →
  r1 B C) ∧
  ((∀ (A B C D : Int),
  let a!1 := A ≤ (0 : Int) ∨ ¬A % (3 : Int) = (0 : Int);
  r1 B A → D = (2 : Int) + A → A ≤ (0 : Int) ∨ ¬A % (3 : Int) = (0 : Int) → C = B → r1 C D) ∧
  ((∀ (A B C : Int),
  (r1 A B) →
  (C = A + B) →
  (¬B ≤ (0 : Int)) →
  (B % (3 : Int) = (0 : Int)) →
  r0 C) ∧
  (∀ (A : Int),
  (r0 A) →
  (¬A % (6 : Int) = (0 : Int)) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_17_000»
