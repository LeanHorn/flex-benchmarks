import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«three_dots_moving_2_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/three_dots_moving_2_000.smt2":44:1-44:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/three_dots_moving_2_000.smt2":6:1-18:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/three_dots_moving_2_000.smt2":19:1-31:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/three_dots_moving_2_000.smt2":32:1-42:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (D ≥ B + (-1 : Int) * C) →
  (D ≥ B + (-1 : Int) * A) →
  (¬B ≤ A) →
  (D ≥ C + (-2 : Int) * A + B) →
  r0 A B C D) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := (D = if B ≤ F then (1 : Int) + B else (-1 : Int) + B) ∧ E = D ∧ B = C;
  let a!2 := D = B ∧ E = (-1 : Int) + C ∧ ¬B = C ∨ a!1;
  r0 B C F A → G = (-1 : Int) + A → D = B ∧ E = (-1 : Int) + C ∧ ¬B = C ∨ a!1 → ¬C = F → r0 D E F G) ∧
  (∀ (A B C D : Int),
  (r0 A B C D) →
  (D ≤ (0 : Int)) →
  (¬B = C) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«three_dots_moving_2_000»
