import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_mutants_22_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_22_000.smt2":41:1-41:12 (check-sat, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_22_000.smt2":6:1-15:2 (clause 1, command 3)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_22_000.smt2":16:1-28:2 (clause 2, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_mutants_22_000.smt2":29:1-39:2 (clause 3, command 5)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (C = (0 : Int)) →
  (B = (0 : Int)) →
  (D = (2 : Int) * A) →
  r0 B C D) ∧
  ((∀ (A B C D E F : Int),
  let a!1 := D = (1 : Int) + A ∧ E = (1 : Int) + B ∨ D = (-1 : Int) + A ∧ E = (-1 : Int) + B;
  r0 A B C → D = (1 : Int) + A ∧ E = (1 : Int) + B ∨ D = (-1 : Int) + A ∧ E = (-1 : Int) + B → F = C + D + E → r0 D E F) ∧
  (∀ (A B C : Int),
  (r0 A B C) →
  (C = (77 : Int)) →
  False))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_mutants_22_000»
