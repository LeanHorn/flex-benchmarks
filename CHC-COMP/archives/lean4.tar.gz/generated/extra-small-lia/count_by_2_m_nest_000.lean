import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«count_by_2_m_nest_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/count_by_2_m_nest_000.smt2":62:1-62:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/count_by_2_m_nest_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/count_by_2_m_nest_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/count_by_2_m_nest_000.smt2":28:1-38:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/count_by_2_m_nest_000.smt2":39:1-49:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/count_by_2_m_nest_000.smt2":50:1-60:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Prop),
  ∃ (r1 : Int → Int → Prop),
  (∀ (v_0 : Int),
  (True) →
  ((0 : Int) = v_0) →
  r0 v_0) ∧
  ((∀ (A v_1 : Int),
  (r0 A) →
  (¬(256 : Int) ≤ A) →
  ((0 : Int) = v_1) →
  r1 A v_1) ∧
  ((∀ (A B C : Int),
  (r1 B A) →
  (¬(16 : Int) ≤ A) →
  (C = (2 : Int) + A) →
  r1 B C) ∧
  ((∀ (A B C : Int),
  (r1 A B) →
  (B ≥ (16 : Int)) →
  (C = A + B) →
  r0 C) ∧
  (∀ (A : Int),
  (r0 A) →
  (A ≥ (256 : Int)) →
  (¬A = (256 : Int)) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«count_by_2_m_nest_000»
