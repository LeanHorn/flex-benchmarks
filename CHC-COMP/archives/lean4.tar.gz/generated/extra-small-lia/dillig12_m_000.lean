import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«dillig12_m_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig12_m_000.smt2":67:1-67:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig12_m_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig12_m_000.smt2":17:1-31:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig12_m_000.smt2":32:1-43:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig12_m_000.smt2":44:1-54:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/dillig12_m_000.smt2":55:1-65:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Int → Prop),
  (∀ (A B C D E : Int),
  (C = (0 : Int)) →
  (B = (0 : Int)) →
  (A = (0 : Int)) →
  (D = (0 : Int)) →
  r1 A B C D E) ∧
  ((∀ (A B C D E F G H I J : Int),
  (r1 A B C D J) →
  (I = if J = (1 : Int) then E + F else E) →
  (H = C + F) →
  (G = (1 : Int) + B) →
  (F = (1 : Int) + A) →
  (E = D + G) →
  r1 F G H I J) ∧
  ((∀ (A B C D E F G : Int),
  let a!1 := F = if C = (1 : Int) then (2 : Int) + D + (-2 : Int) * E else (1 : Int);
  r1 A B E D C → a!1 → G = (0 : Int) → r0 F G) ∧
  ((∀ (A B C : Int),
  (r0 B A) →
  (C = (1 : Int) + A ∨ C = (2 : Int) + A) →
  (A ≤ B) →
  r0 B C) ∧
  (∀ (A B : Int),
  (r0 A B) →
  (B ≥ A) →
  (B ≥ (5 : Int)) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«dillig12_m_000»
