import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«gj2007_m_2_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_2_000.smt2":136:1-136:12 (check-sat, command 18)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_2_000.smt2":10:1-19:2 (clause 1, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_2_000.smt2":20:1-31:2 (clause 2, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_2_000.smt2":32:1-42:2 (clause 3, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_2_000.smt2":43:1-54:2 (clause 4, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_2_000.smt2":55:1-65:2 (clause 5, command 11)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_2_000.smt2":66:1-77:2 (clause 6, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_2_000.smt2":78:1-88:2 (clause 7, command 13)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_2_000.smt2":89:1-100:2 (clause 8, command 14)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_2_000.smt2":101:1-111:2 (clause 9, command 15)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_2_000.smt2":112:1-123:2 (clause 10, command 16)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/gj2007_m_2_000.smt2":124:1-134:2 (clause 11, command 17)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  ∃ (r3 : Int → Int → Int → Prop),
  ∃ (r4 : Int → Int → Int → Prop),
  (∀ (A B C : Int),
  (A = (0 : Int)) →
  (¬C ≤ (0 : Int)) →
  (B = (2 : Int) * C) →
  r2 A B C) ∧
  ((∀ (A B C D E : Int),
  let a!1 := D = if (2 : Int) * E ≤ A then (1 : Int) + B else B;
  r2 A B E → C = (1 : Int) + A → ¬E ≤ A → a!1 → r2 C D E) ∧
  ((∀ (A B C : Int),
  (r2 A B C) →
  (A ≥ C) →
  r4 A B C) ∧
  ((∀ (A B C D E : Int),
  let a!1 := D = if (2 : Int) * E ≤ A then (1 : Int) + B else B;
  r4 A B E → C = (1 : Int) + A → ¬(2 : Int) * E ≤ A → a!1 → r4 C D E) ∧
  ((∀ (A B C D : Int),
  (r4 B C D) →
  (A ≥ (2 : Int) * D) →
  r1 B C D) ∧
  ((∀ (A B C D E : Int),
  let a!1 := D = if (2 : Int) * E ≤ A then (1 : Int) + B else B;
  r1 A B E → C = (1 : Int) + A → ¬(3 : Int) * E ≤ A → a!1 → r1 C D E) ∧
  ((∀ (A B C D : Int),
  (r1 B C D) →
  (A ≥ (3 : Int) * D) →
  r3 B C D) ∧
  ((∀ (A B C D E : Int),
  let a!1 := D = if (2 : Int) * E ≤ A then (1 : Int) + B else B;
  r3 A B E → C = (1 : Int) + A → ¬(4 : Int) * E ≤ A → a!1 → r3 C D E) ∧
  ((∀ (A B C D : Int),
  (r3 B C D) →
  (A ≥ (4 : Int) * D) →
  r0 B C D) ∧
  ((∀ (A B C D E : Int),
  let a!1 := D = if (2 : Int) * E ≤ A then (1 : Int) + B else B;
  r0 A B E → C = (1 : Int) + A → ¬(5 : Int) * E ≤ A → a!1 → r0 C D E) ∧
  (∀ (A B C : Int),
  (r0 A B C) →
  (A ≥ (5 : Int) * C) →
  (¬B = (5 : Int) * C) →
  False))))))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«gj2007_m_2_000»
