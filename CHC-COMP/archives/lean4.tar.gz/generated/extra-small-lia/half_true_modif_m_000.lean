import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«half_true_modif_m_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/half_true_modif_m_000.smt2":65:1-65:12 (check-sat, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/half_true_modif_m_000.smt2":7:1-16:2 (clause 1, command 4)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/half_true_modif_m_000.smt2":17:1-27:2 (clause 2, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/half_true_modif_m_000.smt2":28:1-38:2 (clause 3, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/half_true_modif_m_000.smt2":39:1-52:2 (clause 4, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/half_true_modif_m_000.smt2":53:1-63:2 (clause 5, command 8)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Int → Prop),
  (∀ (A B C D : Int),
  (C = (0 : Int)) →
  (A = (0 : Int)) →
  (B ≥ (0 : Int)) →
  (D = (0 : Int)) →
  r1 A B C D) ∧
  ((∀ (A B C D E : Int),
  (r1 B A D E) →
  (C = (1 : Int) + A) →
  r1 B C D E) ∧
  ((∀ (A B C D E : Int),
  (r1 B A D E) →
  (C = (52 : Int) + A) →
  r0 B C D E) ∧
  ((∀ (A B C D E F G : Int),
  (r0 B E A C) →
  (F = if C = (0 : Int) then (1 : Int) + A else A) →
  (D = (1 : Int) + B) →
  (¬(2 : Int) * E ≤ B) →
  (G = if C = (0 : Int) then (1 : Int) else (0 : Int)) →
  r0 D E F G) ∧
  (∀ (A B C D : Int),
  (r0 B D C A) →
  (B ≥ (2 : Int) * D) →
  (¬C = D) →
  False))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«half_true_modif_m_000»
