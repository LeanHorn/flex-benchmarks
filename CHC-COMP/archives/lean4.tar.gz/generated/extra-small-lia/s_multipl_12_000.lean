import Init

set_option maxRecDepth 4096

namespace «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_12_000»

-- Statements

section
set_option Elab.async false

-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_12_000.smt2":85:1-85:12 (check-sat, command 12)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_12_000.smt2":8:1-17:2 (clause 1, command 5)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_12_000.smt2":18:1-28:2 (clause 2, command 6)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_12_000.smt2":29:1-39:2 (clause 3, command 7)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_12_000.smt2":40:1-50:2 (clause 4, command 8)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_12_000.smt2":51:1-61:2 (clause 5, command 9)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_12_000.smt2":62:1-72:2 (clause 6, command 10)
-- Source: "/Users/jamkabeeralikhan/Documents/Programming/Flex/evaluation/CHC-COMP/sources/extra-small-lia/s_multipl_12_000.smt2":73:1-83:2 (clause 7, command 11)
/-- There are interpretations of the declared symbols satisfying every Horn clause. -/
def Problem : Prop :=
  ∃ (r0 : Int → Int → Int → Prop),
  ∃ (r1 : Int → Int → Int → Prop),
  ∃ (r2 : Int → Int → Int → Prop),
  (∀ (A v_1 v_2 : Int),
  (¬A ≤ (0 : Int)) →
  ((0 : Int) = v_1) →
  ((0 : Int) = v_2) →
  r0 A v_1 v_2) ∧
  ((∀ (A B C D : Int),
  (r0 A C D) →
  (¬A ≤ (0 : Int)) →
  (B = (-1 : Int) + A) →
  r1 B C D) ∧
  ((∀ (A B C D E : Int),
  (r1 C A B) →
  (E = (-1 : Int) + B) →
  (¬C ≤ A) →
  (D = (1 : Int) + A) →
  r1 C D E) ∧
  ((∀ (A B C : Int),
  (r1 A B C) →
  (A ≤ B) →
  r2 A B C) ∧
  ((∀ (A B C D E : Int),
  (r2 C A B) →
  (E = (1 : Int) + B) →
  (¬C ≤ B) →
  (D = (-1 : Int) + A) →
  r2 C D E) ∧
  ((∀ (A B C : Int),
  (r2 A B C) →
  (A ≤ C) →
  r0 A B C) ∧
  (∀ (A B C : Int),
  (r0 A B C) →
  (A = (0 : Int)) →
  (¬B = C) →
  False))))))

end

-- Proofs

-- Unfinished proof: replace sorry to establish the existence of a satisfying interpretation.
theorem problem : Problem := by
  sorry

end «Smt2Lean».«Generated».«extra-small-lia».«s_multipl_12_000»
